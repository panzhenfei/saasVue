function creat(){
var html=''
html+='<div class="jump"></div>'
}

/**
 *================================================= ======================
 *镞ユ湡阃夋嫨鍣╦s缁勪欢銆 
 *@author 锛歫ohnnyzheng(johnnyzheng@tencent.com) 閮戠伩鍙 
 *@version 锛  2012-07-11
 *@modification list锛 2012-08-16 瑙勮浸镙峰纺钖岖О
 * 2013-01-04 澧炲姞涓婚璁剧疆鎺ュ彛
 * 2013-01-31 澧炲姞镊畾涔夌伆鎺夊懆链  锻ㄥ嚑镄勯€夐」锛屽锷犺嚜锷ㄥ垵濮嫔寲镊姩鎻愪氦镄勫姛鑳  
 * 2013-03-15 鏀寔涓€涓〉闱㈠涓棩链熼€夋嫨鍣纴蹇嵎镞ユ湡阃夋嫨
 * 2013-03-26 澧炲姞纭銆佸彇娑堟寜阍殑闅愯棌锛岃€岀洿鎺ヨ嚜锷ㄦ彁浜 
 * 2013-08-01 镓╁睍鎺ュ彛锛屽锷犳渶杩 90澶╋纴澧炲姞镊畾涔夊彲阃夋椂闂 
 * 2013-08-12 镞ユ湡阃夋嫨鍣ㄦ浣揿搴﹁秴鍑鸿绐楀ぇ灏忕殑镞跺€椤埗锷ㄩ紦闱犲彸瀵归绨
 * 2014-02-25 澧炲姞涓氩姟鎺ュ彛锛氲幏鍙栧綋鍓嶆棩链熷璞＄殑镄勯€変腑镞ユ湡
 * 2014-10-13 镓╁睍鍙傛暟锛屾敮鎸佹棩链熶笅鎷夐€夋嫨镊畾涔夊勾鍜屾湀浠斤纴閰嶅悎theme:ta鏉ヤ娇鐢ㄣ€  
 *================================================= ======================
*/
	/**
 	* @description 鏁翠釜镞ユ湡阃夋嫨鍣ㄥ璞＄殑鏋勯€犲嚱鏁板叆鍙ｏ纴鏀寔涓板瘜镄勬帴鍙ｅ弬鏁颁紶阃掞纴澶у鏁版彁渚涢粯璁ら历缃纴鍙紶鍏ヨ鐩 
 	* @param {String} inputId 镞ユ湡阃夋嫨鍣↖D
 	* @param {object} options 閰岖疆鏁扮粍
 	*/
	function pickerDateRange(inputId, options) {
    /**
     * 榛樿閰岖疆鍙傛暟鏁版嵁锛屾疮涓弬鏁版兜涔夊湪钖庤В阅 
     */
    var defaults = {
		aToday : 'aToday', //浠婂ぉ
		aYesterday : 'aYesterday', //鏄ㄥぉ
		aRecent7Days : 'aRecent7Days', //链€杩 7澶 
		aRecent14Days : 'aRecent14Days',//链€杩 14澶 
		aRecent30Days : 'aRecent30Days', //链€杩 30澶 
		aRecent90Days : 'aRecent90Days', //链€杩 90澶 
        startDate : '', // 寮€濮嬫棩链 
        endDate : '', // 缁撴潫镞ユ湡
        startCompareDate : '', // 瀵规瘮寮€濮嬫棩链 
        endCompareDate : '', // 瀵规瘮缁撴潫镞ユ湡
	    minValidDate : '315507600', //链€灏忓彲鐢ㄦ椂闂达纴鎺у埗镞ユ湡阃夋嫨鍣ㄧ殑鍙€夊姏搴 
        maxValidDate : '', // 链€澶у彲鐢ㄦ椂闂达纴涓巗topToday 閰岖疆浜掓枼
        success : function(obj) {return true;}, //锲炶皟鍑芥暟锛岄€夋嫨镞ユ湡涔嫔悗镓ц浣旷鎿崭綔
        startDateId : 'startDate', // 寮€濮嬫棩链熻緭鍏ユID
        startCompareDateId : 'startCompareDate', // 瀵规瘮寮€濮嬫棩链熻緭鍏ユID
        endDateId : 'endDate', // 缁撴潫镞ユ湡杈揿叆妗咺D
        endCompareDateId : 'endCompareDate', // 瀵规瘮缁撴潫镞ユ湡杈揿叆妗咺D
        target : '', // 镞ユ湡阃夋嫨妗嗙殑鐩爣锛屼竴鑸负<form> 镄处D链 
        needCompare : false, // 鏄惁暗€瑕佽繘琛屾棩链熷姣 
		suffix : '', //鐩稿簲鎺т欢镄勫悗缂€
		inputTrigger : 'input_trigger',
		compareTrigger : 'compare_trigger',
        compareCheckboxId : 'needCompare', // 姣旇缉阃夋嫨妗 
        calendars : 1, // 灞旷ず镄勬湀浠芥暟锛屾渶澶ф槸2
        dayRangeMax : 0, // 镞ユ湡链€澶ц浸锲 (浠ュぉ璁＄畻)
        monthRangeMax : 12, // 镞ユ湡链€澶ц浸锲 (浠ユ湀璁＄畻)
        dateTable : 'dateRangeDateTable', // 镞ユ湡琛ㄦ牸镄凛SS绫 
        selectCss : 'dateRangeSelected', // 镞堕棿阃夋嫨镄勬牱寮 
        compareCss : 'dateRangeCompare', // 姣旇缉镞堕棿阃夋嫨镄勬牱寮 
        coincideCss : 'dateRangeCoincide', // 阅嶅悎閮ㄥ垎镄勬牱寮 
		firstCss : 'first', //璧峰镙峰纺
		lastCss : 'last', //缁撴潫镙峰纺
		clickCss : 'today', //镣瑰向镙峰纺
        disableGray : 'dateRangeGray', // 闱炲綋鍓嶆湀镄勬棩链熸牱寮 
        isToday : 'dateRangeToday', // 浠婂ぉ镞ユ湡镄勬牱寮 
        joinLineId : 'joinLine',
        isSingleDay : false,
        defaultText : ' 镊  ',
        singleCompare : false,
        stopToday : true,
        isTodayValid : false,
		weekendDis : false, //鐏版帀锻ㄦ汤涓嶅彲阃夈€ 
		disCertainDay : [], //涓嶅彲鐢ㄧ殑锻ㄦ棩链熻缃暟缁勶纴濡傦细[1,3]鏄锻ㄤ竴锛  锻ㄤ笁涓ゅぉ涓嶅彲阃夛纴姣忎釜锻ㄧ殑锻ㄤ竴锛屽懆涓夐兘涓嶅彲阃夋嫨銆 
        disCertainDate : [],//涓嶅彲鐢ㄧ殑镞ユ湡璁剧疆鏁扮粍锛屽:[1,3]鏄1鍙凤纴3鍙  涓ゅぉ涓嶅彲阃夛纴鐗瑰埆镄勶纴[true,1,3]鍒椤弽涔嬶纴鍙湁1锛 3鍙€夛纴鍏朵捆涓嶅彲阃夈€ 
		shortOpr : false, //缁揿悎鍗曞ぉ镞ユ湡阃夋嫨镄勭煭鎿崭綔锛屼笉暗€瑕佺'瀹氩拰鍙栨秷镄勬搷浣沧寜阍€ 
		noCalendar : false, //镞ユ湡杈揿叆妗嗘槸钖﹀睍绀 
		theme : 'gri', //镞ユ湡阃夋嫨鍣ㄧ殑涓婚锛岀洰鍓嶆敮鎸  'gri' / 'ta'
		magicSelect : false, //鐢ㄦ埛镊畾涔夐€夋嫨骞淬€佹湀锛屼笌{theme:ta}閰嶅悎浣跨敤銆 
		autoCommit : false, //锷犺浇钖庣珛椹嚜锷ㄦ彁浜 
		autoSubmit : false, //娌℃湁纭畾锛屽彇娑堟寜阍纴鐩存帴鎻愪氦 
		replaceBtn : 'btn_compare'
    };
    //灏嗗璞¤祴缁檩_method鍙橀噺
    var __method = this;
	
    this.inputId = inputId;
	this.inputCompareId = inputId + 'Compare';
	this.compareInputDiv = 'div_compare_'+inputId;
    // 閰岖疆鍙傛暟
    this.mOpts = $.extend({}, defaults, options);
	//榛樿镞ュ巻鍙傛暟链€澶ф槸3
	this.mOpts.calendars = Math.min(this.mOpts.calendars, 3);
	//镙规嵁涓嶅悓涓婚暗€瑕佸垵濮嫔寲镄勫彉阅 
	this.mOpts.compareCss = this.mOpts.theme == 'ta' ? this.mOpts.selectCss :this.mOpts.compareCss
    //鏄ㄥぉ,浠婂ぉ,链€杩 7澶 ,链€杩 14澶 ,链€杩 30澶	
	this.periodObj = {};
	this.periodObj[__method.mOpts.aToday] = 0;
	this.periodObj[__method.mOpts.aYesterday] = 1;
	this.periodObj[__method.mOpts.aRecent7Days] = 6;
	this.periodObj[__method.mOpts.aRecent14Days] = 13;
	this.periodObj[__method.mOpts.aRecent30Days] = 29;
	this.periodObj[__method.mOpts.aRecent90Days] = 89;
    // 璁板綍鍒濆榛樿镞堕棿
    this.startDefDate = '';
    // 闅忔満ID钖庣紑
    var suffix = '' == this.mOpts.suffix ? (new Date()).getTime() : this.mOpts.suffix;
    // 镞ユ湡阃夋嫨妗咲IV镄处D
    this.calendarId = 'calendar_' + suffix;
    // 镞ユ湡鍒楄〃DIV镄处D
    this.dateListId = 'dateRangePicker_' + suffix;
    // 镞ユ湡姣旇缉灞 
    this.dateRangeCompareDiv = 'dateRangeCompareDiv_' + suffix;
	//镞ユ湡阃夋嫨灞 
	this.dateRangeDiv = 'dateRangeDiv_' + suffix;
    // 镞ユ湡瀵规瘮阃夋嫨鎺у埗镄刢heckbox
    this.compareCheckBoxDiv = 'dateRangeCompareCheckBoxDiv_' + suffix;
    // 镞堕棿阃夋嫨镄勭'璁ゆ寜阍 
    this.submitBtn = 'submit_' + suffix;
    // 镞ユ湡阃夋嫨妗嗗叧闂寜阍 
    this.closeBtn = 'closeBtn_' + suffix;
    // 涓娄竴涓湀镄勬寜阍 
    this.preMonth = 'dateRangePreMonth_' + suffix;
    // 涓嬩竴涓湀镄勬寜阍 
    this.nextMonth = 'dateRangeNextMonth_' + suffix;
    // 琛ㄥ崟涓紑濮嬨€佺粨鏉熴€佸紑濮嫔姣斻€佺粨鏉熷姣旀椂闂 
    this.startDateId = this.mOpts.startDateId + '_' + suffix;
    this.endDateId = this.mOpts.endDateId + '_' + suffix;
    this.compareCheckboxId = this.mOpts.compareCheckboxId + '_' + suffix;
    this.startCompareDateId = this.mOpts.startCompareDateId + '_' + suffix;
    this.endCompareDateId = this.mOpts.endCompareDateId + '_' + suffix;
    // 鍒濆鍖栨棩链熼€夋嫨鍣ㄩ溃鏉跨殑HTML浠ｇ爜涓 
    var wrapper = {
		gri :[
			'<div id="' + this.calendarId + '" class="gri_dateRangeCalendar">',
				'<table class="gri_dateRangePicker"><tr id="' + this.dateListId + '"></tr></table>',
				'<div class="gri_dateRangeOptions" '+ (this.mOpts.autoSubmit ? ' style="display:none" ' : '') +'>',
					'<div class="gri_dateRangeInput" id="' + this.dateRangeDiv + '" >',
						'<input type="text" class="gri_dateRangeInput" name="' + this.startDateId + '" id="' + this.startDateId + '" value="' + this.mOpts.startDate + '" readonly / >',
						'<span id="' + this.mOpts.joinLineId + '"> - </span>',
						'<input type="text" class="gri_dateRangeInput" name="' + this.endDateId + '" id="' + this.endDateId + '" value="' + this.mOpts.endDate + '" readonly / ><br />',
					'</div>',
					'<div class="gri_dateRangeInput" id="' + this.dateRangeCompareDiv + '">',
						'<input type="text" class="gri_dateRangeInput" name="' + this.startCompareDateId + '" id="' + this.startCompareDateId + '" value="' + this.mOpts.startCompareDate + '" readonly / >',
						'<span class="' + this.mOpts.joinLineId + '"> - </span>',
						'<input type="text" class="gri_dateRangeInput" name="' + this.endCompareDateId + '" id="' + this.endCompareDateId + '" value="' + this.mOpts.endCompareDate + '" readonly / >',
					'</div>',
					'<div>',
						'<input type="button" name="' + this.submitBtn + '" id="' + this.submitBtn + '" value="纭畾" />',
						' <a id="' + this.closeBtn + '" href="javascript:;">鍏抽棴</a>',
					'</div>',
				'</div>',
			'</div>'
		],
		ta:[
			'<div id="' + this.calendarId + '" class="ta_calendar ta_calendar2 cf">',
				'<div class="ta_calendar_cont cf" id="'+ this.dateListId +'">',
					//'<table class="dateRangePicker"><tr id="' + this.dateListId + '"></tr></table>',
				'</div>',
				'<div class="ta_calendar_footer cf" '+ (this.mOpts.autoSubmit ? ' style="display:none" ' : '') +'>',
					'<div class="frm_msg">',
						'<div id="' + this.dateRangeDiv + '">',
							'<input type="text" class="ta_ipt_text_s" name="' + this.startDateId + '" id="' + this.startDateId + '" value="' + this.mOpts.startDate + '" readonly / >',
							'<span class="' + this.mOpts.joinLineId + '"> - </span>',
							'<input type="text" class="ta_ipt_text_s" name="' + this.endDateId + '" id="' + this.endDateId + '" value="' + this.mOpts.endDate + '" readonly / ><br />',
						'</div>',
						'<div id="' + this.dateRangeCompareDiv + '">',
							'<input type="text" class="ta_ipt_text_s" name="' + this.startCompareDateId + '" id="' + this.startCompareDateId + '" value="' + this.mOpts.startCompareDate + '" readonly / >',
							'<span class="' + this.mOpts.joinLineId + '"> - </span>',
							'<input type="text" class="ta_ipt_text_s" name="' + this.endCompareDateId + '" id="' + this.endCompareDateId + '" value="' + this.mOpts.endCompareDate + '" readonly / >',
						'</div>',
					'</div>',
					'<div class="frm_btn">',
						'<input class="ta_btn ta_btn_primary" type="button" name="' + this.submitBtn + '" id="' + this.submitBtn + '" value="纭畾" />',
						'<input class="ta_btn" type="button" id="' + this.closeBtn + '" value="鍙栨秷"/>',
					'</div>',
				'</div>',
			'</div>'
		]
	};
	
	
	//瀵规瘮镞ユ湡妗嗕綋镄删tml涓 
	var checkBoxWrapper = {
	gri:[
		'<label class="gri_contrast" for ="' + this.compareCheckboxId + '">',
            '<input type="checkbox" class="gri_pc" name="' + this.compareCheckboxId + '" id="' + this.compareCheckboxId + '" value="1"/>瀵规瘮',
        '</label>',
		'<input type="text" name="'+this.inputCompareId+'" id="'+this.inputCompareId+'" value="" class="gri_date"/>'
	],
	ta:[
		'<label class="contrast" for ="' + this.compareCheckboxId + '">',
            '<input type="checkbox" class="pc" name="' + this.compareCheckboxId + '" id="' + this.compareCheckboxId + '" value="1"/>瀵规瘮',
        '</label>',
		'<div class="ta_date" id="'+this.compareInputDiv+'">',
		' <span name="dateCompare" id="'+this.inputCompareId+'" class="date_title"></span>',
		' <a class="opt_sel" id="'+ this.mOpts.compareTrigger +'" href="#">',
        ' <i class="i_orderd"></i>',
        ' </a>',
		'</div>'
	]
	};
	//鎶奵heckbox鏀惧埌椤甸溃镄勭浉搴斾綅缃 ,鏀剧疆鍒癷nputid钖庨溃added by johnnyzheng
	
	if(this.mOpts.theme == 'ta'){
		$(checkBoxWrapper[this.mOpts.theme].join('')).insertAfter($('#div_' + this.inputId));
	}else{
		$(checkBoxWrapper[this.mOpts.theme].join('')).insertAfter($('#' + this.inputId));
	}
	//镙规嵁浼犲叆鍙傛暟鍐冲畾鏄惁灞旷ず镞ユ湡杈揿叆妗 
	if(this.mOpts.noCalendar){
		$('#' + this.inputId).css('display', 'none');
		$('#' + this.compareCheckboxId).parent().css('display','none');
	}
    // 鎶婃椂闂撮€夋嫨妗嗘斁鍒伴〉闱腑
    $(0 < $('#appendParent').length ? '#appendParent' : document.body).append(wrapper[this.mOpts.theme].join(''));
    $('#' + this.calendarId).css('z-index', 9999);
    // 鍒濆鍖栫洰镙囧湴鍧€镄勫崖绱 
    if(1 > $('#' + this.mOpts.startDateId).length) {
        $(''!=this.mOpts.target?'#'+this.mOpts.target:'body').append('<input type="hidden" id="' + this.mOpts.startDateId + '" name="' + this.mOpts.startDateId + '" value="' + this.mOpts.startDate + '" />');
    } else {
        $('#' + this.mOpts.startDateId).val(this.mOpts.startDate);
    }
    if(1 > $('#' + this.mOpts.endDateId).length) {
        $(''!=this.mOpts.target?'#'+this.mOpts.target:'body').append('<input type="hidden" id="' + this.mOpts.endDateId + '" name="' + this.mOpts.endDateId + '" value="' + this.mOpts.endDate + '" />');
    } else {
        $('#' + this.mOpts.endDateId).val(this.mOpts.endDate);
    }
    if(1 > $('#' + this.mOpts.compareCheckboxId).length) {
        $(''!=this.mOpts.target?'#'+this.mOpts.target:'body').append('<input type="checkbox" id="' + this.mOpts.compareCheckboxId + '" name="' + this.mOpts.compareCheckboxId + '" value="0" style="display:none;" />');
    }
    // 濡傛灉涓嶉渶瑕佹瘮杈冩棩链燂纴鍒欓渶瑕侀殣钘忔瘮杈冮儴鍒嗙殑鍐呭
    if(false == this.mOpts.needCompare) {
		$('#' + this.compareInputDiv).css('display', 'none');
        $('#' + this.compareCheckBoxDiv).css('display', 'none');
        $('#' + this.dateRangeCompareDiv).css('display', 'none');
        $('#' + this.compareCheckboxId).attr('disabled', true);
        $('#' + this.startCompareDateId).attr('disabled', true);
        $('#' + this.endCompareDateId).attr('disabled', true);
		//闅愯棌瀵规瘮镄刢heckbox
		$('#' + this.compareCheckboxId).parent().css('display','none');
		$('#'+ this.mOpts.replaceBtn).length > 0 && $('#'+ this.mOpts.replaceBtn).hide();
    } else {
        if(1 > $('#' + this.mOpts.startCompareDateId).length) {
            $(''!=this.mOpts.target?'#'+this.mOpts.target:'body').append('<input type="hidden" id="' + this.mOpts.startCompareDateId + '" name="' + this.mOpts.startCompareDateId + '" value="' + this.mOpts.startCompareDate + '" />');
        } else {
            $('#' + this.mOpts.startCompareDateId).val(this.mOpts.startCompareDate);
        }
        if(1 > $('#' + this.mOpts.endCompareDateId).length) {
            $(''!=this.mOpts.target?'#'+this.mOpts.target:'body').append('<input type="hidden" id="' + this.mOpts.endCompareDateId + '" name="' + this.mOpts.endCompareDateId + '" value="' + this.mOpts.endCompareDate + '" />');
        } else {
            $('#' + this.mOpts.endCompareDateId).val(this.mOpts.endCompareDate);
        }
        if('' == this.mOpts.startCompareDate || '' == this.mOpts.endCompareDate) {
            $('#' + this.compareCheckboxId).attr('checked', false);
            $('#' + this.mOpts.compareCheckboxId).attr('checked', false);
        } else {
            $('#' + this.compareCheckboxId).attr('checked', true);
            $('#' + this.mOpts.compareCheckboxId).attr('checked', true);
        }
		
    }
    // 杈揿叆妗嗙剑镣瑰畾鍦ㄧ涓€涓緭鍏ユ
    this.dateInput = this.startDateId;
    // 涓烘柊镄勮緭鍏ユ锷犺儗鏅壊
    this.changeInput(this.dateInput);

    // 寮€濮嬫椂闂  input 镄  click 浜嬩欢
    $('#' + this.startDateId).bind('click', function() {
        // 濡傛灉鐢ㄦ埛鍦ㄩ€夋嫨鍩哄嗳缁撴潫镞堕棿镞讹纴鎹㈠埌瀵规瘮镞堕棿浜嗭纴鍒 
        if(__method.endCompareDateId == __method.dateInput) {
            $('#' + __method.startCompareDateId).val(__method.startDefDate);
        }
        __method.startDefDate = '';
        __method.removeCSS(1);
        //__method.addCSS(1);
        __method.changeInput(__method.startDateId);
        return false;
    });
    $('#' + this.calendarId).bind('click', function(event) {
        //event.preventDefault();
        // 阒叉鍐掓场
        event.stopPropagation();
    });
    // 寮€濮嬫瘮杈冩椂闂  input 镄  click 浜嬩欢
    $('#' + this.startCompareDateId).bind('click', function() {
        // 濡傛灉鐢ㄦ埛鍦ㄩ€夋嫨鍩哄嗳缁撴潫镞堕棿镞讹纴鎹㈠埌瀵规瘮镞堕棿浜嗭纴鍒 
        if(__method.endDateId == __method.dateInput) {
            $('#' + __method.startDateId).val(__method.startDefDate);
        }
        __method.startDefDate = '';
        __method.removeCSS(0);
        //__method.addCSS(0);
        __method.changeInput(__method.startCompareDateId);
        return false;
    });
    /**
     * 璁剧疆锲炶皟鍙ユ焺锛岀偣鍑绘垚锷熷悗锛岃繑锲炰竴涓椂闂村璞★纴鍖呭惈寮€濮嬬粨鏉熸椂闂 
     * 鍜屽姣斿紑濮嬬粨鏉熸椂闂 
     */
    $('#' + this.submitBtn).bind('click', function() {
        __method.close(1);
        __method.mOpts.success({'startDate': $('#' + __method.mOpts.startDateId).val(), 
								'endDate': $('#' + __method.mOpts.endDateId).val(), 
								'needCompare' : $('#' + __method.mOpts.compareCheckboxId).val(),
								'startCompareDate':$('#' + __method.mOpts.startCompareDateId).val(), 
								'endCompareDate':$('#' + __method.mOpts.endCompareDateId).val()
								});
        return false;
    });
    // 镞ユ湡阃夋嫨鍏抽棴鎸夐挳镄  click 浜嬩欢
    $('#' + this.closeBtn).bind('click', function() {
        __method.close();
        return false;
    });
    // 涓鸿緭鍏ユ娣诲姞click浜嬩欢
    $('#' + this.inputId).bind('click', function() {
        __method.init();
        __method.show(false, __method);
        return false;
    });
	$('#' + this.mOpts.inputTrigger).bind('click', function() {
        __method.init();
        __method.show(false, __method);
        return false;
    });
	$('#' + this.mOpts.compareTrigger).bind('click', function() {
        __method.init(true);
        __method.show(true, __method);
        return false;
    });
	   // 涓鸿緭鍏ユ娣诲姞click浜嬩欢
    $('#' + this.inputCompareId).bind('click', function() {
        __method.init(true);
        __method.show(true, __method);
        return false;
    });
	
	//鍒ゆ柇鏄惁鏄疄镞舵暟鎹 ,濡傛灉鏄皢镞堕棿榛樿濉庞杩涘幓added by johnnyzheng 12-06
	if(this.mOpts.singleCompare){
		if(this.mOpts.theme === 'ta'){
			$('#' + __method.startDateId).val(__method.mOpts.startDate);
			$('#' + __method.endDateId).val(__method.mOpts.startDate);
			$('#' + __method.startCompareDateId).val(__method.mOpts.startCompareDate);
			$('#' + __method.endCompareDateId).val(__method.mOpts.startCompareDate);
		}
		else{
			$('#' + __method.startDateId).val(__method.mOpts.startDate);
			$('#' + __method.endDateId).val(__method.mOpts.startDate);
			$('#' + __method.startCompareDateId).val(__method.mOpts.startCompareDate);
			$('#' + __method.endCompareDateId).val(__method.mOpts.startCompareDate);
			$('#' + this.compareCheckboxId).attr('checked',true);
			$('#' + this.mOpts.compareCheckboxId).attr('checked',true);
		}
		
		
	}
    // 镞堕棿瀵规瘮
    $('#' + this.dateRangeCompareDiv).css('display', $('#' + this.compareCheckboxId).attr('checked') ? '' : 'none');
	$('#' + this.compareInputDiv).css('display', $('#' + this.compareCheckboxId).attr('checked') ? '' : 'none');
    $('#' + this.compareCheckboxId).bind('click', function() {
		$('#' + __method.inputCompareId).css('display', this.checked ? '' : 'none');
        // 闅愯棌瀵规瘮镞堕棿阃夋嫨
        $('#' + __method.dateRangeCompareDiv).css('display', this.checked ? '' : 'none');
		$('#' + __method.compareInputDiv).css('display', this.checked ? '' : 'none');
        // 鎶娄袱涓姣旀椂闂存缃负涓嶅彲鐢 
        $('#' + __method.startCompareDateId).css('disabled', this.checked ? false : true);
        $('#' + __method.endCompareDateId).css('disabled', this.checked ? false : true);
        // 淇敼琛ㄥ崟镄  checkbox 钟舵€ 
        $('#' + __method.mOpts.compareCheckboxId).attr('checked', $('#' + __method.compareCheckboxId).attr('checked'));
        // 淇敼琛ㄥ崟镄勫€ 
        $('#' + __method.mOpts.compareCheckboxId).val($('#' + __method.compareCheckboxId).attr('checked')?1:0);
        // 鍒濆鍖栭€夋鑳屾櫙
        if($('#' + __method.compareCheckboxId).attr('checked')) {
            sDate = __method.str2date($('#' + __method.startDateId).val());
            sTime = sDate.getTime();
            eDate = __method.str2date($('#' + __method.endDateId).val());
			eTime = eDate.getTime();
            scDate = $('#' + __method.startCompareDateId).val();
            ecDate = $('#' + __method.endCompareDateId).val();
            if('' == scDate || '' == ecDate) {
                ecDate = __method.str2date(__method.date2ymd(sDate).join('-'));
                ecDate.setDate(ecDate.getDate() - 1);
				scDate = __method.str2date(__method.date2ymd(sDate).join('-'));
                scDate.setDate(scDate.getDate() - ((eTime - sTime) / 86400000) - 1);
				//杩欓噷瑕佸拰STATS_START_TIME镄勬椂闂磋繘琛屽姣旓纴濡傛灉榛樿濉庞镄勫姣旀椂闂村湪杩欎釜镞堕棿涔嫔墠added by johnnyzheng
				if(ecDate.getTime() < __method.mOpts.minValidDate * 1000){
					scDate = sDate;
					ecDate = eDate;
				}
				if(ecDate.getTime() >= __method.mOpts.minValidDate * 1000 && scDate.getTime() < __method.mOpts.minValidDate * 1000){
					scDate.setTime(__method.mOpts.minValidDate * 1000)
					scDate = __method.str2date(__method.date2ymd(scDate).join('-'));
					ecDate.setDate(scDate.getDate() + ((eTime - sTime) / 86400000) - 1);
				}
                $('#' + __method.startCompareDateId).val(__method.formatDate(__method.date2ymd(scDate).join('-')));
                $('#' + __method.endCompareDateId).val(__method.formatDate(__method.date2ymd(ecDate).join('-')));
            }
            __method.addCSS(1);
            // 杈揿叆妗嗙剑镣瑰垏鎹㈠埌姣旇缉寮€濮嬫椂闂 
            __method.changeInput(__method.startCompareDateId);

        } else {
            __method.removeCSS(1);
            // 杈揿叆妗嗙剑镣瑰垏鎹㈠埌寮€濮嬫椂闂 
            __method.changeInput(__method.startDateId);
        }
		//鐢ㄦ埛镣瑰向榛樿镊姩鎻愪氦added by johnnyzheng 12-08
		__method.close(1);
		__method.mOpts.success({'startDate': $('#' + __method.mOpts.startDateId).val(), 
								'endDate': $('#' + __method.mOpts.endDateId).val(), 
								'needCompare' : $('#' + __method.mOpts.compareCheckboxId).val(),
								'startCompareDate':$('#' + __method.mOpts.startCompareDateId).val(), 
								'endCompareDate':$('#' + __method.mOpts.endCompareDateId).val()
								});
    });

    // 鍒濆鍖栧紑濮 
    this.init();
    // 鍏抽棴镞ユ湡阃夋嫨妗嗭纴骞舵妸缁撴灉鍙嶆樉鍒拌緭鍏ユ
    this.close(1);
	if(this.mOpts.replaceBtn && $('#'+this.mOpts.replaceBtn).length > 0){
		$('#'+ __method.compareCheckboxId).hide();
		$('.contrast').hide();
		$('#'+this.mOpts.replaceBtn).bind('click', function(){
			var self = this;
			$('#'+ __method.compareCheckboxId).attr('checked')
			? $('#'+ __method.compareCheckboxId).removeAttr('checked')
			: $('#'+ __method.compareCheckboxId).attr('checked', 'checked');
			$('#'+ __method.compareCheckboxId).click();
			$('#'+ __method.compareCheckboxId).attr('checked')
			? function(){
					$('#'+ __method.compareCheckboxId).removeAttr('checked');
					$('.contrast').hide();
					$(self).text('鎸夋椂闂村姣 ');
				}()
			: function(){
					$('#'+ __method.compareCheckboxId).attr('checked', 'checked');
					$('.contrast').show();
					$(self).text('鍙栨秷瀵规瘮');
				}();
		});
	}
	
	if(this.mOpts.autoCommit){
		this.mOpts.success({'startDate': $('#' + __method.mOpts.startDateId).val(), 
								'endDate': $('#' + __method.mOpts.endDateId).val(),
								'needCompare' : $('#' + __method.mOpts.compareCheckboxId).val(), 
								'startCompareDate':$('#' + __method.mOpts.startCompareDateId).val(), 
								'endCompareDate':$('#' + __method.mOpts.endCompareDateId).val()
								});
	}
    //璁╃敤鎴风偣鍑婚〉闱㈠嵆鍙叧闂脊绐 
    $(document).bind('click', function () {
       __method.close();
    });
};

/**
 * @description 镞ユ湡阃夋嫨鍣ㄧ殑鍒濆鍖栨楠娉曪纴瀵硅薄铡熷瀷镓╁睍
 * @param {Boolean} isCompare 镙囱瘑褰揿墠鍒濆鍖栭€夋嫨闱㈡澘鏄惁鏄姣旀棩链 
 */
pickerDateRange.prototype.init = function(isCompare) {
    var __method = this;
    var minDate, maxDate;
	var isNeedCompare = typeof(isCompare) != 'undefined'? isCompare && $("#" + __method.compareCheckboxId).attr('checked') : $("#" + __method.compareCheckboxId).attr('checked') ;
    // 娓呯┖镞ユ湡鍒楄〃镄勫唴瀹 
    $("#" + this.dateListId).empty();
	
    // 濡傛灉寮€濮嬫棩链熶负绌猴纴鍒椤彇褰揿ぉ镄勬棩链熶负寮€濮嬫棩链 
    var endDate = '' == this.mOpts.endDate ? (new Date()) : this.str2date(this.mOpts.endDate);
    // 镞ュ巻缁撴潫镞堕棿
    this.calendar_endDate = new Date(endDate.getFullYear(), endDate.getMonth() + 1, 0);

	//濡傛灉鏄痬agicSelect 镊畾涔夊勾鍜屾湀浠斤纴鍒栾嚜瀹氢箟濉庞镞ユ湡
	if(this.mOpts.magicSelect && this.mOpts.theme == 'ta'){
		var i = 0;
		do{
			var td = null;
			if(i==0){
				td = this.fillDate(this.str2date($('#'+this.endDateId).val()).getFullYear(), this.str2date($('#'+this.endDateId).val()). getMonth(), i);
				$("#" + this.dateListId).append(td);
			}
			else{
				td = this.fillDate(this.str2date($('#'+this.startDateId).val()).getFullYear(), this.str2date($('#'+this.startDateId).val()). getMonth(), i);
				var firstTd = (this.mOpts.theme == 'ta' ? $("#" + this.dateListId).find('table').get(0) : $("#" + this.dateListId).find ('td').get(0));
				$(firstTd).before(td);
			}
			i++;
		}while(i<2);
		// 镞ュ巻寮€濮嬫椂闂 
		this.calendar_startDate = new Date(this.str2date($('#'+this.startDateId).val()).getFullYear(), this.str2date($('#'+this.startDateId).val()) .getMonth(), 1);
	
	}else{
		// 璁＄畻骞舵樉绀轰互endDate 涓虹粨灏剧殑链€杩戝嚑涓湀镄勬棩链熷垪琛 
		for(var i = 0; i < this.mOpts.calendars; i ++) {
			var td = null;
			if(this.mOpts.theme == 'ta'){
				td = this.fillDate(endDate.getFullYear(), endDate.getMonth(), i);
			}
			else{
				td = document.createElement('td');
				$(td).append(this.fillDate(endDate.getFullYear(), endDate.getMonth(), i));
				$(td).css('vertical-align', 'top');
			}
			if(0 == i) {
				$("#" + this.dateListId).append(td);
			} else {
				var firstTd = (this.mOpts.theme == 'ta' ? $("#" + this.dateListId).find('table').get(0) : $("#" + this.dateListId).find ('td').get(0));
				$(firstTd).before(td);
			}
			endDate.setMonth(endDate.getMonth() - 1, 1);
		}
		 // 镞ュ巻寮€濮嬫椂闂 
		this.calendar_startDate = new Date(endDate.getFullYear(), endDate.getMonth() + 1, 1);
	}

    // 涓娄竴涓湀
    $('#' + this.preMonth).bind('click', function() {
        __method.calendar_endDate.setMonth(__method.calendar_endDate.getMonth() - 1, 1);
        __method.mOpts.endDate = __method.date2ymd(__method.calendar_endDate).join('-');
        __method.init(isCompare);
		//濡傛灉鏄崟链堥€夋嫨镄勬椂链欙纴瑕佹带鍒籼nput杈揿叆妗  added by johnnyzheng 2011-12-19
		if(1 == __method.mOpts.calendars){
			if('' == $('#' + __method.startDateId).val()){
				__method.changeInput(__method.startDateId);
			}
			else{
				__method.changeInput(__method.endDateId);
			}
		}
        return false;
    });
    // 涓嬩竴涓湀
    $('#' + this.nextMonth).bind('click', function() {
        __method.calendar_endDate.setMonth(__method.calendar_endDate.getMonth() + 1, 1);
        __method.mOpts.endDate = __method.date2ymd(__method.calendar_endDate).join('-');
		__method.init(isCompare);
		//濡傛灉鏄崟链堥€夋嫨镄勬椂链欙纴瑕佹带鍒籼nput杈揿叆妗  added by johnnyzheng 2011-12-19
		if(1 == __method.mOpts.calendars){
			if('' == $('#' + __method.startDateId).val()){
				__method.changeInput(__method.startDateId);
			}
			else{
				__method.changeInput(__method.endDateId);
			}
		}
        return false;
    });
	
	//濡傛灉链夌敤鎴疯嚜瀹氢箟阃夋嫨链堜唤锛屽垯涓哄叾缁戝畾浜嬩欢
	if(this.mOpts.magicSelect) this.bindChangeForSelect();
	

    // 鍒濆鍖栨椂闂撮€夊尯鑳屾櫙
    if(this.endDateId != this.dateInput && this.endCompareDateId != this.dateInput) {
         (isNeedCompare && typeof(isCompare) !='undefined') ? this.addCSS(1) : this.addCSS(0);
    }
	
	if(isNeedCompare && typeof(isCompare) !='undefined'){
		__method.addCSS(1);
	}
	else{
		__method.addCSS(0);
	
	}
	
	// 闅愯棌瀵规瘮镞ユ湡妗 
	$('#' + __method.inputCompareId).css('display', isNeedCompare ? '' : 'none');
	$('#' + this.compareInputDiv).css('display', $('#' + this.compareCheckboxId).attr('checked') ? '' : 'none');
	//鏄ㄥぉ锛屼粖澶╋纴链€杩 7澶╋纴链€杩 30澶╁揩鎹风殑镣瑰向锛屾牱寮忚镊繁瀹氢箟锛宨d鍙互浼犻€掗粯璁わ纴涔熷彲瑕嗙洊
	for(var property in __method.periodObj){
		if($('#'+ property).length > 0){
			$('#' + property).unbind('click');
			$('#' + property).bind('click' , function(){
				//澶勭悊镣瑰向镙峰纺
				var cla = __method.mOpts.theme == 'ta' ? 'active' : 'a';
				$(this).parent().nextAll().removeClass(cla);
				$(this).parent().prevAll().removeClass(cla);
				$(this).parent().addClass(cla);
				//鎷兼帴鎻愪氦镞堕棿涓 
				var timeObj = __method.getSpecialPeriod(__method.periodObj[$(this).attr('id')]);
				$('#' + __method.startDateId).val(__method.formatDate(timeObj.otherday));
				$('#' + __method.endDateId).val(__method.formatDate(timeObj.today));
				$('#' + __method.mOpts.startDateId).val($('#' + __method.startDateId).val());
				$('#' + __method.mOpts.endDateId).val($('#' + __method.endDateId).val());
				__method.mOpts.theme == 'ta' ? $('#'+__method.compareInputDiv).hide() : $('#' + __method.inputCompareId).css('display','none');
				$('#' + __method.compareCheckboxId).attr('checked', false);
				$('#' + __method.mOpts.compareCheckboxId).attr('checked', false);
				$('#' + this.compareInputDiv).css('display', $('#' + this.compareCheckboxId).attr('checked') ? '' : 'none');
                __method.close(1);
				//浜庢钖屾椂娓呯┖瀵规瘮镞堕棿妗嗙殑镞堕棿
				$('#' + __method.startCompareDateId).val('');
				$('#' + __method.endCompareDateId).val('');
				$('#' + __method.mOpts.startCompareDateId).val('');
				$('#' + __method.mOpts.endCompareDateId).val('');
				$('#' + __method.mOpts.compareCheckboxId).val(0);
				
				if($('#'+ __method.mOpts.replaceBtn).length > 0){
					$('.contrast').hide();
					$('#'+ __method.mOpts.replaceBtn).text('鎸夋椂闂村姣 ');
				}
				//镣瑰向鎻愪氦
				__method.mOpts.success({'startDate': $('#' + __method.mOpts.startDateId).val(), 
								'endDate': $('#' + __method.mOpts.endDateId).val(), 
								'needCompare' : $('#' + __method.mOpts.compareCheckboxId).val(),
								'startCompareDate':$('#' + __method.mOpts.startCompareDateId).val(), 
								'endCompareDate':$('#' + __method.mOpts.endCompareDateId).val()
								});
			}); 
		}
	}

    // 璁╃敤鎴锋坠锷ㄥ叧闂垨鎻愪氦镞ュ巻锛屾疮娆″垵濮嫔寲镄勬椂链欑粦瀹泛纴鍏抽棴镄勬椂链栾В缁  by zacharycai
    $(document).bind('click', function () {
        __method.close();
    });

    //瀹屽叏娓呯┖镞ユ湡鎺т欢镄勫€  by zacharycai
    $('#' + this.inputId).bind('change', function(){
        if ($(this).val() === ''){
            $('#' + __method.startDateId).val('');
            $('#' + __method.endDateId).val('');
            $('#' + __method.startCompareDateId).val('');
            $('#' + __method.endCompareDateId).val('');
        }
    })
};

pickerDateRange.prototype.bindChangeForSelect = function(){
	var __method = this;
	//姘旀场寮圭獥
	var _popup = function(btn, ctn, wrap, css) {
			css = css || 'open';
			var ITEMS_TIMEOUT = null, time_out = 500;
	
			function hidePop() {
				$('#' + ctn).removeClass(css);
			}
	
			function showPop() {
				$('#' + ctn).addClass(css);
			}
	
			function isPopShow() {
				return $('#' + ctn).attr('class') == css;
			}
	
	
			$("#" + btn).click(function() {
				isPopShow() ? hidePop() : showPop();
			}).mouseover(function() {
				clearTimeout(ITEMS_TIMEOUT);
			}).mouseout(function() {
				ITEMS_TIMEOUT = setTimeout(hidePop, time_out);
			});
	
			$('#' + wrap).mouseover(function() {
				clearTimeout(ITEMS_TIMEOUT);
			}).mouseout(function() {
				ITEMS_TIMEOUT = setTimeout(hidePop, time_out);
			});
		};
	
	//镊畾涔夐€夋嫨镄勮Е鍙戝姩浣 
	try{
		$("#" + this.dateListId).find('div[id*="selected"]').each(function(){
				//缁戝畾pop
				var _match = $(this).attr('id').match(/(\w+)_(\d)/i);
				if(_match){
					var _name = _match[1];//钖岖О
					var _idx = _match[2];//涓嬫爣
					
					if(_name=='yselected'){
						_popup('_ybtn_'+_idx, $(this).attr('id'), '_yctn_'+_idx);
					}
					else if(_name=='mselected'){
						_popup('_mbtn_'+_idx, $(this).attr('id'), '_mctn_'+_idx);
					}
					
					$(this).find('li a').each(function(){
						$(this).click(function() {
							var match = $(this).parents('.select_wrap').attr('id').match(/(\w+)_(\d)/i);
							//if(match){
								var name = match[1];//钖岖О
								var idx = match[2];//涓嬫爣
								var nt = null;
								if(idx^1 == 0){
								//寮€濮 
									if(name == 'yselected'){
										__method.calendar_startDate.setYear($(this).text()*1 , 1);
										//__method.calendar_startDate.setMonth(__method.str2date($('#'+__method.startDateId).val()).getMonth(), 1);
									}
									else if(name='mselected'){
										//__method.calendar_startDate.setYear(__method.str2date($('#'+__method.startDateId).val()).getFullYear(), 1);
										__method.calendar_startDate.setMonth($(this).text()*1-1, 1);
									}
									__method.mOpts.startDate = __method.date2ymd(__method.calendar_startDate).join('-');
									nt = __method.fillDate(__method.calendar_startDate.getFullYear(), __method.calendar_startDate.getMonth(), idx);
								}
								else{
									//缁撴潫
									if(name == 'yselected'){
										__method.calendar_endDate.setYear($(this).text()*1 , 1);
										//__method.calendar_endDate.setMonth(__method.str2date($('#'+__method.endDateId).val()).getMonth(), 1);
									}
									else if(name='mselected'){
										//__method.calendar_endDate.setYear(__method.str2date($('#'+__method.endDateId).val()).getFullYear(), 1);
										__method.calendar_endDate.setMonth($(this).text()*1-1, 1);
									}
									__method.mOpts.endDate = __method.date2ymd(__method.calendar_endDate).join('-');
									nt = __method.fillDate(__method.calendar_endDate.getFullYear(), __method.calendar_endDate.getMonth(), idx);
								}
								var tb = $("#" + __method.dateListId).find('table').get(idx^1);
								$(tb).replaceWith(nt);
							//}
							__method.removeCSS(0);
							__method.bindChangeForSelect();
						});		
					});
				}
			});
		}catch(e){
			window.console && console.log(e);
		}
}
/**
 * @description 璁＄畻浠婂ぉ锛屾槰澶╋纴链€杩 7澶╋纴链€杩 30澶╄繑锲炵殑镞堕棿锣冨洿
 * @param {Num} period 蹇嵎阃夋嫨镄勬椂闂存锛屼粖澶┿€佹槰澶┿€佹渶杩 7澶┿€佹渶杩 30澶 
 */
pickerDateRange.prototype.getSpecialPeriod = function(period){
	var __method = this;
	var date = new Date();
	//濡傛灉浠婂ぉ涓嶅彲鐢纴鍒欎粠鏄ㄥぉ钖戝墠鎺  added by johnnyzheng 12-07
	(true == __method.mOpts.isTodayValid && ('' != __method.mOpts.isTodayValid) || 2 > period)? '' : date.setTime(date.getTime() - ( 1 * 24 * 60 * 60 * 1000));
	var timeStamp = ((date.getTime()- ( period * 24 * 60 * 60 * 1000)) < (__method.mOpts.minValidDate * 1000)) ? (__method.mOpts.minValidDate * 1000) : (date.getTime( )- ( period * 24 * 60 * 60 * 1000)) ;
	var todayStr = date.getFullYear() + '-' + (date.getMonth()+ 1 ) + '-' + date.getDate();
	date.setTime(timeStamp);
	var otherdayStr = date.getFullYear() + '-' + (date.getMonth()+ 1 ) + '-' + date.getDate();
	if(period == __method.periodObj.aYesterday){
		todayStr = otherdayStr;
	}
	return {today: todayStr , otherday : otherdayStr};
}

pickerDateRange.prototype.getCurrentDate = function(){
    return {
            'startDate': $('#' + this.mOpts.startDateId).val(), 
            'endDate': $('#' + this.mOpts.endDateId).val(), 
            'needCompare' : $('#' + this.mOpts.compareCheckboxId).val(),
            'startCompareDate':$('#' + this.mOpts.startCompareDateId).val(), 
            'endCompareDate':$('#' + this.mOpts.endCompareDateId).val()
            };
};

/**
 * @description 绉婚櫎阃夋嫨镞ユ湡闱㈡澘镄勬牱寮 
 * @param {Boolean} isCompare 鏄惁鏄姣旀棩链熼溃鏉 
 * @param {String} specialClass 鐗规畩镄勬牱寮忥纴杩欓噷榛樿鏄父瑙勫拰瀵规瘮镞ユ湡涓ょ镙峰纺镄勯吨钖堟牱寮 
 */
pickerDateRange.prototype.removeCSS = function(isCompare, specialClass) {
    // 鍒濆鍖栧姣旀椂闂撮吨钖堥儴鍒嗙殑镙峰纺绫 
    if('undefined' == typeof(specialClass)) {
        specialClass = this.mOpts.theme + '_' + this.mOpts.coincideCss;
    }
    // 鏄惁绉婚櫎瀵规瘮閮ㄥ垎镄勬牱寮 :0 镞ユ湡阃夋嫨;1 瀵规瘮镞ユ湡阃夋嫨
    if('undefined' == typeof(isCompare)) {
        isCompare = 0;
    }
	
    // 鏁翠釜镞ユ湡鍒楄〃镄勫紑濮嬫棩链 
	var s_date = this.calendar_startDate;
	var e_date = this.calendar_endDate;
	//濡傛灉鏄敤鎴疯嚜瀹氢箟阃夋嫨镄勮瘽锛岄渶瑕佸庞链兼牱寮忚竟鐣屾棩链 
	if(this.mOpts.magicSelect){
		s_date = this.str2date($('#'+this.startDateId).val());
		e_date = this.str2date($('#'+this.endDateId).val());
	}
    var bDate = new Date(s_date.getFullYear(), s_date.getMonth(), s_date.getDate());
    var cla = '';
    // 浠庡紑濮嬫棩链熷惊鐜埌缁撴潫镞ユ湡
    for(var d = new Date(bDate); d.getTime() <= e_date.getTime(); d.setDate(d.getDate() + 1)) {
            if(0 == isCompare) {
                // 绉婚櫎镞ユ湡镙峰纺
                cla = this.mOpts.theme + '_' + this.mOpts.selectCss;
            } else {
                // 绉婚櫎瀵规瘮镞ユ湡镙峰纺
                cla = this.mOpts.theme + '_' + this.mOpts.compareCss;
            }
        // 绉婚櫎鎸囧畾镙峰纺
        $('#'+ this.calendarId + '_' + this.date2ymd(d).join('-')).removeClass(cla);
		$('#'+ this.calendarId + '_' + this.date2ymd(d).join('-')).removeClass(this.mOpts.firstCss).removeClass(this.mOpts.lastCss).removeClass(this .mOpts.clickCss);
    }
};

/**
 * @description 涓洪€変腑镄勬棩链熷姞涓婃牱寮忥细1=姣旇缉镞堕棿锛 0=镞堕棿锣冨洿
 * @param {Boolean} isCompare 鏄惁鏄姣旀棩链熼溃鏉 
 * @param {String} specialClass 鐗规畩镄勬牱寮忥纴杩欓噷榛樿鏄父瑙勫拰瀵规瘮镞ユ湡涓ょ镙峰纺镄勯吨钖堟牱寮 
 */
pickerDateRange.prototype.addCSS = function(isCompare, specialClass) {

    // 鍒濆鍖栧姣旀椂闂撮吨钖堥儴鍒嗙殑镙峰纺绫 
    if('undefined' == typeof(specialClass)) {
        specialClass = this.mOpts.theme + '_' + this.mOpts.coincideCss;
    }
    // 鏄惁绉婚櫎瀵规瘮閮ㄥ垎镄勬牱寮 :0 镞ユ湡阃夋嫨;1 瀵规瘮镞ユ湡阃夋嫨
    if('undefined' == typeof(isCompare)) {
        isCompare = 0;
    }
    // 銮峰彇4涓棩链 
    var startDate = this.str2date($('#' + this.startDateId).val());
    var endDate = this.str2date($('#' + this.endDateId).val());
    var startCompareDate = this.str2date($('#' + this.startCompareDateId).val());
    var endCompareDate = this.str2date($('#' + this.endCompareDateId).val());

    // 寰幆寮€濮嬫棩链 
    var sDate = 0 == isCompare ? startDate : startCompareDate;
    // 寰幆缁撴潫镞ユ湡
    var eDate = 0 == isCompare ? endDate : endCompareDate;
    var cla = '';
    for(var d = new Date(sDate); d.getTime() <= eDate.getTime(); d.setDate(d.getDate() + 1)) {
            if(0 == isCompare) {
                // 娣诲姞镞ユ湡镙峰纺
                cla = this.mOpts.theme + '_' + this.mOpts.selectCss;
				$('#' + this.calendarId + '_' + this.date2ymd(d).join('-')).removeClass(this.mOpts.firstCss).removeClass(this.mOpts.lastCss).removeClass(this .mOpts.clickCss);
				$('#' + this.calendarId + '_' + this.date2ymd(d).join('-')).removeClass(cla);
            } else {
                // 娣诲姞瀵规瘮镞ユ湡镙峰纺
                cla = this.mOpts.theme + '_' + this.mOpts.compareCss;
            }

        $('#' + this.calendarId + '_' + this.date2ymd(d).join('-')).attr('class', cla);
    }
	if(this.mOpts.theme == 'ta'){
		//涓哄紑濮嬬粨鏉熸坊锷犵壒娈婃牱寮 
		$('#' + this.calendarId + '_' + this.date2ymd(new Date(sDate)).join('-')).removeClass().addClass(this.mOpts.firstCss);
		$('#' + this.calendarId + '_' + this.date2ymd(new Date(eDate)).join('-')).removeClass().addClass(this.mOpts.lastCss);
		//濡傛灉寮€濮嬬粨鏉熸椂闂寸浉钖 
		sDate.getTime() == eDate.getTime() && $('#'+ this.calendarId + '_' + this.date2ymd(new Date(eDate)).join('-')).removeClass(). addClass(this.mOpts.clickCss);
	}
};

/**
 * @description 鍒ゆ柇寮€濮嬨€佺粨鏉熸棩链熸槸钖﹀鍦ㄥ厑璁哥殑锣冨洿鍐 
 * @param {String} startYmd 寮€濮嬫椂闂村瓧绗︿覆
 * @param {String} endYmd 缁撴潫镞堕棿瀛楃涓 
 */
pickerDateRange.prototype.checkDateRange = function(startYmd, endYmd) {
    var sDate = this.str2date(startYmd);
    var eDate = this.str2date(endYmd);
    var sTime = sDate.getTime();
    var eTime = eDate.getTime();
    var minEDate, maxEDate;

    if(eTime >= sTime) {
        // 鍒ゆ柇鏄惁瓒呰绷链€澶ф棩链熷
        maxEDate = this.str2date(startYmd);
        maxEDate.setMonth(maxEDate.getMonth() + this.mOpts.monthRangeMax);
        maxEDate.setDate(maxEDate.getDate() + this.mOpts.dayRangeMax - 1);
        if(maxEDate.getTime() < eTime) {
            alert('缁撴潫镞ユ湡涓嶈兘澶т簬锛 ' + this.date2ymd(maxEDate).join('-'));
            return false;
        }
    } else {
        // 鍒ゆ柇鏄惁瓒呰绷链€澶ф棩链熷
        //maxEDate = this.str2date(stPartYmd);
		maxEDate = this.str2date(endYmd);
        maxEDate.setMonth(maxEDate.getMonth() - this.mOpts.monthRangeMax);
        maxEDate.setDate(maxEDate.getDate() - this.mOpts.dayRangeMax + 1);
        if(maxEDate.getTime() > eTime) {
            alert('寮€濮嬫棩链熶笉鑳借皬浜庯细' + this.date2ymd(maxEDate).join('-'));
            return false;
        }
    }
    return true;
}

/**
 * @description 阃夋嫨镞ユ湡
 * @param {String} ymd 镞堕棿瀛楃涓 
 */
pickerDateRange.prototype.selectDate = function(ymd) {
    //镣瑰向镞ユ湡镣圭殑镞跺€欐坊锷犲搴旇緭鍏ユ镄勬牱寮忥纴钥屼笉鏄箣鍓岖殑镵氱剑鍒拌緭鍏ユ镞舵樉绀烘牱寮  by zacharycai
    this.changeInput(this.dateInput);
    // 镙煎纺鍖栨棩链 
    var ymdFormat = this.formatDate(ymd);

    // start <-> end 鍒囨崲
    if(this.startDateId == this.dateInput) {
        // 绉婚櫎镙峰纺
        this.removeCSS(0);
		this.removeCSS(1);
        // 涓哄綋鍓岖偣锷犳牱寮 
        $('#'+ this.calendarId + '_' + ymd).attr('class', (this.mOpts.theme == 'ta' ? this.mOpts.clickCss : this.mOpts.theme + '_' + this.mOpts.selectCss));
		// 銮峰彇寮€濮嬫椂闂寸殑鍒濆链 
		this.startDefDate = $('#' + this.dateInput).val();
		// 旋存敼瀵瑰簲杈揿叆妗嗙殑链 
		$('#' + this.dateInput).val(ymdFormat);
        // 鍒囨崲杈揿叆妗嗙剑镣 ,濡傛灉鏄疄镞舵暟鎹偅涔堥€夋嫨涓€澶╃殑鏁版嵁
        if (true == this.mOpts.singleCompare || true == this.mOpts.isSingleDay) {
            this.dateInput = this.startDateId;
			$('#' + this.endDateId).val(ymdFormat);
			(this.mOpts.shortOpr || this.mOpts.autoSubmit) && this.close(1);
            this.mOpts.success({'startDate': $('#' + this.mOpts.startDateId).val(),
                'endDate': $('#' + this.mOpts.endDateId).val(),
                'needCompare' : $('#' + this.mOpts.compareCheckboxId).val(),
                'startCompareDate':$('#' + this.mOpts.startCompareDateId).val(),
                'endCompareDate':$('#' + this.mOpts.endCompareDateId).val()
            });

        } else {
            this.dateInput = this.endDateId;
        }
		
    } else if(this.endDateId == this.dateInput) {
        // 濡傛灉寮€濮嬫椂闂存湭阃 
        if('' == $('#' + this.startDateId).val()) {
            this.dateInput = this.startDateId;
            this.selectDate(ymd);
            return false;
        }
        // 鍒ゆ柇鐢ㄦ埛阃夋嫨镄勬椂闂磋浸锲 
        if(false == this.checkDateRange($('#' + this.startDateId).val(), ymd)) {
            return false;
        }
        // 濡傛灉缁撴潫镞堕棿灏忎簬寮€濮嬫椂闂 
        if(-1 == this.compareStrDate(ymd, $('#' + this.startDateId).val())) {
            // 旋存敼瀵瑰簲杈揿叆妗嗙殑链 (缁撴潫镞堕棿)
            $('#' + this.dateInput).val($('#' + this.startDateId).val());
            // 旋存敼瀵瑰簲杈揿叆妗嗙殑链 (寮€濮嬫椂闂 )
            $('#' + this.startDateId).val(ymdFormat);
            ymdFormat = $('#' + this.dateInput).val();
        }
        // 旋存敼瀵瑰簲杈揿叆妗嗙殑链 
        $('#' + this.dateInput).val(ymdFormat);
        // 鍒囨崲杈揿叆妗嗙剑镣 
        this.dateInput = this.startDateId;
		this.removeCSS(0);
        this.addCSS(0);
		//this.addCSS(0, this.mOpts.coincideCss);
        this.startDefDate = '';
		if(this.mOpts.autoSubmit){
			this.close(1);
            this.mOpts.success({'startDate': $('#' + this.mOpts.startDateId).val(),
                'endDate': $('#' + this.mOpts.endDateId).val(),
                'needCompare' : $('#' + this.mOpts.compareCheckboxId).val(),
                'startCompareDate':$('#' + this.mOpts.startCompareDateId).val(),
                'endCompareDate':$('#' + this.mOpts.endCompareDateId).val()
            });
		}
    } else if(this.startCompareDateId == this.dateInput) {
        // 绉婚櫎镙峰纺
        this.removeCSS(1);
		this.removeCSS(0);
        // 涓哄綋鍓岖偣锷犳牱寮 
		$('#'+ this.calendarId + '_' + ymd).attr('class', (this.mOpts.theme == 'ta' ? this.mOpts.clickCss : this.mOpts.theme + '_' + this.mOpts.compareCss));
        // 銮峰彇寮€濮嬫椂闂寸殑鍒濆链 
        this.startDefDate = $('#' + this.dateInput).val();
        // 旋存敼瀵瑰簲杈揿叆妗嗙殑链 
        $('#' + this.dateInput).val(ymdFormat);
        // 鍒囨崲杈揿叆妗嗙剑镣 
		if (true == this.mOpts.singleCompare || true == this.mOpts.isSingleDay) {
            this.dateInput = this.startCompareDateId;
			$('#' + this.endCompareDateId).val(ymdFormat);
			(this.mOpts.shortOpr || this.mOpts.autoSubmit) && this.close(1);
            this.mOpts.success({'startDate': $('#' + this.mOpts.startDateId).val(),
                'endDate': $('#' + this.mOpts.endDateId).val(),
                'needCompare' : $('#' + this.mOpts.compareCheckboxId).val(),
                'startCompareDate':$('#' + this.mOpts.startCompareDateId).val(),
                'endCompareDate':$('#' + this.mOpts.endCompareDateId).val()
            });
        }
		else{
		     this.dateInput = this.endCompareDateId;
		}
		
    } else if(this.endCompareDateId == this.dateInput) {
        // 濡傛灉寮€濮嬫椂闂存湭阃 
        if('' == $('#' + this.startCompareDateId).val()) {
            this.dateInput = this.startCompareDateId;
            this.selectDate(ymd);
            return false;
        }
        // 鍒ゆ柇鐢ㄦ埛阃夋嫨镄勬椂闂磋浸锲 
        if(false == this.checkDateRange($('#' + this.startCompareDateId).val(), ymd)) {
            return false;
        }
        // 濡傛灉缁撴潫镞堕棿灏忎簬寮€濮嬫椂闂 
        if(-1 == this.compareStrDate(ymd, $('#' + this.startCompareDateId).val())) {
            // 旋存敼瀵瑰簲杈揿叆妗嗙殑链 (缁撴潫镞堕棿)
            $('#' + this.dateInput).val($('#' + this.startCompareDateId).val());
            // 旋存敼瀵瑰簲杈揿叆妗嗙殑链 (寮€濮嬫椂闂 )
            $('#' + this.startCompareDateId).val(ymdFormat);
            ymdFormat = $('#' + this.dateInput).val();
        }
        // 旋存敼瀵瑰簲杈揿叆妗嗙殑链 
        $('#' + this.dateInput).val(ymdFormat);
        // 鍒囨崲杈揿叆妗嗙剑镣 
        this.dateInput = this.startCompareDateId;
        //this.addCSS(1, this.mOpts.coincideCss);
		this.removeCSS(1);
		this.addCSS(1);
        this.startDefDate = '';
		if(this.mOpts.autoSubmit){
			this.close(1);
            this.mOpts.success({'startDate': $('#' + this.mOpts.startDateId).val(),
                'endDate': $('#' + this.mOpts.endDateId).val(),
                'needCompare' : $('#' + this.mOpts.compareCheckboxId).val(),
                'startCompareDate':$('#' + this.mOpts.startCompareDateId).val(),
                'endCompareDate':$('#' + this.mOpts.endCompareDateId).val()
            });
		}
    }
    // 鍒囨崲鍒颁笅涓€涓緭鍏ユ
// this.changeInput(this.dateInput);
};

/**
 * @description鏄剧ず镞ユ湡阃夋嫨妗 
 * @param {Boolean} isCompare 鏄惁鏄姣旀棩链熼€夋嫨妗 
 * @param {Object} __method 镞舵湡阃夋嫨鍣ㄨ秴绾у璞 
 */ 
pickerDateRange.prototype.show = function(isCompare, __method) {
	$('#' + __method.dateRangeDiv).css('display', isCompare ? 'none' : '');
	$('#' + __method.dateRangeCompareDiv).css('display', isCompare ? '' : 'none');
    var pos = isCompare ? $('#' + this.inputCompareId).offset() : $('#' + this.inputId).offset();
	var offsetHeight = isCompare ? $('#' + this.inputCompareId).height() : $('#' + this.inputId).height();
    var clientWidth = parseInt($(document.body)[0].clientWidth);
    var left = pos.left;
    $("#" + this.calendarId).css('display', 'block');
    if (true == this.mOpts.singleCompare || true == this.mOpts.isSingleDay) {
        $('#' + this.endDateId).css('display', 'none');
		$('#' + this.endCompareDateId).css('display','none');
        $('#' + this.mOpts.joinLineId).css('display', 'none');
		$('.' + this.mOpts.joinLineId).css('display', 'none');
    }
    // 濡傛灉鍜岃緭鍏ユ宸﹀榻愭椂瓒呭嚭浜嗗搴﹁浸锲达纴鍒椤彸瀵归绨
    if(0 < clientWidth && $("#" + this.calendarId).width() + pos.left > clientWidth) {
        left = pos.left + $('#' + this.inputId).width() - $("#" + this.calendarId).width() + ((/msie/i.test(navigator.userAgent) && !(/opera/i.test(navigator.userAgent)))? 5 : 0) ;
		__method.mOpts.theme=='ta' && (left += 50);
	}
    $("#" + this.calendarId).css('left', left + 'px');
    //$("#" + this.calendarId).css('top', pos.top + (offsetHeight ? offsetHeight- 1 : (__method.mOpts.theme=='ta'?35:22)) + 'px ');
	$("#" + this.calendarId).css('top', pos.top + (__method.mOpts.theme=='ta'?35:22) + 'px');
	//绗竴娆℃樉绀虹殑镞跺€欙纴涓€瀹氲鍒濆鍖栬緭鍏ユ
	isCompare ? this.changeInput(this.startCompareDateId) : this.changeInput(this.startDateId);
    return false;
};

/**
 * @description 鍏抽棴镞ユ湡阃夋嫨妗 
 * @param {Boolean} btnSubmit 鏄惁鏄偣鍑荤'瀹氭寜阍叧闂殑 
 */
pickerDateRange.prototype.close = function(btnSubmit) {
	var __method = this;
    //by zacharycai 鍏抽棴钖庡氨瑙ｇ粦浜 
    //$(document).unbind('click');

    // 鎶婂紑濮嬨€佺粨鏉熸椂闂存樉绀哄埌杈揿叆妗  (PS:濡傛灉阃夋嫨镄勪粖镞ワ纴鏄ㄦ棩锛屽垯鍙～鍏ヤ竴涓棩链 )
    // 濡傛灉寮€濮嫔拰缁撴潫钖屼釜镞堕棿涔熺收镙峰垎娈礲y zacharycai
    //$('#' + this.inputId).val($('#' + this.startDateId).val() + ($('#' + this.startDateId).val() == $(' #' + this.endDateId).val() ? '' : this.mOpts.defaultText + $('#' + this.endDateId).val()));
	if(btnSubmit){
		//濡傛灉鏄崟镞ュ揩鎹烽€夋嫨
		if (this.mOpts.shortOpr === true){
			$('#' + this.inputId).val($('#' + this.startDateId).val());
			$('#' + this.inputCompareId).val($('#' + this.startCompareDateId).val());
		}else{
			$('#' + this.inputId).val($('#' + this.startDateId).val() + ('' == $('#' + this.endDateId).val() ? '' : this.mOpts.defaultText + $('#' + this.endDateId).val()));
		}
		//鍒ゆ柇褰揿墠澶╂槸钖﹀彲阃夛纴鏉ュ喅瀹氢粠钖庡线鍓嶆帹淇敼镞ユ湡鏄粠鍝竴镣瑰紑濮 
		var nDateTime = ((true == this.mOpts.isTodayValid && '' != this.mOpts.isTodayValid)) ? new Date().getTime() : new Date().getTime() - (1 * 24 * 60 * 60 * 1000);
		var bDateTime = this.str2date($('#' + this.startDateId).val()).getTime();
		var eDateTime = this.str2date($('#' + this.endDateId).val()).getTime();
		//濡傛灉endDateTime灏忎簬bDateTime 鐩镐簰浜ゆ崲
		if(eDateTime < bDateTime){
			var tmp = $('#' + this.startDateId).val();
			$('#' + this.startDateId).val($('#' + this.endDateId).val());
			$('#' + this.endDateId).val(tmp);
		}
		 var _val = this.mOpts.shortOpr == true ? $('#' + this.startDateId).val() : ($('#' + this.startDateId).val() + ('' == $( '#' + this.endDateId).val() ? '' : this.mOpts.defaultText + $('#' + this.endDateId).val()));
		// 鎶婂紑濮嬨€佺粨鏉熸椂闂存樉绀哄埌杈揿叆妗  (PS:濡傛灉阃夋嫨镄勪粖镞ワ纴鏄ㄦ棩锛屽垯鍙～鍏ヤ竴涓棩链 )
		var input = document.getElementById(this.inputId);
		if(input && input.tagName == 'INPUT'){
			$('#' + this.inputId).val(_val);
			$('#'+this.inputCompareId).is(':visible') && $('#'+this.inputCompareId).val(_compareVal);
		}else{
			$('#' + this.inputId).html(_val);
			$('#'+this.inputCompareId).is(':visible') && $('#'+this.inputCompareId).html(_compareVal);
		}
		// //鍦╦s渚у氨锅氩ソ镞ユ湡镙″嗳锛屼互鍓嶉溃镄勬棩链熼€夋嫨镄勮法搴︿负鍑嗭纴濡傛灉钖庨溃镄勮法搴﹁秴杩囦简褰揿墠鍙敤镞堕棿锛屽垯浠ュ綋鍓嶅彲鐢ㄦ椂闂村悜鍓嶆帹added by johnnyzheng 11-29
		if(this.mOpts.theme != 'ta'){
			if('' != $('#' + this.startCompareDateId).val() && '' != $('#' + this.endCompareDateId).val()){
				var bcDateTime = this.str2date($('#' + this.startCompareDateId).val()).getTime();
				var ecDateTime = this.str2date($('#' + this.endCompareDateId).val()).getTime();
				var _ecDateTime = bcDateTime + eDateTime - bDateTime;
				if(_ecDateTime > nDateTime){
				//濡傛灉璁＄畻寰楀埌镄勬椂闂磋秴杩囦简褰揿墠鍙敤镞堕棿锛岄偅涔埚氨鍜屾湇锷″櫒绔缭鎸佷竴镊达纴灏嗗綋鍓嶅彲鐢ㄧ殑澶╂暟钖戝墠鎺ㄦ棩链熼€夋嫨鍣ㄧ殑璺ㄥ害added by johnnyzheng 11-29
					_ecDateTime = nDateTime;
					$('#' + this.startCompareDateId).val(this.formatDate(this.date2ymd(new Date(_ecDateTime + bDateTime - eDateTime)).join('-')));
				}
				$('#' + this.endCompareDateId).val(this.formatDate(this.date2ymd(new Date(_ecDateTime)).join('-')));
				
				//鎶婂紑濮嬬粨鏉熷姣旀椂闂村ぇ灏忛吨鏂扮煫姝ｄ竴涓 
				var bcDateTime = this.str2date($('#' + this.startCompareDateId).val()).getTime();
				var ecDateTime = this.str2date($('#' + this.endCompareDateId).val()).getTime();
				if(ecDateTime < bcDateTime){
					var tmp = $('#' + this.startCompareDateId).val();
					$('#' + this.startCompareDateId).val($('#' + this.endCompareDateId).val());
					$('#' + this.endCompareDateId).val(tmp);
				}
			}
		}
		//鎶婂姣旀椂闂村～鍏ヨ緭鍏ユ (PS:濡傛灉阃夋嫨浠婃棩锛屾槰镞ワ纴鍒椤彧濉叆涓€涓棩链 )
		//$('#' + this.inputCompareId).val($('#' + this.startCompareDateId).val() + this.mOpts.defaultText + $('#' + this.endCompareDateId).val() );
		var _compareVal = this.mOpts.shortOpr == true ? $('#' + this.startCompareDateId).val() : ($('#' + this.startCompareDateId).val() + ('' == $( '#' + this.endCompareDateId).val() ? '' : this.mOpts.defaultText + $('#' + this.endCompareDateId).val()));
		if(input && input.tagName == 'INPUT'){
				$('#' + this.inputCompareId).val(_compareVal);
		}else{
				$('#' + this.inputCompareId).html(_compareVal);
		}
		// 璁＄畻鐩搁殧澶╂暟
		var step = (bDateTime - eDateTime) / 86400000;

		// 旋存敼鐩爣鍏幂礌链 
		$('#' + this.mOpts.startDateId).val($('#' + this.startDateId).val());
		$('#' + this.mOpts.endDateId).val($('#' + this.endDateId).val());
		$('#' + this.mOpts.startCompareDateId).val($('#' + this.startCompareDateId).val());
		$('#' + this.mOpts.endCompareDateId).val($('#' + this.endCompareDateId).val());
		//镣瑰向纭畾鎸夐挳杩涜镆ヨ钖庡皢鍙栨秷镓€链夌殑浠婂ぉ鏄ㄥぉ链€杩 7澶╃殑蹇嵎阈炬帴added by johnnyzheng 11-29
		for(var property in this.periodObj){
			if($('#' + this.mOpts[property])){
				$('#' + this.mOpts[property]).parent().removeClass('a');
			}
		}
	}
	// 闅愯棌镞ユ湡阃夋嫨妗  寤惰繜200ms 鍏抽棴镞ユ湡阃夋嫨妗 
	$("#" + __method.calendarId).css('display', 'none');
    return false;
};

/**
 * @description 镞ユ湡濉庞鍑芥暟
 * @param {Num} year 骞 
 * @param {Num} month 链 
 */ 
pickerDateRange.prototype.fillDate = function(year, month, index) {
    var __method = this;
	var isTaTheme = this.mOpts.theme == 'ta';
    // 褰撴湀绗竴澶 
    var firstDayOfMonth = new Date(year, month, 1);
    var dateBegin = new Date(year, month, 1);
    var w = dateBegin.getDay();
    // 璁＄畻搴旇寮€濮嬬殑镞ユ湡
    dateBegin.setDate(1 - w);

    // 褰撴湀链€钖庝竴澶 
    var lastDayOfMonth = new Date(year, month + 1, 0);
    var dateEnd = new Date(year, month + 1, 0);
    w = dateEnd.getDay();
    // 璁＄畻搴旇缁撴潫镄勬棩链 
    dateEnd.setDate(dateEnd.getDate() + 6 - w);

    var today = new Date();
    var dToday = today.getDate();
    var mToday = today.getMonth();
    var yToday = today.getFullYear();
	
	var table = document.createElement('table');
	if(isTaTheme){
		table.className = this.mOpts.dateTable;

		cap = document.createElement('caption');
		
		//濡傛灉鏄痬agicSelect锛岀敤鎴疯嚜瀹氢箟镄勯€夋嫨骞村拰链堜唤
		if(this.mOpts.magicSelect){
			var yh = ['<div class="select_wrap" id="yselected_'+index+'"><div class="select" id="_ybtn_'+index+'">'+year+'</div><div class ="dropdown" id="_yctn_'+index+'"><ul class="list_menu">']
			var mh = ['<div class="select_wrap" id="mselected_'+index+'"><div class="select" id="_mbtn_'+index+'">'+(month+1)+'</ div><div class="dropdown" id="_mctn_'+index+'"><ul class="list_menu">']
		
			//var yh = ['<select name="yselected_'+index+'" class="xxxs">'];
			//var mh = ['<select name="mselected_'+index+'" class="xxxs">'];
			i=1;
			yt = yToday;
			do{
				//yh.push('<option value="'+yt+'" '+(yt == year? 'selected' : '')+'>'+(yt--)+'</option>') ;
				//mh.push('<option value="'+i+'" '+(i == (month+1)? 'selected' : '')+'>'+(i++)+'</option> ');
				yh.push('<li><a href="javascript:;">'+(yt--)+'</a></li>');
				mh.push('<li><a href="javascript:;">'+(i++)+'</a></li>');
			}while(i <= 12);
			//yh.push('</select>');
			//mh.push('</select>');		
			yh.push('</ul></div></div>');
			mh.push('</ul></div></div>');			
			$(cap).append(yh.join('') +'<span class="joinLine"> 骞  </span>'+mh.join('')+'<span class="joinLine"> 链   </span>');

		}
		else{
			$(cap).append(year + '骞 ' + (month + 1) + '链 ');
		}
		
		$(table).append(cap);
		thead = document.createElement('thead');
		tr = document.createElement('tr');
		var days = ['锻ㄦ棩', '锻ㄤ竴', '锻ㄤ簩', '锻ㄤ笁', '锻ㄥ洓', '锻ㄤ簲', '锻ㄥ叚'];
		for(var i = 0; i < 7; i ++) {
			th = document.createElement('th');
			$(th).append(days[i]);
			$(tr).append(th);
		}
		$(thead).append(tr);
		$(table).append(thead);
		
		tr = document.createElement('tr');
		td = document.createElement('td');
		// 濡傛灉鏄渶钖庝竴涓湀镄勬棩链燂纴鍒椤姞涓娄笅涓€涓湀镄勯摼鎺 
		if(!this.mOpts.magicSelect){
			if(0 == index) {
				$(td).append('<a href="javascript:void(0);" id="' + this.nextMonth + '"><i class="i_next"></i></a>' );
			}
			// 濡傛灉鏄涓€涓湀镄勬棩链燂纴鍒椤姞涓娄笂涓€涓湀镄勯摼鎺 
			if(index + 1 == this.mOpts.calendars) {
				$(td).append('<a href="javascript:void(0);" id="' + this.preMonth + '"><i class="i_pre"></i></a>' );
			}
		}
		
	// $(td).append('<span style="font-size:16px">' + year + '骞 ' + (month + 1) + '链 ' + '</span>');
		$(td).attr('colSpan', 7);
		$(td).css('text-align', 'center');
		$(tr).append(td);
		$(table).append(tr);
	}
	else{
		table.className = this.mOpts.theme + '_' + this.mOpts.dateTable;

		tr = document.createElement('tr');
		td = document.createElement('td');
		// 濡傛灉鏄渶钖庝竴涓湀镄勬棩链燂纴鍒椤姞涓娄笅涓€涓湀镄勯摼鎺 
		if(0 == index) {
			$(td).append('<a href="javascript:void(0);" id="' + this.nextMonth + '" class="gri_dateRangeNextMonth"><span>next</span></a> ');
		}
		// 濡傛灉鏄涓€涓湀镄勬棩链燂纴鍒椤姞涓娄笂涓€涓湀镄勯摼鎺 
		if(index + 1 == this.mOpts.calendars) {
			$(td).append('<a href="javascript:void(0);" id="' + this.preMonth + '" class="gri_dateRangePreMonth"><span>pre</span></a> ');
		}
		$(td).append(year + '骞 ' + (month + 1) + '链 ');
		$(td).attr('colSpan', 7);
		$(td).css('text-align', 'center');
		$(td).css('background-color', '#F9F9F9');
		$(tr).append(td);
		$(table).append(tr);

		var days = ['镞 ', '涓€', '浜 ', '涓 ', '锲 ', '浜 ', '鍏 '];
		tr = document.createElement('tr');
		for(var i = 0; i < 7; i ++) {
			td = document.createElement('td');
			$(td).append(days[i]);
			$(tr).append(td);
		}
		$(table).append(tr);
	}
    // 褰揿墠链堢殑镓€链夋棩链 (鍖呮嫭绌虹槠浣岖疆濉庞镄勬棩链 )
    var tdClass = '', deviation = 0, ymd = '';
    for(var d = dateBegin; d.getTime() <= dateEnd.getTime(); d.setDate(d.getDate() + 1)) {
        if(d.getTime() < firstDayOfMonth.getTime()) { // 褰揿墠链堜箣鍓岖殑镞ユ湡
            tdClass = this.mOpts.theme + '_' + this.mOpts.disableGray;
            deviation = '-1';
        } else if(d.getTime() > lastDayOfMonth.getTime()) { // 褰揿墠链堜箣钖庣殑镞ユ湡
            tdClass = this.mOpts.theme + '_' + this.mOpts.disableGray;
            deviation = '1';
        } else if((this.mOpts.stopToday == true && d.getTime() < today.getTime()) || d.getTime() < __method.mOpts.minValidDate * 1000 || ('' !== __method .mOpts.maxValidDate && d.getTime() > __method.mOpts.maxValidDate * 1000)) { // 褰揿墠镞堕棿涔嫔悗镄勬棩链燂纴鎴栬€呭紑钖粺璁′箣鍓岖殑镞ユ湡
            tdClass = this.mOpts.theme + '_' + this.mOpts.disableGray;
            deviation = '2';
        } else { // 褰揿墠链堟棩链 
            deviation = '0';
            if(d.getDate() == dToday && d.getMonth() == mToday && d.getFullYear() == yToday) {
                if (true == this.mOpts.isTodayValid) {
                    tdClass = this.mOpts.theme + '_' + this.mOpts.isToday;
                } else {
                    tdClass = this.mOpts.theme + '_' + this.mOpts.disableGray;
                    deviation = '2';
                }
            }
			else {
                tdClass = '';
            }
			//璁╁懆链笉鍙€変笉鍙€ 
			if(this.mOpts.weekendDis && (d.getDay()==6 || d.getDay()==0)){
				tdClass = this.mOpts.theme + '_' + this.mOpts.disableGray;
				deviation = '3';
			}
			//璁╁懆鍑犱笉鍙€ 
			if(this.mOpts.disCertainDay && this.mOpts.disCertainDay.length > 0 ){
				for(var p in this.mOpts.disCertainDay){
					if(!isNaN(this.mOpts.disCertainDay[p]) && d.getDay() === this.mOpts.disCertainDay[p]){
						tdClass = this.mOpts.theme + '_' + this.mOpts.disableGray;
						deviation = '4';
					}
				}
			}
            //璁╁嚑鍙蜂笉鍙€ 
            if(this.mOpts.disCertainDate && this.mOpts.disCertainDate.length > 0 ){
                var isDisabled = false;

                for(var p in this.mOpts.disCertainDate){
                    if(!isNaN(this.mOpts.disCertainDate[p]) || isNaN(parseInt(this.mOpts.disCertainDate[p]))){
                        if ( this.mOpts.disCertainDate[0] === true ){
                            isDisabled = !!(d.getDate() !== this.mOpts.disCertainDate[p]);
                            if ( !isDisabled ){
                                break;
                            }
                        }else {
                            isDisabled = !!(d.getDate() === this.mOpts.disCertainDate[p]);
                            if ( isDisabled ){
                                break;
                            }
                        }

                    }
                }

                if ( isDisabled ){
                    tdClass = this.mOpts.theme + '_' + this.mOpts.disableGray;
                    deviation = '4';
                }

            }
        }

        // 濡傛灉鏄懆镞 
        if(0 == d.getDay()) {
            tr = document.createElement('tr');
        }

        td = document.createElement('td');
        td.innerHTML = d.getDate();
        if('' != tdClass) {
            $(td).attr('class', tdClass);
        }

        // 鍙湁褰揿墠链埚彲浠ョ偣鍑 
        if(0 == deviation) {
            ymd = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
            $(td).attr('id', __method.calendarId + '_' + ymd);
			$(td).css('cursor','pointer');
            (function(ymd) {
                $(td).bind("click", ymd, function() {
                    __method.selectDate(ymd);
                    return false;
                });
            })(ymd);
        }

        $(tr).append(td);

        // 濡傛灉鏄懆鍏 
        if(6 == d.getDay()) {
            $(table).append(tr);
        }
    }

    return table;
};

/**
 * @description 鎶婃椂闂村瓧涓茶浆鎴愭椂闂存牸寮 
 * @param {String} str 镞堕棿瀛楃涓 
 */ 
pickerDateRange.prototype.str2date = function(str) {
    var ar = str.split('-');
    // 杩斿洖镞ユ湡镙煎纺
    return new Date(ar[0], ar[1] - 1, ar[2]);
};

/**
 * @description 姣旇缉涓や釜镞堕棿瀛椾覆镄勫ぇ灏 :1 澶т簬; 0 绛変簬; -1 灏忎簬
 * @param {String} b 寰呮瘮杈冩椂闂翠覆1
 * @param {String} e 寰呮瘮杈冩椂闂翠覆2
 */
pickerDateRange.prototype.compareStrDate = function(b, e) {
    var bDate = this.str2date(b);
    var eDate = this.str2date(e);

    // 1 澶т簬; 0 绛変簬; -1 灏忎簬
    if(bDate.getTime() > eDate.getTime()) {
        return 1;
    } else if(bDate.getTime() == eDate.getTime()) {
        return 0;
    } else {
        return -1;
    }
};

/**
 * @description 鎶婃椂闂存牸寮忚浆鎴愬璞 
 * @param {Date} d 镞堕棿
 */ 
pickerDateRange.prototype.date2ymd = function(d) {
    return [d.getFullYear(), (d.getMonth() + 1), d.getDate()];
};

/**
 * @description 鍒囨崲鐒︾偣鍒板綋鍓嶈緭鍏ユ
 * @param {String} 镞ユ湡妗嗕綋ID
 */
pickerDateRange.prototype.changeInput = function(ipt) {
    // 寮哄埗淇敼涓哄紑濮嬭緭鍏ユ
    if (true == this.mOpts.isSingleDay) {
        ipt = this.startDateId;
    }
    // 镓€链 4涓緭鍏ユ
    var allInputs = [this.startDateId, this.startCompareDateId, this.endDateId, this.endCompareDateId];

    // 濡傛灉ipt 鏄棩链熻緭鍏ユ锛屽垯涓烘棩链熸牱寮忥纴钖﹀垯涓哄姣旀棩链熸牱寮 
    var cla = '';
    if(ipt == this.startDateId || ipt == this.endDateId) {
        cla = this.mOpts.theme + '_' + this.mOpts.selectCss;
    } else {
        cla = this.mOpts.theme + '_' + this.mOpts.compareCss;
    }
    if(ipt == this.endDateId && this.mOpts.singleCompare) {
        cla = this.mOpts.theme + '_' + this.mOpts.compareCss;
    }

    // 绉婚櫎镓€链夎緭鍏ユ镄勯梼锷犳牱寮 
    for(var i in allInputs) {
        $('#' + allInputs[i]).removeClass(this.mOpts.theme + '_' + this.mOpts.selectCss);
        $('#' + allInputs[i]).removeClass(this.mOpts.theme + '_' + this.mOpts.compareCss);
    }

    // 涓烘寚瀹氲緭鍏ユ娣诲姞镙峰纺
    $('#' + ipt).addClass(cla);
	//鑳屾櫙锲緍epeat
	$('#' + ipt).css('background-repeat', 'repeat');
    // 鎶婅緭鍏ョ剑镣圭Щ鍒版寚瀹氲緭鍏ユ
    this.dateInput = ipt;
};

/**
 * @description 镞ユ湡镙煎纺鍖栵纴锷犲墠瀵奸浂
 */ 
pickerDateRange.prototype.formatDate = function(ymd) {
    return ymd.replace(/(\d{4})\-(\d{1,2})\-(\d{1,2})/g, function(ymdFormatDate, y, m, d){
        if(m < 10){
            m = '0' + m;
        }
        if(d < 10){
            d = '0' + d;
        }
        return y + '-' + m + '-' + d;
    });
};

var queryURL="localhost:8080";
var queryType="";
var projectId="";
var datetype="";
var map = new Map();
var gongrenStatusMap=new Map();
var shuliangmap = new Map();
var countmap = new Map();
var statusmap=new Map();
var shigongyuanmap = new Map();
var shigongyuancountmap = new Map();
function Map() {
    this.arr = new Array();
    var struct = function(key, value) {
        this.key = key;
        this.value = value;
    };
    this.put = function(key, value){
        for (var i = 0; i < this.arr.length; i++) {
            if ( this.arr[i].key === key ) {
                this.arr[i].value = value;
                return;
            }
        }
        this.arr[this.arr.length] = new struct(key, value);
    };
    this.get = function(key) {
        for (var i = 0; i < this.arr.length; i++) {
            if ( this.arr[i].key === key ) {
                return this.arr[i].value;
            }
        }
        return null;
    };
    this.values=function(){
        var value=[]
        for (var i = 0; i < this.arr.length; i++) {
            value.push(this.arr[i].value);
        }
        return value.join(",");
    };
    this.remove = function(key) {
        var v;
        for (var i = 0; i < this.arr.length; i++) {
            v = this.arr.pop();
            if ( v.key === key ) {
                continue;
            }
            this.arr.unshift(v);
        }
    };
    this.size = function() {
        return this.arr.length;
    };
    this.isEmpty = function() {
        return this.arr.length <= 0;
    };
}
(function() {
	var calendarDate = {};
	var riliHtml = '';
	calendarDate.today = new Date();
	calendarDate.year = calendarDate.today.getFullYear(); //当前年
	calendarDate.month = calendarDate.today.getMonth() + 1; //当前月
	calendarDate.date = calendarDate.today.getDate(); //当前日
	calendarDate.day = calendarDate.today.getDay(); //当前几
	//绘制
	function getIndexDay() {
		isLeapYear();
		getDays();
		riliHtml = '';
		//本月一号几
		calendarDate.monthStart = new Date(calendarDate.year + "/" + calendarDate.month + "/1").getDay();
		//上个月所占空格数
		if(calendarDate.monthStart == 0) { //独占一行
			calendarDate.monthStart = 7;
		}
		//上月数据
		for(var i = calendarDate.monthStart; i > 0; i--) {
			var dataDateStr = calendarDate.lastYear + "-" + calendarDate.lastMonth + "-" + (calendarDate.lastDays - i + 1);
			riliHtml += '<div class="ht-rili-td ht-rili-td-disabled" name="weekplan" data-date="' + dataDateStr + '"><span class="ht-rili-day">' + (calendarDate.lastDays - i + 1) + '</span><span class="ht-rili-money"></span></div>'
		}
		
		//添加日期下面的数据
//		var pushdata={date:'2017-9-20',data:'120'}
//		
//		calendarDate.opt.data.push(pushdata)
//		console.log(calendarDate.opt.data)
		//本月数据
		for(var k = 0; k < calendarDate.days; k++) {
			var flag
			var dataDateStr = calendarDate.year + "-" + calendarDate.month + "-" + (k + 1);
			for(var d in calendarDate.opt.data) {
				var nowDate = dataDateStr;
				var dataDate = calendarDate.opt.data[d].date;
				flag = checkDate(nowDate, dataDate);
				if(flag) {
					//riliHtml += '<div class="ht-rili-td ht-rili-onclick" data-date="' + dataDateStr + '"><span class="ht-rili-day ">' + (k + 1) + '</span><span class="ht-rili-money" data-money="' + calendarDate.opt.data[d].data + '">' + calendarDate.opt.data[d].data + '</span></div>';
					riliHtml += '<div class="ht-rili-td ht-rili-onclick" name="weekplan" data-date="' + dataDateStr + '"><span class="ht-rili-day ">' + (k + 1) + '</span><span class="ht-rili-money" data-money="' + calendarDate.opt.data[d].data + '">' + '</span></div>';
					break;
				}
			}
			if(!flag) {

				riliHtml += '<div class="ht-rili-td ht-rili-td-disabled" name="weekplan" data-date="' + dataDateStr + '"><span class="ht-rili-day ">' + (k + 1) + '</span><span class="ht-rili-money"></span></div>';
			}


		}
		//下月数据
		for(var j = 0; j < (42 - calendarDate.days - calendarDate.monthStart); j++) { //42-已占用表格数=剩余表格数
			var dataDateStr = calendarDate.nextYear + "-" + calendarDate.nextMonth + "-" + (j + 1);
			riliHtml += '<div class="ht-rili-td ht-rili-td-disabled" name="weekplan" data-date="' + dataDateStr + '"><span class="ht-rili-day">' + (j + 1) + '</span><span class="ht-rili-money"></span></div>';
		}
		$('.ht-rili-body').append(riliHtml);
		$('.ht-rili-onclick').on('click', function() {
			dateClick(this);
		})
		
		
		var diri = $(".ht-rili-date").text().split("年")
				//点击时候的年月拼成数字
				var dirip = Number(diri[0]) * 100 + Number(diri[1].split("月")[0])
				//当前日期年月拼成数字
				var date = new Date;
				var year = date.getFullYear();
				var month = date.getMonth() + 1;
				month = (month < 10 ? "0" + month : month);
				var mydate = (year.toString() + month.toString());
		
		
			$('.ht-rili-td-disabled').on('click', function() {
				if(dirip<mydate){
					dateClick(this);
				}else if(dirip==mydate){
					if($(this).find(".ht-rili-day").hasClass("col")){
						dateClick(this);
					}
					
				}
			})
	}


	//是否是闰年
	function isLeapYear() {
		if((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0)) {
			calendarDate.isLeapYear = true;
		} else {
			calendarDate.isLeapYear = false;
		}
	}
	//日期点击事件
	function dateClick(obj) {

		$(obj).siblings().each(function() {
			$(this).removeClass('ht-rili-td-active');

		});
		$(obj).addClass('ht-rili-td-active');

        var number=obj.childNodes[1].innerHTML;
        console.log(obj.childNodes[1].innerHTML)
        if(!number){
            return;
        }

		//个位数月和日加0
		var Mo=""+calendarDate.month
		var zr_moth,zr_day
		if(calendarDate.month<10 && Mo.length<2){
			zr_moth="0"+calendarDate.month
		}else{
			zr_moth=calendarDate.month
		}
		var Da=""+$(obj).find("span").eq(0).text()
		if($(obj).find("span").eq(0).text()<10 && Da.length<2){
			zr_day="0"+$(obj).find("span").eq(0).text()
		}else(
			zr_day=$(obj).find("span").eq(0).text()
		)

		console.log(calendarDate.year+"-"+zr_moth+"-"+zr_day)
		setTimeout(function () {
            var date=calendarDate.year+"-"+zr_moth+"-"+zr_day;
            if (window.parent.document.getElementById("projectId")){
                window.parent.document.getElementById("projectId").value=projectId;
            }
			if (queryType=='gongren'){
                window.parent.parent.document.getElementById("showDate").value=date;
                window.parent.parent.document.getElementById("showType").value=queryType;
                var showRecord=window.parent.parent.document.getElementById("showRecord");
                showRecord.onclick();

			}else if (queryType=='gongzhang'){
                window.parent.document.getElementById("showDate").value=date;
                window.parent.document.getElementById("showType").value=queryType;
                var showRecord=window.parent.document.getElementById("showRecord");
                showRecord.onclick();
			}else if (queryType=='shigongyuan' ){
                window.parent.document.getElementById("showDate").value=date;
                window.parent.document.getElementById("showType").value=queryType;
                var showRecord=window.parent.document.getElementById("showRecord");
                showRecord.onclick();
            }


        },20)



	}
	//获取上个月份，本月，下个月份信息
	function getDays() {
		//上月天数
		if(parseInt(calendarDate.month) == 1) {
			calendarDate.lastDays = new Date(calendarDate.year - 1, 12, 0).getDate();
			calendarDate.lastMonth = new Date(calendarDate.year - 1, 12, 0).getMonth() + 1;
			calendarDate.lastYear = new Date(calendarDate.year - 1, 12, 0).getFullYear();
		} else {
			calendarDate.lastDays = new Date(calendarDate.year, calendarDate.month - 1, 0).getDate();
			calendarDate.lastMonth = new Date(calendarDate.year, calendarDate.month - 1, 0).getMonth() + 1;
			calendarDate.lastYear = new Date(calendarDate.year, calendarDate.month - 1, 0).getFullYear();
		}
		//下个月天数
		if(parseInt(calendarDate.month) == 12) {
			calendarDate.nextDays = new Date(calendarDate.year + 1, 1, 0).getDate();
			calendarDate.nextMonth = new Date(calendarDate.year + 1, 1, 0).getMonth() + 1;
			calendarDate.nextYear = new Date(calendarDate.year + 1, 1, 0).getFullYear();
		} else {
			calendarDate.nextDays = new Date(calendarDate.year, calendarDate.month + 1, 0).getDate();
			calendarDate.nextMonth = new Date(calendarDate.year, calendarDate.month + 1, 0).getMonth() + 1;
			calendarDate.nextYear = new Date(calendarDate.year, calendarDate.month + 1, 0).getFullYear();
		}
		//本月天数
		calendarDate.days = new Date(calendarDate.year, calendarDate.month, 0).getDate();
	}
	//检测时间是否一致
	function checkDate(dateStr1, dateStr2) {
		var date1 = dateStr1.split("-"); //[0]year,[1]month,[2]date;
		var date2 = dateStr2.split("-"); //[0]year,[1]month,[2]date;
		if(date1[1] < 10 && date1[1].length < 2) {
			date1[1] = "0" + date1[1];
		}
		if(date1[2] < 10 && date1[2].length < 2) {
			date1[2] = "0" + date1[2];
		}
		if(date2[1] < 10 && date2[1].length < 2) {
			date2[1] = "0" + date2[1];
		}
		if(date2[2] < 10 && date2[2].length < 2) {
			date2[2] = "0" + date2[2];
		}
		date1 = date1.join("-");
		date2 = date2.join("-");
		return date1 == date2;
	}

	$.fn.extend({
		calendar: function(opt) {
			if((opt.beginDate != undefined && opt.endDate != undefined) || (opt.data.length > 0)) {
				var date = new Date;
				var year = date.getFullYear() ;
				var month=date.getMonth()+1; 
				var day=date.getDate();
				var zr_date=''+year+"-"+month+"-"+day
				var zr_data='0'
				var pushdata={date:zr_date,data:zr_data}
				opt.data.push(pushdata)
				opt.data.shift()
				
				var beginDate = opt.data[0].date;
				var endDate = opt.data[opt.data.length - 1].date;
				calendarDate.beginYear = parseInt(beginDate.split('-')[0]); //起始年
				calendarDate.beginMonth = parseInt(beginDate.split('-')[1]); //起始月
				calendarDate.beginDate = parseInt(beginDate.split('-')[2]); //起始日

				calendarDate.endYear = parseInt(endDate.split('-')[0]); //结束年
				calendarDate.endMonth = parseInt(endDate.split('-')[1]); //结束月
				calendarDate.endDate = parseInt(endDate.split('-')[2]); //结束日

				calendarDate.year = parseInt(beginDate.split('-')[0]); //设置起始日期为当前日期
				calendarDate.month = parseInt(beginDate.split('-')[1]); //设置起始日期为当前日期
				calendarDate.date = parseInt(beginDate.split('-')[2]); //设置起始日期为当前日期
				calendarDate.opt = opt;

			} else {
				console.log('未传入beginDate或endDate！');
			}

            queryType=opt.showtypes;
            projectId=opt.projectId;
            datetype=opt.datetype;
            // console.log("获取查询类型",queryType)
            // console.log("获取查询类型",projectId)
            // console.log("获取查询类型",datetype)
			//加载容器                                                                                                                                                    //<strong class="ht-rili-title">' + opt.title + '</strong>
			calendarDate.container = '<div class="ht-rili-querybox"><div class="ht-rili-datebox"><span class="ht-rili-leftarr"></span><span class="ht-rili-date"></span><span class="ht-rili-rightarr"></span></div></div><div class="ht-rili-head"><div class="ht-rili-th">日</div><div class="ht-rili-th">一</div><div class="ht-rili-th">二</div><div class="ht-rili-th">三</div><div class="ht-rili-th">四</div><div class="ht-rili-th">五</div><div class="ht-rili-th">六</div></div><div class="ht-rili-body"><!--<div class="ht-rili-td"><span class="ht-rili-day">1</span><span class="ht-rili-money">&yen;100</span></div>--></div>'
			$(opt.ele).append(calendarDate.container);
			$('.ht-rili-date').html(calendarDate.year + '年 ' + calendarDate.month + '月');

			getIndexDay();
			//点击上个月
			$('.ht-rili-leftarr').on('click', function() {
				$('.ht-rili-body').html('');
				if(calendarDate.month == 1) {
					calendarDate.year -= 1;
					calendarDate.month = 12;
				} else {
					calendarDate.month -= 1;
				}
				$('.ht-rili-date').html(calendarDate.year + '年 ' + calendarDate.month + '月');

				getIndexDay();
				//设置黑色字体
				var daytime,zr_moth
				var diri = $(".ht-rili-date").text().split("年")
				//点击时候的年月拼成数字
				var dirip = Number(diri[0]) * 100 + Number(diri[1].split("月")[0])
				//当前日期年月拼成数字
				var date = new Date;
				var year = date.getFullYear();
				var month = date.getMonth() + 1;
				month = (month < 10 ? "0" + month : month);
				var mydate = (year.toString() + month.toString());
                var Mo=""+calendarDate.month
                if(calendarDate.month<10 && Mo.length<2){
                    zr_moth="0"+calendarDate.month
                }else{
                    zr_moth=calendarDate.month
                }
                var month=calendarDate.year+'-'+zr_moth;
                //显示当月周计划
                if (queryType=='shigongyuan' && datetype=='week'){
                    getWeekPlan();
                }
                getDataByMonth(month);
				if(dirip<mydate){
				for(var i = 0; i < 42; i++) {
					if($(".ht-rili-body div").eq(i).text() == 1) {
						//	    				$(".ht-rili-body div").eq(i).find("span").eq(0).addClass("col")
						if(calendarDate.month == 4 || calendarDate.month == 6 || calendarDate.month == 9 || calendarDate.month == 11) {
							daytime = 30
						} else if((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0) && calendarDate.month == 2) {
							daytime = 29
						} else if(calendarDate.month == 1 || calendarDate.month == 3 || calendarDate.month == 5 || calendarDate.month == 7 || calendarDate.month == 8 || calendarDate.month == 10 || calendarDate.month == 12) {
							daytime = 31
						} else if(!((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0)) && calendarDate.month == 2) {
							daytime = 28
						}
						for(var j = i; j < daytime + i; j++) {
							$(".ht-rili-body div").eq(j).find("span").eq(0).addClass("col")
							$(".ht-rili-body div").eq(j).find("span").eq(0).addClass("4444")
							$(".ht-rili-body div").eq(j).addClass("zrdian")
                            setData(calendarDate,j);
						}
						break
					}
					}	
				}
				//点击到当前月
				if(dirip==mydate){
                    //显示当月周计划
                    if (queryType=='shigongyuan' && datetype=='week'){
                        getWeekPlan();
                    }
                    var month=calendarDate.year + '-' + calendarDate.month;
                    if(calendarDate.month<10 && Mo.length<2){
                        month="0"+calendarDate.month
                    }else{
                        month=calendarDate.month
                    }
                    month=calendarDate.year+'-'+month;
                    getDataByMonth(month);
				for(var i = 0; i < 42; i++) {
					if($(".ht-rili-body div").eq(i).text() == 1) {
						var date = new Date;
							var day = date.getDate() ;
						if(calendarDate.month == 4 || calendarDate.month == 6 || calendarDate.month == 9 || calendarDate.month == 11) {
							daytime = 30
						} else if((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0) && calendarDate.month == 2) {
							daytime = 29
						} else if(calendarDate.month == 1 || calendarDate.month == 3 || calendarDate.month == 5 || calendarDate.month == 7 || calendarDate.month == 8 || calendarDate.month == 10 || calendarDate.month == 12) {
							daytime = 31
						} else if(!((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0)) && calendarDate.month == 2) {
							daytime = 28
						}
						for(var j = i; j < day + i; j++) {
							$(".ht-rili-body div").eq(j).find("span").eq(0).addClass("col")
                            setData(calendarDate,j);
                            $(".ht-rili-body div").eq(day+i-1).find(".col").css({"background":"#4ba9e9","border-radius":"50%"})
						}
						break

					}
					}
				}
				
				
			})
			//点击下个月
			$('.ht-rili-rightarr').on('click', function() {
				$('.ht-rili-body').html('');
				if(calendarDate.month == 12) {
					calendarDate.year += 1;
					calendarDate.month = 1;
				} else {
					calendarDate.month += 1;
				}
				$('.ht-rili-date').html(calendarDate.year + '年 ' + calendarDate.month + '月');
				console.log("当前日期",calendarDate.year + '年 ' + calendarDate.month + '月')
				getIndexDay();
                var Mo=""+calendarDate.month
                var zr_moth
                if(calendarDate.month<10 && Mo.length<2){
                    zr_moth="0"+calendarDate.month
                }else{
                    zr_moth=calendarDate.month
                }
                var month=calendarDate.year+'-'+zr_moth;
				//显示当月周计划
                if (queryType=='shigongyuan' && datetype=='week'){
                    getWeekPlan();
                }
                getDataByMonth(month);
                var diri = $(".ht-rili-date").text().split("年")
				//点击时候的年月拼成数字
				var dirip = Number(diri[0]) * 100 + Number(diri[1].split("月")[0])
				//当前日期年月拼成数字
				var date = new Date;
				var year = date.getFullYear();
				var month = date.getMonth() + 1;
				month = (month < 10 ? "0" + month : month);
				var mydate = (year.toString() + month.toString());
				if(dirip < mydate) {
					var daytime
					for(var i = 0; i < 42; i++) {
						
						if($(".ht-rili-body div").eq(i).text() == 1) {
							if(calendarDate.month == 4 || calendarDate.month == 6 || calendarDate.month == 9 || calendarDate.month == 11) {
								daytime = 30
							} else if((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0) && calendarDate.month == 2) {
								daytime = 29
							} else if(calendarDate.month == 1 || calendarDate.month == 3 || calendarDate.month == 5 || calendarDate.month == 7 || calendarDate.month == 8 || calendarDate.month == 10 || calendarDate.month == 12) {
								daytime = 31
							} else if(!((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0)) && calendarDate.month == 2) {
								daytime = 28
							}
							for(var j = i; j < daytime + i; j++) {

								$(".ht-rili-body div").eq(j).find("span").eq(0).addClass("col")
                                setData(calendarDate,j);
							}
							break

						}
					}
				}
				//点击到当月时候
				if(dirip == mydate) {
                    //显示当月周计划
                    if (queryType=='shigongyuan' && datetype=='week'){
                        getWeekPlan();
                    }
                    var month=calendarDate.year+'-'+calendarDate.month;
                    if(calendarDate.month<10 && Mo.length<2){
                        month="0"+calendarDate.month
                    }else{
                        month=calendarDate.month
                    }
                    month=calendarDate.year+'-'+month;
                    getDataByMonth(month);
					var daytime
					for(var i = 0; i < 42; i++) {
						if($(".ht-rili-body div").eq(i).text() == 1) {

							var date = new Date;
							var day = date.getDate() ;
							if(calendarDate.month == 4 || calendarDate.month == 6 || calendarDate.month == 9 || calendarDate.month == 11) {
								daytime = 30
							} else if((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0) && calendarDate.month == 2) {
								daytime = 29
							} else if(calendarDate.month == 1 || calendarDate.month == 3 || calendarDate.month == 5 || calendarDate.month == 7 || calendarDate.month == 8 || calendarDate.month == 10 || calendarDate.month == 12) {
								daytime = 31
							} else if(!((calendarDate.year % 4 == 0) && (calendarDate.year % 100 != 0 || calendarDate.year % 400 == 0)) && calendarDate.month == 2) {
								daytime = 28
							}
							for(var j = i; j < day+i; j++) {

								$(".ht-rili-body div").eq(j).find("span").eq(0).addClass("col")
								$(".ht-rili-body div").eq(j).find("span").eq(1).addClass("200")

                                setData(calendarDate,j);

                                $(".ht-rili-body div").eq(day+i-1).find(".col").css({"background":"#4ba9e9","border-radius":"50%"})
							}
							break

						}
					}
				}
				
				

			})


			//显示当月周计划
            if (queryType=='shigongyuan' && datetype=='week'){
                getWeekPlan();
            }
            var Mo=""+calendarDate.month
            var month=calendarDate.year + '-' + calendarDate.month;
            if(calendarDate.month<10 && Mo.length<2){
                month="0"+calendarDate.month
            }else{
                month=calendarDate.month
            }
            month=calendarDate.year+'-'+month;
            getDataByMonth(month);
			//当前月 加载
			for(var i = 0; i < 42; i++) {
						if($(".ht-rili-body div").eq(i).text() == 1) {
                            var date = new Date;
                            var day = date.getDate() ;
                            // console.log("当前月日期",calendarDate.year + '年 ' + calendarDate.month + '月')
							// console.log("type",queryType)
							for(var j = i; j < day+i; j++) {
                                setData(calendarDate,j);
							}
							$(".ht-rili-body div").eq(day+i-1).attr("class","ht-rili-td ht-rili-onclick");
							break

						}
			}

		},
		calendarGetActive: function() { //获取当前选中日期的值
			//未选中时返回undefined
			var data
			var activeEle = $(this).find(".ht-rili-td-active");
			var date = activeEle.attr("data-date");
			var money = activeEle.children(".ht-rili-money").attr("data-money");
			return data = {
				date: date,
				money: money
			}
		}
	});
})(jQuery)

/**
 * 根据月份显示每天的日期
 * @param calendarDate
 * @param j
 * @returns {string}
 */
function  getDay(calendarDate,j) {
    var dayObj=$(".ht-rili-body div").eq(j);
    var Mo=""+calendarDate.month
    var zr_moth,zr_day
    if(calendarDate.month<10 && Mo.length<2){
        zr_moth="0"+calendarDate.month
    }else{
        zr_moth=calendarDate.month
    }
    var Da=""+dayObj.find("span").eq(0).text()
    if(dayObj.find("span").eq(0).text()<10 && Da.length<2){
        zr_day="0"+dayObj.find("span").eq(0).text()
    }else(
        zr_day=dayObj.find("span").eq(0).text()
    )

    var everyDate=calendarDate.year+"-"+zr_moth+"-"+zr_day;
    return everyDate;
}

function reload() {
	history.go(0)
}

function getDataByMonth(month) {
	console.log("日历类型",queryType)
	console.log("当前登陆人id",BackCookie.getCookie("userid"))
    var username = decodeURI(getCookie("username"));
    if (queryType=='gongren'){
         map = new Map();
        gongrenStatusMap = new Map();
	}else if (queryType=='gongzhang'){
        shuliangmap = new Map();
        countmap = new Map();
        statusmap=new Map();
	}
    else if (queryType=='shigongyuan'){
        shigongyuanmap = new Map();
        shigongyuancountmap = new Map();
        var projectIds="";
        if (datetype=='week'){
            projectIds= projectId
		}else {
			projectIds =  getProjectInfo();
            if (projectIds.length>0){
                projectIds=projectIds.join(",");
            }
		}
        projectId=projectIds;
	}
    console.log("项目ID",projectId)
    $.ajax({
        type: "get",
        async: false,
        url: "/attendance_api/calendar_commonList",
        data: {
            "userid":BackCookie.getCookie("userid"),
            "type":queryType,
            "month":month,
			"projectId":projectId
        },
        datatype: "json",
        success: function(data) {
            var resultData=data.result;
           console.log("查询结果",resultData)
            if (resultData){

                for (var i=0;i<resultData.length;i++){
                    if (queryType=='gongren'){
                        var gognrenshuliang=map.get(resultData[i].dateStr);
                    	if(gognrenshuliang){
                            map.put(resultData[i].dateStr,gognrenshuliang+resultData[i].shuliang);
						}else {
                            map.put(resultData[i].dateStr,resultData[i].shuliang);
						}
                        gongrenStatusMap.put(resultData[i].dateStr,resultData[i].statusConfirm);
                    }else if (queryType=='gongzhang'){
                    	var dateStr= resultData[i].dateStr;
                        var shuliangDate=shuliangmap.get(resultData[i].dateStr);
                        var countDate=countmap.get(resultData[i].dateStr);
                        var statusDate=statusmap.get(resultData[i].dateStr);
                        if(shuliangDate){
                            shuliangmap.put(resultData[i].dateStr,shuliangmap.get(resultData[i].dateStr)+resultData[i].shuliang)
                        }else {
                            shuliangmap.put(resultData[i].dateStr,resultData[i].shuliang)
                        }
                        if(countDate){
                            countmap.put(resultData[i].dateStr,countmap.get(resultData[i].dateStr)+1)
                          //  console.log("累计",resultData[i].dateStr,countmap.get(resultData[i].dateStr))
                        }else {
                          //  countmap.put("单个",resultData[i].dateStr)
                            countmap.put(resultData[i].dateStr,1)
                        }
                        if(statusDate){
                            statusmap.put(resultData[i].dateStr,statusmap.get(resultData[i].dateStr)+","+resultData[i].statusConfirm)
                        }else {
                            statusmap.put(resultData[i].dateStr,resultData[i].statusConfirm)
                        }

                    }else if (queryType=='shigongyuan'){

                        var date=shigongyuanmap.get(resultData[i].dateStr);
                        if(date){
                            shigongyuanmap.put(resultData[i].dateStr,shigongyuanmap.get(resultData[i].dateStr)+1)
                        }else {
                            shigongyuanmap.put(resultData[i].dateStr,1)
                        }
                        var statusDate=statusmap.get(resultData[i].dateStr);
                        if(statusDate){
                            statusmap.put(resultData[i].dateStr,statusmap.get(resultData[i].dateStr)+","+resultData[i].statusConfirmProjectmember)
                        }else {
                            statusmap.put(resultData[i].dateStr,resultData[i].statusConfirmProjectmember)
                        }

                        if (resultData[i].statusConfirmProjectmember==1){
                            shigongyuancountmap.put(resultData[i].dateStr,shigongyuancountmap.get(resultData[i].dateStr)+1);
                        }
                    }

                }
               // console.log("map结果",shigongyuancountmap)

            }

        },
        error: function() {
            alert("err")

        }
    });
}


function  getStatus(status) {
	//console.log("状态",status)
	var rtnFlag=0;
	for (var i=0;i<status.length;i++){
			if (status[i]=='0'){
                rtnFlag=0;
			}
            else if (status[i]=='1'){
                rtnFlag=1;
                break;
            }
	}
	if (rtnFlag==1){
        for (var i=0;i<status.length;i++){
            if (status[i]=='1'){
                rtnFlag=1;
            }
            else if (status[i]!='1'){
                rtnFlag=2;
            }
        }
	}
    //console.log("返回",rtnFlag)
    return rtnFlag
}


/**
 * 获取项目信息
 * @returns {*}
 */
function getProjectInfo() {
    var objAry=[];
    $.ajax({
        type: "get",
        url: "/trans_api/get_projectinfo",
        async: false,
        data: {
            "userid": BackCookie.getCookie("userid")
        },
        datatype: "json",
        success: function (data) {
            var result = data.result;

            for (var i = 0; i < result.length; i++) {
                objAry.push(result[i].projectId);
            }

        },

        error: function () {
            alert("eee")
            cmApi.message("err")
        }
    });

    return objAry;
}


function setData(calendarDate,j) {
    var everyDate=getDay(calendarDate,j);
    var number=0;
    var count=0;
    var querenCount=0;
    $(".ht-rili-body div").eq(j).find("span").eq(0).addClass("col")
    if (queryType=='gongren'){
        var status=0;
        if(map.get(everyDate)!=null){
            number=map.get(everyDate);
            status=gongrenStatusMap.get(everyDate);
            if(status==0){//未确认
                $(".ht-rili-body div").eq(j).attr("class","ht-rili-td ht-rili-td-disabled sign")
			}else {//已确认
                $(".ht-rili-body div").eq(j).attr("class","ht-rili-td ht-rili-td-disabled sign confirm")
			}

			if(number==0 ){
            	if(status==1){
                    $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money low")
                }else {
                    $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money")
				}
			}else if (number>1){
                $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money high")
			}
            //$(".ht-rili-body div").eq(j).find(".col").css({"background":"rgba(221, 82, 77, 0.58)","border-radius":"50%"})
            $(".ht-rili-body div").eq(j).find("span").eq(1).html(number)
        }
    }else if (queryType=='gongzhang'){
        if (shuliangmap.get(everyDate)!=null){
            number=shuliangmap.get(everyDate);
           // number=Number(number).toFixed(1);
        }
        if (countmap.get(everyDate)!=null){
            count=countmap.get(everyDate);

        }
        if (shuliangmap.get(everyDate)!=null || countmap.get(everyDate)!=null){
            if(number==count){
                $(".ht-rili-body div").eq(j).find("span").eq(1).html(number)
            }else {
                $(".ht-rili-body div").eq(j).find("span").eq(1).html(number+"/"+count)
            }
        }

        if (statusmap.get(everyDate)!=null){

            var status = statusmap.get(everyDate).split(",");
            if (getStatus(status)==0){//未确认
               // $(".ht-rili-body div").eq(j).find(".col").css({"background":"rgba(221, 82, 77, 0.58)","border-radius":"50%"})
                $(".ht-rili-body div").eq(j).attr("class","ht-rili-td ht-rili-td-disabled sign");
            }else if (getStatus(status)==1){//全部确认
               // $(".ht-rili-body div").eq(j).find(".col").css({"background":"#4cd964","border-radius":"50%"})
               $(".ht-rili-body div").eq(j).attr("class","ht-rili-td ht-rili-td-disabled sign confirm")
            }else if (getStatus(status)==2){//部分确认
                // $(".ht-rili-body div").eq(j).find(".col").css({"background":"#f39826","border-radius":"50%"})
                 $(".ht-rili-body div").eq(j).attr("class","ht-rili-td ht-rili-td-disabled sign confirm-half")
                //$(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money low")
            }

            if(number>count){
                $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money high")
            }else if(number<count){
                $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money low")
			}
        }

    }else if (queryType=='shigongyuan'){
    //	console.log("施工员日历",shigongyuanmap)
        if(shigongyuanmap.get(everyDate)!=null || shigongyuancountmap.get(everyDate)!=null){
        	if (shigongyuanmap.get(everyDate)!=null){
                number=shigongyuanmap.get(everyDate);
                //number=Number(number).toFixed(1);
            }
        	if (shigongyuancountmap.get(everyDate)!=null){
                querenCount=shigongyuancountmap.get(everyDate);
               // querenCount=Number(querenCount).toFixed(1);
            }

            if(number==querenCount){

                $(".ht-rili-body div").eq(j).find("span").eq(1).html(number)
            }else {
                $(".ht-rili-body div").eq(j).find("span").eq(1).html(querenCount+"/"+number)

            }

        }
        if (statusmap.get(everyDate)!=null){
            var status = String(statusmap.get(everyDate)).split(",");
            if (getStatus(status)==0){//未确认
                $(".ht-rili-body div").eq(j).attr("class","ht-rili-td ht-rili-td-disabled sign");
                //$(".ht-rili-body div").eq(j).find(".col").css({"background":"rgba(221, 82, 77, 0.58)","border-radius":"50%"})
            }else if (getStatus(status)==1){//全部确认
                $(".ht-rili-body div").eq(j).attr("class","ht-rili-td ht-rili-td-disabled sign confirm")
               // $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money high")
               // $(".ht-rili-body div").eq(j).find(".col").css({"background":"#4cd964","border-radius":"50%"})
            }else if (getStatus(status)==2){//部分确认
               // $(".ht-rili-body div").eq(j).find(".col").css({"background":"#f39826","border-radius":"50%"})
                $(".ht-rili-body div").eq(j).attr("class","ht-rili-td ht-rili-td-disabled sign confirm-half")
               // $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money low")
            }
        }


        if(querenCount>number){
            $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money high")
		}else if (querenCount<number){
            $(".ht-rili-body div").eq(j).find(".ht-rili-money").attr("class","ht-rili-money low")
		}
    }




}

/**
 * 显示每周计划
 */
function getWeekPlan() {
    loading("努力加载...")
    var weeks=[];
    var plan=$("div[name='weekplan']");
    //第一行日历
    var plan1_start = plan[0].getAttribute("data-date");
    var plan1_end =plan[6].getAttribute("data-date");
    //第二行日历
    var plan2_start = plan[7].getAttribute("data-date");
    var plan2_end =plan[13].getAttribute("data-date");
    //第三行日历
    var plan3_start = plan[14].getAttribute("data-date");
    var plan3_end =plan[20].getAttribute("data-date");
    //第四行日历
    var plan4_start =plan[21].getAttribute("data-date");
    var plan4_end =plan[27].getAttribute("data-date");
    //第五行日历
    var plan5_start =plan[28].getAttribute("data-date");
    var plan5_end =plan[34].getAttribute("data-date");
    //第六行日历
    var plan6_start =plan[35].getAttribute("data-date");
    var plan6_end =plan[41].getAttribute("data-date");
    var obj1=new Object();
    obj1.start=plan1_start;
    obj1.end=plan1_end;
    var obj2=new Object();
    obj2.start=plan2_start;
    obj2.end=plan2_end;
    var obj3=new Object();
    obj3.start=plan3_start;
    obj3.end=plan3_end;
    var obj4=new Object();
    obj4.start=plan4_start;
    obj4.end=plan4_end;
    var obj5=new Object();
    obj5.start=plan5_start;
    obj5.end=plan5_end;
    var obj6=new Object();
    obj6.start=plan6_start;
    obj6.end=plan6_end;
    weeks.push(obj1)
    weeks.push(obj2)
    weeks.push(obj3)
    weeks.push(obj4)
    weeks.push(obj5)
    weeks.push(obj6)
    //console.log(weeks)
    //console.log("返回结果",result)

    var planhtml='<li></li>' +'<li style="font-size: 13px;">计划</li>';
	var result = getWeekPlanData(weeks)
    for (var k=0;k<result.length;k++){
     var div = '<div class="ht-rili-td ht-rili-td-disabled" name="plan"  style=" clear: both; color: #ff4d65; ">'+
        '<span  class="ht-rili-day">'+result[k]+'</span><span class="ht-rili-money"></span>' +
		'</div>'
        planhtml+=div;
    }
    var html='<ul id="left-calendar" class="left_rili">'+'</ul>';
    $(".calendar-box").before(html)
    $("#left-calendar").html(planhtml);
    setTimeout(function () {
        $("#left-calendar").css("height",Number(document.getElementById("calendar").offsetHeight)-2)
    },500)
    setTimeout(function () {
        layer.closeAll();
    },500)
}



/**
 * 获取周计划
 * @returns {*}
 */
function getWeekPlanData(weeks) {
	//var weekStr=encodeURIComponent(JSON.stringify(weeks))
    var weekStr=JSON.stringify(weeks)
	console.log("weeks",weeks)
    var result =[];
    $.ajax({
        type: "get",
        url: "/attendance_api/get_week_plan",
        async: false,
        data: {
            "UserId": BackCookie.getCookie("userid"),
			"monthStr":weekStr,
			"type":"shigongyuan",
			"projectId":projectId
        },
        datatype: "json",
        success: function (data) {
             result = data.result;
        	//console.log("查询结果",data)
        },

        error: function () {
            alert("eee")
            cmApi.message("err")
        }
    });

    return result;
}
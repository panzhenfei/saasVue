var confirmDoc = {
	init: function(usertype,userId, thisDocId, confirmDocId, tableName, btuText, Fn, isConfirmFn, Fx) {

		if(userId == undefined || userId == "" || thisDocId == undefined || thisDocId == "" || confirmDocId == undefined || confirmDocId == "") {
			console.log("缺少初始参数");
			return;
		}

		confirmDoc.verify(userId, thisDocId, confirmDocId, tableName, function(t) {

			confirmDoc.createConfirmBtu(usertype,thisDocId, t, btuText, Fn, isConfirmFn);

		});

	},
	createConfirmBtu: function(usertype,thisDocId, tableName, btuText, Fn, isConfirmFn) {

		var div1 = document.createElement("div");
		div1.id = "confirmBtu";
		div1.className = "fixed-bottom";

		var div2 = document.createElement("div");
		div2.className = "mui-table mui-text-center";

		var div3 = document.createElement("div");
		div3.className = "mui-table-cell";

		var botton1 = document.createElement("botton");
		botton1.type = "button";
		botton1.className = "mui-btn mui-btn-primary";
		botton1.style = "padding-top: 15px;";
		botton1.innerHTML = btuText == "" ? "确认" : btuText;
		botton1.onclick = function() {
            if(usertype=='projectmanage'){//项目经理确认
            var dateqr = document.getElementById("DateQueren1");
            var date="";
            if(dateqr){
                date=dateqr.innerHTML;
            }
            if(!date) {
                msg("请选择确认日期");
                return false;
            }
                var upload=document.getElementById("uploadFile");
                if(upload){
                    if(!uploadFile.getUploadIds()){
                        msg("请上传附件");
                        return false;
                    }

                }
			}

            confirmLayer("是否确认？",function () {
                var isconfirm = true;
                if((typeof isConfirmFn) == "function") {
                    if(isConfirmFn) {
                        isconfirm = isConfirmFn();
                    }

                }

                if(isconfirm != true) {
                    return;
                }

                $.ajax({
                    type: "post",
                    url: "/sass_api/update_confirm_doc",
                    data: {
                        "docId": thisDocId,
                        "tableName": tableName
                    },

                    datatype: "json",
                    success: function(data) {
                        console.log(data)
                        var code = data.code;
                        Fn && Fn(code);
						/*if(code == 200) {
						 msg("确认成功");
						 confirmDoc.hiddenBtu();
						 }*/
                    }
                });
            })


		}
		div3.appendChild(botton1);
		div2.appendChild(div3);
		div1.appendChild(div2);

		var section = document.getElementsByTagName("section")[0];

		if(section != null && section != undefined) {
			var p = section.parentNode;
			p.insertBefore(div1, section);

		}

	},
	hiddenBtu: function() {
		var confirmBtu = document.getElementById("confirmBtu");
		if(confirmBtu != null && confirmBtu != undefined) {
			confirmBtu.style.display = "none";

		}

	},
	verify: function(userId, thisDocId, confirmDocId, tableName, Fn, Fx) {

		$.ajax({
			type: "post",
			url: "/sass_api/get_confirm_info",
			data: {
				//"userId": Number(getCookie("userid"))
				"confirmDocId": confirmDocId,
				"docId": thisDocId
			},
			datatype: "json",
			success: function(data) {

				if(data.result.confirmValue == "0" && userId == data.result.confirmPersonID) {
					Fn && Fn(tableName);

				} else {

					Fx && Fx(tableName);
				}

			},
			error: function() {
				alert("连接错误")

			}
		});

	},
	createConfirmStatus: function() {

	},
	createHead: function(n) {

		var div1 = document.createElement("div");
		div1.className = "bill-title";
		var span1 = document.createElement("span");
		span1.className = "title";
		span1.innerHTML = "";

		div1.appendChild(span1);
		return div1

	}
};

//*************附件上传
function getfile() {
    if (uploadFile.getUploadIds() == "" || uploadFile.getUploadIds() == null) {
        msg("请上传附件")
        return false;
    }
    return true;
}
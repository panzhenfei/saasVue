var appServer = '/project_work_api/test_request_server';//STS授权服务端
var urllib = OSS.urllib;
var OSS = OSS.Wrapper;
var STS = OSS.STS;
var client;
var OSSData = {
    loadkey:function () {
        $.ajax({
            type: "post",
            url: getUrl()+appServer,
            async: false,
            data: {},
            datatype: "json",
            success: function(data) {
                console.log("授权",data)
                client = new OSS({
                    endpoint:"https://oss-cn-shenzhen.aliyuncs.com",
                    region: 'https://bucketjianyun.oss-cn-shenzhen.aliyuncs.com',
                    accessKeyId: 'LTAIW2i5hWnpFkEB',
                    accessKeySecret: 'oHGyrSuOBNO6DoQVCroZcQsD7nMKoK',
                    bucket: 'bucketjianyun'
                });
            },
            error: function() {
                console.log("err")
            }
        });
    },
    signatureBigUrl:function (key) {
        if(!key){
            return null;
        }
       return client.signatureUrl(key,{expires: 600, process : 'image/resize,w_30'});
    },
    signatureSmallUrl:function (key) {
        if(!key){
            return null;
        }
        var  strff =key.substring(key.indexOf("."),key.length);
        key=key.substring(0,key.indexOf("."));
        key=key+"_small"+strff;
       return client.signatureUrl(key,{expires: 600, process : 'image/resize,w_30'});
    },
    signatureThumbnailUrl:function (key) {
        if(!key){
            return null;
        }
        var  strff =key.substring(key.indexOf("."),key.length);
        key=key.substring(0,key.indexOf("."));
        key=key+"_96x96"+strff;
       return client.signatureUrl(key,{expires: 600, process : 'image/resize,w_30'});
    }
}


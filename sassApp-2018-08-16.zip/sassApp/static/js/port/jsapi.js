/*window.appApi.getUserInfo();

window.appApi.callBackFun = function(callFlag, CONTENT) {
	alert(callFlag)
	if(callFlag == appApi.callBackFlag.USER_INFO) {
		alert(JSON.stringify(CONTENT))
	}
}*/
try {
	window.appApi.cleanLocalWebCache();
} catch(e) {
	//TODO handle the exception
	console.log("不存在app的方法")
}

var domain = "http://java.winfreeinfo.com:9013";

var userStr = undefined;
var setUserInfoResult = function(result, iosIfrObjStrT) {
	userStr = result;
}

var baseFunction = {
	jsonp: function(u, dataJson, Fn) {

		$.ajax({
			url: u,
			type: 'post',
			dataType: 'jsonp',
			jsonp: "callback",
			data: dataJson,
			success: function(data) {
				Fn && Fn(data);
			},
			error: function(data) {
				console.error("连接失败 ");
			}
		});
	}

};

var methodFunction = {
	getUserId: function(ticket, FN) {

		var userStatus = window.appApi.getUserInfo();

		var s = setInterval(function() {
			//ios 是异步的方法,安卓的是同步的所以要判断用户值
			//alert(userStr)
			if(userStatus == "设备不支持获取用户信息") {
				FN && FN("设备不支持获取用户信息");
				clearInterval(s);
				return;
			} else {
				if(userStatus != undefined && userStatus.indexOf("}") >= 0) {
					userStr = userStatus;
				}
			}
			if(userStr != undefined) {
				clearInterval(s);
			}

			var userinfo = JSON.parse(userStr);
			var checkUrl = domain + "/verify/ticket";
			baseFunction.jsonp(checkUrl, {
				"ticket": ticket,
				"userid": userinfo.userCode
			}, function(data) {
				var code = data.code;
				console.log(data)

				if(code == 0) {
					var userid = data.id;
					console.log(userid)
					FN && FN(userid);

				} else {
					console.log(data.message);
					alert("没有权限或者没有用户");
				}

			});

		}, 500);

	},
	getUserIdTest: function(ticket, FN) {

		baseFunction.jsonp("http://java.winfreeinfo.com:9013/verify/ticket", {
			"ticket": ticket,
			"userid": "10421"
		}, function(data) {
			var code = data.code;
			console.log(data)
			console.log(code)

			if(code == 0) {
				var userid = data.id;
				console.log(userid)
				FN && FN(userid);

			} else {
				console.log(data.message);
				alert("没有权限或者没有用户");
			}

		});

	}
};

var jy = {
	method: methodFunction,
	base: baseFunction
};
/*配置要加载的js*/
// var require = {
//     baseUrl : '/resources/js',
//     paths : {
//         // 搜索
//         "search" : 'buyer/search/search',
//         "template" : 'template.min',
//         "loadGoods" : 'buyer/search/loadGoods',
//         "analysis" : 'buyer/search/analysis'
//     },
//     shim: {
//         // "jquery": {
//         //     exports : "$"
//         // },
//         // "amplify": {
//         //     exports : "amplify"
//         // },
//         // "ckeditor": {
//         //     exports : "ckeditor"
//         // }
//     }
// };
require.config({
        baseUrl : '/static',
        paths : {
            // 搜索
            "search" : 'webstatic/search/js/search',
            "template" : 'js/template/template.min',
            "loadGoods" : 'webstatic/search/js/loadGoods',
            "analysis" : 'webstatic/search/js/analysis',

            "search_m" : 'webstatic/search/js/material/search_m',
            "loadGoods_m" : 'webstatic/search/js/material/loadGoods_m',

            "search_mi" : 'webstatic/search/js/materialInfo/search_mi',
            "loadGoods_mi" : 'webstatic/search/js/materialInfo/loadGoods_mi',

            "search_labour" : 'webstatic/search/js/labour/search_labour',
            "loadGoods_labour" : 'webstatic/search/js/labour/loadGoods_labour',

            "search_contact" : 'webstatic/search/js/contact/search_contact',
            "loadGoods_contact" : 'webstatic/search/js/contact/loadGoods_contact'
        },
        shim: {
            // "jquery": {
            //     exports : "$"
            // },
            // "amplify": {
            //     exports : "amplify"
            // },
            // "ckeditor": {
            //     exports : "ckeditor"
            // }
        }
});


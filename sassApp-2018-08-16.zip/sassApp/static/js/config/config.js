/*--------通用常量配置--------*/
// 当前访问的地址
var curr_url = window.location.href;

/****** sunline平台 ******/
var TITLEBAR_TEXT="蜘筑侠";
// sunline域名
var SUNLINE_SERVER_ADDRESS = "";
//上传服务器地址
var UPLOAD_SERVER_ADDRESS = '';
/****** sunline平台 ******/

/****** 好思平台 ******/
// 好思域名
var HAOSI_SERVER_ADDRESS = '';
// 好思域名关键部分截取
var HAOSI_SERVER_SHORT = '';
// 好思域名通配符
var HAOSI_TONGPEIFU = '@hs//';
// 好思域名通配符数组（或者需要被替换的字符，此处地址域名无需修改）
var HAOSI_REPLACE = ["@hs/", "http://haosi.winfreeinfo.com:9001"];
/****** 好思平台 ******/

var DEVICE_FLAG = "saaspro";

var DOWN_LOAD_APP_URL = getUrl() + "/static/webstatic/mycenter/ext/share_detail.html";

// 安卓下载地址
var ANDROID_URL = "";

// IOS下载地址
var IOS_URL = "";


var SHARE_OPERATE = {
	DISH_SHARE: 1,
	VIDEO_SHARE: 2
}

if(curr_url.indexOf("https://m.cloudccif.com") > -1) {
    SUNLINE_SERVER_ADDRESS = "https://m.cloudccif.com";
	HAOSI_SERVER_ADDRESS = "https://haosi.cloudccif.com";
	HAOSI_SERVER_SHORT = "https://haosi";
	ANDROID_URL = "http://17120431944.fx.sj.360.cn/qcms/view/t/detail?id=3914913&appinstall=0"; // 360
    IOS_URL = "https://itunes.apple.com/cn/app/id1296162995?mt=8";
    UPLOAD_SERVER_ADDRESS = "https://m.cloudccif.com:8000";
    // ANDROID_URL = "http://shouji.baidu.com/software/22848501.html";  // 百度
} else {
    SUNLINE_SERVER_ADDRESS = "http://java.winfreeinfo.com";
	HAOSI_SERVER_ADDRESS = "http://haosi.winfreeinfo.com:9001"
	HAOSI_SERVER_SHORT = "http://haosi";
	ANDROID_URL = "https://www.pgyer.com/jyxr";
	IOS_URL = "https://www.pgyer.com/jyxr";
    UPLOAD_SERVER_ADDRESS = "http://res.winfreeinfo.com:8000";
}

//获取上下文路径
function getUrl() {
	var url = curr_url;
	var str1 = url.substr(url.indexOf("/") + 2, url.length - 1);
	var index = str1.indexOf("/") + url.indexOf("/") + 2;
	return url.substr(0, index);
}

// 获取页面上下文的路径
function getPagePath() {
	return getUrl() + "/static/webstatic";
}

function getCookie(name) {
	var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
	if(arr != null)
		return arr[2];
	return null;
}

function setCookie(name) {
	var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
	if(arr != null)
		return arr[2];
	return null;
}

//获取访问工具内核
var browser = {
	versions: function() {
		var u = navigator.userAgent,
			app = navigator.appVersion;
		return { //移动终端浏览器版本信息
			trident: u.indexOf('Trident') > -1, //IE内核
			presto: u.indexOf('Presto') > -1, //opera内核
			webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
			gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
			mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
			ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
			android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或uc浏览器
			iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
			iPad: u.indexOf('iPad') > -1, //是否iPad
			webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
		};
	}(),
	language: (navigator.browserLanguage || navigator.language).toLowerCase()
}

window.onload = function() {
	var tab_list = document.getElementById("tab_list_id");
	var rollback = document.getElementById("rollback_id");
	if(browser.versions.ios || browser.versions.android) { //如果是app打开,隐藏
		if(tab_list != null) {
			tab_list.setAttribute("style", "display:none");
		}
		if(rollback != null) {
			rollback.setAttribute("style", "display:none");
		}
	} else {
		if(tab_list != null) {
			tab_list.setAttribute("style", "display:block");
		}
		if(rollback != null) {
			rollback.setAttribute("style", "display:block");
		}
	}

}

/**
 * 插件功能：前端基础配置。
 * 插件作者：Cyrus
 */
var latestVer="2018/08/13 15:24:02";
var cfg = window.cfg || {};
cfg = {
	// 普通资源
	resVerUrl:{
		css:{
			common:{

			},
			laowu:{

			},
			calendar:{
				calendar_pro_css:{path:"/static/calendar/css/calendar-pro.css",ver:latestVer},
			},
			mycenter:{
			},
			newpage:{
				style_css:{path:"/static/newPage/css/style.css",ver:latestVer},
			},
			contacts:{
				page_css:{path:"/static/css/page.css",ver:latestVer},
                mobiscroll_scroller_android_ics_css:{path:"/static/webstatic/contacts/mc_css/mobiscroll.scroller.android-ics.css",ver:latestVer},
                mobiscroll_scroller_css:{path:"/static/webstatic/contacts/mc_css/mobiscroll.scroller.css",ver:latestVer},
			},
			community:{
				video_js_min_css:{path:"/static/plugins/video/video-js.min.css",ver:latestVer},
			},

		},
		js:{
			
			community:{
				community_comment_js:{path:"/static/webstatic/community/js/community_comment.js",ver:latestVer},
				community_info_js:{path:"/static/webstatic/community/js/community_info.js",ver:latestVer},
				community_main_js:{path:"/static/webstatic/community/js/community_main.js",ver:latestVer},
				community_send_info_js:{path:"/static/webstatic/community/js/community_send_info.js",ver:latestVer},
				community_video_js:{path:"/static/webstatic/community/js/community_video.js",ver:latestVer},
				dropload_js:{path:"/static/webstatic/community/js/dropload.js",ver:latestVer},
				lyz_delayLoading_min_js:{path:"/static/webstatic/community/js/lyz.delayLoading.min.js",ver:latestVer},
				search_filter_js:{path:"/static/webstatic/community/js/search_filter.js",ver:latestVer},
				video_min_js:{path:"/static/plugins/video/video.min.js",ver:latestVer},
			},
			laowu:{
				common_js:{path:"/static/webstatic/new_laowu/js/common.js",ver:latestVer},
				gongzhong_js:{path:"/static/webstatic/new_laowu/js/gongzhong.js",ver:latestVer},
				imageRotate_js:{path:"/static/webstatic/new_laowu/js/imageRotate.js",ver:latestVer},
				phone_list_js:{path:"/static/webstatic/new_laowu/js/phone_list.js",ver:latestVer},
				project_calendar_js:{path:"/static/webstatic/new_laowu/js/project_calendar.js",ver:latestVer},
				project_conform_list_js:{path:"/static/webstatic/new_laowu/js/project_conform_list.js",ver:latestVer},
				project_contact_list_js:{path:"/static/webstatic/new_laowu/js/project_contact_list.js",ver:latestVer},
				project_gongren_list_js:{path:"/static/webstatic/new_laowu/js/project_gongren_list.js",ver:latestVer},
				project_manager_calendar_js:{path:"/static/webstatic/new_laowu/js/project_manager_calendar.js",ver:latestVer},
				project_manager_sign_js:{path:"/static/webstatic/new_laowu/js/project_manager_sign.js",ver:latestVer},
				project_normal_config_js:{path:"/static/webstatic/new_laowu/js/project_normal_config.js",ver:latestVer},
				project_number_config_js:{path:"/static/webstatic/new_laowu/js/project_number_config.js",ver:latestVer},
				project_sign_js:{path:"/static/webstatic/new_laowu/js/project_sign.js",ver:latestVer},
				project_work_js:{path:"/static/webstatic/new_laowu/js/project_work.js",ver:latestVer},
				select_member_js:{path:"/static/webstatic/new_laowu/js/select_member.js",ver:latestVer},

			},
			danju:{
                public:{
                    xlsx_js:{path:"/static/js/xlsx.core.min.js",ver:latestVer}
				},
				chengnuo:{
                    newCreat_js:{path:"/static/newwebstatic/chengnuo/js/newCreat.js",ver:latestVer},
                    ttp_js:{path:"/static/newwebstatic/chengnuo/js/ttp.js",ver:latestVer}
				},
				shoufajian:{
					newCreat_js:{path:"/static/newwebstatic/lianxi/js/newCreat.js",ver:latestVer},
                    ttp_js:{path:"/static/newwebstatic/lianxi/js/ttp.js",ver:latestVer}
				},
				laowu:{
                    work_content_js:{path:"/static/newwebstatic/laowu/js/work_content.js",ver:latestVer},
                    ttp_js:{path:"/static/newwebstatic/laowu/js/ttp.js",ver:latestVer}
				},
                gongdan:{
                    work_content_js:{path:"/static/newwebstatic/gongdan/js/work_content.js",ver:latestVer},
                    ttp_js:{path:"/static/newwebstatic/gongdan/js/ttp.js",ver:latestVer}
                },
				gonggao:{
                    gonggao_detail_js:{path:"/static/newwebstatic/gonggao/js/gonggao_detail.js",ver:latestVer},
                    gonggao_send_js:{path:"/static/newwebstatic/gonggao/js/gonggao_sent.js",ver:latestVer},
				},
			},
			xk:{
                xk_common_js:{path:"/static/newwebstatic/js/xk_common.js",ver:latestVer},
                xk_util_js:{path:"/static/newwebstatic/js/xk_util.js",ver:latestVer},
			},
			room:{
				project_contract_js:{path:"/static/webstatic/chatroom/js/project_contract.js",ver:latestVer},
				project_contract_info_js:{path:"/static/webstatic/chatroom/js/project_contract_info.js",ver:latestVer},
				project_member_js:{path:"/static/webstatic/chatroom/js/project_member.js",ver:latestVer},
			},
			meeting:{
				meetings_add_js:{path:"/static/webstatic/meeting/js/meetings_add.js",ver:latestVer},
				meetings_info_js:{path:"/static/webstatic/meeting/js/meetings_info.js",ver:latestVer},
				meetings_js:{path:"/static/webstatic/meeting/js/meetings.js",ver:latestVer},
			},
			calendar:{
				calendar_short_js:{path:"/static/calendar/js/calendar_short.js",ver:latestVer},
				calendar_laowu_js:{path:"/static/calendar/js/calendar_laowu.js",ver:latestVer},
				calendar_work_js:{path:"/static/calendar/js/calendar_work.js",ver:latestVer},
			},
			message:{
                application_list_js:{path:"/static/webstatic/message/js/application_list.js",ver:latestVer},
			},
			mycenter:{
				mycenter_js:{path:"/static/webstatic/mycenter/js/mycenter.js",ver:latestVer},
				myInfo_js:{path:"/static/webstatic/mycenter/js/my_info.js",ver:latestVer},
				bundle_js:{path:"/static/webstatic/mycenter/js/lrz/lrz.bundle.js",ver:latestVer},
				imageRotate_js:{path:"/static/webstatic/mycenter/js/attendance/imageRotate.js",ver:latestVer},
				upload_js:{path:"/static/webstatic/mycenter/js/lrz/upload.js",ver:latestVer},
				teaminfo_list_js:{path:"/static/webstatic/mycenter/js/teaminfo_list.js",ver:latestVer},
				project_list_js:{path:"/static/webstatic/mycenter/js/project_list.js",ver:latestVer},
				audio_min_js:{path:"/static/webstatic/mycenter/js/audiojs/audio.min.js",ver:latestVer},
				attention_collect_js:{path:"/static/webstatic/mycenter/js/attention_collect.js",ver:latestVer},
				account_setting_js:{path:"/static/webstatic/mycenter/js/account_setting.js",ver:latestVer},
				change_phone_js:{path:"/static/webstatic/mycenter/js/change_phone.js",ver:latestVer},
				change_identity_js:{path:"/static/webstatic/mycenter/js/change_identity.js",ver:latestVer},
				resetpwd_js:{path:"/static/webstatic/mycenter/js/resetpwd.js",ver:latestVer},
				setting_untie_js:{path:"/static/webstatic/mycenter/js/setting_untie.js",ver:latestVer},
				template_js:{path:"/static/js/template/template.min.js",ver:latestVer},
				public_home_page_js:{path:"/static/webstatic/mycenter/js/homepage/public_home_page.js",ver:latestVer},
				company_home_page_js:{path:"/static/webstatic/mycenter/js/homepage/company_home_page.js",ver:latestVer},
				column_js:{path:"/static/webstatic/mycenter/js/columns/column.js",ver:latestVer},
				zhanshige_js:{path:"/static/webstatic/mycenter/js/columns/zhanshige.js",ver:latestVer},
				home_page_js:{path:"/static/webstatic/mycenter/js/homepage/home_page.js",ver:latestVer},
                lrz_bundle_js:{path:"/static/webstatic/mycenter/js/lrz/lrz.bundle.js",ver:latestVer},
                my_code_card_js:{path:"/static/webstatic/mycenter/js/my_code_card.js",ver:latestVer},
                select_member_share_js:{path:"/static/webstatic/mycenter/js/select_member_share.js",ver:latestVer},
                enterprise_home_js:{path:"/static/webstatic/mycenter/js/enterprise_home.js",ver:latestVer},
            },
			newpage:{
				remAuto_js:{path:"/static/newPage/js/remAuto.js",ver:latestVer},
				xyqrcode_js:{path:"/static/js/xyqrcode.js",ver:latestVer},
				jquery_qrcode_js:{path:"/static/js/jquery-qrcode-0.14.0.js",ver:latestVer},
			},
			register:{
				forget_password_js:{path:"/static/webstatic/register/js/forget_password.js",ver:latestVer},
				register_js:{path:"/static/webstatic/register/js/register.js",ver:latestVer},
			    authenticate_js:{path:"/static/webstatic/register/js/authenticate.js",ver:latestVer},
                change_phone_js:{path:"/static/webstatic/register/js/change_phone.js",ver:latestVer},
                login_register_js:{path:"/static/webstatic/register/js/login_register.js",ver:latestVer},
                third_bind_js:{path:"/static/webstatic/register/js/third_bind.js",ver:latestVer},
                z_stat_js:{path:"https://s19.cnzz.com/z_stat.php?id=1271317956&web_id=1271317956",ver:latestVer},
			},
			contacts:{
				eg_details_js:{path:"/static/webstatic/contacts/js/eg_details.js",ver:latestVer},
				upload_js:{path:"/static/webstatic/mycenter/js/lrz/upload.js",ver:latestVer},
				lrz_bundle_js:{path:"/static/webstatic/mycenter/js/lrz/lrz.bundle.js",ver:latestVer},
				py_js:{path:"/static/webstatic/contacts/js/py.js",ver:latestVer},
				select_member_js:{path:"/static/webstatic/contacts/js/select_member.js",ver:latestVer},
				eg_list_js:{path:"/static/webstatic/contacts/js/eg_list.js",ver:latestVer},
				select_member_comm_js:{path:"/static/webstatic/contacts/js/select_member_comm.js",ver:latestVer},
				contacts_comm_js:{path:"/static/webstatic/contacts/js/contacts_comm.js",ver:latestVer},
				group_address_m_js:{path:"/static/webstatic/contacts/js/group_address_m.js",ver:latestVer},
				contacts_comm_js:{path:"/static/webstatic/contacts/js/contacts_comm.js",ver:latestVer},
				team_issue_js:{path:"/static/webstatic/contacts/js/team_issue.js",ver:latestVer},
				add_team_issue_js:{path:"/static/webstatic/contacts/js/add_team_issue.js",ver:latestVer},
				add_manually_js:{path:"/static/webstatic/contacts/js/add_manually.js",ver:latestVer},
                phone_list_js:{path:"/static/webstatic/contacts/js/phone_list.js",ver:latestVer},
                address_list_js:{path:"/static/webstatic/contacts/js/address_list.js",ver:latestVer},
				py_js:{path:"/static/webstatic/contacts/js/py.js",ver:"2018-08-04 14:29:00"},
				select_member_js:{path:"/static/webstatic/contacts/js/select_member.js",ver:latestVer},
				eg_list_js:{path:"/static/webstatic/contacts/js/eg_list.js",ver:latestVer},
				select_member_comm_js:{path:"/static/webstatic/contacts/js/select_member_comm.js",ver:latestVer},
				contacts_comm_js:{path:"/static/webstatic/contacts/js/contacts_comm.js",ver:latestVer},
				group_address_m_js:{path:"/static/webstatic/contacts/js/group_address_m.js",ver:latestVer},
				team_issue_js:{path:"/static/webstatic/contacts/js/team_issue.js",ver:latestVer},
				add_team_issue_js:{path:"/static/webstatic/contacts/js/add_team_issue.js",ver:latestVer},
				add_manually_js:{path:"/static/webstatic/contacts/js/add_manually.js",ver:latestVer},
                phone_list_js:{path:"/static/webstatic/contacts/js/phone_list.js",ver:latestVer},
                address_list_js:{path:"/static/webstatic/contacts/js/address_list.js",ver:latestVer},
                contact_edit_js:{path:"/static/webstatic/contacts/js/contact_edit.js",ver:latestVer},
                select_friend_js:{path:"/static/webstatic/contacts/js/select_friend.js",ver:latestVer},
                select_member_dept_js:{path:"/static/webstatic/contacts/js/select_member_dept.js",ver:latestVer},
                select_member_group_set_js:{path:"/static/webstatic/contacts/js/select_member_group_set.js",ver:latestVer},
                select_member_share_js:{path:"/static/webstatic/contacts/js/select_member_share.js",ver:latestVer},
                select_radio_member_js:{path:"/static/webstatic/contacts/js/select_radio_member.js",ver:latestVer},
                select_member_group_common_js:{path:"/static/webstatic/contacts/js/select_member_group_common.js",ver:latestVer},
                new_friends_js:{path:"/static/webstatic/contacts/js/new_friends.js",ver:latestVer},
                team_search_js:{path:"/static/webstatic/contacts/js/team_search.js",ver:latestVer},
                common_js:{path:"/static/webstatic/contacts/js/common.js",ver:latestVer},
                team_create_js:{path:"/static/webstatic/contacts/js/team_create.js",ver:latestVer},
                mobiscroll_area_js:{path:"/static/webstatic/contacts/mc_js/mobiscroll.area.js",ver:latestVer},
                mobiscroll_core_js:{path:"/static/webstatic/contacts/mc_js/mobiscroll.core.js",ver:latestVer},
                mobiscroll_scroller_android_ics_js:{path:"/static/webstatic/contacts/mc_js/mobiscroll.scroller.android-ics.js",ver:latestVer},
                mobiscroll_scroller_js:{path:"/static/webstatic/contacts/mc_js/mobiscroll.scroller.js",ver:latestVer},
                mobiscroll_zepto_js:{path:"/static/webstatic/contacts/mc_js/mobiscroll.zepto.js",ver:latestVer},
                zepto_js:{path:"/static/webstatic/contacts/mc_js/zepto.js",ver:latestVer},
                mobiscroll_i18n_zh_js:{path:"/static/webstatic/contacts/mc_js/i18n/mobiscroll.i18n.zh.js",ver:latestVer},
			},
			dish:{
                project_list_js:{path:"/static/newwebstatic/js/project_list.js",ver:latestVer},
                file_gui_js:{path:"/static/newwebstatic/js/file_gui.js",ver:latestVer},
                dish_js:{path:"/static/webstatic/dish/js/dish.js",ver:latestVer},
                dish1_js:{path:"/static/webstatic/dish/js/dish1.js",ver:latestVer},
                detail_js:{path:"/static/webstatic/dish/js/detail.js",ver:latestVer},
                dir_js:{path:"/static/webstatic/dish/js/dir.js",ver:latestVer},
                file_js:{path:"/static/webstatic/dish/js/file.js",ver:latestVer},
                move_select_js:{path:"/static/webstatic/dish/js/move_select.js",ver:latestVer},
                search_js:{path:"/static/webstatic/dish/js/search.js",ver:latestVer},
                upload_select_js:{path:"/static/webstatic/dish/js/upload_select.js",ver:latestVer},
			},
			common:{
				xyqrcode_js:{path:"/static/js/xyqrcode.js",ver:latestVer},
				jquery_qrcode_js:{path:"/static/js/jquery-qrcode-0.14.0.js",ver:latestVer},
				regions_js:{path:"/static/webstatic/chatroom/js/regions.js",ver:latestVer},
			},
            simplify:{
                columnJiegou_create_js:{path:"/static/webstatic/work/js/query/columnJiegou_create.js",ver:latestVer},
                columnJiegou_show_js:{path:"/static/webstatic/work/js/query/columnJiegou_show.js",ver:latestVer},
                columnTools_js:{path:"/static/webstatic/work/js/query/columnTools.js",ver:latestVer}
			},
			newwebstatic:{
                add_validation03_js:{path:"/static/newwebstatic/js/add_validation03.js",ver:latestVer},
			}


		},
		// 转换成时间戳
		getUrl:function(res){
			return res.path+"?v="+new Date(res.ver).getTime();
		}
	}
}
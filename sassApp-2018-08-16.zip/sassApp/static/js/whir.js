/**
 * 插件功能：使用localStorage缓存js和css文件，减少http请求和页面渲染时间，适用于Web移动端H5页面制作。
 * 插件作者：Cyrus
 * 使用方法：
 *   1.此页面需要改动的内容：cacheKey和resVerUrl
 *   2.加载Js和加载css：参照各页面
 *   3.测试/生产强制使用缓存，开发默认不使用，如果要用(手机不可用)，需要在浏览器的sessionStorage定义devcache=1，随着浏览器标签页关闭即消失
 */
var whir = window.whir || {};
whir.latestVer = "2018/08/11 10:52:06";
whir.res = {
	cacheFlag: "_JY_",
	// 最新版本号
//	whir.latestVer: "2018/08/10 16:42:05",
	// 该配置提交代码一定要为true.
	cacheAble: true,
	init: function() {
		var _self = this;
		// 测试/生产强制用缓存
		var curl = window.location.href;
		if(curl.indexOf("https://m.cloudccif.com") > -1 || curl.indexOf("http://java.winfreeinfo.com") > -1) {
			_self.cacheAble = true;
		} else {
			// 开发环境如果要使用缓存，需要在sessionStorage指定
			if(sessionStorage.getItem("devcache") == "1") {
				_self.cacheAble = true;
				// 开发环境默认不使用缓存
			} else {
				_self.cacheAble = false;
			}
		}
	},
	// 资源版本，用于刷新localStorage缓存，只有需要加到缓存的公共资源才配置此处，默认目录为js/css
	// key命名与resUrl保持一致，如果有目录则要有层级，例如：photo:{photoSwipe_js:"photo/photoSwipe.js"}
	// value用"/"划分层级，例如：“photo/photoSwipe.js”
	// 这个部署过一次后千万千万不能改
	cacheKey: {
		css: {
			common_css: "common.css",
			mui_min_css: "mui.min.css",
			icons_extend_css: "icons-extend.css",
			layer_css: "layer.css",
			style_css: "style.css",
			mui_picker_css: "mui.picker.min.css",
			mui_indexedList_css: "mui.indexedList.css",
			page_css: "page.css",
			column_css: "column.css",
			swiper_min_css:"swiper_min_css"
		},
		js: {
			whir_js: "whir.js",
			axios_min_js: "axios.min.js",
			mui_min_js: "mui.min.js",
			vue_min_js: "vue.min.js",
			config_js: "config.js",
			common_js: "common.js",
			appApi_js: "appApi.js",
			layer_js: "layer.js",
			alert_js: "alert.js",
			jquery_min_js: "jquery.min.js",
			mui_picker_js: "mui.picker.min",
			util_js: "util.js",
			mui_pullToRefresh_js: "mui.pullToRefresh.js",
			mui_pullToRefresh_material_js: "mui.pullToRefresh.material.js",
			mui_indexedList_js: "mui.indexedList.js",
			exif_js: "exif.js",
			mui_view_js: "mui.view.js",
			photoSwipe_js: "photo/photoSwipe_js",
			swiper_min_js:"swiper_min_js"

			// photo:{
			//     photoSwipe_js:"photo/photoSwipe.js"
			// }
		}
	},
	// 系统所有资源都在这里定义。版本号为年-月-日 时:分:秒
	// cache和whirs.cacheKey配置一一对应
	resVerUrl: {
		css: {
			common_css: {
				path: "/static/css/common.css",
				ver: whir.latestVer
			},
			mui_min_css: {
				path: "/static/css/mui.min.css",
				ver: whir.latestVer
			},
			icons_extend_css: {
				path: "/static/css/icons-extend.css",
				ver: whir.latestVer
			},
			layer_css: {
				path: "/static/plugins/layer3.1.0/need/layer.css",
				ver: whir.latestVer
			},
			style_css: {
				path: "/static/css/style.css",
				ver: whir.latestVer
			},
			mui_picker_css: {
				path: "/static/css/mui.picker.min.css",
				ver: whir.latestVer
			},
			mui_indexedList_css: {
				path: "/static/css/mui.indexedList.css",
				ver: whir.latestVer
			},
			page_css: {
				path: "/static/css/page.css",
				ver: whir.latestVer
			},
			column_css: {
				path: "/static/css/column.css",
				ver: whir.latestVer
			},
			swiper_min_css: {
				path: "//cdn.bootcss.com/Swiper/4.2.0/css/swiper.min.css",
				ver: whir.latestVer
			},
		
		},
		js: {
			whir_js: {
				path: "/static/js/whir.js",
				ver: whir.latestVer
			},
			axios_min_js: {
				path: "https://cdn.bootcss.com/axios/0.17.1/axios.min.js",
				ver: whir.latestVer
			},
			mui_min_js: {
				path: "https://cdn.bootcss.com/mui/3.7.1/js/mui.min.js",
				ver: whir.latestVer
			},
			vue_min_js: {
				path: "https://cdn.bootcss.com/vue/2.5.13/vue.min.js",
				ver: whir.latestVer
			},
			jquery_min_js: {
				path: "https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js",
				ver: whir.latestVer
			},
			config_js: {
				path: "/static/js/config/config.js",
				ver: whir.latestVer
			},
			common_js: {
				path: "/static/js/common.js",
				ver: whir.latestVer
			},
			appApi_js: {
				path: "/static/js/appApi.js",
				ver: whir.latestVer
			},
			layer_js: {
				path: "/static/plugins/layer3.1.0/layer.js",
				ver: whir.latestVer
			},
			alert_js: {
				path: "/static/plugins/layer/alert.js",
				ver: whir.latestVer
			},
			mui_picker_js: {
				path: "/static/js/mui.picker.min.js",
				ver: whir.latestVer
			},
			util_js: {
				path: "/static/js/util.js",
				ver: whir.latestVer
			},
			mui_pullToRefresh_js: {
				path: "/static/js/mui.pullToRefresh.js",
				ver: whir.latestVer
			},
			mui_pullToRefresh_material_js: {
				path: "/static/js/mui.pullToRefresh.material.js",
				ver: whir.latestVer
			},
			mui_indexedList_js: {
				path: "/static/js/mui.indexedList.js",
				ver: whir.latestVer
			},
			exif_js: {
				path: "https://cdn.bootcss.com/exif-js/2.3.0/exif.js",
				ver: whir.latestVer
			},
			mui_view_js: {
				path: "/static/plugins/mui/mui.view.js",
				ver: whir.latestVer
			},
			photo: {
				photoSwipe_js: {
					path: "/static/js/photo/photoSwipe.js",
					ver: whir.latestVer
				}
			},
			swiper_min_js: {
				path: "https://cdn.bootcss.com/Swiper/4.2.0/js/swiper.min.js",
				ver: whir.latestVer
			},
			// photo:{
			//     photoSwipe_js:{path:"/static/js/photo/photoSwipe.js",ver:whir.latestVer}
			// }
		}

	},
	//动态加载js文件并缓存
	loadJs: function(name, res, callback, async) {
		var _self = this;
		if(window.localStorage) {
			if(async == undefined) {
				async = true;
			}
			var xhrSuccess = function() {
				if(xhr.readyState == 4 && xhr.status == 200) {
					js = xhr.responseText;
					// 允许用缓存才写入
					if(_self.cacheAble) {
						localStorage.setItem(ls_resKey, js);
						localStorage.setItem(ls_verKey, curr_resVer);
					}
					js = js == null ? "" : js;
					whir.res.writeJs(js);
					if(callback != null) {
						callback(); //回调，执行下一个引用
					}
				}
			}
			var xhr;
			// 资源版本
			var curr_resVer = new Date(res.ver).getTime();
			var urlAndVer = res.path + "?v=" + curr_resVer;
			var ls_resKey = "_JY_" + name;
			var ls_verKey = "_JY_" + name + "_ver";
			var js = localStorage.getItem(ls_resKey);
			if(js == null || js.length == 0 || curr_resVer != localStorage.getItem(ls_verKey) || !_self.cacheAble) {
				if(window.ActiveXObject) {
					xhr = new ActiveXObject("Microsoft.XMLHTTP");
				} else if(window.XMLHttpRequest) {
					xhr = new XMLHttpRequest();
				}
				if(xhr != null) {
					// 异步方式
					xhr.open("GET", urlAndVer, async);
					xhr.send(null);

					if(async == true) {
						xhr.onreadystatechange = function() {
							xhrSuccess();
						};
					} else {
						xhrSuccess();
					}

				}
			} else {
				whir.res.writeJs(js);
				if(callback != null) {
					callback(); //回调，执行下一个引用
				}
			}
		} else {
			whir.res.linkJs(urlAndVer);
		}
	},
	loadCss: function(name, res, callback) {
		var _self = this;
		if(window.localStorage) {
			var xhr;
			// 替换所有css的字符串，通用处理方法
			var rplStrRes = function() {
				//css = css.replace(/[.][.]\//g, "/static/"); //css里的相对路径需单独处理
			}
			// 资源版本
			var curr_resVer = new Date(res.ver).getTime();
			var urlAndVer = res.path + "?v=" + curr_resVer;
			var ls_resKey = "_JY_" + name;
			var ls_verKey = "_JY_" + name + "_ver";
			var css = localStorage.getItem(ls_resKey);
			var xhrSuccess = function() {
				if(xhr.readyState == 4 && xhr.status == 200) {
					css = xhr.responseText;
					// 允许用缓存才写入
					if(_self.cacheAble) {
						localStorage.setItem(ls_resKey, css);
						localStorage.setItem(ls_verKey, curr_resVer);
					}
					css = css == null ? "" : css;
					rplStrRes();
					whir.res.writeCss(css);
					if(callback != null) {
						callback(); //回调，执行下一个引用
					}
				}
			}

			if(css == null || css.length == 0 || curr_resVer != localStorage.getItem(ls_verKey) || !_self.cacheAble) {
				if(window.ActiveXObject) {
					xhr = new ActiveXObject("Microsoft.XMLHTTP");
				} else if(window.XMLHttpRequest) {
					xhr = new XMLHttpRequest();
				}
				if(xhr != null) {
					// 同步方式
					xhr.open("GET", urlAndVer, false);
					xhr.send(null);

					// 同步不需要监听
					//                     xhr.onreadystatechange = function () {
					xhrSuccess()
					//                     };
				}
			} else {
				rplStrRes();
				whir.res.writeCss(css);
				if(callback != null) {
					callback(); //回调，执行下一个引用
				}
			}
		} else {
			whir.res.linkCss(urlAndVer);
		}
	}, //往页面写入js脚本
	writeJs: function(text) {
		var head = document.getElementsByTagName('HEAD').item(0);
		var link = document.createElement("script");
		link.type = "text/javascript";
		link.innerHTML = text;
		head.appendChild(link);
	}, //往页面写入css样式
	writeCss: function(text) {
		var head = document.getElementsByTagName('HEAD').item(0);
		var link = document.createElement("style");
		link.type = "text/css";
		link.innerHTML = text;
		head.appendChild(link);
	}, //往页面引入js脚本
	linkJs: function(url) {
		var head = document.getElementsByTagName('HEAD').item(0);
		var link = document.createElement("script");
		link.type = "text/javascript";
		link.src = url;
		head.appendChild(link);
	}, //往页面引入css样式
	linkCss: function(url) {
		var head = document.getElementsByTagName('HEAD').item(0);
		var link = document.createElement("link");
		link.type = "text/css";
		link.rel = "stylesheet";
		link.rev = "stylesheet";
		link.media = "screen";
		link.href = url;
		head.appendChild(link);
	}
}
whir.res.init();
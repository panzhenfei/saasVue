/**
 * 日期日历
 * @param {Object} FX function(date) 获取年月date yyyy-m  , 需要给变量  showHint = ["1", "2", "10"]当页需要标红点的天数
 * @param {Object} Fn function(date) 点击日期获取日期并且续写后续事件 ,获取年月日date yyyy-m-d (未到日没有后续事件)
 */
var showHint;


/*CalendarInit(function(s) {
 //alert(s)
 return SearchInit(s);
 }, function(date) {
 getRecord(date);
 //	$("#attendanceRecord").click();
 });*/
function CalendarInit(calendarControlId, FX, Fn) {

alert(calendarControlId)
    if (calendarControlId){
        alert(1)
        CalendarMethod.calendarElementInit(calendarControlId);
    }


    var currentMonth = new Date().getMonth();

    currentMonth = CalendarMethod.loadCalendar(",", FX, currentMonth, Fn)

    document.getElementById("backMonth").onclick = function () {
        currentMonth = CalendarMethod.loadCalendar("back", FX, currentMonth, Fn);
    }

    document.getElementById("beforeMonth").onclick = function () {
        currentMonth = CalendarMethod.loadCalendar("before", FX, currentMonth, Fn);
    }
}

function test() {
    alert("日历")
}

var CalendarMethod = {
    loadCalendar: function (condition, FX, currentMonth, Fn) {
        var date = new Date();
        if (condition == "before") {
            currentMonth -= 1;
            date.setMonth(currentMonth);
        } else if (condition == "back") {
            currentMonth += 1;
            date.setMonth(currentMonth);

        }

        FX && FX(date.getFullYear() + "-" + (date.getMonth() + 1));

        showHint = showHint == undefined ? [""] : showHint;

        this.changeCalendar(date, showHint, Fn);
        return currentMonth;
    },
    changeCalendar: function (date, showHint, Fn) {

        document.getElementById("dateYD").innerHTML = date.getFullYear() + "-" + (date.getMonth() + 1);

        var days = this.getDays(date);
        var LiStr = "";
        var hintIndex = 0;
        /*var contrastDate = date;*/
        var isAdd = null;
        for (var i = 0; i < days; i++) {
            /*contrastDate = date;
             contrastDate.setDate(i + 1);*/
            isAdd = null;
            var testdate = date;
            isAdd = (hintIndex < showHint.length) && (showHint[hintIndex] == (i + 1));
            LiStr += '<li class="' + (this.compriseDay(testdate, i) != "2" ? 'over' : ' ') + '" index="' + (i + 1) + '" ><span class="' + (this.compriseDay(date, i) != "2" ? 'day' : 'day1') + '">' + (this.compriseDay(testdate, i) == "1" ? '今天' : (i + 1)) + '<span class="label-sign' + (isAdd ? ' sign-in' : '') + '"></span></span></li>';
            hintIndex = isAdd ? hintIndex + 1 : hintIndex;
            /*
             if(hintIndex < showHint.length && showHint[hintIndex] == (i + 1)) {
             LiStr += '<li class="' + (contrastDate < new Date() ? 'over' : ' ') + '" index="' + (i + 1) + '" ><span class="day">' + (i + 1) + '<span class="label-sign sign-in"></span></span></li>';
             hintIndex += 1;

             } else {
             LiStr += '<li class="' + (contrastDate < new Date() ? 'over' : ' ') + '" index="' + (i + 1) + '" ><span class="day">' + (i + 1) + '<span class="label-sign' + ((hintIndex < showHint.length && showHint[hintIndex] == (i + 1)) ? ' sign-in' : '') + '"></span></span></li>';
             //LiStr += '<li class="over" index="' + (i + 1) + '" ><span class="day">' + (i + 1) + '<span class="label-sign"></span></span></li>';
             }*/

        }
        document.getElementById("dateUl").innerHTML = LiStr;

        /*$("#dateUl").html(LiStr);
         $("#dateYD").html(date.getFullYear() + "-" + (date.getMonth() + 1));*/
        this.getReturnDate(date, Fn);

    },
    getDays: function (date) {

        //获取年份
        var year = date.getFullYear();
        //获取当前月份
        var mouth = date.getMonth() + 1;
        //定义当月的天数；
        var days;
        //当月份为二月时，根据闰年还是非闰年判断天数
        if (mouth == 2) {
            days = year % 4 == 0 ? 29 : 28;

        } else if (mouth == 1 || mouth == 3 || mouth == 5 || mouth == 7 || mouth == 8 || mouth == 10 || mouth == 12) {
            //月份为：1,3,5,7,8,10,12 时，为大月.则天数为31；
            days = 31;
        } else {
            //其他月份，天数为：30.
            days = 30;
        }
        //输出天数
        //alert('当月天数为：' + days);
        return days
    },
    getReturnDate: function (date, Fn) {
        var dateUl = document.getElementById("dateUl");
        var dateYD = document.getElementById("dateYD");
        var dateArr = dateYD.innerHTML.split("-");


        var liArr = dateUl.getElementsByTagName("li");
        for (var i = 0; i < liArr.length; i++) {
            if (this.compriseDay(date, i) != "2") {
                liArr[i].onclick = function () {
                    //Fn && Fn(dateYD.innerHTML + "-" + (Number(this.getAttribute("index")) > 9 ? this.getAttribute("index") : "0" + this.getAttribute("index")));
                    Fn && Fn(dateArr[0] + "-" + ( Number(dateArr[1]) > 9 ? dateArr[1] : "0" + dateArr[1]) + "-" + (Number(this.getAttribute("index")) > 9 ? this.getAttribute("index") : "0" + this.getAttribute("index")));
                }

            }

        }

    },
    compriseDay: function (date, i) {

        //var contrastDate = date;

        date.setDate(i + 1);
        date.setHours(0);
        date.setMinutes(0);
        date.setSeconds(0);

        var YDdate = document.getElementById("dateYD").innerHTML.split("-");
        var YDDateTime = new Date();

        YDDateTime.setFullYear(YDdate[0])
        YDDateTime.setMonth(YDdate[1] - 1)
        YDDateTime.setDate(i + 1)
        YDDateTime.setHours(0);
        YDDateTime.setMinutes(0);
        YDDateTime.setSeconds(0);

        var nowDate = new Date();
        nowDate.setHours(0);
        nowDate.setMinutes(0);
        nowDate.setSeconds(0);

        return YDDateTime.getTime() < nowDate.getTime() ? "0" : (YDDateTime.getTime() == nowDate.getTime() ? "1" : "2");

    },
    calendarElementInit: function (calendarControlId) {

        var calendarControl = document.getElementById(calendarControlId);
        calendarControl.innerHTML ="";
        calendarControl.className = "date-time";
        //head
        var datehead = document.createElement('div');
        datehead.className = "date-head";
        var beforeMonth = document.createElement("span");
        beforeMonth.id = "beforeMonth";
        beforeMonth.className = "label-left";
        beforeMonth.innerHTML = "<<";
        var dateYD = document.createElement("dateYD");
        dateYD.id = "dateYD";
        dateYD.innerHTML = "2017-06";
        var backMonth = document.createElement("backMonth");
        backMonth.id = "backMonth";
        backMonth.className = "label-right";
        backMonth.innerHTML = ">>";
        datehead.appendChild(beforeMonth);
        datehead.appendChild(dateYD);
        datehead.appendChild(backMonth);
        //body
        var datebody = document.createElement('div');
        datebody.className = "date-body";

        var ul1 = document.createElement('ul');
        ul1.className = "mui-table date-weekday";

        var li1 = document.createElement("li");
        li1.className = "mui-table-cell"
        li1.innerHTML = "一";
        ul1.appendChild(li1);

        var li2 = document.createElement("li");
        li2.className = "mui-table-cell"
        li2.innerHTML = "二";
        ul1.appendChild(li2);

        var li3 = document.createElement("li");
        li3.className = "mui-table-cell"
        li3.innerHTML = "三";
        ul1.appendChild(li3);

        var li4 = document.createElement("li");
        li4.className = "mui-table-cell"
        li4.innerHTML = "四";
        ul1.appendChild(li4);

        var li5 = document.createElement("li");
        li5.className = "mui-table-cell"
        li5.innerHTML = "五";
        ul1.appendChild(li5);

        var li6 = document.createElement("li");
        li6.className = "mui-table-cell"
        li6.innerHTML = "六";
        ul1.appendChild(li6);

        var li7 = document.createElement("li");
        li7.className = "mui-table-cell"
        li7.innerHTML = "七";
        ul1.appendChild(li7);

        //dateUl

        var dateUl = document.createElement("ul")
        dateUl.id = "dateUl";
        //dateUl.setAttribute("id", "dateUl");
        dateUl.className = "data-day";

        datebody.appendChild(ul1);
        datebody.appendChild(dateUl);
        //append
        calendarControl.appendChild(datehead);
        calendarControl.appendChild(datebody)
    }

};


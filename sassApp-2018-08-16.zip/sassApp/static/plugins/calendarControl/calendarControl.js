/**
 * 日期日历
 * @param {Object} FX function(date) 获取年月date yyyy-m  , 需要给变量  showHint = ["1", "2", "10"]当页需要标红点的天数
 * @param {Object} Fn function(date) 点击日期获取日期并且续写后续事件 ,获取年月日date yyyy-m-d (未到日没有后续事件)
 */
var showHint;

function CalendarInit(FX, Fn) {

    var currentMonth = new Date().getMonth();

    currentMonth = CalendarMethod.loadCalendar(",", FX, currentMonth, Fn)

    document.getElementById("backMonth").onclick = function () {
        currentMonth = CalendarMethod.loadCalendar("back", FX, currentMonth, Fn);
    }

    document.getElementById("beforeMonth").onclick = function () {
        currentMonth = CalendarMethod.loadCalendar("before", FX, currentMonth, Fn);
    }
}

var CalendarMethod = {
    loadCalendar: function (condition, FX, currentMonth, Fn) {
        var date = new Date();
        if (condition == "before") {
            currentMonth -= 1;
            date.setMonth(currentMonth);
        } else if (condition == "back") {
            currentMonth += 1;
            date.setMonth(currentMonth);

        }

        FX && FX(date.getFullYear() + "-" + (date.getMonth() + 1));

        showHint = showHint == undefined ? [""] : showHint;

        this.changeCalendar(date, showHint, Fn);
        return currentMonth;
    },
    changeCalendar: function (date, showHint, Fn) {

        document.getElementById("dateYD").innerHTML = date.getFullYear() + "-" + (date.getMonth() + 1);
        var data = this.getDays(date);
        var days=data.days;
        var year=data.year;
        var month=data.month;
        var first=data.firstWeek;
        var last=data.lastWeek;
        var lastMonth=first;
        if(lastMonth==0){
            lastMonth=7;
        }
        var year = date.getFullYear();
        var month = date.getMonth();

        if(month==0)
        {
            month=12;
            year=year-1;
        }
        if (month < 10) {
            month = "0" + month;
        }
        var firstDay = year + "-" + month + "-" + "01";//上个月的第一天
        var myDate = new Date(year, month, 0);
        var lastDay = year + "-" + month + "-" + myDate.getDate();//上个月的最后一
        var riliHtml="";
        for(var i = lastMonth-1; i > 0; i--) {
            var dataDateStr = (myDate.getDate() - i + 1);
            console.log("上个月"+dataDateStr)
            riliHtml+='<li class="" index="-1" ><span class="day">'+dataDateStr+'<span class="label-sign"></span></span></li>';
        }

        // alert("上个月"+(lastMonth-1))
        // alert("下个月"+(42 - days-(lastMonth-1)))
        //下月数据
        var nextHtml="";
        for(var j = 0; j < (42 - days - (lastMonth-1)); j++) { //42-已占用表格数=剩余表格数
            var dataDateStr = (j + 1);
            nextHtml+='<li class="" index="-1" ><span class="day">'+dataDateStr+'<span class="label-sign"></span></span></li>';
        }
        console.log("加载日历",days)
        console.log("加载日历",first)
        console.log("加载日历",last)
        var LiStr = "";
        var hintIndex = 0;
        /*var contrastDate = date;*/
        var isAdd = null;
        for (var i = 0; i < days; i++) {
            /*contrastDate = date;
             contrastDate.setDate(i + 1);*/
            isAdd = null;
            var testdate = date;
            isAdd = (hintIndex < showHint.length) && (showHint[hintIndex] == (i + 1));
            LiStr += '<li class="' + (this.compriseDay(testdate, i) != "2" ? 'over' : 'next') + '" index="' + (i + 1) + '" ><span class="' + (this.compriseDay(date, i) != "2" ? 'day' : 'day') + '">' + (this.compriseDay(testdate, i) == "1" ? '今天' : (i + 1)) + '<span class="label-sign' + (isAdd ? ' sign-in' : '') + '"></span></span></li>';
            hintIndex = isAdd ? hintIndex + 1 : hintIndex;
        }

        // console.log(LiStr)
        document.getElementById("dateUl").innerHTML = riliHtml+LiStr+nextHtml;

        /*$("#dateUl").html(LiStr);
         $("#dateYD").html(date.getFullYear() + "-" + (date.getMonth() + 1));*/
        this.getReturnDate(date, Fn);

    },
    getDays: function (date) {

        var obj=new Object();
        //获取年份
        var year = date.getFullYear();
        //获取当前月份
        var mouth = date.getMonth() + 1;

        //定义当月的天数；
        var days;
        //当月份为二月时，根据闰年还是非闰年判断天数
        if (mouth == 2) {
            days = year % 4 == 0 ? 29 : 28;

        } else if (mouth == 1 || mouth == 3 || mouth == 5 || mouth == 7 || mouth == 8 || mouth == 10 || mouth == 12) {
            //月份为：1,3,5,7,8,10,12 时，为大月.则天数为31；
            days = 31;
        } else {
            //其他月份，天数为：30.
            days = 30;
        }
        // alert(getFirstWeek(year,mouth,1));
        // alert(getLastWeek(year,mouth,days));
        //输出天数
        //alert('当月天数为：' + days);
        obj.days=days;
        obj.firstWeek=getFirstWeek(year,mouth,1);
        obj.lastWeek=getLastWeek(year,mouth,days);
        obj.year=year;
        obj.month=mouth;
        return obj;
    },
    getReturnDate: function (date, Fn) {
        var dateUl = document.getElementById("dateUl");
        var dateYD = document.getElementById("dateYD");
        var dateArr = dateYD.innerHTML.split("-");


        var liArr = dateUl.getElementsByTagName("li");
        for (var i = 0; i < liArr.length; i++) {
           // console.log('比较',this.compriseDay(date, i))
           // if (this.compriseDay(date, i) != "2") {

                // return;
                liArr[i].onclick = function () {
                    //alert("点击")
                   // console.log(this.getAttribute("index"))
                    if(this.getAttribute("index")==-1 || this.getAttribute("class")=='next'){
                        return;
                    }

                    //Fn && Fn(dateYD.innerHTML + "-" + (Number(this.getAttribute("index")) > 9 ? this.getAttribute("index") : "0" + this.getAttribute("index")));
                    Fn && Fn(dateArr[0] + "-" + ( Number(dateArr[1]) > 9 ? dateArr[1] : "0" + dateArr[1]) + "-" + (Number(this.getAttribute("index")) > 9 ? this.getAttribute("index") : "0" + this.getAttribute("index")));
                }

            //}

        }

    },
    compriseDay: function (date, i) {

        //var contrastDate = date;

        date.setDate(i + 1);
        date.setHours(0);
        date.setMinutes(0);
        date.setSeconds(0);

        var YDdate = document.getElementById("dateYD").innerHTML.split("-");
        var YDDateTime = new Date();

        YDDateTime.setFullYear(YDdate[0])
        YDDateTime.setMonth(YDdate[1] - 1)
        YDDateTime.setDate(i + 1)
        YDDateTime.setHours(0);
        YDDateTime.setMinutes(0);
        YDDateTime.setSeconds(0);

        var nowDate = new Date();
        nowDate.setHours(0);
        nowDate.setMinutes(0);
        nowDate.setSeconds(0);

        return YDDateTime.getTime() < nowDate.getTime() ? "0" : (YDDateTime.getTime() == nowDate.getTime() ? "1" : "2");

    },
    calendarElementInit: function () {

        var calendarControl = document.getElementById("calendarControl");
        calendarControl.className = "date-time";
        //head
        var datehead = document.createElement('div');
        datehead.className = "date-head";
        datehead.id="head"
        datehead.setAttribute("onclick","stopEvt(event)");
        var beforeMonth = document.createElement("span");
        beforeMonth.id = "beforeMonth";
        beforeMonth.className = "label-left";
        beforeMonth.innerHTML = "<<";
        var dateYD = document.createElement("dateYD");
        dateYD.id = "dateYD";
        dateYD.innerHTML = "2017-06";
        var backMonth = document.createElement("backMonth");
        backMonth.id = "backMonth";
        backMonth.className = "label-right";
        backMonth.innerHTML = ">>";
        datehead.appendChild(beforeMonth);
        datehead.appendChild(dateYD);
        datehead.appendChild(backMonth);
        //body
        var datebody = document.createElement('div');
        datebody.className = "date-body";
        datebody.setAttribute("onclick","stopEvt(event)");
        var ul1 = document.createElement('ul');
        ul1.className = "mui-table date-weekday";

        var li1 = document.createElement("li");
        li1.className = "mui-table-cell"
        li1.innerHTML = "一";
        ul1.appendChild(li1);

        var li2 = document.createElement("li");
        li2.className = "mui-table-cell"
        li2.innerHTML = "二";
        ul1.appendChild(li2);

        var li3 = document.createElement("li");
        li3.className = "mui-table-cell"
        li3.innerHTML = "三";
        ul1.appendChild(li3);

        var li4 = document.createElement("li");
        li4.className = "mui-table-cell"
        li4.innerHTML = "四";
        ul1.appendChild(li4);

        var li5 = document.createElement("li");
        li5.className = "mui-table-cell"
        li5.innerHTML = "五";
        ul1.appendChild(li5);

        var li6 = document.createElement("li");
        li6.className = "mui-table-cell"
        li6.innerHTML = "六";
        ul1.appendChild(li6);

        var li7 = document.createElement("li");
        li7.className = "mui-table-cell"
        li7.innerHTML = "日";
        ul1.appendChild(li7);

        //dateUl

        var dateUl = document.createElement("ul")
        dateUl.id = "dateUl";
        //dateUl.setAttribute("id", "dateUl");
        dateUl.className = "data-day";

        datebody.appendChild(ul1);
        console.log(dateUl)
        datebody.appendChild(dateUl);
        //append
        calendarControl.appendChild(datehead);
        calendarControl.appendChild(datebody)
    }

};

var getFirstWeek = function(year,month,day){
//1.根据年度和月份，创建日期
//应该先对year,month进行整数及范围校验的。
    var d = new Date();
    d.setYear(year);
    d.setMonth(month-1);
    d.setDate(day);
    console.log(d);
    //获得周几
    var weeks = ['0','1','2','3','4','5','6'];
    //alert("第一天"+d.getDay())
    return weeks[d.getDay()];
}

var getLastWeek = function(year,month,day){
//1.根据年度和月份，创建日期
//应该先对year,month进行整数及范围校验的。
    var d = new Date();
    d.setYear(year);
    d.setMonth(month-1);
    d.setDate(day);
    console.log(d);
    //获得周几
    var weeks = ['7','1','2','3','4','5','6'];
    return weeks[d.getDay()];
}

function stopEvt(e) {
    e.stopPropagation();//阻止点击事件向上冒泡
}
CalendarMethod.calendarElementInit();
/*!
 * pull to refresh v2.0
 *author:wallace
 *2015-7-22
 *edit:heliang
 */
var wrapper=null;
var count=0;
var refresher = {
	info: {
		"pullUpLable": "释放开始加载...",
		"pullingUpLable": "加载更多数据...",
		"loadingLable": "加载中......"
	},
	init: function(parameter) {
		var wrapper = document.getElementById(parameter.id);
		if(!wrapper.querySelector(".scroller")){
		var div = document.createElement("div");
		div.className = "scroller";
		div.id = "scroller";
		wrapper.appendChild(div);
		var scroller = wrapper.querySelector(".scroller");
		var list = wrapper.querySelector("#" + parameter.id + " ul");
		scroller.insertBefore(list, scroller.childNodes[0]);
		
		//下拉
		var pullDown = document.createElement("div");
		pullDown.className = "pullDown";
		var loader = document.createElement("div");
		loader.className = "loader";
		for (var i = 0; i < 4; i++) {
			var span = document.createElement("span");
			loader.appendChild(span);
		}
		pullDown.appendChild(loader);
		var pullDownLabel = document.createElement("div");
		pullDownLabel.className = "pullDownLabel";
		pullDown.appendChild(pullDownLabel);
		scroller.insertBefore(pullDown, scroller.childNodes[0]);

		//上拉
		var pullUp = document.createElement("div");
		pullUp.className = "pullUp";
		var loader = document.createElement("div");
		loader.className = "loader";
		for (var i = 0; i < 4; i++) {
			var span = document.createElement("span");
			loader.appendChild(span);
		}
		pullUp.appendChild(loader);
		var pullUpLabel = document.createElement("div");
		pullUpLabel.className = "pullUpLabel";
		pullUp.appendChild(pullUpLabel);
		scroller.appendChild(pullUp);

		}
		var pullUpEl = wrapper.querySelector(".pullUp");
		var pullUpOffset = pullUpEl.offsetHeight;
		this.scrollIt(parameter, pullUpEl, pullUpOffset);
		for(var p in parameter){
			this.info[p] = parameter[p];
		}
	},
	scrollIt: function(parameter, pullUpEl, pullUpOffset) {
		var wrapperObj = document.getElementById(parameter.id);
		if(wrapper!=null){
			wrapper.destroy();
		}
		wrapper= new iScroll(parameter.id, {useTransition: true,fixedScrollbar:true,vScrollbar: false,onRefresh: function () {refresher.onRelease(pullUpEl);},onTouchEnd:function(){refresher.onTouchEnd()},onScrollMove: function () {refresher.onScrolling(this,parameter.pullUpAction,pullUpEl,pullUpOffset);},onScrollEnd: function () {refresher.onPulling(parameter.pullDownAction,pullUpEl,parameter.pullUpAction);}});
		this.option = parameter;
		document.addEventListener('touchstart', function(e) {
			count=1;
			//console.log("touchstart....");
		});
		document.addEventListener('touchmove', function(e) {
			e.preventDefault();
			var touch = e.targetTouches[0];
			h = window.screen.height-50;
			var u = navigator.userAgent
			var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); 
			if(isiOS){
				if(touch.pageY<0 || h<touch.pageY){
					 if(count==1){
						 if (refresher.option.pullUpAction) refresher.option.pullUpAction();
						 count++;
						 }
				}
			}
		}, false);
	},
	clear:function(){
		var id = this.info['id'];
		var ulObj = $("#"+id+" ul")[0];
		wrapper = null;
		$("#"+id).children(".scroller").remove();
		$("#"+id).append(ulObj);
	},
	onScrolling: function(e,pullUpAction, pullUpEl, pullUpOffset) {
		
		if (e.scrollerH < e.wrapperH && e.y < (e.minScrollY - pullUpOffset) || e.scrollerH > e.wrapperH && e.y < (e.maxScrollY - pullUpOffset)) {
			pullUpEl.style.display = "block";
			pullUpEl.classList.add("flip");
			pullUpEl.querySelector('.pullUpLabel').innerHTML = refresher.info.pullingUpLable;
			/*if(e.maxScrollY>=80 || e.maxScrollY<0){
				console.log("e.maxScrollY=",e.maxScrollY);
				if (pullUpAction) pullUpAction();
			}*/
		}
		if (e.scrollerH < e.wrapperH && e.y > (e.minScrollY - pullUpOffset) && pullUpEl.id.match('flip') || e.scrollerH > e.wrapperH && e.y > (e.maxScrollY - pullUpOffset) && pullUpEl.id.match('flip')) {
			pullUpEl.querySelector('.pullUpLabel').innerHTML = refresher.info.pullUpLable;
			e.maxScrollY = pullUpEl.offsetHeight;
			
		}
	},
	onRelease: function(pullUpEl) {
		if (pullUpEl.className.match('loading')) {
			pullUpEl.classList.toggle("loading");
			pullUpEl.querySelector('.pullUpLabel').innerHTML ="";
			pullUpEl.querySelector('.loader').style.display = "none"
			pullUpEl.style.lineHeight = pullUpEl.offsetHeight + "px";
		}
	},

	onPulling: function(pullDownAction, pullUpEl, pullUpAction) {
		if (pullUpEl.className.match('flip')) {
			pullUpEl.classList.add("loading");
			pullUpEl.classList.remove("flip");
			pullUpEl.querySelector('.pullUpLabel').innerHTML = refresher.info.loadingLable;
			pullUpEl.querySelector('.loader').style.display = "block"
			pullUpEl.style.lineHeight = "60px";
		    if (pullUpAction) pullUpAction();
		}
		
	},
	onTouchEnd:function(){
	
	}
}
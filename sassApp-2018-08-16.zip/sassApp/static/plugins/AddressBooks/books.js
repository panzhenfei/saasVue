/*<div>

			<div id="app" class="mui-views">
				<div class="mui-view">
					<div class="mui-navbar">
					</div>
					<div class="mui-pages">
					</div>
				</div>
			</div>

			<div id="select_member" class="mui-page">

				<!-- 手机通讯录选择start -->
				<div id="phone_list">
					<div id="show_select_phone" class="pop-up" style="height: 100%;" v-show="select_phone">

						<div class="pop-header">
							<h1 class="p-title">请选择手机通讯录成员</h1>
							<button id="cannel_phones_id" style="display: none;" class="mui-btn mui-btn-link mui-pull-left" @click="hidePhoneSelect">取消</button>
						</div>
						<div class="pop-title"></div>
						<div class="pop-title"></div>
/////
						<div id='list' class="mui-indexed-list address-list hide">
							<div class="mui-indexed-list-search mui-input-row mui-search">
								<input type="search" class="mui-input-clear mui-indexed-list-search-input" placeholder="搜索">
							</div>
							<div class="mui-indexed-list-bar">
								<div class="align-middle">
									<a>A</a>
									<a>B</a>
									<a>C</a>
									<a>D</a>
									<a>E</a>
									<a>F</a>
									<a>G</a>
									<a>H</a>
									<a>I</a>
									<a>J</a>
									<a>K</a>
									<a>L</a>
									<a>M</a>
									<a>N</a>
									<a>O</a>
									<a>P</a>
									<a>Q</a>
									<a>R</a>
									<a>S</a>
									<a>T</a>
									<a>U</a>
									<a>V</a>
									<a>W</a>
									<a>X</a>
									<a>Y</a>
									<a>Z</a>
									<a>#</a>
								</div>
							</div>
							
							<div class="mui-indexed-list-alert"></div>
							<div class="mui-indexed-list-inner">
								<div id="empty-view" class="mui-indexed-list-empty-alert">没有数据</div>
								<ul class="mui-table-view">
									<template v-for="(items,index1) in phones">
										<template v-for="(item,index2) in items">
											<template v-if="item.name">
												<template v-if="item.isp == 1">
													<li :data-group="item.first" class="mui-table-view-divider mui-indexed-list-group">
														{{item.first}}
													</li>
												</template>
												<li :data-value="item.first" class="mui-table-view-cell mui-indexed-list-item mui-checkbox">
													<!--<a :href="['javascript:appApi.openNewWindow(pagepath+\'/contacts/eg_details.html?phone='+item.phone+'&name='+item.name+'\')']">-->
													<div class="mui-slider-cell">
														<div class="oa-contact-cell mui-table">
															<div class="oa-contact-input mui-table-cell"><input type="checkbox" :value="item.name+'='+item.phone" /></div>
															<div class="oa-contact-avatar mui-table-cell">
																<span class="oa-pic-default bgr2" v-text="item.name"></span>
															</div>
															<div class="oa-contact-content mui-table-cell">
																<h4 class="oa-contact-name" v-text="item.name"></h4>
																<p class="oa-contact-email" v-text="item.phone"></p>
															</div>
														</div>
													</div>
												</li>
											</template>
										</template>
									</template>
								</ul>
							</div>

						</div>

						<div style="position: absolute; left: 10px; bottom: 0px; z-index: 2;">
							<span id="show_s" class="color-primary" style="font-size: 17px;" v-text="select_phones"></span>
						</div>
						<div style="position:absolute;right:30px;bottom:0;z-index: 3;">
							<button id='done' class="mui-btn mui-btn-nav mui-btn-primary mui-pull-right mui-disabled" onclick="batchSetECList()">确定</button>
						</div>
					</div>
				</div>
				<!-- 手机通讯录选择end -->
			</div>*/

function init() {
	var div1 = document.createElement("div");
	div1.className = "";

	/*app Div Start*/
	var div2 = document.createElement("div");
	div2.className = "mui-views";
	div2.id = "app";

	var div3 = document.createElement("div");
	div3.className = "mui-view";

	var div4 = document.createElement("div");
	div4.className = "mui-navbar";

	var div5 = document.createElement("div");
	div5.className = "mui-pages";
	div3.appendChild(div4);
	div3.appendChild(div5);
	div2.appendChild(div3);
	div1.appendChild(div2);
	/*app Div End*/

	/*通讯录Start*/

	var dHead = document.createElement("div");
	dHead.id = "select_member";
	dHead.className = "mui-page";

	var div6 = document.createElement("div");
	div6.id = "phone_list";

	var div7 = document.createElement("div");
	div7.id = "show_select_phone";
	div7.className = "pop-up";
	div7.style = "height: 100%;";
	div7.setAttribute("v-show", "select_phone");

	var div8 = document.createElement("div");
	div8.className = "pop-header";

	var h1 = document.createElement("h1");
	h1.className = "p-title";
	h1.innerHTML = "请选择手机通讯录成员";

	var button1 = document.createElement("button");
	button1.className = "mui-btn mui-btn-link mui-pull-left";
	button1.id = "cannel_phones_id";
	button1.style.display = "none";
	//button1.setAttribute("@click", "hidePhoneSelect");
	button1.innerHTML = "取消";
	div8.appendChild(h1);
	div8.appendChild(button1);
	div7.appendChild(div8);

	var div9 = document.createElement("div");
	div9.className = "pop-title";

	var div10 = document.createElement("div");
	div10.className = "pop-title";
	div7.appendChild(div9);
	div7.appendChild(div10);

	var di1 = document.createElement("div");
	di1.className = "mui-indexed-list address-list hide";
	di1.id = "list";

	/*di1.appendChild(di2);
	di1.appendChild(di3);*/

	var di2 = document.createElement("div");
	di2.className = "mui-indexed-list-search mui-input-row mui-search";

	var input1 = document.createElement("input");
	input1.className = "mui-input-clear mui-indexed-list-search-input";
	input1.type = "search";
	input1.placeholder = "搜素";
	di2.appendChild(input1);
	di1.appendChild(di2);

	var di3 = document.createElement("div");
	di3.className = "mui-indexed-list-bar";

	var di4 = document.createElement("div");
	di4.className = "align-middle";
	var tmpArr = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "N", "M", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "#"];

	for(var i = 0; i < tmpArr.length; i++) {
		var a1 = document.createElement("a");
		a1.innerHTML = tmpArr[i];
		di4.appendChild(a1);
	}
	di3.appendChild(di4);
	di1.appendChild(di3)

	/*<div class="mui-indexed-list-alert"></div>
							<div class="mui-indexed-list-inner">
								<div id="empty-view" class="mui-indexed-list-empty-alert">没有数据</div>
								
								<ul class="mui-table-view">
								
									<template v-for="(items,index1) in phones">1
										<template v-for="(item,index2) in items">2
											<template v-if="item.name">3
												<template v-if="item.isp == 1">4
													<li :data-group="item.first" class="mui-table-view-divider mui-indexed-list-group">
														{{item.first}}
													</li>
												</template>
												<li :data-value="item.first" class="mui-table-view-cell mui-indexed-list-item mui-checkbox">
													<div class="mui-slider-cell">
														<div class="oa-contact-cell mui-table">
															<div class="oa-contact-input mui-table-cell"><input type="checkbox" :value="item.name+'='+item.phone" /></div>
															<div class="oa-contact-avatar mui-table-cell">
																<span class="oa-pic-default bgr2" v-text="item.name"></span>
															</div>
															<div class="oa-contact-content mui-table-cell">
																<h4 class="oa-contact-name" v-text="item.name"></h4>
																<p class="oa-contact-email" v-text="item.phone"></p>
															</div>
														</div>
													</div>
												</li>
											</template>
										</template>
									</template>
								</ul>
							</div>*/

	var d1 = document.createElement("div");
	d1.className = "mui-indexed-list-alert";
	di1.appendChild(d1);

	var d2 = document.createElement("div");
	d2.className = "mui-indexed-list-inner";

	var d3 = document.createElement("div");
	d3.className = "mui-indexed-list-empty-alert";
	d3.id = "empty-view";
	d3.innerHTML = "没有数据";

	d2.appendChild(d3);

	var u1 = document.createElement("ul");
	u1.className = "mui-table-view";

	var template1 = document.createElement("template");
	template1.setAttribute("v-for", "(items,index1) in phones");

	var template2 = document.createElement("template");
	template2.setAttribute("v-for", "(item,index2) in items");

	var template3 = document.createElement("template");
	template3.setAttribute("v-if", "item.name");

	var template4 = document.createElement("template");
	template4.setAttribute("v-if", "item.isp == 1");

	var l11 = document.createElement("li");
	l11.className = "mui-table-view-divider mui-indexed-list-group";
	l11.setAttribute("data-group", "item.first");
	l11.innerHTML = "{{item.first}}";
	template4.appendChild(l11);
	template3.appendChild(template4);

	var l12 = document.createElement("li");
	l12.className = "mui-table-view-cell mui-indexed-list-item mui-checkbox";
	l12.setAttribute(":data-value", "item.first");

	var d10 = document.createElement("div");
	d10.className = "mui-slider-cell";

	var d11 = document.createElement("div");
	d11.className = "oa-contact-cell mui-table";

	var d12 = document.createElement("div");
	d12.className = "oa-contact-input mui-table-cell";

	var input4 = document.createElement("input");
	input4.className = "";
	input4.type = "checkbox";
	input4.setAttribute(":value", "item.name+'='+item.phone");
	d12.appendChild(input4);
	d11.appendChild(d12);

	var d13 = document.createElement("div");
	d13.className = "oa-contact-avatar mui-table-cell";

	var span1 = document.createElement("span");
	span1.className = "oa-pic-default bgr2";
	span1.setAttribute("v-text", "item.name");
	d13.appendChild(span1);
	d11.appendChild(d13);

	var d14 = document.createElement("div");
	d14.className = "oa-contact-content mui-table-cell";

	var h41 = document.createElement("h4");
	h41.className = "oa-contact-name";
	h41.setAttribute("v-text", "item.name");

	var p1 = document.createElement("p");
	p1.className = "oa-contact-email";
	p1.setAttribute("v-text", "item.phone");
	d14.appendChild(h41);
	d14.appendChild(p1);
	d11.appendChild(d14);
	d10.appendChild(d11);
	l12.appendChild(d10);

	template3.appendChild(l12);
	template2.appendChild(template3);
	template1.appendChild(template2);

	u1.appendChild(template1);
	d2.appendChild(u1);

	di1.appendChild(d2);

	var dd1 = document.createElement("div");
	dd1.style = "position: absolute; left: 10px; bottom: 0px; z-index: 2;";

	var span4 = document.createElement("span");
	span4.className = "color-primary";
	span4.id = "show_s";
	span4.style = "font-size: 17px;";
	span4.setAttribute("v-text", "select_phones");
	dd1.appendChild(span4);

	var dd2 = document.createElement("div");
	dd2.style = "position:absolute;right:30px;bottom:0;z-index: 3;";
	dd2.className = "";

	var button7 = document.createElement("button");
	button7.className = "mui-btn mui-btn-nav mui-btn-primary mui-pull-right mui-disabled";
	button7.id = "done";
	button7.setAttribute("onclick", "batchSetECList()");
	button7.innerHTML = "确定";

	dd2.appendChild(button7);
	div7.appendChild(di1);
	div7.appendChild(dd1);
	div7.appendChild(dd2);
	div6.appendChild(div7);
	dHead.appendChild(div6);
	div1.appendChild(dHead);

	document.body.appendChild(div1);

}
//init();
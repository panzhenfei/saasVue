/**
 * demo 返回整个评价节点,自定义添加进页面各个角落
 * var commentBodyDiv = init("测试", ["测试1", "测试2", "测试3", "测试4", "测试5"], 5, ["极差", "较差", "一般", "较好", "超级棒"], false, function() {
	//alert("请打分!")
}, function() {

});
 *
 * @param {Object} title  标题
 * @param {Object} commentOptionArr 指标项
 * @param {Object} StartSize 评分星数量
 * @param {Object} commentSpanArr 评分星对应的提示
 * @param {Object} isPic 是否上传图片(待优化)
 * @param {Object} Fn 有未评项提示
 * @param {Object} Fx 点击发布回调事件
 */

var commentFN = {

    init: function(commentJson, title, commentOptionArr, StartSize, commentSpanArr, isPic, Fn, Fx) {
        var commentBodyDiv = document.createElement("div");
        commentBodyDiv.className = "module01";

        var commentTitleDiv = document.createElement("div");
        commentTitleDiv.className = "module01-head";
        var titleTextSpan = document.createElement("sapn");
        titleTextSpan.className = "title line-title";
        titleTextSpan.innerHTML = title;

        commentTitleDiv.appendChild(titleTextSpan);
        commentBodyDiv.appendChild(commentTitleDiv);

        /*评论选项--------------------------Start*/
        var commentOptionDiv = document.createElement("div");
        commentOptionDiv.className = "comment-score";
        var resultJson = {};
        var options = [];

        for(var i = 0; i < commentOptionArr.length; i++) {
            var thisCommentOptionArr = commentOptionArr[i];
            options.push(commentOptionArr[i]);

            var div1 = document.createElement("div");
            div1.className = "item-score";

            var label1 = document.createElement("label");
            label1.innerHTML = commentOptionArr[i] + "：";
            div1.appendChild(label1);
            resultJson[commentOptionArr[i]] = "0";

            var div2 = document.createElement("div");
            div2.className = "score-box";

            for(var j = 0; j < StartSize; j++) {
                var i1 = document.createElement("i");
                i1.setAttribute("nowOption", commentOptionArr[i]);
                i1.className = "ystar_3";
                i1.setAttribute("index", j + 1);
                i1.onclick = function() {
                    var index = this.getAttribute("index");
                    var divList = this.parentNode.childNodes;

                    for(var k = 0; k < divList.length; k++) {
                        if(k < index) {
                            divList[k].className = "ystar_1";
                        } else {
                            divList[k].className = "ystar_3";
                        }

                    }
                    this.parentNode.nextSibling.innerHTML = commentSpanArr[index - 1];
                    var resJson = JSON.parse(this.parentNode.parentNode.parentNode.getAttribute("resultJson"));
                    resJson[this.getAttribute("nowOption")] = index;
                    this.parentNode.parentNode.parentNode.setAttribute("resultJson", JSON.stringify(resJson))

                }
                div2.appendChild(i1);
            }
            div1.appendChild(div2);

            var span1 = document.createElement("span");
            span1.className = "txt-evaluation";
            span1.innerText = "请打分";
            div1.appendChild(span1);

            commentOptionDiv.appendChild(div1);

        }
        commentOptionDiv.setAttribute("resultJson", JSON.stringify(resultJson));
        commentBodyDiv.appendChild(commentOptionDiv);
        /*评论选项--------------------------End*/

        /*评论内容--------------------------Start*/

        var contetnDiv = document.createElement("div");
        contetnDiv.className = "textarea-box";

        var contetnBodyDiv = document.createElement("div");
        contetnBodyDiv.className = "mui-input-row";

        var contetnTextarea = document.createElement("textarea");
        contetnTextarea.placeholder = "说说它的优点和不足";
        contetnBodyDiv.appendChild(contetnTextarea);
        contetnDiv.appendChild(contetnBodyDiv);

        commentBodyDiv.appendChild(contetnDiv);

        /*评论内容--------------------------End*/

        /*评论图片--------------------------Start*/
        //待优化
        if(isPic) { //是否有上传图片的功能

            var contetnPicDiv = document.createElement("div");
            contetnPicDiv.className = "comment-img-container comment-img-container02";

            var contetnPicUl = document.createElement("ul");
            contetnPicUl.className = "img-container";

            var contetnPicLi = document.createElement("li");
            contetnPicLi.className = "comment-img-item upload-btn";
            var inp1 = document.createElement("input");
            inp1.type = "file";
            contetnPicLi.appendChild(inp1);
            contetnPicUl.appendChild(contetnPicLi);
            contetnPicDiv.appendChild(contetnPicUl);

            commentBodyDiv.appendChild(contetnPicDiv);

        }

        /*评论图片--------------------------End*/

        /*评论发布--------------------------Start*/

        /*<a class="mui-btn" href="#">去评价</a>*/
        var a1 = document.createElement("a");
        a1.className = "mui-btn";
        a1.style = "margin: 10px 10px;";
        a1.innerHTML = "评论";
        a1.setAttribute("jsonStr", JSON.stringify(commentJson));
        a1.onclick = function() {
            var rJson = JSON.parse(this.previousSibling.previousSibling.getAttribute("resultJson"));
            var textValue = this.previousSibling.childNodes[0].childNodes[0].value;
            rJson.textValue = textValue;
            //console.log(rJson)
            for(var key in rJson) {
                if(rJson[key] == "0" || rJson[key] == "undefined") {
                    //alert("请打分!")
                    Fn && Fn();
                    return;
                }
            }

            Fx && Fx(JSON.parse(this.getAttribute("jsonStr")),rJson, this);

            //commentFN.isUnableEdit(this);

        }
        commentBodyDiv.appendChild(a1);

        /*评论发布--------------------------End*/

        return commentBodyDiv;
        //document.body.appendChild(commentBodyDiv);
    },
    isUnableEdit: function(aObj) {

        if(aObj.getAttribute("isSave") == "1") {
            aObj.previousSibling.childNodes[0].childNodes[0].disabled = "disabled";
            var iArr = aObj.previousSibling.previousSibling.getElementsByTagName("i");
            for(var i = 0; i < iArr.length; i++) {
                iArr[i].onclick = null;

            }
            aObj.style.display = "none";

        }

    }

};
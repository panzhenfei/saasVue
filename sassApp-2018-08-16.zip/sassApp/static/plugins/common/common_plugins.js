/**
 * 需要Jq配合
 */
var commonPlugins = {

	getProjectInfo: function(Id, Fn) {

		/**
		 * 给Li提供选择项目,提供项目Id
		 * @param {Object} Id
		 */

		/*<a class="mui-navigate-right" href="#">
					<label>项目名称</label><span class="mui-badge mui-badge-inverted">海乐花苑建筑装饰工程</span>
				</a>*/

		var obj = document.getElementById(Id);

		obj.addEventListener("click", function() {
			var selectDiv = document.getElementById("common_select_div");
			selectDiv.style.display = selectDiv.style.display == "none" ? "block" : "none";

			commonPlugins.preventBubble();

		})

		var a1 = document.createElement("a")
		a1.className = "mui-navigate-right";
		a1.href = "#";

		var label1 = document.createElement("label")
		label1.innerHTML = "项目名称";

		var span1 = document.createElement("span")
		span1.className = "mui-badge mui-badge-inverted";
		span1.innerHTML = "请选择";
		span1.id = "project_text";

		a1.appendChild(label1);
		a1.appendChild(span1);
		obj.appendChild(a1)

		commonPlugins.ajaxGetProjectInfo(10169, function(data) {
			console.log(data)
			var optArr = [];
			for(var i = 0; i < data.length; i++) {
				var tmpJson = {};
				tmpJson.k = data[i].projectName;
				tmpJson.v = data[i].projectId;
				optArr.push(tmpJson);
			}

			commonPlugins.createSelectDiv(optArr, function(li) {
				var opt = JSON.parse(li.getAttribute("opt"));
				console.log(opt)
				document.getElementById("project_text").innerHTML = opt.k;
				document.getElementById("project_text").setAttribute("value", opt.v);

				Fn && Fn(opt);
			});

		});

	},
	ajaxGetProjectInfo: function(userid, Fn) {

		$.ajax({
			type: "get",
			url: "/trans_api/get_projectinfo",
			async: false,
			data: {
				"userid": userid
			},
			datatype: "json",
			success: function(data) {
				var result = data.result;
				Fn && Fn(result);

			},

			error: function(e) {
				console.log(e)

			}
		});

	},
	createSelectDiv: function(opt, Fn) {
		//div.id = common_select_div
		//div.id text = common_select_text

		var div1 = document.createElement("div");
		div1.id = "common_select_div";

		div1.className = "mui-popup mui-popup-in";
		div1.style.display = "none";

		var div2 = document.createElement("div");
		div2.id = "common_select_text";
		div2.className = "mui-popup-title mui-text-left";
		div2.innerHTML = "正在加载";

		var ul1 = document.createElement("ul");
		ul1.id = "common_select_ul";
		ul1.className = "mui-popup-content mui-table-view mui-text-left eg-table-view";
		ul1.style.maxHeight = "300px";
		ul1.style.overflow = "auto";

		if(opt.length == undefined || opt.length == 0) {
			var li1 = commonPlugins.createSelectLi();
			ul1.appendChild(li1);
		}

		for(var i = 0; i < opt.length; i++) {

			var li1 = commonPlugins.createSelectLi(opt[i], Fn);
			ul1.appendChild(li1);

		}

		div1.appendChild(div2);
		div1.appendChild(ul1);

		document.addEventListener("click", function() {
			var thisDiv = document.getElementById("common_select_div");
			thisDiv.style.display = "none";
		})

		document.body.appendChild(div1);

		return div1;

	},
	createSelectLi: function(opt, Fn) {
		var li1 = document.createElement("li");
		li1.className = "mui-table-view-cell";
		//li1.id = dynamicTableId + "_select_nothing";
		li1.setAttribute("opt", JSON.stringify(opt));

		if(opt == undefined) {
			li1.innerHTML = "无";
			return li1;
		}

		li1.innerHTML = opt.k;
		li1.setAttribute("value", opt.v);

		li1.addEventListener("click", function() {
			Fn && Fn(li1);
		})

		return li1;
	},
	preventBubble: function(event) {

		var e = arguments.callee.caller.arguments[0] || event; //若省略此句，下面的e改为event，IE运行可以，但是其他浏览器就不兼容  
		if(e && e.stopPropagation) {
			e.stopPropagation();
		} else if(window.event) {
			window.event.cancelBubble = true;
		}

	}

};
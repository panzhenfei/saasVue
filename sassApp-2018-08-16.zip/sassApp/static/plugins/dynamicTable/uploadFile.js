/**
 * 
 * @param {String} uploadFileId
 * 显示附件上传的DIv 的id
 * 
 * @param {String} action
 * 上传的地址 ///sass_api/up_file 默认
 * 
 * @param {Function} Fn
 * 上传成功后的回调函数
 * 
 * @param {String} module
 * 模块名,不给模块名或者给空就是labour,默认为labour
 * 
 * @param {Boolean} multiple
 * 是否多选, true为多选,不填或者false是单选
 */
function FileUpload(uploadFileId, action, Fn, module, multiple) {
	/**
	 * type 0 保存,1读取,初始化为保存状态
	 */
	uploadFile.init(uploadFileId, 0, action, Fn, module, multiple);
}

var uploadFile = {
	init: function(uploadFileId, type, action, Fn, module, multiple) {
		this.createBody(uploadFileId, type, action, Fn, module, multiple);
	},
	createBody: function(uploadFileId, type, action, Fn, module, multiple) {

		if(uploadFileId == "" || uploadFileId == undefined) { //判断是否有这个div
			alert("请给指定的div的Id");
			return;
		}

		var div1 = document.getElementById(uploadFileId);
		var div2 = document.createElement("div");
		div2.className = "singlebox";
		var label1 = document.createElement("div");
		label1.innerHTML = "附件列表";
		var span1 = document.createElement("span");
		span1.className = "mui-badge mui-badge-inverted";
		if(type == 0) {
			//需要保存
			var span2 = document.createElement("span");
			span2.id = "uploadBtu";
			span2.className = "mui-icon mui-icon-paperclip";
			span1.appendChild(span2);
		}

		var form1 = document.createElement("form");
		form1.id = uploadFileId + "Form";
		form1.style.display = "none";
		form1.method = "post";
		form1.action = type == 0 ? action : "";
		form1.enctype = "multipart/form-data";
		form1.onsubmit = function() {
			uploadFile.Successcallback(uploadFileId, Fn);
			return false;
		}
		var upFile = document.createElement("input");
		upFile.id = "upFile";
		upFile.name = "file";
		upFile.type = "file";
		if(multiple) {
			upFile.multiple = "multiples";
		}
		upFile.className = "nput-file";
		upFile.onclick = function() {
			try {
				window.webactivity.setInputType(0);
			} catch(e) {
				//TODO handle the exception
				console.log(e.message)
			}
		}
		upFile.onchange = function() {
			uploadFile.uploadF();
		}

		var input20 = document.createElement("input");
		input20.type = "text";
		input20.name = "module";
		input20.id = "module";
		input20.value = module;

		var input2 = document.createElement("input");
		input2.type = "text";
		input2.name = "userid";
		input2.id = "userid";
		input2.value = getCookie("userid");

		var input3 = document.createElement("input");
		input3.type = "text";
		input3.name = "nowNum";
		input3.id = "nowNum";

		var input4 = document.createElement("input");
		input4.type = "text";
		input4.name = "filename";
		input4.id = "filename";

		var input5 = document.createElement("input");
		input5.type = "text";
		input5.name = "filesize";
		input5.id = "filesize";

		var input7 = document.createElement("input");
		input7.type = "text";
		input7.name = "fileJson";
		input7.id = "fileJson";

		var input6 = document.createElement("input");
		input6.type = "submit";
		input6.id = "formSub";

		/*<input id="formSub" type="submit" />*/

		form1.appendChild(upFile);
		form1.appendChild(input2);
		form1.appendChild(input3);
		form1.appendChild(input4);
		form1.appendChild(input5);
		form1.appendChild(input6);
		form1.appendChild(input7);
		form1.appendChild(input20); //模块名

		var div3 = document.createElement("div");
		div3.className = "enclosure";
		div3.id = "fileBox";
		div3.setAttribute("uploadNum", 0);

		var h51 = document.createElement("h5");
		h51.className = "mui-content-padded content-added";

		if(type == 0) {
			span2.onclick = function() {
				upFile.click();

			}

		}

		div2.appendChild(label1);
		div2.appendChild(span1);
		div2.appendChild(form1);

		div1.appendChild(div2);
		div1.appendChild(div3);
		div1.appendChild(h51);
		return div1;

	},
	Successcallback: function(uploadFileId, Fn) {
		/**
		 * 上传成功的回调函数
		 * @param {String} uploadFileId 显示附件的Div 的id
		 * @param {Function} Fn 提供的回调函数
		 */

		$("#" + uploadFileId + "Form").ajaxSubmit(function(message) {

			var result = message.result;

			for(var i = 0; i < result.length; i++) {

				var n = result[i].random; //获取上传成功附件位置
				var thisNode = document.getElementById("file_" + n);

				var UploadJson = uploadFile.getUploadJson(); //获取上传附件状态Json

				if(thisNode != undefined && UploadJson[n] != undefined) {
					//修改附件上传状态

					if(message.code == 200) {
						//上传成功
						thisNode.innerHTML = "上传成功";

						var tmpNode = document.getElementById("upload_" + n);

						var span1 = document.createElement("span"); //添加删除按钮
						span1.className = "btn-delete";
						span1.setAttribute("index", n);
						span1.setAttribute("fileid", result[i].id);
						span1.setAttribute("onclick", "uploadFile.deleteFile(this);")
						tmpNode.appendChild(span1);
						//修改状态
						UploadJson[n] = uploadFile.getNeedJson(UploadJson[n])
						UploadJson[n].status = true;
						UploadJson[n].id = result[i].id;

						//UploadJson[n] = message.result.id;

					} else if(message.code == 500) {
						//上传失败
						thisNode.innerHTML = "上传失败";
					}
				}

				uploadFile.setUploadJson(UploadJson);
			}
			Fn && Fn(message);
		});

		return false;

	},
	uploadF: function() {
		var filename = document.getElementById("upFile").value;
		uploadFile.createItem();
		document.getElementById("formSub").click();
	},
	createItem: function() {
		/**
		 * 创建附件项
		 * 拼接数据
		 */

		var files = document.getElementById("upFile").files;
		var fileJson = new Array(); //上传到后台的json字符串

		for(var i = 0; i < files.length; i++) {

			var file = files[i];

			var filesize = file.size;
			var filename = file.name;

			var n = fileBox.getAttribute("uploadNum");
			n++;

			var innerStr = '<div id="upload_' + n + '" class="enclosure-item" >' +
				'<span class="enclosure-type"></span>' +
				'<div class="enclosure-con">' +
				'<p class="name">' + filename + '	<span id="file_' + n + '">正在上传</span></p>' +
				'<P class="secondary">' + (filesize / 1024).toFixed(2) + 'KB</P>' +
				'</div></div>';

			//			document.getElementById("nowNum").value = n;
			
			var newJson = {};//当行的数据
			newJson.filename = filename;//文件名
			newJson.thisNum = n;//当行附件的位置
			fileJson.push(JSON.stringify(newJson))//后台接收参数字段
			document.getElementById("fileJson").value = "[" + fileJson.toString() + "]";
			fileBox.innerHTML += innerStr;
			
			var UploadJson = uploadFile.getUploadJson();//获取上传总状态
			UploadJson[n] = uploadFile.getNeedJson(UploadJson[n]);//添加当前附件到总状态中,为satus false 

			UploadJson[n] = {
				"status": false
			};
			uploadFile.setUploadJson(UploadJson);
			fileBox.setAttribute("uploadNum", n);
		}
	},
	setDeleteJson: function(node) {

		var index = node.getAttribute("index");

		var fileBox = document.getElementById("fileBox");
		var deleteArr = fileBox.getAttribute("deleteArr");
		deleteArr = deleteArr == "" || deleteArr == null ? index : deleteArr + "," + index;
		fileBox.setAttribute("deleteArr", deleteArr);

		//node.parentNode.remove();

		var UploadJson = uploadFile.getUploadJson();
		delete UploadJson[index]
		uploadFile.setUploadJson(UploadJson);

		//index.get

	},
	deleteFile: function(node) {

		confirmLayer("是否删除该附件", function() {

			var index = node.getAttribute("index");
			var fileid = node.getAttribute("fileid");
			document.getElementById("file_" + index).innerHTML = "正在删除";
			node.style.display = "none";
			console.log(fileid)

			if(fileid != null && fileid != "") {

				uploadFile.deleteAjax(fileid, function(data) {

					var code = data.code;

					if(code == 0) {

						var UploadJson = uploadFile.getUploadJson();
						//上传数目
						var fileBox = document.getElementById("fileBox");
						var uploadnum = fileBox.getAttribute("uploadnum");
						fileBox.setAttribute("uploadnum", (uploadnum - 1));

						delete UploadJson[index]
						uploadFile.setUploadJson(UploadJson);
						console.log(fileid)

						// warmAlert(data.message, function() {
						node.parentNode.parentNode.removeChild(node.parentNode);
						layer.closeAll();

						//});

					}

				});

			}

		})

		//ajax

	},
	deleteAjax: function(fileId, Fn) {
		$.ajax({
			type: "post",
			url: "/sass_api/delete_file",
			data: {
				"fileId": fileId,
				"userId": getCookie("userid")
			},
			datatype: "json",
			success: function(data) {
				Fn && Fn(data);
			},
			err: function(e) {
				console.log(e.getMessage())

			}
		});

	},
	getDeleteJson: function() {
		var fileBox = document.getElementById("fileBox");
		fileBox.getAttribute("deleteArr");

	},
	getNeedJson: function(thisJson) {

		if(thisJson == undefined) {
			//没有
			var newJson = {};
			return JSON.parse(JSON.stringify(newJson));
		} else {
			//有
			return thisJson;
		}

	},
	getUploadJson: function() {

		var fileBox = document.getElementById("fileBox");
		var UploadJsonStr = fileBox.getAttribute("UploadJson");

		if(UploadJsonStr == "" || UploadJsonStr == undefined || UploadJsonStr == null) {
			var newJson = {};
			return newJson;
		} else {
			return JSON.parse(UploadJsonStr);
		}

	},
	getUploadResult: function() {

		var fileBox = document.getElementById("fileBox");
		var UploadJsonStr = fileBox.getAttribute("UploadJson");

		if(UploadJsonStr == "" || UploadJsonStr == undefined || UploadJsonStr == null) {
			return false;
		} else {
			if(UploadJsonStr.indexOf("false") > 0) {
				return false;
			}
			return JSON.parse(UploadJsonStr);
		}

	},
	getUploadIds: function() {
		var j = uploadFile.getUploadResult();
		if(j == null) {
			return null;
		}
		var ids = "";
		for(var i in j) {
			ids = ids == "" ? j[i].id : ids + "," + j[i].id;
		}
		return ids;

	},
	setUploadJson: function(UploadJson) {
		var fileBox = document.getElementById("fileBox");
		fileBox.setAttribute("UploadJson", JSON.stringify(UploadJson));

	},
	loadUploadFile: function(uploadFileId, loadObj) {

		uploadFile.init(uploadFileId, 1, "");

		if((typeof loadObj) == "string" && loadObj != "") {

			$.ajax({
				type: "post",
				url: "/sass_api/get_uploadfile_info",
				data: {
					"fileIdStr": loadObj
				},

				datatype: "json",
				success: function(data) {
					console.log(data);

					var result = data.result;

					if(result.length != undefined && result != null) {

						for(var i = 0; i < result.length; i++) {
							uploadFile.createLoadItem(result[i]);
						}

					}

				}
			});

		}

	},
	createLoadItem: function(data) {
		var fileBox = document.getElementById("fileBox");
		//		shorturl
		/*		var innerStr = '<div class="enclosure-item" >' +

					'<span class="enclosure-type"></span>' +
					'<div class="enclosure-con">' +
					'<p class="name">' + data.filename + '</p>' +
					'<P class="secondary">' + data.filesize + '</P>' +
					'</div></div>';

				fileBox.innerHTML += innerStr;
		*/
		console.log(data)

		var divElent = uploadFile.createFileItem(data.longurl, data.filename, data.filesize, data.shorturl);

		fileBox.appendChild(divElent);

	},
	createFileItem: function(route, filename, filesize, shorturl) {

		var div1 = document.createElement("div");
		div1.className = "enclosure-item";
		div1.setAttribute("route", route);

		div1.onclick = function() {

			uploadFile.fileGetUrl(shorturl, function(data) {
				console.log(data)
				var openurl = data.result;
				window.open(openurl);

			});

		}

		var span1 = document.createElement("span");
		span1.className = "enclosure-type";

		var div2 = document.createElement("div");
		div2.className = "enclosure-con";

		var p1 = document.createElement("p");
		p1.className = "name";
		p1.innerHTML = filename;

		var p2 = document.createElement("p");
		p2.className = "secondary";
		p2.innerHTML = filesize;

		div2.appendChild(p1);
		div2.appendChild(p2);

		div1.appendChild(span1);
		div1.appendChild(div2);

		return div1;

	},
	fileGetUrl: function(shortUrl, Fn) {

		$.ajax({
			type: "post",
			url: "/sass_api/get_file_url",
			data: {
				"shortUrl": shortUrl
			},

			datatype: "json",
			success: function(data) {

				Fn && Fn(data);

			}
		});

	}

};

/*FileUpload("uploadFile", "/sass_api/up_file", function() {
	console.log(uploadFile.getUploadResult())
});

//uploadFile.loadUploadFile("uploadFile", "39,40");*/
/**
 * 2017-09-08 动态表,目前三种形式 select radio single
 */

/*radio单选形式
 * 
{
	name: "类别",//字段中文名
	field: "type",//字段名
	type: "radio",//字段属性
	//isNull: true, //是否为空,默认为false既默认不能为空
	disabled: false,//不能做修改
	placeholder: "请选择类别",//提示语
	opt: ["合同内", "合同外"],//选择的内容,支持 [{k:'',v:''},{k:'',v:''}],赋值
	value: "合同内",//初始值
	run: function(v, n) {//v 当前值的,n当前行数//选择后的触发
	},
}
*/

/* 
 * single
 * 
 * "shuliangContract": {
      name: "合同工程量",*
      field: "shuliangContract",*
      type: "single",*
      isNull: true, //默认为false
      input: "number",//如果是数字字段,默认为text
      formula: "shuliang*danjia",//计算公式
       value: 0//初始值
       hidden: true//是否隐藏
       onchange:function(v, n){
       	
       }
  }, */

function dynamicTable(dynamicTableId, optJson) {
	/*
	 * 给动态表Div 填上初始的数值
	 * 当前行数 lineNum
	 * 已删除的行数 deleteNum
	 * 
	 * 初始化动态表的对象
	 * 
	 */

	this.dynamicJson = optJson;

	dynamicT.initDiv(optJson, dynamicTableId); //改变结构

	//console.log(optJson)
	dynamicT.init(optJson, dynamicTableId); //初始化

}

/*
 * 动态表的方法
 */
var dynamicT = {

	initDiv: function(optJson, dynamicTableId) {
		//改变结构

		var dynamicTable = document.getElementById(dynamicTableId);

		var dynamicTablePar = document.createElement("div");
		dynamicTablePar.id = "dynamicTableId_par";
		var dynamicTable_copy = document.createElement("div");
		dynamicTable_copy.id = dynamicTableId;
		dynamicTable_copy.setAttribute("lineNum", 0);
		dynamicTable_copy.setAttribute("deleteNum", 0);

		dynamicTablePar.appendChild(dynamicTable_copy);
		var selectDiv = dynamicT.createSelectDiv(dynamicTableId);
		dynamicTablePar.appendChild(selectDiv);
		var tmpPar = dynamicTable.parentNode;
		tmpPar.insertBefore(dynamicTablePar, dynamicTable);
		dynamicTable.remove();

	},
	createSelectDiv: function(dynamicTableId) {

		/*<div class="mui-popup mui-popup-in" style="display: none;">
				<div class="mui-popup-title mui-text-left">选择要确认签到的项目</div>
				<ul id="projectSelect" class="mui-popup-content mui-table-view mui-text-left eg-table-view">
					<li id="projectNothing" class="mui-table-view-cell">无</li>
				</ul>
			</div>*/

		var div1 = document.createElement("div");
		div1.id = dynamicTableId + "_select_div";

		div1.className = "mui-popup mui-popup-in";
		div1.style.display = "none";

		var div2 = document.createElement("div");
		div2.id = dynamicTableId + "_select_text";
		div2.className = "mui-popup-title mui-text-left";
		div2.innerHTML = "正在加载";

		var ul1 = document.createElement("ul");
		ul1.id = dynamicTableId + "select_ul";
		ul1.className = "mui-popup-content mui-table-view mui-text-left eg-table-view";
		ul1.style.maxHeight = "300px";
		ul1.style.overflow = "auto";

		var li1 = dynamicT.createSelectLi(dynamicTableId, "无");

		ul1.appendChild(li1);
		div1.appendChild(div2);
		div1.appendChild(ul1);

		document.addEventListener("click", function() {
			var thisDiv = document.getElementById(dynamicTableId + "_select_div");
			thisDiv.style.display = "none";
		})

		return div1;

	},
	createSelectLi: function(dynamicTableId, opt, field, Fn) {
		var li1 = document.createElement("li");
		li1.className = "mui-table-view-cell";
		//li1.id = dynamicTableId + "_select_nothing";
		li1.setAttribute("fieldName", field);

		if((typeof opt) == "string") {
			li1.innerHTML = opt;
			li1.setAttribute("value", opt);

		} else {
			li1.innerHTML = opt.k;
			li1.setAttribute("value", opt.v);
		}

		li1.addEventListener("click", function() {
			Fn && Fn(li1);
		})

		return li1;
	},
	init: function(optJson, dynamicTableId) {

      //  console.log(optJson)
        /**
		 * 初始化动态表
		 * @param {Object} optJson 配置参数Json
		 * @param {Object} dynamicTableId 动态表Div的Id
		 */

		var dynamicTable = document.getElementById(dynamicTableId);
		var f = optJson.field;

		console.log("字段",f)
		//创建下一行按钮
		var div1 = document.createElement("div");
		div1.id = dynamicTableId + "_" + "addLine";
		div1.className = "bill-more";
		div1.innerHTML = '<span class="mui-icon mui-icon-plusempty"></span>增加一行';
		div1.onclick = function() {

            console.log("字段",f)
			//点击事件为加一行
			dynamicT.addLine([dynamicT.createHead(optJson.title, dynamicTableId), dynamicT.createUl(f, dynamicTableId)], dynamicTableId, f);
		}

		//console.log("div",div1)
		dynamicTable.appendChild(div1);

		//初始添加第一行		
		this.addLine([this.createHead(optJson.title, dynamicTableId), this.createUl(f, dynamicTableId)], dynamicTableId, f);

	},

	loadDynamic: function(dynamicTableId, optJson, loadJson) {
		/**
		 * 显示动态表的数据
		 * 
		 * @param {Object} dynamicTableId 动态表的Id
		 * @param {Object} optJson 初始化配置Json
		 * @param {Object} loadJson 显示的数组对象Json
		 */

		//需要显示多少行
		var lineNum = loadJson.length;
		//获取配置字段Json
		var f = optJson.field;
		//遍历显示Json
		for(var i = 0; i < lineNum; i++) {
			//加一行
			this.addLine([this.createHead(optJson.title, dynamicTableId), this.createUl(f, dynamicTableId)], dynamicTableId);

			//遍历配置Json
			for(field in f) {

				//获取当前字段的input
				var thisInput = document.getElementsByName(field + "_" + (i + 1))[0];
				//如果input不为空
				if(thisInput != undefined) {

					//当前行数字段的值

					if(loadJson[i][field] == null && f[field].show != true) {
						dynamicT.hideField(field, (i + 1))

						continue;
					}

					//console.log(loadJson[i][field])
					var thisFieldValue = loadJson[i][field] == undefined ? "" : loadJson[i][field];

					//时间格式需要转化毫秒数转化为为时间格式的字符串,如果不是则忽视
					try {
						thisFieldValue = f[field].format != undefined ? new Date(thisFieldValue).Format(f[field].format) : thisFieldValue;
					} catch(e) {
						console.log(e);
						console.log("转换出错");
						thisFieldValue = loadJson[i][field];
					}

					if(f[field].type == "single") {
						//单行

						if(!thisFieldValue){
                            thisFieldValue=0;
						}
						thisInput.value = thisFieldValue;

					} else if(f[field].type == "select") {
						//多选

						/*thisInput.previousSibling.value = thisFieldValue;
						var option = document.createElement("option");
						option.innerHTML = thisFieldValue;
						option.checked = "checked";
						thisInput.previousSibling.appendChild(option);*/
						thisInput.nextSibling.style.display = "none";

						thisInput.value = thisFieldValue;
					} else if(f[field].type == "radio") {
						//radio显示与single一样
						var deleteDiv = thisInput.parentNode;
						var lableNode = deleteDiv.previousSibling;
						//lableNode.className = "";
						var liNode = thisInput.parentNode.parentNode;
						liNode.className = "mui-table-view-cell mui-input-row";
						deleteDiv.remove();
						var inp1 = document.createElement("input");
						inp1.type = "text";
						inp1.value = thisFieldValue
						;
						inp1.name = field + "_" + (i + 1);
						liNode.appendChild(inp1);

					}

				}
			}
		}
		this.frostDynamic(dynamicTableId);
	},
	createUl: function(f, dynamicTableId) {

		//TODO UL

		/**
		 *创建动态表Ul 
		 * @param {Object} f 字段配置
		 * @param {Object} dynamicTableId 动态表Id
		 */
		var ul1 = document.createElement("ul");
		ul1.className = "mui-table-view eg-table-view";

		//console.log("动态创建表",f)
		for(key in f) {

			if(f[key].type == "single") {

				//创建单行
				ul1.appendChild(this.createSingle(f[key], dynamicTableId))
			} else if(f[key].type == "select") {

				//创建下拉选
				//ul1.appendChild(this.createSelect(f[key], dynamicTableId))
				ul1.appendChild(this.creatNewSelect(f[key], dynamicTableId))

			} else if(f[key].type == "radio") {

				ul1.appendChild(this.createRadio(f[key], dynamicTableId))

			}
		}

		return ul1;

	},
	addLine: function(addArr, dynamicTableId, fieldJson) {

		/**
		 *添加一行 
		 * @param {Object} addArr [head,ul] 组成的一行
		 * @param {Object} dynamicTableId 动态表id
		 * @param {Object} fieldJson 字段配置   //用于配置公式用
		 */


		//console.log("初始化数组",addArr)
		if(addArr.length != undefined) {
			var dynamicTable = document.getElementById(dynamicTableId);
			var addLine = document.getElementById(dynamicTableId + "_addLine");
			var newDiv = document.createElement("div");
            newDiv.name='lineIndex';
			for(var i = 0; i < addArr.length; i++) {
				newDiv.appendChild(addArr[i]);
			}


			//console.log("index",this.setLineNum(dynamicTableId))
			newDiv.setAttribute("lineIndex", this.setLineNum(dynamicTableId));
			//添加一行
			dynamicTable.insertBefore(newDiv, addLine);

			//添加计算公式
			for(key in fieldJson) {

				if(fieldJson[key].formula != "" && fieldJson[key].formula != undefined) {
					//添加值改变的返回方法,公式中添加返回值
					dynamicT.formulaSum(fieldJson[key].formula, this.getAllLineNum(dynamicTableId), key, fieldJson);
				}

			}

		}
	},

	createHead: function(title, dynamicTableId) {
		/**
		 *创建头部 
		 * @param {Object} title
		 * @param {Object} dynamicTableId
		 */

		var div1 = document.createElement("div");
		div1.className = "bill-title";
		var span1 = document.createElement("span");
        span1.name="biaoti";
		span1.className = "title";
		span1.innerHTML = title + "（" + (this.getLineNum(dynamicTableId) + 1) + "）";
		var span2 = document.createElement("span");
		span2.className = "btn-delete";
		span2.innerHTML = "删除";
		span2.name = "deleteBtu";
		span2.onclick = function() {
			//删除点击事件
			var parentN = this.parentNode.parentNode;
			//
			dynamicT.subtractLineNum(dynamicTableId);
			document.getElementById(dynamicTableId).removeChild(parentN);
			//刷新标题下标
            var linenum=document.getElementById(dynamicTableId).getAttribute("linenum");
            var childrens = document.getElementById(dynamicTableId).childNodes;
            if(childrens && childrens.length>0 && linenum>0){
				for(var i=0;i<linenum;i++){
					var num=i*1+1;
                  var head = document.getElementById(dynamicTableId).childNodes[i].childNodes[0].firstChild;
                    head.innerHTML=title + "（" + num + "）";
                    document.getElementById(dynamicTableId).childNodes[i].setAttribute("lineindex",num);
				}
			}

		}
		div1.appendChild(span1);
		div1.appendChild(span2);


		return div1

	},
	createSingle: function(thisJson, dynamicTableId) {
		//console.log("创建",thisJson)
		/**
		 * 创建 
		 * @param {Object} thisJson
		 * @param {Object} dynamicTableId
		 */

		var li1 = document.createElement("li");
		li1.className = "mui-table-view-cell mui-input-row";
		var label1 = document.createElement("label");
		label1.innerHTML = thisJson.name;

		var input1 = document.createElement("input");

		if(thisJson.input == undefined) {
			//没有这个属性默认为text
			input1.type = "text";

		} else if(thisJson.input == "number") {

			input1.type = "number";
			input1.min = "0.0";
			input1.step = "0.1";

		}

		if(thisJson.disabled == true) {
			input1.disabled = "disabled";
		}

		if(thisJson.value != null && thisJson.value != undefined) {
			input1.value = thisJson.value;
		}

		/*if(thisJson.onchange != null && thisJson.onchange != undefined) {

			var changeFn = thisJson.onchange;

			input1.addEventListener("change", function() {
				changeFn && changeFn();
			})

			//input1.value = thisJson.value;
		}*/

		var n = this.getAllLineNum(dynamicTableId);
		//监听值变更时触发
		var changeFn = thisJson.onchange;
		input1.addEventListener("input", function() {

			//console.log("变更...")
			var thisNode = document.getElementsByName(thisJson.field + "_" + (n + 1))[0];
			if(thisNode != null) {
				changeFn && changeFn(thisNode.value, n + 1);
			}

		})

		input1.name = thisJson.field + "_" + (n + 1);
		input1.setAttribute("fieldName", thisJson.field);
		//input1.placeholder = thisJson.name;

		input1.placeholder = thisJson.placeholder == undefined ? "" : thisJson.placeholder;

		li1.appendChild(label1);

		if(thisJson.hidden == true && thisJson.hidden != undefined) {
			li1.style.display = "none";
		}

		li1.setAttribute("property", thisJson.field + "_" + (n + 1))
		li1.setAttribute("field", thisJson.field);
		li1.setAttribute("lineNum", (n + 1));
		li1.id = thisJson.field + "_" + (n + 1)

		li1.appendChild(input1);

		return li1;
	},
	createRadio: function(thisJson, dynamicTableId) {

		/**
		 * 创建radio行
		 * @param {Object} thisJson 当前行的json
		 * @param {Object} dynamicTableId 动态表的ID
		 */

		var n = this.getAllLineNum(dynamicTableId);

		var li1 = document.createElement("li");
		li1.className = "mui-table-view-cell muitl-input-row";
		var label1 = document.createElement("label");
		label1.innerHTML = thisJson.name;
		label1.className = "mui-pull-left";

		var input2 = document.createElement("input");
		input2.name = thisJson.field + "_" + (n + 1);
		input2.id = thisJson.field + "_input_" + (n + 1);
		input2.style.display = "none";

		li1.appendChild(label1);

		var div1 = document.createElement("div");
		div1.className = "select-box col-xs-6";
		div1.style.overflow = "hidden";

		div1.appendChild(input2);

		var thisOpt = thisJson.opt;

		//创建单选框
		for(var i = 0; i < thisOpt.length; i++) {

			var div2 = document.createElement("div");
			div2.className = "mui-input-row mui-radio mui-left";

			var label1 = document.createElement("label");

			var input1 = document.createElement("input");
			input1.type = "radio";
			input1.name = thisJson.field + "_radio_" + (n + 1);
			input1.setAttribute("fieldName", thisJson.field);

			input1.addEventListener("click", function() {
				//点击选中单选按钮,给当前行的input添加值
				var inpNode = document.getElementById(thisJson.field + "_input_" + (n + 1));
				var radioNodes = document.getElementsByName(thisJson.field + "_radio_" + (n + 1));
				var thisValue = dynamicT.getRadioValue(radioNodes);
				inpNode.value = thisValue;

				var thisRun = thisJson.run;
				//运行run方法,就是点击选择的后续方法
				thisRun && thisRun(this.getAttribute("value"), (n + 1));

			});

			if(thisJson.disabled == true) {
				input1.disabled = "disabled";
			}

			/**
			 * 赋值,两种赋值方法,和select相同
			 * 支持["",""]方式,key和value相同
			 * 支持[{"k":"显示的值","v":"选中后赋的值"},{"k":"显示的值","v":"选中后赋的值"}]
			 * 两种方式,看情况选择,在赋值的时候判断是否有默认值,选中存在的默认值
			 */
			if((typeof thisOpt[i]) == "string") {
				label1.innerHTML = thisOpt[i];
				input1.value = thisOpt[i];
				input1.setAttribute("key", thisOpt[i])

				if(thisJson.value != null && thisJson.value != undefined) {

					if(thisOpt[i] == thisJson.value) {
						input1.checked = "checked";
						input2.value = thisJson.value;
					}
				}
			} else {
				label1.innerHTML = thisOpt[i].k;
				input1.value = thisOpt[i].v;
				input1.setAttribute("key", thisOpt[i].k)
				if(thisJson.value != null && thisJson.value != undefined) {
					if(thisOpt[i].k == thisJson.value || thisOpt[i].v == thisJson.value) {
						input1.checked = "checked";
						input2.value = thisJson.value;
					}
				}

			}

			div2.appendChild(label1);
			div2.appendChild(input1);
			div1.appendChild(div2);

		}

		li1.appendChild(div1);

		//是否一开始就隐藏
		if(thisJson.hidden == true && thisJson.hidden != undefined) {
			li1.style.display = "none";
		}

		li1.setAttribute("property", thisJson.field + "_" + (n + 1))
		li1.setAttribute("field", thisJson.field);
		li1.setAttribute("lineNum", (n + 1));
		li1.id = thisJson.field + "_" + (n + 1)

		return li1;

	},

	creatNewSelect: function(thisJson, dynamicTableId, changeNum) {

		console.log("创建下拉框",thisJson)
		/**
		 * 创建下拉单选 
		 * @param {Object} thisJson 配置Json
		 * @param {Object} dynamicTableId 动态表id
		 * @param {Object} changeNum 改变的第几行,可以为空 
		 */

		var thisOpt = thisJson.opt;
		var n = changeNum != undefined ? (changeNum - 1) : dynamicT.getAllLineNum(dynamicTableId);

		var li1 = document.createElement("li");
		li1.className = "mui-table-view-cell mui-input-row";

		var label1 = document.createElement("label");
		label1.innerHTML = thisJson.name;

		var input2 = document.createElement("input");
		input2.type = "text";
		//input2.className = "mui-table-view-cell mui-input-row";

		input2.name = thisJson.field + "_" + (n + 1);
		//input2.style.display = "none"; //默认隐藏
		//提示语
		input2.placeholder = thisJson.placeholder == undefined ? "" : thisJson.placeholder;

		if(thisJson.disabled == true) {
			//不可修改
			input2.disabled = "disabled";
		}

		if(thisJson.value != null && thisJson.value != undefined) {
			//默认值
			input2.value = thisJson.value;
		}

		var button1 = document.createElement("button");
		button1.className = "mui-btn select-btn";
		button1.innerHTML = '选择<span class="mui-icon mui-icon-arrowdown"></span></span>';
		button1.style.display = (thisJson.select == true || thisJson.select == undefined) ? "block" : "none";

		button1.addEventListener("click", function(event) {

			var selectDiv = document.getElementById(dynamicTableId + "_select_div");
			var selectText = document.getElementById(dynamicTableId + "_select_text");
			selectText.innerHTML = thisJson.name;
			var selectUl = document.getElementById(dynamicTableId + "select_ul");

			if(thisOpt.length > 0) {
				selectUl.innerHTML = "";
			}

			var thisRun = thisJson.run;

			for(var i = 0; i < thisOpt.length; i++) {

				var li2 = dynamicT.createSelectLi(dynamicTableId, thisOpt[i], thisJson.field + "_" + (n + 1), function(node) {
					var fieldname = node.getAttribute("fieldname");
					var inpNode = document.getElementsByName(fieldname)[0];
					inpNode.value = node.getAttribute("value");
					thisRun && thisRun(node.getAttribute("value"), (n + 1));
				});

				selectUl.appendChild(li2);

			}

			selectDiv.style.display = selectDiv.style.display == "block" ? "none" : "block";
			event.stopPropagation();

		})

		li1.appendChild(label1);
		li1.appendChild(input2);
		li1.appendChild(button1);

		if(thisJson.hidden == true && thisJson.hidden != undefined) {
			//隐藏
			li1.style.display = "none";
		}

		li1.setAttribute("property", thisJson.field + "_" + (n + 1))
		li1.setAttribute("field", thisJson.field);
		li1.setAttribute("lineNum", (n + 1));
		li1.id = thisJson.field + "_" + (n + 1);

		return li1;

	},

	createSelect: function(thisJson, dynamicTableId, changeNum) {

		/**
		 * 
		 * @param {Object} thisJson
		 * @param {Object} dynamicTableId
		 * @param {Object} changeNum //改变的行数,用于改变多选行
		 */

		//创建多选项

		//当前行一共行数
		//如果changeNum存在就证明是需要更改的行数
		var n = changeNum != undefined ? (changeNum - 1) : dynamicT.getAllLineNum(dynamicTableId);

		var li2 = document.createElement("li");
		li2.className = "mui-table-view-cell mui-input-row";
		var div2 = document.createElement("div");
		div2.className = "mui-push-right";
		var label2 = document.createElement("label");
		label2.innerHTML = thisJson.name;
		var select1 = document.createElement("select");
		select1.style.position = "relative";

		//input
		var input2 = document.createElement("input");

		input2.name = thisJson.field + "_" + (n + 1);
		input2.style.display = "none"; //默认隐藏

		//提示语
		input2.placeholder = thisJson.name + "(双击选择)";
		input2.setAttribute("loadStr", thisJson.name + "(双击选择)");

		//双击事件,用于可改状态时使用
		input2.ondblclick = function() {
			this.style.display = "none";
			this.value = "";
			var options = this.previousSibling.getAttribute("options");
			this.previousSibling.innerHTML = options;

		}

		if(thisJson.disabled == true) {
			//不可修改
			select1.disabled = "disabled";
			input2.disabled = "disabled";
		}

		if(thisJson.value != null && thisJson.value != undefined) {
			//默认值
			select1.value = thisJson.value;
			input2.value = thisJson.value;
		}

		var thisOpt = thisJson.opt;
		//选项

		var option2 = document.createElement("option");
		//第一项为默认请选择
		option2.innerHTML = "请选择";
		option2.value = "";
		select1.appendChild(option2);

		//遍历选项配置
		for(var i = 0; i < thisOpt.length; i++) {

			var option1 = document.createElement("option");

			if((typeof thisOpt[i]) == "string") {
				//老版string
				option1.innerHTML = thisOpt[i];
				option1.value = thisOpt[i];
			} else {
				if(thisOpt[i].k != undefined) {
					option1.innerHTML = thisOpt[i].k;
					option1.value = thisOpt[i].v != undefined ? thisOpt[i].v : thisOpt[i].k;
				}

			}

			select1.appendChild(option1);

		}

		if(thisJson.change == true) {
			//自定义填值
			var option3 = document.createElement("option");
			option3.innerHTML = "自定义";
			option3.value = "自定义";
			select1.appendChild(option3);

		}

		select1.onchange = function() {
			//select改变时

			if(this.value == "自定义") {
				this.setAttribute("options", this.innerHTML);

				this.innerText = "";

				var inputNode = select1.nextSibling;
				var loadStr = inputNode.getAttribute("loadStr")
				inputNode.value = "";
				inputNode.placeholder = loadStr;
				var width = dynamicT.getStyle(this, "width");
				var height = dynamicT.getStyle(this, "height");

				inputNode.style = "display:block;width:" + width + ";height:" + height + ";left:" + this.offsetLeft + "px;";
				inputNode.style.position = "absolute";

			} else {
				document.getElementsByName(thisJson.field + "_" + (n + 1))[0].value = this.value == "请选择" ? "" : this.value;

				if(this.value != "") {
					var thisRun = thisJson.run;
					thisRun && thisRun(this.value, (n + 1));
				}

			}

		}
		div2.appendChild(label2);
		div2.appendChild(select1);
		div2.appendChild(input2);
		li2.appendChild(div2);

		if(thisJson.hidden == true && thisJson.hidden != undefined) {
			//隐藏
			li2.style.display = "none";
		}

		li2.setAttribute("property", thisJson.field + "_" + (n + 1))
		li2.setAttribute("field", thisJson.field);
		li2.setAttribute("lineNum", (n + 1));
		li2.id = thisJson.field + "_" + (n + 1);

		return li2;

	},

	changeSelect: function(dynamicTableId, lineNum, changeJson) {

		/**
		 * 替换行变成Newselect 
		 * @param {Object} dynamicTableId
		 * @param {Object} lineNum
		 * @param {Object} changeJson
		 */

		/*{
			name: "类别",
			field: "type",
			type: "select",
			//isNull: true, //默认为false
			opt: ["合同内", "合同外", "增加工"],
			run: function(v) {
				alert(v)
			},
		}*/

		var field = changeJson.field;
		var liNode = document.getElementById(field + "_" + lineNum);

		//var newLi = dynamicT.createSelect(changeJson, dynamicTableId, lineNum);
		var newLi = dynamicT.creatNewSelect(changeJson, dynamicTableId, lineNum);

		liNode.parentNode.insertBefore(newLi, liNode);
		liNode.remove();
	},
	getAllLineNum: function(dynamicTableId) {
		/**
		 * 获取总数,包括已删除
		 * @param {Object} dynamicTableId
		 */

		return this.getLineNum(dynamicTableId) + this.getDeleteNum(dynamicTableId);
	},

	getLineNum: function(dynamicTableId) {
		/**
		 * 存在的行数
		 * @param {Object} dynamicTableId 动态表的div的id
		 */

		var dynamicTable = document.getElementById(dynamicTableId);

		return Number(dynamicTable.getAttribute("lineNum"));

	},

	setLineNum: function(dynamicTableId, num) {

		/**
		 * //设置lineNum的数值,
		 * @param {Object} dynamicTableId
		 * @param {Object} num
		 */

		var dynamicTable = document.getElementById(dynamicTableId);
		var n
		if(num == undefined) {
			n = this.getLineNum(dynamicTableId) + 1;
			dynamicTable.setAttribute("lineNum", n)
		} else {
			n = num;
			dynamicTable.setAttribute("lineNum", n)
		}

		return n;
	},
	subtractLineNum: function(dynamicTableId) {
		/**
		 *  减去当前行数,加上删除行数
		 * @param {Object} dynamicTableId 动态表id
		 */

		var dynamicTable = document.getElementById(dynamicTableId);

		//把当前行数减一
		var n = Number(this.getLineNum(dynamicTableId)) - 1;
		dynamicTable.setAttribute("lineNum", n);
		//把已减行数加一
		this.addDeleteNum(dynamicTableId);
		return n;

	},

	addDeleteNum: function(dynamicTableId) {
		/**
		 *  动态表删除行数+1
		 * @param {Object} dynamicTableId
		 */

		var dynamicTable = document.getElementById(dynamicTableId);
		var n = this.getDeleteNum(dynamicTableId) + 1;
		dynamicTable.setAttribute("deleteNum", n)
		return n;
	},

	getDeleteNum: function(dynamicTableId) {

		/**
		 * 获取已经删除的行数
		 * @param {Object} dynamicTableId
		 */

		var dynamicTable = document.getElementById(dynamicTableId);
		var n = Number(dynamicTable.getAttribute("deleteNum"));
		return n;

	},
	onlyNumber: function(event) {
		/**
		 * 只有数字
		 */
		var keyCode = event.keyCode;
		if(keyCode < 48 || keyCode > 57) {
			event.keyCode = 0;
		}
	},

	getResultJson: function(dynamicTableId, dynamicJson) {

		/**
		 * 获取 动态表填写的内容
		 * @param {Object} dynamicTableId
		 * @param {Object} dynamicJson
		 */

		var isMove = false;
		var fieldArr = []; //字段名的Arr
		var thisJson = dynamicJson.field;

		for(key in thisJson) {
			//key 字段
			fieldArr.push(key);
		}

		var n = this.getAllLineNum(dynamicTableId); //已产生的行数

		var resultArr = [];

		for(var i = 1; i <= n; i++) {
			var newJson = {};
			var isAdd = false;

			for(var o = 0; o < fieldArr.length; o++) {
				//遍历字段Arr

				if(document.getElementsByName(fieldArr[o] + "_" + i)[0] == undefined) {
					break;
				}
				isAdd = true;

				var thisNode = document.getElementsByName(fieldArr[o] + "_" + i)[0];

				if(thisJson[fieldArr[o]].isNull == undefined || thisJson[fieldArr[o]].isNull == false) {
					//没有设置是否为空,默认为不为空(false)

					if(thisJson[fieldArr[o]].type == "single") {
						//单选

						if(thisNode.value == "") {
							thisNode.style.border = "1px solid red";
							isMove = dynamicT.moveScroll(thisNode, isMove);
						} else {
							thisNode.style.border = "";
						}

					} else if(thisJson[fieldArr[o]].type == "select") {
						//多选

						if(thisNode.value == "") {
							thisNode.style.border = "1px solid red";
							isMove = dynamicT.moveScroll(thisNode, isMove);
						} else {
							thisNode.style.border = "";
						}

					} else if(thisJson[fieldArr[o]].type == "radio") {
						// radio为空边框设置

						if(thisNode.value == "") {
							thisNode.parentNode.style.border = "1px solid red";
							isMove = dynamicT.moveScroll(thisNode.parentNode, isMove);
						} else {
							thisNode.parentNode.style.border = "";
						}

					}

				} else if(thisJson[fieldArr[o]].isNull == true) {
					//可以为空
					thisNode.style.border = "";

				}

				//当前行字段的结果
				newJson[fieldArr[o]] = document.getElementsByName(fieldArr[o] + "_" + i)[0].value;

			}

			if(isAdd) {
				resultArr.push(newJson)
			}

		}

		return isMove == true ? null : resultArr;
		//return resultArr;

	},

	moveScroll: function(thisNode) {
		//移动至不能为空的行
		var docTop = document.body.clientHeight; //可见搞
		var screenTop = window.screen.heightl //屏幕高
		var thisTop = this.getElementTop(thisNode.previousSibling); //元素上的高

		window.scrollTo(0, thisTop);
		isMove = true;
		return isMove;

		//TODO 保留优化,精确到移动到屏幕中央

		/*if(thisTop / docTop < 0.75) {
			//

		} else {

		}*/

	},
	getElementTop: function(element) {
		//获取元素到顶部的高
		var actualTop = element.offsetTop;　　　　
		var current = element.offsetParent;　　　　
		while(current !== null) {　　　　　　
			actualTop += current.offsetTop;　　　　　　
			current = current.offsetParent;　　　　
		}　　　　
		return actualTop;　　

	},
	frostDynamic: function(dynamicTableId) {
		//冻结动态表
		var dynamicTable = document.getElementById(dynamicTableId);

		var inputArr = dynamicTable.getElementsByTagName("input");
		var selectArr = dynamicTable.getElementsByTagName("select");

		var spanArr = dynamicTable.getElementsByTagName("span");

		for(var i = 0; i < inputArr.length; i++) {
			inputArr[i].disabled = "disabled";

		}

		for(var o = 0; o < selectArr.length; o++) {
			selectArr[o].disabled = "disabled";
		}

		for(var p = 0; p < spanArr.length; p++) {
			if(spanArr[p].innerHTML == "删除") {
				spanArr[p].style.display = "none";
			}

		}

	},
	unfreezeDynamic: function(dynamicTableId) {
		//解冻动态表
		var dynamicTable = document.getElementById(dynamicTableId);

		var inputArr = dynamicTable.getElementsByTagName("input");
		var selectArr = dynamicTable.getElementsByTagName("select");

		var spanArr = dynamicTable.getElementsByTagName("span");

		for(var i = 0; i < inputArr.length; i++) {
			inputArr[i].disabled = "";

		}

		for(var o = 0; o < selectArr.length; o++) {
			selectArr[o].disabled = "";
		}

		for(var p = 0; p < spanArr.length; p++) {
			if(spanArr[p].innerHTML == "删除") {
				spanArr[p].style.display = "block";
			}

		}

	},
	unfreezeField: function(dynamicTableId, fieldName) {
		//解冻字段
		var dynamicTable = document.getElementById(dynamicTableId);

		var lineNum = this.getAllLineNum(dynamicTableId);

		var inputArr;
		var selectArr;

		for(var i = 0; i < lineNum; i++) {

			inputArr = document.getElementsByName(fieldName + "_" + (i + 1));
			inputArr[0].disabled = "";

			//待完善

			//selectArr = document.getElementsByName(fieldName + "_" + (i + 1));

		}

	},

	formulaSum: function(formula, lineNum, targetField, optJson) {

		/**
		 * 计算公式 
		 * @param {Object} formula 公式
		 * @param {Object} lineNum 当前行号
		 * @param {Object} targetField 当前key
		 * @param {Object} optJson  配置json
		 */

		var formula_copy = formula;

		//公式计算
		//var formula = "a+b*c/d-a";

		var newArr;
		var sJson = {};
		formula = formula.replace(/\+/g, "|+|");
		formula = formula.replace(/\-/g, "|-|");
		formula = formula.replace(/\*/g, "|*|");
		formula = formula.replace(/\//g, "|/|");

		formula = formula.replace(/\(/g, "|(|");
		formula = formula.replace(/\)/g, "|)|");
		var formulaArr = formula.split("|");

		var formulaField = formula_copy;

		formulaField = formulaField.replace(/\+/g, "|");
		formulaField = formulaField.replace(/\-/g, "|");
		formulaField = formulaField.replace(/\*/g, "|");
		formulaField = formulaField.replace(/\//g, "|");

		formulaField = formulaField.replace(/\(/g, "|");
		formulaField = formulaField.replace(/\)/g, "|");

		var formulaFieldArr = this.arrUniq(formulaField.split("|"));

		for(var i = 0; i < formulaFieldArr.length; i++) {

			var thisNode = document.getElementsByName(formulaFieldArr[i] + "_" + lineNum)[0];
			var thisFiledName = formulaFieldArr[i];
			if(thisNode != null) {
				var formulaArrStr = thisNode.getAttribute("formulaArr");
				var formulaArr

				if(formulaArrStr != "" && formulaArrStr != undefined) {
					//有其他公式
					formulaArr = JSON.parse(formulaArrStr);
				} else {
					//没有其他公式
					formulaArr = [];
				}

				formulaArr.push(formula_copy);

				thisNode.setAttribute("formulaArr", JSON.stringify(formulaArr));
				//console.log(thisNode)

				thisNode.onchange = function() {
					//					var changeFn = optJson[thisFiledName].onchange;
					//					changeFn && changeFn(thisNode.value, lineNum);
					dynamicT.calculate(this.getAttribute("fieldname"), lineNum, targetField, optJson);
				}
			}

		}

	},
	arrUniq: function(arr) {
		//数组去重
		var result = []
		for(var i = 0; i < arr.length; i++) {
			if(result.indexOf(arr[i]) == -1) {
				result.push(arr[i])
			}
		}
		return result;

	},
	calculate: function(field, lineNum, targetField, optJson) {

		//计算

		var thisNode = document.getElementsByName(field + "_" + lineNum)[0];

		//console.log(thisNode)

		var formulaArr = JSON.parse(thisNode.getAttribute("formulaArr"));

		for(var i = 0; i < formulaArr.length; i++) {
			var formula = formulaArr[i];

			var newArr;
			var sJson = {};

			formula = formula.replace(/\+/g, "|+|");
			formula = formula.replace(/\-/g, "|-|");
			formula = formula.replace(/\*/g, "|*|");
			formula = formula.replace(/\//g, "|/|");
			formula = formula.replace(/\)/g, "|)|");
			formula = formula.replace(/\(/g, "|(|");

			//console.log(formulaArr)

			var formulaArr = formula.split("|");

			for(var i = 0; i < formulaArr.length; i++) {

				if(formulaArr[i] != "+" && formulaArr[i] != "-" && formulaArr[i] != "*" && formulaArr[i] != "/") {
					if(sJson[formulaArr[i]] == undefined) {
						newArr = [];
					} else {
						newArr = sJson[formulaArr[i]]
					}

					newArr.push(i)
					sJson[formulaArr[i]] = newArr;

					var needNode = document.getElementsByName(formulaArr[i] + "_" + lineNum)[0];
					if(needNode != undefined && needNode != null) {
						//删除一项，插入两项
						formulaArr.splice(i, 1, Number(needNode.value));
					}
				}
			}

			//onchange属性添加在计算中 ,用于在计算后能够得到准确的改变数值

			var changeFn = optJson[targetField].onchange;
			var formulaStr = formulaArr.join("");
			var resultValue = eval(formulaStr);
			var targetField = document.getElementsByName(targetField + "_" + lineNum)[0];
			if(targetField != null && targetField != undefined) {
				targetField.value = resultValue;
				changeFn && changeFn(resultValue, lineNum);
			}
		}
	},
	clearTable: function(dynamicTableId, optJson) {
		//初始化动态表
		var dynamicTable = document.getElementById(dynamicTableId);
		dynamicTable.setAttribute("linenum", "0");
		dynamicTable.setAttribute("deletenum", "0");
		dynamicTable.innerHTML = "";

		if(optJson != undefined) {
			dynamicT.init(optJson, dynamicTableId);
		}

	},
	getFieldAllValue: function(dynamicTableId, fieldName) {
		//获取字段的全部值
		var dynamicTable = document.getElementById(dynamicTableId);
		var lineNum = this.getAllLineNum(dynamicTableId);
		var needInputNode;
		var returnArr = [];
		for(var i = 0; i < lineNum; i++) {
			needInputNode = document.getElementsByName(fieldName + "_" + (i + 1))[0];

			if(needInputNode != undefined) {
				returnArr.push(needInputNode.value);
			}
		}
		return returnArr;
	},
	getStyle: function(obj, attr) {
		//获取元素的样式属性
		return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj)[attr];
	},

	getRadioValue: function(thisNodes) {

		/**
		 *获取radio的选中值 
		 * @param {Object} thisNodes //radio的全部节点
		 */

		if(thisNodes.length != undefined) {

			for(var i = 0; i < thisNodes.length; i++) {

				if(thisNodes[i].checked) {
					return thisNodes[i].value;
				}
			}
		}
		return "";

	},
	hideField: function(fieldName, lineNum) {
		//隐藏某行某个字段
		var liNode = document.getElementById(fieldName + "_" + lineNum);
		if(liNode != null) {
			liNode.style.display = "none";
		}

	}

};

　　
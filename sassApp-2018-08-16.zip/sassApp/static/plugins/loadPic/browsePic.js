﻿document.writeln("<div class=\"pswp\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">");
document.writeln("    <div class=\"pswp__bg\"><\/div>");
document.writeln("    <div class=\"pswp__scroll-wrap\">");
document.writeln("        <div class=\"pswp__container\">");
document.writeln("            <div class=\"pswp__item\"><\/div>");
document.writeln("            <div class=\"pswp__item\"><\/div>");
document.writeln("            <div class=\"pswp__item\"><\/div>");
document.writeln("        <\/div>");
document.writeln("        <div class=\"pswp__ui pswp__ui--hidden\">");
document.writeln("            <div class=\"pswp__top-bar\">");
document.writeln("                <div class=\"pswp__counter\"><\/div>");
document.writeln("                <button class=\"pswp__button pswp__button--close\" title=\"Close (Esc)\"><\/button>");
//document.writeln("                <button class=\"pswp__button pswp__button--share\" title=\"Share\"><\/button>");
// document.writeln("                <button class=\"pswp__button pswp__button--fs\" title=\"Toggle fullscreen\"><\/button>");
// document.writeln("                <button class=\"pswp__button pswp__button--zoom\" title=\"Zoom in\/out\"><\/button>");
document.writeln("                <div class=\"pswp__preloader\">");
document.writeln("                    <div class=\"pswp__preloader__icn\">");
document.writeln("                        <div class=\"pswp__preloader__cut\">");
document.writeln("                            <div class=\"pswp__preloader__donut\"><\/div>");
document.writeln("                        <\/div>");
document.writeln("                    <\/div>");
document.writeln("                <\/div>");
document.writeln("            <\/div>");
document.writeln("            <div class=\"pswp__share-modal pswp__share-modal--hidden pswp__single-tap\">");
document.writeln("                <div class=\"pswp__share-tooltip\"><\/div>");
document.writeln("            <\/div>");
document.writeln("            <button class=\"pswp__button pswp__button--arrow--left\" title=\"Previous (arrow left)\">");
document.writeln("            <\/button>");
document.writeln("            <button class=\"pswp__button pswp__button--arrow--right\" title=\"Next (arrow right)\">");
document.writeln("            <\/button>");
document.writeln("            <div class=\"pswp__caption\">");
document.writeln("                <div class=\"pswp__caption__center\"><\/div>");
document.writeln("            <\/div>");
document.writeln("        <\/div>");
document.writeln("    <\/div>");
document.writeln("<\/div>");

var pathname = getPathname();

document.writeln('<link rel="stylesheet" href="' + pathname + 'plugins/loadPic/css/photoswipe.css">');
document.writeln('<link rel="stylesheet" href="' + pathname + 'plugins/loadPic/css/default-skin/default-skin.css">');

document.writeln("<script language='JavaScript' src='" + pathname + "plugins/loadPic/js/photoswipe.js'></script>");
document.writeln("<script language='JavaScript' src='" + pathname + "plugins/loadPic/js/photoswipe-ui-default.min.js'></script>");

var openPhotoSwipe = function(index, items, disableAnimation, fromURL) {
    var pswpElement = document.querySelectorAll('.pswp')[0],
        gallery,
        options;

    // 这里可以定义参数
    options = {
        fullscreenEl : false,//是否需要全屏的按钮
        galleryUID: 0,
    };
    if(fromURL) {
        if(options.galleryPIDs) {
            for(var j = 0; j < items.length; j++) {
                if(items[j].pid == index) {
                    options.index = j;
                    break;
                }
            }
        } else {
            options.index = parseInt(index, 10) - 1;
        }
    } else {
        options.index = parseInt(index, 10);
    }
    if( isNaN(options.index) ) {
        return;
    }
    if(disableAnimation) {
        options.showAnimationDuration = 0;
    }
    gallery = new PhotoSwipe( pswpElement, PhotoSwipeUI_Default, items, options);
    gallery.init();
}

function getPathname() {
	var pathname = window.location.pathname;
	pathname = pathname.substring(0, pathname.indexOf("static") + 7)
	return pathname;

}
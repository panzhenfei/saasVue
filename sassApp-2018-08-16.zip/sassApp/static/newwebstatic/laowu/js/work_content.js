var webPath = getUrl()
var pagepath = getPagePath()
var paramMap = getParam(window.location.href); //获取地址栏参数
var imgid = [] //全局变量获取attachment
var loginType = paramMap.loginType
var projectSn = paramMap.projectSn
var projectName = paramMap.projectName
var currUserPhone = paramMap.currUserPhone
var currRoomId = paramMap.currRoomId
var currRoomImId = paramMap.currRoomImId
var currRoomName = paramMap.currRoomName
var currRoomCreditCode = paramMap.currRoomCreditCode
var isRoomId = paramMap.isRoomId
var isRoomName = paramMap.isRoomName
var isRoomCreditCode = paramMap.isRoomCreditCode
if(paramMap.isRoomCreditCode == '') {
    paramMap.isRoomCreditCode = paramMap.isRoomName
} else {
    paramMap.isRoomCreditCode = paramMap.isRoomCreditCode
}
//存储url信息
localStorage.removeItem("urlnews")
var urlnews = location.href.split("?")[1]
localStorage.setItem("urlnews", urlnews)

//当前用户
var userid = getCookie("userid")
var username = getCookie("username")
//选公司回调
window.appApi.callBackFun = function(callFlag, CONTENT) {
    if(callFlag == appApi.callBackFlag.GONGSI) {
        app.aa(CONTENT);
    }
}
//gongdanTabs: [][{"name":"2018-05-08","selectdStatus":false,"value":[{"sid":"j6e1FDXvA8vz937Mx17L9","mingcheng":"壹壹哈哈","danwei":"宗","shuliang":66,"withShuliang":66,"createDate":1525761848000},{"sid":"05HmmRRlb0JhbI8RvvSyD","mingcheng":"666","danwei":"吨","shuliang":1000,"withShuliang":0,"createDate":1525761069000},{"sid":"4t8CGx46Y30vz6rxWWOjG","mingcheng":"666","danwei":"天","shuliang":1000,"withShuliang":0,"createDate":1525749013000}]},{"name":"2018-05-10","selectdStatus":false,"value":[{"sid":"2BJo2D89JOjirpfGptICE","mingcheng":"我 ","danwei":"吨","shuliang":99,"withShuliang":0,"createDate":1525944581000}]},{"name":"2018-05-06","selectdStatus":false,"value":[{"sid":"K2I3hQwKpOv0f44DKuEeQ","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525601871000},{"sid":"v5jFA1Wk7DC9xUWupqNQO","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525601871000},{"sid":"K2109KmjxaihVsp6086Ig","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525601672000},{"sid":"VPqiKp9ox7RXWgky58ADl","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525601672000},{"sid":"36soNBNCFsncY1KfBT3TX","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525601208000},{"sid":"t98CYqN5VDw8RI9C5A7It","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525601208000},{"sid":"023576yVGcJdcBL13NzW0","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525601185000},{"sid":"ROooBXCRR6kLq0y9El0DR","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525601185000},{"sid":"59kEXlKtV3l0w2NzspVp1","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525596992000},{"sid":"bGnfX3W4aVwBwY29D26OC","mingcheng":"LED灯","danwei":"盏","shuliang":1000,"withShuliang":0,"createDate":1525596992000}]}]
var nes = location.href
var fujianid = [] //全局变量获取attachment

var app = new Vue({
    el: '#app',
    data: {
        units: [{
            value: "平方米"
        }, {
            value: "立方米"
        }, {
            value: "吨"
        }, {
            value: "米"
        }, {
            value: "个"
        }, {
            value: "次"
        }, {
            value: "天"
        }, {
            value: "块"
        }, {
            value: "组"
        }, {
            value: "捆"
        }, {
            value: "宗"
        }, {
            value: "项"
        }, {
            value: "株"
        }],
        nowdata:'',
        startDate: "",
        endDate: "",
        isUnitShow: false,
        selectdTab: {},
        backicon: 0,
        tapyewu: false,
        neshref: nes,
        callbackCode: "", //回调code 111 选人  222选公司
        selectdTadIndex: "", //记录请求选人的列表框下标
        hetongs: [],
        userName: decodeURI(username),
        userID: userid,
        dateShenqing: '',
        projectName: projectName,
        projectSN: projectSn,
        companySaleName: "",
        companySaleID: "",
        companySaleRoomImID: "",
        companySaleRoomID: "",
        companyBuyName: "",
        companyBuyClassName: "",
        companyBuyID: "",
        companyBuyRoomImID: "",
        companyBuyRoomID: "",
        currRoom: {},
        beizhu: "",
        tuisongimid: "",
        contractName: "",
        tabs: [],
        id: '',
        attachmentIds: "",
        currRoomId: paramMap.currRoomId,
        gongdanTabs: [],
        selectdAllGdTabStatus: false,
        money: 0,
        sites: [],
        imgs: [],
        fujians: [],
        zrimg: [],
        zrfujian: [],
        atts: [],
        reponseId: undefined,
        confirm: '',
        postType:'',
        keyall: [],
        postStatus:true,
        cfgid: paramMap.cfgid,
        projectSn: paramMap.projectSn,
        isRoomId: paramMap.isRoomId,
        isRoomName: paramMap.isRoomName,
        isRoomCreditCode: paramMap.isRoomCreditCode,
        currRoomImId: paramMap.isRoomImId,
        currRoomClassName: paramMap.currRoomClassName,
        curRoomName: paramMap.currRoomName,
    },
    //监听
    watch: {
        //列表监听
        gongdanTabs: {
            handler: function(newValue) {
                var _self = this;

                var dateSlectdCount = 0;
                $.each(newValue, function(index) {
                    if(this.selectdStatus) {
                        dateSlectdCount++
                    }
                })
                if(dateSlectdCount == newValue.length) {
                    _self.$data.selectdAllGdTabStatus = true
                } else {
                    _self.$data.selectdAllGdTabStatus = false
                }

            },
            deep: true
        },
    },
    created: function() {
        var _self = this;
        var getTime = new Date()
        //昨天
        var beforedata=new Date(new Date()-24*60*60*1000)
        var beforeyear=beforedata.getUTCFullYear()
        var beforemoth=parseInt(beforedata.getMonth()) + 1
        var beforeday=beforedata.getDate()
        var nowyear = getTime.getUTCFullYear()
        var nowmoth = parseInt(getTime.getMonth()) + 1
        var noeday = getTime.getDate()
        var nowshi = getTime.getHours()
        var noefen = getTime.getMinutes()
        var nowmiao = getTime.getSeconds()
        if(beforemoth < 10) {
            beforemoth= "0" + beforemoth
        }
        if(beforeday < 10) {
            beforeday= "0" + beforeday
        }
        if(nowmoth < 10) {
            nowmoth = "0" + nowmoth
        }
        if(noeday < 10) {
            noeday = "0" + noeday
        }
        if(nowshi < 10) {
            nowshi = "0" + nowshi
        }
        if(noefen < 10) {
            noefen = "0" + noefen
        }
        if(nowmiao < 10) {
            nowmiao = "0" + nowmiao
        }
        _self.$data.nowdata=nowyear+"-"+nowmoth+"-"+noeday
        _self.$data.dateShenqing = nowyear + "-" + nowmoth +
            "-" + noeday + " " + nowshi + ":" + noefen +
            ":" + nowmiao
        //					_self.form.MissionStartDate = formDate("2018-02-05");
        //获取合同数据

        _self.$data.endDate=beforeyear+"-"+beforemoth+"-"+beforeday
        if(paramMap.id != undefined) {
            this.starinfo()
        } else {
            //						_self.getHt()
            _self.getnews()
        }
        //					_self.getHt()
        //					_self.loadData()
    },
    mounted: function() {
        mui.init();
        (function($) {
            //阻尼系数
            //					var deceleration = mui.os.ios?0.003:0.0009;
            $('.mui-scroll-wrapper').scroll({
                bounce: false,
                indicators: true, //是否显示滚动条
                deceleration: 0.0005
            });
        })(mui);
       /* document.getElementById("backdrop").addEventListener(
            'tap',
            function() {
                //阻止默认事件
                event.detail.gesture.preventDefault();
                // 移除手势滑动
                //						mui('.mui-off-canvas-wrap').offCanvas().close()
            });*/
        //主界面容器
        document.getElementsByClassName('mui-inner-wrap')[0]
            .addEventListener('drag', function(event) {
                event.stopPropagation();
            });

        window.addEventListener('touchmove', function(e) {
            var target = e.target;
            if(target && target.tagName === 'TEXTAREA') { //textarea阻止冒泡
                e.stopPropagation();
            }
        }, true);
    },
    // 在 `methods` 对象中定义方法
    methods: {
        fjFileType : function(){
            $(".mui-backdrop-attchments").show();
            $(".pop-up-attchments").show();
        },
        showCloudFile:function(){
            //打开项目列表
            appApi.openNewWindow(getUrl() + "/static/newwebstatic/file_gui/project_list.html?entrance=bill&projectSN="+paramMap.projectSn);

        },
        hideDiv : function(){
            $(".mui-backdrop-attchments").hide();
            $(".pop-up-attchments").hide();
        },
        changeImgIds : function(dishImgIds){//得到广播回来的ID
            var _self = this;
            var forfile = []
            $(".mui-backdrop-attchments").hide();
            $(".pop-up-attchments").hide();

            var parm = {
                dishIds :dishImgIds,
            }
            axios.post(getUrl()+"/contract/copydishinfo",parm).then(function(response){
                var rtnfiles = response.data.result.success;
                for(var i=0;i<rtnfiles.length;i++){
                    fujianid.push(rtnfiles[i].fileId);
                    forfile.push({
                        name: rtnfiles[i].fileName,
                        fileId: rtnfiles[i].fileId
                    })
                }
                _self.$data.fujians = _self.$data.fujians.concat(forfile)
                if(fujianid.toString()){
                    _self.$data.zrfujian = fujianid.toString().split(',')
                }
            })
        },
        //获取退回数据
        //获取退回的数据
        starinfo: function() {
            var _self = this
            var param = {
                id: paramMap.id,
            }
            axios.post(getUrl() + "/contract/get_content", param).then(function(response) {
                if(response.data.code == 200) {
                    var result = response.data.result;
                    console.log("result",result)

                    var norl = JSON.parse(response.data.result.noralJson)
                    console.log("norl",norl.tablefields)
                    var cont = JSON.parse(response.data.result.contentJson)
                    var data = response.data.result
                    //页面上显示信息
                    _self.$data.startDate = norl.tablefields.startDate.split(" ")[0]
                    _self.$data.endDate = norl.tablefields.endDate.split(" ")[0]
                    _self.$data.currRoom.description = norl.tablefields.zhuanye
                    _self.$data.companyBuyClassName = norl.tablefields.companyBuyRoomClassName
                    _self.$data.companyBuyName = norl.tablefields.companyBuyName
                    _self.$data.tabs = norl.subtablefields
                    _self.$data.currRoomId = norl.table.roomid
                    if(norl.attachment&&(norl.attachment.indexOf(",")!=-1)){
                        _self.$data.zrimg = norl.attachment.toString().split(',')
                    }
                    //附件
                    app.imgsrc(norl.attachment)
                    //提交信息
                    _self.$data.id = paramMap.id
                    _self.$data.cfgid = norl.table.id
                    _self.$data.projectSn = norl.table.projectid
                    _self.$data.isRoomId = norl.table.roomid
                    _self.$data.isRoomName = norl.table.roomname
                    _self.$data.isRoomCreditCode = norl.tablefields.companySaleID

                    _self.$data.currRoomImId = norl.currRoomImId
                    _self.$data.currRoomClassName = norl.currRoomClassName
                    _self.$data.curRoomName = norl.curRoomName
                    _self.$data.toImId = norl.toImid
                    _self.$data.companyBuyRoomImID = norl.toImid

                    _self.$data.fapiaoTaxLv = norl.tablefields.fapiaoTaxLv
                    _self.$data.piao = norl.tablefields.fapiaoTitle
                    _self.$data.projectName = norl.tablefields.projectName
                    _self.$data.companyBuyID = norl.tablefields.companyBuyID
                    _self.$data.companyBuyRoomID = norl.tablefields.companyBuyRoomID
                    _self.$data.companySaleID = norl.tablefields.companySaleID
                    _self.$data.companySaleRoomID = norl.tablefields.companySaleRoomID
                    _self.$data.contractType = norl.tablefields.contractType
                    _self.$data.contractID = norl.tablefields.contractID,

                        _self.getnews()
                }
            })
        },
        imgsrc: function(n) {
            var _self = this
            axios.post(getUrl() + "/sass_api/ get_uploadfile_info?fileIdStr=" + n).then(function(response) {
                if(response.data.code == 200) {
                    console.log(response.data.result)
                    for(var i = 0; i < response.data.result.length; i++) {
                        if(response.data.result[i].type == 1) { //imgs fujians name
                            _self.$data.imgs.push({
                                src: response.data.result[i].newThumbnailTurl
                            })
                            imgid.push(response.data.result[i].id)
                            if(imgid.toString()){
                                _self.$data.zrimg = imgid.toString().split(',')
                            }
                        } else {
                            _self.$data.fujians.push({
                                name: response.data.result[i].filename
                            })
                            fujianid.push(response.data.result[i].id)
                            if(fujianid.toString()){
                                _self.$data.zrfujian = fujianid.toString().split(',')
                            }
                        }
                    }

                }
            })
        },
        /**
         * 确认选中
         */
        confirmTabs: function() {
            var _self = this;
            $.each(_self.$data.gongdanTabs, function(i) {
                $.each(this.value, function(j) {
                    _self.synTab(this, i, j)
                })
            })
            document.getElementById("scrpll1").style.display = "block"
            document.getElementById("scrpll2").style.display = "none"
            document.getElementById("scrpll3").style.display = "none"
            _self.$data.backicon = 1
        },
        /**
         * 选中所有工单中的记录
         */
        selectdAllGdTab: function() {
            var _self = this;
            $.each(_self.$data.gongdanTabs, function() {
                this.selectdStatus = _self.$data.selectdAllGdTabStatus;
                $.each(this.value, function() {
                    this.selectdStatus = _self.$data.selectdAllGdTabStatus;
                })
            })
        },
        /**
         * 选中一个时间段中的记录
         */
        selectdDateAllGdTab: function(dateObj) {
            var _self = this;
            $.each(dateObj.value, function(i) {
                this.selectdStatus = dateObj.selectdStatus;
            })
        },
        selectdGdTab: function(tab) {
            var tabSelectdCount = 0;
            $.each(tab.value, function() {
                if(this.selectdStatus) {
                    tabSelectdCount++
                }
            })
            if(tabSelectdCount == tab.value.length) {
                tab.selectdStatus = true
            } else {
                tab.selectdStatus = false
            }
        },
        /**
         * 同步到Tab中
         * @param {Object} tab
         * @param {Object} i
         */
        synTab: function(tab, i, j) {
            var _self = this
            if(tab.selectdStatus) {
                if((tab.index == "" || tab.index == undefined) && tab.index != 0) {
                    _self.$data.tabs.push({
                        "mingcheng": tab.mingcheng,
                        "shuliang": "",
                        "danwei": tab.danwei,
                        "index": i + "-" + j
                    })
                    tab.index = _self.tabs.length - 1
                }
            } else {
                $.each(_self.$data.tabs, function(index) {
                    if(this.index == i + "-" + j) {
                        _self.$data.tabs.splice(index, 1)
                        tab.index = undefined
                    }
                })

            }
        },
        /**
         * 删除已选单位
         */
        delroom: function() {
            var _self = this;
            _self.$data.companyBuyClassName = "";
        },
        /**
         * 上一步事件
         */
        back: function() {
            var _self = this
            if(_self.$data.backicon == 1) {
                document.getElementById("scrpll1").style.display = "none"
                document.getElementById("scrpll2").style.display = "none"
                document.getElementById("scrpll3").style.display = "none"
                setTimeout(function () {
                    appApi.showBack()
                },100)
            }
            if(_self.$data.backicon > 0) {
                if(_self.$data.backicon == 3) {
                    document.getElementById("scrpll1").style.display = "block"
                    document.getElementById("scrpll2").style.display = "none"
                    document.getElementById("scrpll3").style.display = "none"
                    _self.$data.backicon = _self.$data.backicon - 2
                } else if(_self.$data.backicon == 2) {
                    document.getElementById("scrpll1").style.display = "block"
                    document.getElementById("scrpll2").style.display = "none"
                    document.getElementById("scrpll3").style.display = "none"
                    _self.$data.backicon =1
                } else {
                    _self.$data.backicon = _self.$data.backicon - 1
                }

            }

        },
        /**
         * 下一步事件
         * @param {Object} pageIndex 页码
         */
        next: function(pageIndex) {
            var _self = this;
            if(pageIndex == 0) {
                document.getElementById("scrpll1").style.display = "none"
                document.getElementById("scrpll2").style.display = "none"
                document.getElementById("scrpll3").style.display = "none"
            }
            if(pageIndex == 1) {
                var startdate = parseInt(_self.$data.startDate.split("-")[0] + _self.$data.startDate.split("-")[1] + _self.$data.startDate.split("-")[2])
                var enddate = parseInt(_self.$data.endDate.split("-")[0] + _self.$data.endDate.split("-")[1] + _self.$data.endDate.split("-")[2])
                var nowData=parseInt(_self.$data.nowdata.split("-")[0] + _self.$data.nowdata.split("-")[1] + _self.$data.nowdata.split("-")[2])
//							alert(enddate》nowData)
//                             alert(enddate)
//                             alert(nowData)
//                             alert(_self.$data.nowdata)
                if(_self.$data.startDate == "") {
                    ludan("请完善开始日期!", 1, 1)
                    return false;
                } else if(_self.$data.endDate == "") {
                    ludan("请完善结束日期!", 1, 1)
                    return false;
                } else if(enddate < startdate) {
                    ludan("结束日期不能早于开始日期!", 1, 1)
                    return false;
                }else if(enddate>=nowData){
                    ludan("结束日期不能晚于昨天!", 1, 1)
                    return false;
                }else if(_self.$data.companyBuyClassName == "") {
                    ludan("请选择接收单位!", 1, 1)
                    return false;
                }
                document.getElementById("scrpll1").style.display = "block"
                document.getElementById("scrpll2").style.display = "none"
                document.getElementById("scrpll3").style.display = "none"
            } else if(pageIndex == 2) {
                document.getElementById("scrpll1").style.display = "none"
                document.getElementById("scrpll2").style.display = "none"
                document.getElementById("scrpll3").style.display = "block"
            } else if(pageIndex == 3) {
                var flag = _self.checkTabs()
                if(!flag) {
                    return flag;
                }
                document.getElementById("scrpll3").style.display = "none"
                document.getElementById("scrpll1").style.display = "none"
                document.getElementById("scrpll2").style.display = "block"
            }
            appApi.hideBack()
            _self.$data.backicon = pageIndex;

        },
        /**
         * 选择时间
         * @param {Object} t 类型
         */
        selectDate: function(t) {
            var _self = this
            var dtpicker = new mui.DtPicker({
                type: "date", //设置日历初始视图模式
                beginDate: new Date(2015, 04, 25), //设置开始日期
                endDate: new Date(2016, 04, 25), //设置结束日期
                labels: ['年', '月', '日'], //设置默认标签区域提示语
            })
            //设定日期的默认值
            if(t == "end") {
                dtpicker.setSelectedValue(_self.$data.endDate)
            } else {
                dtpicker.setSelectedValue(_self.$data.startDate)
            }
            dtpicker.show(function(e) {

                console.log("选择",e)
                setTimeout(function () {
                    if(t == "end") {
                        dtpicker.setSelectedValue(_self.$data.endDate)
                        _self.$data.endDate = e.value
                    } else {
                        dtpicker.setSelectedValue(_self.$data.startDate)
                        _self.$data.startDate = e.value
                    }
                   dtpicker.dispose()
                },10)
            })
        },
        /**
         * 选择单位
         * @param {Object} item 清单对象
         */
        selectdUnit: function(item) {
            var _self = this;
            _self.$data.selectdTab.danwei = item.value
            _self.mask();
        },
        /**
         * 展示所有单位
         */
        showUnits: function(tab) {
            var _self = this;
            _self.$data.selectdTab = tab;
            $("input").blur();
            $(".mui-backdrop-unit").show();
            _self.$data.isUnitShow = true
        },
        /**
         * 展示选择单位页面
         * @param {Object} tab 清单对象
         */
        showSl: function(tab) {
            console.log(tab)
            var _self = this;
            _self.$data.selectdTab = tab;
            _self.$data.backicon = _self.$data.backicon + 1;
        },
        //excel表格解析
        //					excelAnalysis: function(e) {
        //						loading("解析中")
        //						var _self = this;
        //						var suffix = /\.[^\.]+$/.exec(e.target.files[0].name).toString()
        //						if(suffix == '.xlsx') {
        //							var files = e.target.files;
        //							var fileReader = new FileReader();
        //							fileReader.onload = function(ev) {
        //								try {
        //									var data = ev.target.result,
        //										workbook = XLSX.read(data, {
        //											type: 'binary'
        //										}), // 以二进制流方式读取得到整份excel表格对象
        //										persons = []; // 存储获取到的数据
        //								} catch(e) {
        //									console.log('文件类型不正确');
        //									return;
        //								}
        //								// 表格的表格范围，可用于判断表头是否数量是否正确
        //								var fromTo = '';
        //								var excelname
        //								// 遍历每张表读取
        //								for(var sheet in workbook.Sheets) {
        //									if(workbook.Sheets.hasOwnProperty(sheet)) {
        //										fromTo = workbook.Sheets[sheet]['!ref'];
        //										if(JSON.stringify(XLSX.utils.sheet_to_json(workbook.Sheets[sheet])[0]).split(",")[1] != undefined) {
        //											excelname = JSON.stringify(XLSX.utils.sheet_to_json(workbook.Sheets[sheet])[0]).split(",")
        //										} else {
        //											excelname = []
        //										}
        //										console.log(excelname)
        //										excelname = excelname.toString()
        //										if(excelname.indexOf("mingcheng") != -1 && excelname.indexOf("danwei") != -1) {
        //											persons = persons.concat(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]));
        //										} else {
        //											layer.close(loading("解析中"))
        //											_self.$data.excelok = 1
        //											ludan("导入的模板格式不正确", 2, 3)
        //
        //										}
        //										// break; // 如果只取第一张表，就取消注释这行
        //									}
        //								}
        //								_self.$data.tabs = _self.$data.tabs.concat(persons)
        //								//							console.log(persons);
        //							};
        //							_self.upfile(e)
        //
        //							// 以二进制方式打开文件
        //							fileReader.readAsBinaryString(files[0]);
        //						} else {
        //							layer.close(loading("解析中"))
        //							ludan("导入的文件格式不正确", 2, 3)
        //						}
        //
        //					},
        sx: function() {
            window.location.href = window.location.href;
        },
        getnews: function() {
            var _self = this
            axios
                .get(
                    getUrl() +
                    "/pcontact_api/getroominfo?roomId=" + _self.$data.currRoomId)
                .then(
                    function(response) {
                        if(response.data.code == 0) {
                            _self.$data.currRoom = response.data.result
                            if(!_self.$data.currRoom.description){//由于班组专业名称和房间名称是同一个字段，因此显示房间名称就行
                            	_self.$data.currRoom.description=_self.$data.currRoom.name;
                            }
                            console.log(" _self.$data.currRoom", _self.$data.currRoom)
                            if(_self.$data.currRoom.superiorId != null) {
                                axios
                                    .get(
                                        getUrl() +
                                        "/pcontact_api/getroominfo?roomId=" +
                                        _self.$data.currRoom.superiorId)
                                    .then(
                                        function(
                                            response) {
                                            if(response.data.code == 0) {
                                                console
                                                    .log(response.data.result)
                                                var room = response.data.result
                                                _self.$data.companyBuyID = room.companyCreditCode
                                                _self.$data.companyBuyName = room.name
                                                _self.$data.companyBuyClassName = room.roomClassName
                                                _self.$data.companyBuyRoomID = room.roomId
                                                _self.$data.companyBuyRoomImID = room.roomImId
                                                _self.getBaoliangInfo()
                                            }
                                        })
                            }

                        }
                    })
        },
        //检索列表数据
        checkTabs: function() {
            var _self = this
            var isStatus = true;
            var isname
            $.each(_self.tabs, function(index) {
                var isCue = true;
                if(this.mingcheng == '') {
                    isCue = false
                    isname = "名称"
                } else if(this.danwei == '') {
                    isCue = false
                    isname = "单位"
                } else if(this.shuliang == '') {
                    isCue = false
                    isname = "数量"
                }
                if(!isCue) {
                    if(index > 8) {
                        index = index - 9
                        //									var y = 0 - (Number($("#one").height()) + (Number($("#two").height()) * index))
                        //									mui('.mui-scroll-wrapper').scroll().scrollTo(0, y, 100);
                    } else {
                        //									mui('.mui-scroll-wrapper').scroll().scrollTo(0, 0, 100);
                    }
                    ludan("请填写第" + index + "工作项的" + isname, 1, 1)
                    $(".table-record tbody tr").eq(index).css("background", "#ffebd1")
                    isStatus = false
                    return isStatus;
                    isStatus = false
                }
            })
            return isStatus;
        },
        initData: function(type) {

            //获取数据
            var _self = this;
			var saveType='update';
            var target=event.currentTarget
            if(type == 1) {
                btnStop()
                saveType='save';
                ludan("保存中", 0, 1)
            } else {
                if(_self.$data.postStatus) {
                    _self.$data.postStatus = false;
                }else{
                    return ;
                }
                btnStop()
                saveType='update';
                ludan("提交中", 0, 1)
            }
            //						var fjid = _self.$data.atts.toString()
            var fjid
            if(_self.$data.attachmentIds == '') {
                _self.$data.attachmentIds = ''
            } else {
                _self.$data.attachmentIds = "," + _self.$data.attachmentIds
            }
            if(imgid.toString() == '') {
                fjid = fujianid.toString()
            } else if(fujianid.toString() == '') {
                fjid = imgid.toString()
            } else {
                fjid = imgid.toString() + "," + fujianid.toString()
            }
            if(type == 2) {
                _self.$data.confirm = '1';
                _self.$data.postType = '1';
            } else {
                _self.$data.confirm = '0';
            }
            $.each(_self.$data.tabs,function(){
                this.shuliang=Number(this.shuliang)
                this.danjia=parseFloat(this.danjia)
            })
            var tablefields = {
                id: _self.$data.reponseId,
                userName: _self.$data.userName,
                userID: _self.$data.userID,
                dateShenqing: _self.$data.dateShenqing,
                projectName: _self.$data.projectName,
                projectSN: _self.$data.projectSn,
                companySaleName: _self.$data.isRoomName,
                companySaleID: _self.$data.isRoomCreditCode,
                companySaleRoomID: _self.$data.isRoomId,
                companyBuyName: _self.$data.companyBuyName,
                companyBuyID: _self.$data.companyBuyID,
                companyBuyRoomID: _self.$data.companyBuyRoomID,
                companyBuyRoomClassName: _self.$data.companyBuyClassName,
                beizhu: _self.$data.beizhu,
                zhuanye: _self.$data.currRoom.description,
                startDate: _self.$data.startDate + " 00:00:00",
                endDate: _self.$data.endDate + " 00:00:00",
            }
            if(_self.$data.id != '') {
                tablefields["id"] = _self.$data.id
            }
            //如果当前房间和推送房间roomimid一样 让当前房间roomimid=''
            if(_self.$data.currRoomImId==_self.$data.companyBuyRoomImID){
                _self.$data.companyBuyRoomImID='1'
            }
            var param = {
                table: {
                    id: _self.$data.cfgid,
                    projectid: _self.$data.projectSn,
                    roomid: _self.$data.isRoomId,
                    roomname: _self.$data.isRoomName,
                },
                confirm: _self.$data.confirm,
                postType: _self.$data.postType ,
                attachment: fjid + _self.$data.attachmentIds,
                currRoomImId: _self.$data.currRoomImId,
                currRoomClassName: _self.$data.currRoomClassName,
                curRoomName: _self.$data.curRoomName,
                toImid: _self.$data.companyBuyRoomImID,
                typeName:"报量",
                title:decodeURI(username)+"的报量",
                //							uid: "10392",
                tablefields: tablefields,
                subtablefields: _self.$data.tabs,
                saveType:saveType,
            }
//						alert(JSON.stringify(param))
            console.log(param)
            axios
                .post(getUrl() + "/contract/save", param)
                .then(
                    function(response) {

                        //alert(JSON.stringify(response))
                        if(response.data.code == 200) {

                            //更新完工量
                            var updTabs = []
                            $.each(_self.$data.gongdanTabs, function() {
                                $.each(this.value, function() {
                                    if(this.selectdStatus) {
                                        updTabs.push({
                                            "shuliang": Number(_self.$data.tabs[this.index].shuliang) + Number(this.withShuliang),
                                            "sid": this.sid
                                        })
                                    }
                                })
                            })
                            if(updTabs.length > 0) {
                                axios.post(getUrl() + "/chart/column/updMxCount", updTabs)
                            }

                            console.log(response)
                            _self.$data.id = response.data.result.id
                            _self.$data.reponseId = response.data.result.id
                            _self.$data.sites = response.data.result.tablefields;

                            var titletype = encodeURIComponent(encodeURIComponent("报量"));
                            var title = encodeURIComponent(encodeURIComponent(decodeURI(username)));
                            var todojson = {
                                "title": decodeURI(username) +
                                "的报量",
                                "titileTwo": _self.$data.currRoomClassName +
                                "-" +
                                _self.$data.curRoomName,
                                "content": "开始日期=" +
                                _self.$data.startDate +
                                "|结束日期=" +
                                _self.$data.endDate,
                                "fileCount": '0',
                                "url":
                                '/static/newwebstatic/laowu/transfer.html?id=' +
                                response.data.result.id +
                                "&formroomimid=" +
                                _self.$data.currRoomImId +
                                "&fromcurrRoomName=" +
                                _self.$data.currRoomClassName,
                                "colorString": "",
                                "todoViewableMember": "0",
                                "toImId": _self.$data.companyBuyRoomImID,
                                'currentRoomImid': _self.$data.currRoomImId,
                                "formuserid": userid,
                                "relation": response.data.result.id,
                                "chatType": "2",
                                //									"confirmUrl": "456", //有确认按钮必要参数
                                //									"refusedUrl": "231", //有拒绝按钮必要参数
                                "todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
                                "setButton": [{
                                    "type": 1, //按钮点击类型 1=请求url 2=打开url
                                    "name": "确认",
                                    "url": "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&projectSn=" + _self.$data.projectSn + "&userid=" + userid+"&sendtype=1"+"&titletype="+titletype
                                }, {
                                    "type": 1, //按钮点击类型 1=请求url 2=打开url
                                    "name": "退回",
                                    "url":  "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id + "&projectSn=" + _self.$data.projectSn + "&userid=" + userid+"&title="+title+"&titletype="+titletype+"&sendtype=1"
                                }]
                            }
                            //										alert(JSON.stringify(todojson));

                            if(type == 2) {

                                //清除撤回的待办
                                var parame = new FormData();
                                parame.append("url", '/static/newwebstatic/laowu/transfer.html?id=' +
                                    response.data.result.id +
                                    "&formroomimid=" +
                                    _self.$data.currRoomImId +
                                    "&fromcurrRoomName=" +
                                    _self.$data.currRoomClassName)
                                parame.append("userId",getCookie("userid"))
                                axios.post(getUrl()+"/sass_api/update_withdraw_todo",parame).then(function (response) {

                                });

//                              ludan("提交中", 0, 1)
 								closeLoading();
                                    window.appApi.sendTodo(todojson)

                                // btnstart(target)
                            } else {
                                //ludan("保存中", 0, 1)
                                 closeLoading();
                                ludan("保存成功", 2, 2,function(){
                                	btnstart(target)
                                })
                            }

                        } else {
                        	closeLoading();
                            msg("response")
                        }
                    })
        },
        aa: function(CONTENT) {
            var _self = this;
            if(_self.$data.callbackCode == 111) {
                try {
                    _self.$data.tabs[_self.$data.selectdTadIndex].gongren = xk_util
                        .getArrayProperty(
                            JSON.parse(CONTENT.result),
                            "nickName").toString()
                } catch(err) {
                    alert("错误了")
                    alert(err)
                }
            } else if(_self.$data.callbackCode == 222) {
                var room = JSON.parse(CONTENT.result)
                if(room.companyId == "" || room.companyId == null) {
                    _self.$data.companyBuyID = room.roomName
                } else {
                    _self.$data.companyBuyID = room.companyId
                }
                _self.$data.companyBuyName = room.roomName
                _self.$data.companyBuyClassName = room.roomClassName
                _self.$data.companyBuyRoomID = room.roomId
                _self.$data.companyBuyRoomImID = room.roomImId
//							_self.getBaoliangInfo()
            }
            /*var addname = '&'
            for(var i = 0; i < JSON.parse(CONTENT.result).length; i++) {
                addname += ","
                addname += JSON.parse(CONTENT.result)[i].roomName
            }*/

            _self.$data.tabs[_self.$data.nuberhang].mingcheng = addname
                .split("$,")[1]
        },
        getBaoliangInfo: function() {
            var _self = this
            axios
            // .post(getUrl() + "/chart/column/baoliang_info?companyShigongID=" + _self.$data.companyBuyRoomID + "&currRoomId=" + currRoomId) //_self.$data.companyBuyRoomID+
                .post(getUrl() + "/chart/column/baoliang_info?companyShigongID=" + currRoomId + "&currRoomId=" + _self.$data.companyBuyRoomID ) //_self.$data.companyBuyRoomID+
                .then(function(response) {
                    if(response.data.code == 200) {

                        console.log(response.data.result)
                        console.log(response.data.result.gdmx)
                        var keys = Object.keys(response.data.result.gdmx);
                        console.log(keys)
                        keys.sort(function(a, b) {
                            return new Date(a) < new Date(b) ? 1 : -1;
                        });
                        console.log(keys)
                        $.each(keys, function() {
                            //初始化
                            for(tab in response.data.result.gdmx[p]) {
                                tab.selectdStatus = false;
                            }
                            var key = this.substring(-1, this.length);
                            _self.$data.gongdanTabs.push({
                                "name": key,
                                "selectdStatus": false,
                                "value": response.data.result.gdmx[this]
                            })
                        })
                        //console.log(JSON.stringify(_self.$data.gongdanTabs))
                        //_self.$data.gongdanTabs = response.data.result.gdmx
                        if(response.data.result.bl){
                        _self.$data.startDate = new Date(response.data.result.bl.end_date).Format("yyyy-MM-dd")
                        }
                    }
                })
        },
        mask: function() {
            var _self = this;
            _self.$data.isUnitShow = false
            $(".mui-backdrop-unit").hide();
        },
        //选工人
        changeman: function(n) {
            var _self = this
            _self.$data.selectdTadIndex = n;
            _self.$data.callbackCode = 111
            window.appApi.openProjectContactSelectPage(
                projectSn, '', '', 1, false,false,false);//过滤自己方的数据
        },
        //选房间
        changRoom: function(n) {
            var _self = this
            _self.$data.callbackCode = 222
            window.appApi
                .openProjectContactSelectPage(projectSn,
                    '', currRoomCreditCode, 3, false,false,false)
        },
        moveimg: function(n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + _self.$data.zrimg[n - 1]).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功", 1, 2)
                    document.getElementById("file").value="";//清除input内容，防止出现不能重复上传的问题
                }
            }).catch(function(error) {
                ludan(error, 1, 3);
            })
            console.log(_self.$data.imgs)
            _self.$data.imgs.splice(n - 1, 1)
            console.log(_self.$data.imgs)
            _self.$data.zrimg.splice(n - 1, 1)
        },
        movefj: function(n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + _self.$data.zrfujian[n - 1]).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功", 1, 2)
                    document.getElementById("files").value="";//清除input内容，防止出现不能重复上传的问题
                }
            }).catch(function(error) {
                ludan(error, 1, 3);
            })
            _self.$data.fujians.splice(n - 1, 1)
            //						console.log(n-1)
            _self.$data.zrfujian.splice(n - 1, 1)
            console.log(_self.$data.zrfujian)
            console.log(typeof JSON
                .stringify(_self.$data.zrfujian))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        },
        addli: function() {
            var _self = this;
            _self.$data.tabs.push({
                selectdStatus: false,
                mingcheng: "",
                danwei: "",
                shuliang: "",
            })
            console.log(_self.$data.tabs[0].mingcheng)
        },
        deleat: function(tab, n) {
            var _self = this;
            _self.$data.tabs.splice(n, 1)
            if(tab.index != null) {
                var indexs = tab.index.split("-");
                _self.$data.gongdanTabs[indexs[0]].value[indexs[1]].selectdStatus = false;
                _self.$data.gongdanTabs[indexs[0]].value[indexs[1]].index = undefined
            }

        },
        //上传文件
        upfile: function(event) {
            this.hideDiv();
            loading("上传中")
            sessionStorage.removeItem("cunnews")
            var _self = this
            var file = document.getElementById(event.target.id).files;
            var zrid = document.getElementById(event.target.id)
                .getAttribute("id")
            var url = getUrl() + "/sass_api/upload_file";
            var form = new FormData();
            var forimg = []
            var forfile = []
            for(var i = 0; i < file.length; i++) {
                form.append("file", file[i]);
                //读取图片数据
                var f = document
                    .getElementById(event.target.id).files[i];
                var imgtype = f.type.split('/')[0]
                if(zrid == "file") {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        var data = e.target.result;
                        //加载图片获取图片真实宽度和高度
                        var image = new Image();
                        image.onload = function() {
                            width = image.width;
                            height = image.height;

                        };
                        image.src = data;
                        forimg.push({
                            src: image.src
                        })
                    };
                    sessionStorage.setItem("cunnews", "1")
                    reader.readAsDataURL(f);
                } else if(zrid == "files" || zrid == "excelFile") {
                    sessionStorage.setItem("cunnews", "2")
                    var na = file[i].name
                    forfile.push({
                        name: f.name
                    })
                    console.log(_self.$data.fujians)
                }
            }
            if(sessionStorage.getItem("cunnews") == 1) {
                form.append("type", "1");
            } else {
                form.append("type", "2");
            }
            form.append("module", "laowu");
            form.append("userid", userid);
            xhr = new XMLHttpRequest();
            xhr.open("post", url, true);
            xhr.onload = function(evt) {
                //请求完成
                layer.close(loading("上传中"))
            };
            xhr.onreadystatechange = function(evt) {
                console.log(xhr)
                if(xhr.readyState == 4 && xhr.status == 200) {
                    console.log(xhr.responseText);
                    var data = JSON.parse(evt.target.responseText);
                    // if(sessionStorage.getItem("cunnews") == 1) {
                    // 	_self.$data.imgs = _self.$data.imgs
                    // 		.concat(forimg)
                    // 	imgid.push(data.result.success)
                    // 	console.log(imgid)
                    // 	_self.$data.zrimg = imgid.toString()
                    // 		.split(',')
                    // } else {
                    // 	fujianid.push(data.result.success)
                    // 	_self.$data.fujians = _self.$data.fujians
                    // 		.concat(forfile)
                    // 	_self.$data.zrfujian = fujianid
                    // 		.toString().split(',')
                    // 	console.log(fujianid.toString())
                    // }
                    var rtnfiles = data.result.success;
                    if(sessionStorage.getItem("cunnews") == 1) {
                        _self.$data.imgs = _self.$data.imgs.concat(rtnfiles)
                        for(var i=0;i<rtnfiles.length;i++){
                            imgid.push(rtnfiles[i].fileId);
                        }
                        console.log(imgid)
                        if(imgid.toString()){

                            _self.$data.zrimg = imgid.toString().split(',')
                        }
                    } else {
                        for(var i=0;i<rtnfiles.length;i++){
                            fujianid.push(rtnfiles[i].fileId);
                        }
                        _self.$data.fujians = _self.$data.fujians.concat(forfile)
                        if(fujianid.toString()){
                            _self.$data.zrfujian = fujianid.toString().split(',')
                        }

                        console.log(fujianid.toString())
                    }
                    _self.$data.atts.push(data.result.success)
                    ludan("上传成功！", 2, 2)

                } else if(xhr.readyState == 4 &&
                    xhr.status == 500) {
                    ludan("上传失败！", 2, 1)
                }
            }
            xhr.onerror = function(evt) {
                //请求失败
                ludan("请求失败！", 2, 1)
                var data = JSON.parse(evt.target.responseText);
                console.log("data");
            };
            xhr.send(form);

        }
    },
})

function formDate(value) {
    var date = new Date(value);
    Y = date.getFullYear(), m = date.getMonth() + 1,
        d = date.getDate(), H = date.getHours(), i = date
        .getMinutes(), s = date.getSeconds();
    if(m < 10) {
        m = '0' + m;
    }
    if(d < 10) {
        d = '0' + d;
    }
    if(H < 10) {
        H = '0' + H;
    }
    if(i < 10) {
        i = '0' + i;
    }
    if(s < 10) {
        s = '0' + s;
    }
    //		<!-- 获取时间格式 2017-01-03 10:13:48 -->
    // var t = Y+'-'+m+'-'+d+' '+H+':'+i+':'+s;
    //		<!-- 获取时间格式 2017-01-03 -->
    var t = Y + '-' + m + '-' + d;
    return t;
}
function submitSuccess(d) {
    if(d.code == 200) {
        ludan("提交成功", 2, 2, function() {
            appApi.refreshData(2);
            setTimeout(function(){
                window.location.reload();
            },200)
        })
        setTimeout(function(){
            window.appApi.closeNewWindow();
        },200)
    }else{
        ludan(d, 2, 3)
    }
}

/**
 * 广播获取云文件的附件ids
 * @param dishImgIds 附件ids
 */
function obtainDishImgIds(dishImgIds){
    app.changeImgIds(dishImgIds);
}
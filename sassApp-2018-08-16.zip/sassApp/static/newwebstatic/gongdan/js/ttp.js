var app = new Vue({
    el: '#app',
    data: {
        todojsoan: '',
        //					sites: [],
        //					pinpai: '',
        //					mingcheng: "",
        typ: paramMap.typ,
        input1: "",
        urlcan: urlcan,
        nes: nes,
        imgs: [],
        fujians: [],
        zrimg: [],
        zrfujian: [],
        printTime: '',
        closewindow: '',
        cunnews: '',
        input11:'',
        btnStatus:true,
    },
    created: function() {
        var _self = this
//					if(this.typ==3){
//						setTimeout(function(){
//							appApi.hideBack()
//						},300)
//					}

        //					this.initData();
        var getTime = new Date()
        var nowTime = getTime.toLocaleDateString()
        var year = nowTime.split("/")[0]
        var mouth = nowTime.split("/")[1]
        var day = nowTime.split("/")[2]
        var nowshi = getTime.getHours()
        var noefen = getTime.getMinutes()
        var nowmiao = getTime.getSeconds()
        if(mouth < 10) {
            mouth = "0" + mouth
        }
        if(day < 10) {
            day = "0" + day
        }
        if(nowshi < 10) {
            nowshi = "0" + nowshi
        }
        if(noefen < 10) {
            noefen = "0" + noefen
        }
        if(nowmiao < 10) {
            nowmiao = "0" + nowmiao
        }
        _self.$data.nowtime = nowshi + ":" + noefen + ":" + nowmiao
        _self.$data.printTime = year + "-" + mouth + "-" + day
        _self.showPcBack();

        //获取参数
    },
    // 在 `methods` 对象中定义方法
    methods: {
    	showPcBack: function() {
			if(isApp) {
				document.getElementById("showPcBackStatus").style.display = 'none'
			} else {
				document.getElementById("showPcBackStatus").style.display = 'block'
			}
		},
        fjFileType : function(){
            $(".mui-backdrop").show();
            $(".pop-up").show();
        },
        hideDiv : function(){
            $(".mui-backdrop").hide();
            $(".pop-up").hide();
        },
        showCloudFile:function(){
            //打开项目列表
            appApi.openNewWindow(getUrl() + "/static/newwebstatic/file_gui/project_list.html?entrance=bill&projectSN="+paramMap.projectid,"我的项目");

        },
        changeImgIds : function(dishImgIds){//得到广播回来的ID
            var _self = this;
            var forfile = []
            this.hideDiv();

            var parm = {
                dishIds :dishImgIds,
            }
            axios.post(getUrl()+"/contract/copydishinfo",parm).then(function(response){
                var rtnfiles = response.data.result.success;
                for(var i=0;i<rtnfiles.length;i++){
                    fujianid.push(rtnfiles[i].fileId);
                    forfile.push({
                        name: rtnfiles[i].fileName,
                        fileId: rtnfiles[i].fileId
                    })
                }
                _self.$data.fujians = _self.$data.fujians.concat(forfile)
                if(fujianid.toString()){
                    _self.$data.zrfujian = fujianid.toString().split(',')
                }
            })
        },
        back: function() {
            var _self = this
//						appApi.showBack()
//						appApi.stopBack()

//						window.location.href = "newInfo.html?id="+paramMap.id
//						if(_self.$data.closewindow == 1) {
//							window.appApi.openChat(paramMap.nowroomImId, "", paramMap.roomname, 2)
//						} else {
//							appApi.closeNewWindow()
//						}
        },
        masktishi: function() {
            msg("数据提交中，请勿重复点击")
        },
        mask: function() {
            $(".mask").css({
                "display": "block",
                "opacity": "0.6"
            })
        },
        sendbtn: function() {
            var _self = this
            if(_self.$data.btnStatus) {
                _self.$data.btnStatus = false;
            var target=event.currentTarget
            btnStop()
            _self.$data.closewindow = 1
            app.mask()
            app.initData(target)
            }

        },
        initData: function(target) {
            //						 this.$options.methods.upfile(event)
            //获取数据
            var _self = this;
            //						var fjid = imgid.toString()
            var fjid
            if(_self.$data.zrimg.toString() == '') {
                fjid = _self.$data.zrfujian.toString()
            } else if(_self.$data.zrfujian.toString() == '') {
                fjid = _self.$data.zrimg.toString()
            } else {
                fjid = _self.$data.zrimg.toString() + "," + _self.$data.zrfujian.toString()
            }
            _self.$data.input11 = _self.$data.input1.replace(/[\r\n]/g, "#.%#");
            //						alert(fjid)
            //评论内容
            //						var id="5a6ecbda70474ea263ddfbb5";
            //						var uid='10392';
            var param = {
                attachment: fjid,
                content: _self.$data.input11,
                type: typ,
                uid: userid,
                docid: paramMap.id,
                roomid: paramMap.roomid,
                roomname: paramMap.roomname,
                projectid: paramMap.projectid,
                score: ""

            }
            //						alert(JSON.stringify(param))
            console.log(param)
            //alert(typ)
            //						alert(JSON.stringify(param))
            //						alert(fjid+"/"+_self.$data.input1+"/"+typ+"/"+userid+"/"+ paramMap.wendangid+"/"+paramMap.roomId+"/"+paramMap.roomName+"/"+paramMap.projectSn)
            if(typ == 99){//撤回功能
                var parm = {
                    "id": paramMap.id,
                    attachment: fjid,
                    content: _self.$data.input11,
                }
                //console.log(parm)
                //alert(param)
                //return
                axios.post(getUrl() + "/contract/withdrawcontent", parm).then(function (res) {
                    if(res.data.code==200){
                        ludan("撤回成功", 2, 2, function() {
                            appApi.closeNewWindow();
                            // btnstart(target)
                            /*setTimeout(function(){window.location.reload(),200})*/
                        })
                    }else if(res.data.code==500){
                        ludan(res.data.message, 2, 2, function() {
                            appApi.closeNewWindow();
                            // btnstart(target)
                            /*setTimeout(function(){window.location.reload(),200})*/
                        })
                    }
                })
            }else {
                axios.post(getUrl() + "/contract/save_note", param).then(function (response) {
                    if (response.data.code == 200) {
                        console.log(response.data)
//								alert(JSON.stringify(_self.$data.noteList))
//								_self.$data.sites = response.data.result.tablefields;s
//									var wenfou =  window.location.href.split("?")[1]
//									window.appApi.closeNewWindow()
//									alert(_self.$data.urlcan)
//									alert(paramMap.fromcurrRoomName + "-" + paramMap.roomName)
                        if (_self.$data.typ == 4) {
                            var todojson = {
//											"title": decodeURI(username) + "退回的工单",
                                "title": "工单退回:" + paramMap.title + "的工单",
                                "titileTwo": paramMap.roomclass + "-" + paramMap.roomname,
                                "content": "",
                                "fileCount": 0,
                                "url": '/static/newwebstatic/gongdan/transfer.html?id=' + paramMap.id,
                                "colorString": "",
                                "todoViewableMember": "0",
                                "toImId": paramMap.formroomimid,
                                //										"toImId":'43371363106817',
                                "formuserid": userid,
                                "currentRoomImid": paramMap.nowroomImId,
                                "chatType": "2",
                                "relation": paramMap.id,
                                "score": "", //评分待办必要参数，设置分数
                                //										"confirmUrl": "456", //有确认按钮必要参数
                                //										"refusedUrl": "231", //有拒绝按钮必要参数
                                "todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
                                "setButton": [{
                                    "type": 1, //按钮点击类型 1=请求url 2=打开url
                                    "name": "确认",
                                    "url": "/contract/do_todobtu?type=4&pingfen=0&docid=" + paramMap.id + "&projectSn=" + paramMap.projectSn + "&userid=" + userid,
//												"pingfen":"",
//												"docid":"",
//												"roomId":"",
//												"roomName":"",
//												"projectSn":"",
//												"userid":""
                                }, {
                                    "type": 1, //按钮点击类型 1=请求url 2=打开url
                                    "name": "退回",
                                    "url": "/contract/do_todobtu?type=4&pingfen=0&docid=" + paramMap.id + "&projectSn=" + paramMap.projectSn + "&userid=" + userid,
                                }]
                                //								alert(JSON.stringify(_self.$data.noteList))
                                //								_self.$data.sites = response.data.result.tablefields;s
                                //									var wenfou =  window.location.href.split("?")[1]
                                //									window.appApi.closeNewWindow()
                                //									alert(_self.$data.urlcan)
                                //									alert(paramMap.fromcurrRoomName + "-" + paramMap.roomName)
                                //
                            }
                            window.appApi.sendTodo(todojson)
                            //										window.location.href = getUrl()+'/static/newwebstatic/lianxi/work_content.html?'+urllast
                        } else if (typ == 1) { //										appApi.refreshData(2)
                            //										window.appApi.closeNewWindow()
                            var parm = {
                                "toImId": paramMap.formroomimid,
                                "chatType": "2",
                                "toNickName": "",
                                "toAvatarUrl": "",
                                //														myExtType: 'notify_type',
                                "content": paramMap.roomname + "已确认" + paramMap.fromRoomName + "的工单",
                            }
                            appApi.sendNotifyMsg(parm)
                            ludan("确认成功", 2, 2, function () {
                                appApi.refreshData(2);
                                appApi.closeNewWindow()
//                                          window.appApi.openChat(paramMap.nowroomImId, "", paramMap.roomname, 2)
//                                             btnstart(target)
                                //										appApi.openNewWindow(getUrl()+'/static/newwebstatic/lianxi/work_kan.html?id='+paramMap.id)
                                //										window.location.href=getUrl()+'/static/newwebstatic/lianxi/work_kan.html?'+_self.$data.urlcan
                                $(".mask").css({
                                    "display": "none",
                                    "opacity": "0.6"
                                })
                            })
                        } else if (typ == 3) {
                            ludan("评论成功", 2, 2, function () {
//                                      	window.history.go(-1)

//                                      	window.location.href = "newInfo.html?id="+paramMap.id
                                appApi.closeNewWindow()
//                                          window.appApi.openChat(paramMap.nowroomImId, "", paramMap.roomname, 2)
//                                             btnstart(target)
                                //										appApi.openNewWindow(getUrl()+'/static/newwebstatic/lianxi/work_kan.html?id='+paramMap.id)
                                //										window.location.href=getUrl()+'/static/newwebstatic/lianxi/work_kan.html?'+_self.$data.urlcan
                                $(".mask").css({
                                    "display": "none",
                                    "opacity": "0.6"
                                })
                            })
                        }

                    } else {
                        btnstart(target)
                        //							msg("获取云盘目录信息失败")
                    }
                })
            }
        },
        //上传文件
        upfile: function(event) {
            this.hideDiv();
            loading("上传中")
            var _self = this
            var file = document.getElementById(event.target.id).files;
            var zrid = document.getElementById(event.target.id).getAttribute("id")
            var url = getUrl() + "/sass_api/upload_file";
            var form = new FormData();
            var forimg = []
            var forfile = []
            for(var i = 0; i < file.length; i++) {
                form.append("file", file[i]);
                //读取图片数据
                var f = document.getElementById(event.target.id).files[i];
                var imgtype = f.type.split('/')[0]
                if(zrid == "file") {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        var data = e.target.result;
                        //加载图片获取图片真实宽度和高度
                        var image = new Image();
                        image.onload = function() {
                            width = image.width;
                            height = image.height;

                        };
                        image.src = data;
                        /*_self.$data.imgs.push({
                            src: image.src
                        })*/
                    };
                    _self.$data.cunnews = 1
                    reader.readAsDataURL(f);
                } else if(zrid == "files") {
                    _self.$data.cunnews = 2
                    var na = file[i].name
                    /*_self.$data.fujians.push({
                        name: f.name
                    })*/
                    console.log(_self.$data.fujians)
                }
                //							reader.readAsDataURL(f);

            }
            if(_self.$data.cunnews == 1) {
                form.append("type", "1");
            } else {
                form.append("type", "2");
            }
            form.append("module", "contractnote");
            form.append("userid", userid);
            xhr = new XMLHttpRequest();
            xhr.open("post", url, true);
            xhr.onload = function(evt) {
                layer.close(loading("上传中"))
            };
            xhr.onreadystatechange = function(evt) {
                console.log(xhr)
                if(xhr.readyState == 4 && xhr.status == 200) {
                	ludan("上传成功",1,2)
                    console.log(xhr.responseText);
                    var data = JSON.parse(evt.target.responseText);
                    var rtnfiles = data.result.success;
                    console.log(data)
                    if(zrid == "file") {
                        for(var i=0;i<rtnfiles.length;i++){
                            imgid.push(rtnfiles[i].fileId);
                            _self.$data.imgs.push({
                                src: rtnfiles[i].src,
                                fileId: rtnfiles[i].fileId
                            })
                        }
                        console.log(imgid)
                        if(imgid.toString()){
                            _self.$data.zrimg = imgid.toString().split(',')
                        }
                    } else if(zrid == "files") {
                        for(var i=0;i<rtnfiles.length;i++){
                            fujianid.push(rtnfiles[i].fileId);
                            _self.$data.fujians.push({
                                name: rtnfiles[i].fileName,
                                fileId:rtnfiles[i].fileId
                            })
                        }
                        if(fujianid.toString()){
                            _self.$data.zrfujian = fujianid.toString().split(',')
                        }

                        console.log(fujianid.toString())
                    }

                } else if(xhr.readyState == 4 && xhr.status == 500) {
                    msg("上传失败")
                }
            }
            xhr.onerror = function(evt) {
                //请求失败
                var data = JSON.parse(evt.target.responseText);
                console.log(data);
            };
            xhr.send(form);

        },
        moveimg: function(fileId,n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + fileId).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功",1,2)
                    document.getElementById("file").value="";//清除input内容，防止出现不能重复上传的问题
                }
            }).catch(function(error) {
                ludan(error, 1, 3);
            })
            //var index = _self.$data.imgs.indexOf(fileId);
//						_self.$data.imgs.splice(index, 1)
            _self.$data.imgs.splice(n, 1)

            //						console.log(n-1)
            var indexs = _self.$data.zrimg.indexOf(fileId);
            _self.$data.zrimg.splice(indexs, 1)
            console.log(_self.$data.zrimg)
            console.log(typeof JSON.stringify(_self.$data.zrimg))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        },
        movefj: function(fileId,n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + fileId).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功",1,2)
                    document.getElementById("files").value="";//清除input内容，防止出现不能重复上传的问题
                }
            }).catch(function(error) {
                ludan(error, 1, 3);
            })
            // var index = _self.$data.fujians.indexOf(fileId);
            _self.$data.fujians.splice(n, 1)
            //						console.log(n-1)
            var indexs = _self.$data.zrfujian.indexOf(fileId);
            _self.$data.zrfujian.splice(indexs, 1)
            console.log(_self.$data.zrfujian)
            console.log(typeof JSON.stringify(_self.$data.zrfujian))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        }
    },
})
var app = new Vue({
    el: '#app',
    data: {
        units: [{
            value: "平方米"
        }, {
            value: "立方米"
        }, {
            value: "吨"
        }, {
            value: "米"
        }, {
            value: "个"
        }, {
            value: "次"
        }, {
            value: "天"
        }, {
            value: "块"
        }, {
            value: "组"
        }, {
            value: "捆"
        }, {
            value: "宗"
        }, {
            value: "项"
        }, {
            value: "株"
        }],
        isUnitShow: false,
        selectdTab: {},
        backicon: 0,
        tapyewu: false,
        neshref: nes,
        callbackCode: "", //回调code 111 选人  222选公司
        selectdTadIndex: "", //记录请求选人的列表框下标
        hetongs: [],
        userName: decodeURI(username),
        userID: userid,
        dateShenqing: '',
        companySaleName: "",
        companySaleClassName: "",
        companySaleID: "",
        companySaleRoomImID: "",
        companySaleRoomID: "",
        companyBuyName: "",
        companyBuyClassName: "",
        companyBuyID: "",
        companyBuyRoomImID: "",
        companyBuyRoomID: "",
        beizhu: "",
        tuisongimid: "",
        contractName: "",
        tabs: [],
        toImId: [],
        money: 0,
        sites: [],
        imgs: [],
        fujians: [],
        zrimg: [],
        zrfujian: [],
        atts: [],
        confirm:"",
        postType:'',
        reponseId: undefined,
        attachmentIds:'',
        excelok:'',
        postStatus:true,
        cfgid:paramMap.cfgid,
        projectName: paramMap.projectName,
        projectSn: paramMap.projectSn,
        isRoomId :paramMap.isRoomId,
        isRoomName : paramMap.isRoomName,
        currRoomImId : paramMap.currRoomImId,
        currRoomClassName:paramMap.currRoomClassName,
        currRoomName : paramMap.currRoomName,
        isapp:false
    },
    created: function() {
        var _self = this;
         setTimeout(function(){
                 	 hideTitleBackground();
                 },500)
        if(!isApp){ //在非app上打开 显示返回按钮
        	this.isapp=true
        }
        if(paramMap.id != undefined) {

            this.informations()
        }
        _self.getnews()
        var getTime = new Date()
        var nowyear = getTime.getUTCFullYear()
        var nowmoth = parseInt(getTime.getMonth()) + 1
        var noeday = getTime.getDate()
        var nowshi = getTime.getHours()
        var noefen = getTime.getMinutes()
        var nowmiao = getTime.getSeconds()
        if(nowmoth < 10) {
            nowmoth = "0" + nowmoth
        }
        if(noeday < 10) {
            noeday = "0" + noeday
        }
        if(nowshi < 10) {
            nowshi = "0" + nowshi
        }
        if(noefen < 10) {
            noefen = "0" + noefen
        }
        if(nowmiao < 10) {
            nowmiao = "0" + nowmiao
        }
        _self.$data.dateShenqing = nowyear + "-" + nowmoth + "-" + noeday + " " + nowshi + ":" + noefen + ":" + nowmiao
        //					_self.form.MissionStartDate = formDate("2018-02-05");
        //获取合同数据
//						_self.getHt()
    },
    mounted: function() {
        mui.init();
        mui('.mui-scroll-wrapper').scroll({
            deceleration: 0.0005, //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
            bounce: false //不启用回弹
        });
        /*document.getElementById("backdrop").addEventListener('tap', function() {
            //阻止默认事件
            event.detail.gesture.preventDefault();
            // 移除手势滑动
            //						mui('.mui-off-canvas-wrap').offCanvas().close()
        });*/
        //主界面容器
        document.getElementsByClassName('mui-inner-wrap')[0].addEventListener('drag', function(event) {
            event.stopPropagation();
        });

        window.addEventListener('touchmove', function(e) {
            var target = e.target;
            if(target && target.tagName === 'TEXTAREA') { //textarea阻止冒泡
                e.stopPropagation();
            }
        }, true);
        //监听手机软件盘
//						var winHeight = $(window).height(); //获取当前页面高度
//						$(window).resize(function() {
//							var thisHeight = $(this).height();
//							var scrollH
//							if(winHeight - thisHeight > 50) {
//								//当软键盘弹出，在这里面操作
//								scrollH = thisHeight + 200
//								alert(5)
//								mui('#mui-scroll-wrapper').scroll().scrollTo(0, -scrollH, 100)
//							} else {
//								//当软键盘收起，在此处操作
//							}
//						});
    },
    // 在 `methods` 对象中定义方法
    methods: {

        fjFileType : function(){

            $(".mui-backdrop-attchments").show();
            $(".attchments").show();
        },
        showCloudFile:function(){
            //打开项目列表
            appApi.openNewWindow(getUrl() + "/static/newwebstatic/file_gui/project_list.html?entrance=bill&projectSN="+paramMap.projectSn,"我的项目");
        },
        hideDiv : function(){
            $(".mui-backdrop-attchments").hide();
            $(".attchments").hide();
        },

        changeImgIds : function(dishImgIds){//得到广播回来的ID

            var _self = this;
            var forfile = []
            $(".mui-backdrop-attchments").hide();
            $(".attchments").hide();

            var parm = {
                dishIds :dishImgIds,
            }
            axios.post(getUrl()+"/contract/copydishinfo",parm).then(function(response){
                var rtnfiles = response.data.result.success;
                for(var i=0;i<rtnfiles.length;i++){
                    fujianid.push(rtnfiles[i].fileId);
                    forfile.push({
                        name: rtnfiles[i].fileName,
                        fileId: rtnfiles[i].fileId
                    })
                }
                _self.$data.fujians = _self.$data.fujians.concat(forfile)
                if(fujianid.toString()){
                    _self.$data.zrfujian = fujianid.toString().split(',')
                }
            })
        },

        //退回加载数据
        informations: function() {
            var _self = this
            var param = {
                id: paramMap.id,
            }
            axios.post(getUrl() + "/contract/get_content", param).then(function(response) {
                if(response.data.code == 200) {
                    var norl = JSON.parse(response.data.result.noralJson)
                    var cont = JSON.parse(response.data.result.contentJson)
                    var data = response.data.result
                    console.log(response.data)
                    _self.$data.contractName = norl.tablefields.contractName
                    _self.$data.tabs = norl.subtablefields
                    _self.$data.companySaleClassName  =norl.tablefields.companySaleName
                    _self.$data.companySaleName=norl.toclassname
                    console.log(norl.subtablefields)
                    app.imgsrc(norl.attachment)
                    //提交数据
                    _self.$data.reponseId= paramMap.id
                    _self.$data.id = paramMap.id
                    _self.$data.cfgid = norl.table.id
                    _self.$data.projectSn = norl.table.projectid
                    _self.$data.isRoomId = norl.table.roomid
                    _self.$data.isRoomName = norl.table.roomname
                    _self.$data.companyBuyRoomImID=norl.toImid
                    _self.$data.currRoomImId = norl.currRoomImId
                    _self.$data.currRoomClassName = norl.currRoomClassName
                    _self.$data.companyBuyName=norl.companyBuyName,
                        _self.$data.currRoomName = norl.curRoomName
                    _self.$data.tuisongimid = norl.toImid
                    _self.$data.companySaleRoomID=norl.tablefields.companySaleRoomID,
                        _self.$data.companySaleName=norl.tablefields.companySaleName,
                        _self.$data.companySaleID=norl.tablefields.companySaleID,
                        _self.$data.companyBuyClassName=norl.tablefields.companyBuyRoomClassName,
                        _self.$data.companyBuyRoomID=norl.tablefields.companyBuyRoomID,
                        _self.$data.companyBuyID=norl.tablefields.companyBuyID,
                        _self.$data.companyBuyName=norl.tablefields.companyBuyName,
                        _self.$data.projectName = norl.tablefields.projectName
                    _self.$data.projectSN = norl.tablefields.projectSN
                    _self.$data.projectSn = norl.table.projectid

                    console.log("初始化",norl)
                }
            })
        },
        imgsrc: function(n) {
            var _self = this
            if(n!=''){
                axios.post(getUrl() + "/sass_api/ get_uploadfile_info?fileIdStr=" + n).then(function(response) {
                    if(response.data.code == 200) {
                        console.log("图片附件",response.data.result)
                        for(var i = 0; i < response.data.result.length; i++) {
                            if(response.data.result[i].type == 1) { //imgs fujians name
                                _self.$data.imgs.push({
                                    src: response.data.result[i].newThumbnailTurl
                                })
                                imgid.push(response.data.result[i].id);
                                if(imgid.toString()){
                                    _self.$data.zrimg = imgid.toString().split(',')
                                }
                            } else {
                                _self.$data.fujians.push({
                                    name: response.data.result[i].filename
                                })
                                fujianid.push(response.data.result[i].id);
                                if(fujianid.toString()){
                                    _self.$data.zrfujian = fujianid.toString().split(',')
                                }
                            }
                        }

                    }
                })
            }
        },
        /**
         * 选择单位
         * @param {Object} item 清单对象
         */
        selectdUnit: function(item) {
            var _self = this;
            _self.$data.selectdTab.danwei = item.value
            _self.mask();
        },
        /**
         * 删除已选单位
         */
        delroom: function() {
            var _self = this;
            _self.$data.companyBuyClassName = "";
        },
        /**
         * 上一步事件
         */
        back: function() {
            var _self = this
            if(_self.$data.backicon == 1) {
                setTimeout(function () {
                    appApi.showBack()
                },100)
            }
            if(_self.$data.backicon > 0) {
                _self.backicon = _self.backicon - 1
            }

        },
        /**
         * 下一步事件
         * @param {Object} pageIndex 页码
         */
        next: function(pageIndex) {
            var _self = this;
            if(pageIndex == 1) {
                var flag = _self.checkTabs()
                if(!flag) {
                    return false;
                }
            } else if(pageIndex == 2) {
                if(_self.$data.companyBuyClassName == "") {
                    ludan("请选择接收单位!", 2, 1)
                    return false;
                }
            }
            appApi.hideBack()
            _self.$data.backicon = pageIndex;

        },
        help:function(){
            appApi.openNewWindow(getUrl()+"/static/newPage/html/mubanHelp.html","帮助")
//							window.location.href="../../newPage/html/mubanHelp.html"
        },
        /**
         * 展示所有单位
         */
        showUnits: function(tab) {
            var _self = this;
            _self.$data.selectdTab = tab;
            $("input").blur();
            $(".mui-backdrop-unit").show();
            _self.$data.isUnitShow = true
        },
        /**
         * 打开excel选文件对话框
         */
        showSelectdFile: function() {
            $("#excelFile").click();
        },
        //excel表格解析
//						excelAnalysis: function(e) {
//							var _self = this;
//							var files = e.target.files;
//							var fileReader = new FileReader();
//							fileReader.onload = function(ev) {
//								try {
//									var data = ev.target.result,
//										workbook = XLSX.read(data, {
//											type: 'binary'
//										}), // 以二进制流方式读取得到整份excel表格对象
//										persons = []; // 存储获取到的数据
//								} catch(e) {
//									console.log('文件类型不正确');
//									return;
//								}
//
//								// 表格的表格范围，可用于判断表头是否数量是否正确
//								var fromTo = '';
//								// 遍历每张表读取
//								for(var sheet in workbook.Sheets) {
//									if(workbook.Sheets.hasOwnProperty(sheet)) {
//										fromTo = workbook.Sheets[sheet]['!ref'];
//										console.log(fromTo);
//										console.log(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]))
//										persons = persons.concat(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]));
//										// break; // 如果只取第一张表，就取消注释这行
//									}
//								}
//								_self.$data.tabs = persons
//
//								console.log(persons);
//							};
//							// 以二进制方式打开文件
//							fileReader.readAsBinaryString(files[0]);
//						},
        //excel表格解析
        excelAnalysis: function(e) {
            var _self = this;
            var suffix = /\.[^\.]+$/.exec(e.target.files[0].name).toString()
            if(suffix == '.xlsx') {
                var files = e.target.files;
                var fileReader = new FileReader();
                fileReader.onload = function(ev) {
                    try {
                        var data = ev.target.result,
                            workbook = XLSX.read(data, {
                                type: 'binary'
                            }), // 以二进制流方式读取得到整份excel表格对象
                            persons = []; // 存储获取到的数据
                    } catch(e) {
                        console.log('文件类型不正确');
                        return;
                    }
                    // 表格的表格范围，可用于判断表头是否数量是否正确
                    var fromTo = '';
                    var excelname
                    // 遍历每张表读取
                    for(var sheet in workbook.Sheets) {
                        if(workbook.Sheets.hasOwnProperty(sheet)) {
                            fromTo = workbook.Sheets[sheet]['!ref'];
                            if(JSON.stringify(XLSX.utils.sheet_to_json(workbook.Sheets[sheet])[0]).split(",")[1] != undefined) {
                                excelname = JSON.stringify(XLSX.utils.sheet_to_json(workbook.Sheets[sheet])[0]).split(",")
                            } else {
                                excelname = []
                            }
                            console.log(excelname)
                            var excelnames=excelname
                            console.log(excelnames.length)
                            excelname = excelname.toString()
                            if(excelname.indexOf("mingcheng") != -1 && excelname.indexOf("danwei") != -1 && excelname.indexOf("shuliang") != -1 && excelnames.length===3) {
                                persons = persons.concat(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]));
                                console.log(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]))
                                layer.close(loading("解析中"))
                                _self.$data.excelok = 0
                            } else {
                                layer.close(loading("解析中"))
                                _self.$data.excelok = 1
                                ludan("导入的模板格式不正确", 2, 3)
                                persons=[]
                            }
                            // break; // 如果只取第一张表，就取消注释这行
                        }
                    }
                    _self.$data.tabs = _self.$data.tabs.concat(persons)
                    //							console.log(persons);
//								fileReader.readAsBinaryString(files[0]);
                    if(_self.$data.excelok===0){
                        _self.upfile(e)
                    }
                };
//							_self.upfile(e)

                // 以二进制方式打开文件
                fileReader.readAsBinaryString(files[0]);


            } else {
                layer.close(loading("解析中"))
                ludan("导入的文件格式不正确", 2, 3)
            }

        },
        sx: function() {
            window.location.href = window.location.href;
        },
        getnews: function() {
            var _self = this
            axios.post(getUrl() + "/pcontact_api/findroombyroomclass?roomClass=xiangmubu&projectSn=" + _self.$data.projectSn).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data.result)
                    _self.$data.shigong = response.data.result.roomName
                    _self.$data.tuisongimid = response.data.result.roomImId
                }
            })
        },
        //检索列表数据
        checkTabs: function() {
            var _self = this
            var isStatus = true;
            $.each(_self.tabs, function(index) {
                var isCue = true;
                if(this.mingcheng == '') {
                    isCue = false
                } else if(this.danwei == '') {
                    isCue = false
                }
                if(!isCue) {
                    if(index > 8) {
                        index = index - 9
                        var y = 0 - (Number($("#one").height()) + (Number($("#two").height()) * index))
                        mui('.mui-scroll-wrapper').scroll().scrollTo(0, y, 100);
                    } else {
                        mui('.mui-scroll-wrapper').scroll().scrollTo(0, 0, 100);
                    }
                    ludan("请将数据填写完整", 1, 1)
                    isStatus = false
                    return isStatus;
                }
            })
            return isStatus;
        },
        initData: function(type) {
            //获取数据
            btnStop()
            var _self = this;
            var saveType='update';
            var target=event.currentTarget
            if(type==1){
            	saveType='save';
                ludan("保存中",0,1)
            }else{
                if(_self.$data.postStatus) {
                    _self.$data.postStatus = false;
                }else{
                    return ;
                }
            	saveType='update';
                ludan("提交中",0,1)
            }
//							var fjid = _self.$data.atts.toString()
            var fjid
            if(_self.$data.attachmentIds == '') {
                _self.$data.attachmentIds = ''
            } else {
                _self.$data.attachmentIds = "," + _self.$data.attachmentIds
            }
            if(imgid.toString() == '') {
                fjid = fujianid.toString()
            } else if(fujianid.toString() == '') {
                fjid = imgid.toString()
            } else {
                fjid = imgid.toString() + "," + fujianid.toString()
            }

            $.each(_self.$data.tabs, function() {
                this.shuliang = Number(this.shuliang)
                this.withShuliang = 0
            })

            if(type==2){
                _self.$data.confirm = '1';
                _self.$data.postType = '1';
            }else{
                _self.$data.confirm = '0';

            }
            var param = {
                table: {
                    id: _self.$data.cfgid,
                    projectid: _self.$data.projectSn,
                    roomid: _self.$data.isRoomId,
                    roomname:  _self.$data.isRoomName,
                },
                confirm: _self.$data.confirm,
                typeName:"派工单",
                title: decodeURI(username) + "的工单",
                postType: _self.$data.postType ,
                attachment: fjid + _self.$data.attachmentIds,
                currRoomImId: _self.$data.currRoomImId,
                companyBuyName:_self.$data.companyBuyName,
                currRoomClassName: _self.$data.currRoomClassName,
                toclassname:_self.$data.companyBuyClassName,
                curRoomName:  _self.$data.currRoomName,
                toImid: _self.$data.companyBuyRoomImID,
                tablefields: {
                    id: _self.$data.reponseId,
                    userName: _self.$data.userName,
                    userID: _self.$data.userID,
                    roomId: _self.$data.isRoomId,
                    companyBuyRoomClassName: _self.$data.companyBuyClassName,
                    companyBuyRoomID: _self.$data.companyBuyRoomID,
                    companyBuyName: _self.$data.companyBuyName,
                    companyBuyID: _self.$data.companyBuyID,
                    companySaleRoomID: _self.$data.isRoomId,
                    companySaleName:  _self.$data.isRoomName,
                    companySaleID: _self.$data.isRoomCreditCode,
                    dateShenqing: _self.$data.dateShenqing,
                    projectName: _self.$data.projectName,
                    projectSN: _self.$data.projectSn,
                },
                subtablefields: _self.$data.tabs,
                saveType:saveType,
            }
            // alert(JSON.stringify(param))
            // return
            console.log(param)
            axios.post(getUrl() + "/contract/save", param).then(function(response) {
                //alert(JSON.stringify(response))
                if(response.data.code == 200) {
                    console.log(response)
                    closeLoading()
                    _self.$data.sites = response.data.result.tablefields;
                    _self.$data.reponseId = response.data.result.id;
                    _self.$data.id=response.data.result.id;

                    if(type == 2) {
//                      layer.close(ludan("提交中",0,1))
                        _self.backicon=2
                        _self.pushMsg(target)
                    } else {
//                      layer.close(ludan("保存中",0,1))
                        ludan("保存成功", 2, 2,function () {
                        	btnstart(target)
                        })
                        
                    }
                } else {
                	closeLoading()
                    msg("保存失败")
                    btnstart(target)
                }
            })
        },
        /**
         * 推送消息函数
         */
        pushMsg: function(target) {
            var _self = this;
            // alert(_self.$data.companyBuyRoomImID)
            var content = "";
            for(var i = 0; i < _self.$data.tabs.length; i++) {
                if(i == 2) {
                    break
                }
                content = content + _self.$data.tabs[i].mingcheng + _self.$data.tabs[i].shuliang + _self.$data.tabs[i].danwei + "|"
            }
            content = content + "共" + _self.$data.tabs.length + "项"
            var titletype = encodeURIComponent(encodeURIComponent("工单"));
            var title = encodeURIComponent(encodeURIComponent(decodeURI(username)+ "的工单"));
            var todojson = {
                "title": decodeURI(username) + "的工单",
                "titileTwo": _self.$data.currRoomClassName + "-" +  _self.$data.currRoomName,
                "content": content,
                "fileCount": '0',
                "url":  '/static/newwebstatic/gongdan/transfer.html?id=' + _self.$data.reponseId,
                "todoViewableMember": "0",
                "toImId": _self.$data.companyBuyRoomImID,
                'currentRoomImid': _self.$data.currRoomImId,
                "formuserid": userid,
                "relation": _self.$data.reponseId,
                "chatType": "2",
                //									"confirmUrl": "456", //有确认按钮必要参数
                //									"refusedUrl": "231", //有拒绝按钮必要参数
                "todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
                "setButton": [{
                    "type": 1, //按钮点击类型 1=请求url 2=打开url
                    "name": "确认",
                    "url":  "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&projectSn=" + _self.$data.projectSn + "&userid=" + userid+"&sendtype=1"+"&titletype="+titletype
                }, {
                    "type": 1, //按钮点击类型 1=请求url 2=打开url
                    "name": "退回",
                    "url":  "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id + "&projectSn=" + _self.$data.projectSn + "&userid=" + userid+"&title="+title+"&titletype="+titletype+"&sendtype=1"
                }]
            }


            //清除撤回的待办
            var parame = new FormData();
            parame.append("url", '/static/newwebstatic/gongdan/transfer.html?id=' + _self.$data.reponseId)
            parame.append("userId",getCookie("userid"))
            axios.post(getUrl()+"/sass_api/update_withdraw_todo",parame).then(function (response) {

            });
                window.appApi.sendTodo(todojson)

            setTimeout(function () {
                ludan("提交成功", 2, 2, function() {
                    appApi.closeNewWindow()
                    // btnstart(target)
                })
            },1000)


        },
        aa: function(CONTENT) {//选择接收方
            var _self = this;
            if(_self.$data.callbackCode == 111) {
                try {
                    _self.$data.tabs[_self.$data.selectdTadIndex].gongren = xk_util.getArrayProperty(JSON.parse(CONTENT.result), "nickName").toString()
                } catch(err) {
                    alert("错误了")
                    alert(err)
                }
            } else if(_self.$data.callbackCode == 222) {
                var room = JSON.parse(CONTENT.result)
                if(room.companyId == "" || room.companyId == null) {
                    _self.$data.companyBuyID = room.roomName
                } else {
                    _self.$data.companyBuyID = room.companyId
                }
                _self.$data.companyBuyName = room.roomName
                _self.$data.companyBuyClassName = room.roomClassName
                _self.$data.companyBuyRoomID = room.roomId
                _self.$data.companyBuyRoomImID = room.roomImId
            }
            _self.$data.tabs[_self.$data.nuberhang].mingcheng = addname.split("$,")[1]
        },
        mask: function() {
            var _self = this;
            _self.$data.isUnitShow = false
            $(".mui-backdrop-unit").hide();
        },
        //选工人
        changeman: function(n) {
            var _self = this
            _self.$data.selectdTadIndex = n;
            _self.$data.callbackCode = 111
            window.appApi.openProjectContactSelectPage(_self.$data.projectSn, '', '', 1, false,false,false)//过滤自己方的数据
        },
        //选房间
        changRoom: function(n) {
            var _self = this
            _self.$data.callbackCode = 222
            window.appApi.openProjectContactSelectPage(_self.$data.projectSn, '', currRoomCreditCode, 3, false,false,false)//过滤自己方的数据
        },
        moveimg: function(n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + _self.$data.zrimg[n-1]).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功",1,2)
                    document.getElementById("file").value="";//清除input内容，防止出现不能重复上传的问题
                }
            }).catch(function(error) {
                ludan(error, 1, 3);
            })
            console.log(_self.$data.imgs)
            _self.$data.imgs.splice(n - 1, 1)
            console.log(_self.$data.imgs)
            //						console.log(n-1)
            //						console.log(_self.$data.zrimg)
            _self.$data.zrimg.splice(n - 1, 1)
            //						console.log(_self.$data.zrimg)
            //						console.log(typeof JSON.stringify(_self.$data.zrimg))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        },
        movefj: function(n) {
            var _self = this;
            console.log("附件",_self.$data.zrfujian)
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + _self.$data.zrfujian[n-1]).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功",1,2)
                    document.getElementById("files").value="";//清除input内容，防止出现不能重复上传的问题
                }
            }).catch(function(error) {
                ludan(error, 1, 3);
            })
            _self.$data.fujians.splice(n - 1, 1)
            //						console.log(n-1)
            _self.$data.zrfujian.splice(n - 1, 1)
            console.log(_self.$data.zrfujian)
            console.log(typeof JSON.stringify(_self.$data.zrfujian))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        },
        addli: function() {
            var _self = this;
            _self.$data.tabs.push({
                mingcheng: "",
                danwei: "",
                shuliang: "",
                withShuliang: 0,
            })
            console.log(mui('.mui-scroll-wrapper').scroll())
        },
        deleat: function(n) {
            var _self = this;
            _self.$data.tabs.splice(n - 1, 1)
        },
        //上传文件
        upfile: function(event) {
            this.hideDiv();
            loading("上传中")
            sessionStorage.removeItem("cunnews")
            var _self = this
            var file = document.getElementById(event.target.id).files;
            var zrid = document.getElementById(event.target.id).getAttribute("id")
            var url = getUrl() + "/sass_api/upload_file";
            var form = new FormData();
            var forimg = []
            var forfile = []
            for(var i = 0; i < file.length; i++) {
                form.append("file", file[i]);
                //读取图片数据
                var f = document.getElementById(event.target.id).files[i];
                var imgtype = f.type.split('/')[0]
                if(zrid == "file") {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        var data = e.target.result;
                        //加载图片获取图片真实宽度和高度
                        var image = new Image();
                        image.onload = function() {
                            width = image.width;
                            height = image.height;

                        };
                        image.src = data;
                        forimg.push({
                            src: image.src
                        })
                    };
                    sessionStorage.setItem("cunnews", "1")
                    reader.readAsDataURL(f);
                } else if(zrid == "files" || zrid == "excelFile") {
                    sessionStorage.setItem("cunnews", "2")
                    var na = file[i].name
                    forfile.push({
                        name: f.name
                    })
                    console.log(_self.$data.fujians)
                }
            }
            if(sessionStorage.getItem("cunnews") == 1) {
                form.append("type", "1");
            } else {
                form.append("type", "2");
            }
            form.append("module", "laowu");
            form.append("userid", userid);
            xhr = new XMLHttpRequest();
            xhr.open("post", url, true);
            xhr.onload = function(evt) {
                //请求完成
                layer.close(loading("上传中"))
            };
            xhr.onreadystatechange = function(evt) {
                console.log(xhr)
                if(xhr.readyState == 4 && xhr.status == 200) {
                    console.log(xhr.responseText);
                    var data = JSON.parse(evt.target.responseText);
                    // if(sessionStorage.getItem("cunnews") == 1) {
                    // 	_self.$data.imgs = _self.$data.imgs.concat(forimg)
                    // 	imgid.push(data.result.success)
                    // 	console.log(imgid)
                    // 	_self.$data.zrimg = imgid.toString().split(',')
                    // } else {
                    // 	fujianid.push(data.result.success)
                    // 	_self.$data.fujians = _self.$data.fujians.concat(forfile)
                    // 	_self.$data.zrfujian = fujianid.toString().split(',')
                    // 	console.log(fujianid.toString())
                    // }
                    var rtnfiles = data.result.success;
                    if(sessionStorage.getItem("cunnews") == 1) {
                        _self.$data.imgs = _self.$data.imgs.concat(rtnfiles)
                        for(var i=0;i<rtnfiles.length;i++){
                            imgid.push(rtnfiles[i].fileId);
                        }
                        console.log(imgid)
                        if(imgid.toString()){
                            _self.$data.zrimg = imgid.toString().split(',')
                        }

                    } else {
                        for(var i=0;i<rtnfiles.length;i++){
                            fujianid.push(rtnfiles[i].fileId);
                        }
                        _self.$data.fujians = _self.$data.fujians.concat(forfile)
                        if(fujianid.toString()){
                            _self.$data.zrfujian = fujianid.toString().split(',')
                        }

                        console.log(fujianid.toString())
                    }
                    _self.$data.atts.push(data.result.success)
                    ludan("上传成功！", 2, 2)

                } else if(xhr.readyState == 4 && xhr.status == 500) {
                    ludan("上传失败！", 2, 1)
                }
            }
            xhr.onerror = function(evt) {
                //请求失败
                ludan("请求失败！", 2, 1)
                var data = JSON.parse(evt.target.responseText);
                console.log("data");
            };
            xhr.send(form);

        }
    },
})
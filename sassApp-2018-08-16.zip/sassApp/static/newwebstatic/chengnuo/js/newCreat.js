var app = new Vue({
	el: '#app',
	data: {
		imgurl: "http://res.winfreeinfo.com:8000",
		imgIcon: 'static/images/ico_image.png',
		id: '',
		currRoomImId: paramMap.isRoomImId,
		currRoomClassName: paramMap.currRoomClassName,
		sites: [],
		form: {
			// 日期
			MissionStartDate: "",
		},
		companySaleName: "",
		companyBuyName: "",
		personAccept: decodeURI(username),
		personDistribute: "",
		type: '单方承诺',
		beizhu: '0',
		personAcceptID: userid,
		personDistributeID: "",
		companySaleName: isRoomName,
		companySaleID: isRoomCreditCode,
		companySaleRoomID: isRoomId,
		companyBuyName: "",
		companyBuyID: "",
		companyBuyRoomID: "",
		bcnroomImId: "",
		imgs: [],
		imgurl: [],
		fujians: [],
		backicon: 0,
		nowtime: '',
		shenqing: '',
		zrimg: [],
		zrfujian: [],
		attachmentIds: "",
		beizhu: '',
		beizhuzhuan: '',
		//地址拦信息
		pa_cigid: paramMap.cfgid,
		pa_projectsn: paramMap.projectSn,
		pa_isroomid: paramMap.isRoomId,
		pa_isroomname: paramMap.isRoomName,
		pa_projectName: paramMap.projectName,
		pa_isRoomCreditCode: isRoomCreditCode,
		pa_isroomid: paramMap.isRoomId,
		tuistatus: '',
		tijao: "",
		baocun: '',
		first: '',
		imgsrc: [],
		chec: 1,
		startroomimid: '',
		UserName: '',
		Userid: isRoomCreditCode,
		Userroomid: '',
		Userroomimid: '',
		touserid: '',
		confirm: '',
		postType: '',
        postStatus:true,
		roomType: ""
	},
	created: function() {
		//					this.informations()
		//					mui.init();
		this.getTime()
		if(paramMap.id != undefined) {
			this.informations()
		} else {
			this.usermains(this.pa_projectsn)
			//						this.getnews()
		}
		if(paramMap.currRoomId) {
			//查询当前房间信息
			this.findRoomInfo(paramMap.currRoomId);
		}
		//获取剪切板信息
        this.getCopyInfo();
	},
	mounted: function() {
		mui.init();
		mui('.mui-scroll-wrapper').scroll({
			deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
		});
		//					document.getElementById("backdrop").addEventListener('tap', function() {
		//						//阻止默认事件
		//						event.detail.gesture.preventDefault();
		//						// 移除手势滑动
		//						//						mui('.mui-off-canvas-wrap').offCanvas().close()
		//					});
		//主界面容器
		//					document.getElementsByClassName('mui-inner-wrap')[0].addEventListener('drag', function(event) {
		//						event.stopPropagation();
		//					});
	},
	methods: {
		fjFileType: function() {
			$(".mui-backdrop").show();
			$(".pop-up").show();
		},
		showCloudFile: function() {
			//打开项目列表
			appApi.openNewWindow(getUrl() + "/static/newwebstatic/file_gui/project_list.html?entrance=bill&projectSN=" + paramMap.projectSn, "我的项目");

		},
		hideDiv: function() {
			$(".mui-backdrop").hide();
			$(".pop-up").hide();
		},
        /**
		 * 获取剪切板信息，判断是否存在数据
         */
        getCopyInfo: function() {
			var _self = this;
			window.appApi.getTextFromClip();
			window.appApi.callBackFun = function(callFlag, CONTENT) {
				if(callFlag == appApi.callBackFlag.CNTEXT) {
					setTimeout(function() {
						var results=CONTENT.result;
						if(results){
							var ary=results.split("=");
						_self.beizhu=ary[1];
						setTimeout(function(){
							appApi.copyText("");
						  },50)
						}
						
					}, 50)
				}
			}
		},
//		getCopyInfo:function(){
//			
//			var text = appApi.getTextFromClip();
//			alert("获取剪贴板"+text)
////			appApi.copyText("");
//			},
		changeImgIds: function(dishImgIds) { //得到广播回来的ID

			var _self = this;
			var forfile = []
			this.hideDiv();

			var parm = {
				dishIds: dishImgIds,
			}
			axios.post(getUrl() + "/contract/copydishinfo", parm).then(function(response) {
				var rtnfiles = response.data.result.success;
				for(var i = 0; i < rtnfiles.length; i++) {
					fujianid.push(rtnfiles[i].fileId);
					forfile.push({
						name: rtnfiles[i].fileName,
						fileId: rtnfiles[i].fileId
					})
				}
				_self.$data.fujians = _self.$data.fujians.concat(forfile)
				if(fujianid.toString()) {
					_self.$data.zrfujian = fujianid.toString().split(',')
				}
			})
		},

		//获取初始数据
		informations: function() {
			var _self = this
			var param = {
				id: paramMap.id,
			}
			axios.post(getUrl() + "/contract/get_content", param).then(function(response) {
				if(response.data.code == 200) {
					var norl = JSON.parse(response.data.result.noralJson)
					var cont = JSON.parse(response.data.result.contentJson)
					var data = response.data.result
					console.log(response.data)
					_self.$data.title = norl.tablefields.name
					_self.$data.yewu = norl.tablefields.type
					//								_self.form.MissionStartDate = formDate(norl.tablefields.dateFasheng)
					norl.tablefields.beizhu = norl.tablefields.beizhu.replace(/#.%#/g, "\n");
					_self.$data.beizhu = norl.tablefields.beizhu
					_self.$data.isroomname = norl.curRoomName
					_self.$data.isRoomCreditCode = norl.tablefields.companySaleID
					//								app.getnews()
					console.log(norl.gongsialllei)
					//承诺人数据 personAccept personDistribute
					_self.$data.personAccept = norl.tablefields.personAccept
					//被承诺人数据
					_self.$data.personDistribute = norl.tablefields.personDistribute
					_self.$data.personDistributeID = norl.tablefields.personDistributeID
					//承诺类型
					_self.$data.type = norl.tablefields.type
					if(norl.tablefields.type == '单方承诺') {
						_self.$data.chec = 1
					} else {
						_self.$data.chec = 2
					}
					//日期 norl.tablefields.dateChengnuo
					if(norl.tablefields.dateChengnuo == null) {} else {
						norl.tablefields.dateChengnuo = norl.tablefields.dateChengnuo.replace(/-/g, "/");
						_self.form.MissionStartDate = formDate(norl.tablefields.dateChengnuo)

					}

					_self.$data.nowCompanyroomid = norl.tablefields.companyBuyRoomID.split(",")
					_self.$data.nowCompanyroomimid = norl.toImid.split(",")
					//图片附件
					_self.$data.imgs = norl.imgs
					console.log(_self.$data.imgs)
					_self.$data.fujians = norl.fujians
					if(norl.imgid.toString()) {
						imgid = norl.imgid.toString().split(",")
						_self.$data.zrimg = norl.imgid.toString().split(",")
					}
					if(norl.fjid.toString()) {
						_self.$data.zrfujian = norl.fjid.toString().split(",")
						fujianid = norl.fjid.toString().split(",")
					}

					//提交信息
					_self.$data.id = paramMap.id
					_self.$data.companySaleName = norl.tablefields.companySaleName
					_self.$data.companySaleID = norl.tablefields.companySaleID
					_self.$data.companySaleRoomID = norl.tablefields.companySaleRoomID
					_self.$data.companyBuyName = norl.tablefields.companyBuyName
					_self.$data.companyBuyID = norl.tablefields.companyBuyID
					_self.$data.companyBuyRoomID = norl.tablefields.companyBuyRoomID

					_self.$data.bcnroomImId = norl.toroomimid

					_self.$data.pa_cigid = norl.table.id
					_self.$data.pa_projectsn = data.projectId
					app.usermains(data.projectId)
					_self.$data.pa_isroomid = data.roomId
					_self.$data.pa_isroomname = data.roomName
					_self.$data.pa_isRoomCreditCode = norl.tablefields.companySaleID
					_self.$data.pa_projectName = norl.tablefields.projectName
					_self.$data.currRoomImId = norl.currRoomImId
					_self.$data.currRoomClassName = norl.curRoomName

				}
			})
		},

		//获取时间
		getTime: function() {
			var _self = this
			var getTime = new Date()
			var nowTime = getTime.toLocaleDateString()
			/**
			 * ios9以下版本获取到的是yyyy年MM月dd日
			 */
			var year = "";
			var mouth = "";
			var day = "";
			if(nowTime.indexOf("年") > 0) {
				year = nowTime.substring(0, nowTime.indexOf("年"));
				mouth = nowTime.substring(nowTime.indexOf("年") + 1, nowTime.indexOf("月"));
				day = nowTime.substring(nowTime.indexOf("月") + 1, nowTime.indexOf("日"));
			} else if(nowTime.indexOf("-") > 0) {
				year = nowTime.split("-")[0]
				mouth = nowTime.split("-")[1]
				day = nowTime.split("-")[2]
			} else {
				year = nowTime.split("/")[0]
				mouth = nowTime.split("/")[1]
				day = nowTime.split("/")[2]
			}
			var nowshi = getTime.getHours()
			var noefen = getTime.getMinutes()
			var nowmiao = getTime.getSeconds()
			if(nowshi < 10) {
				nowshi = "0" + nowshi
			}
			if(noefen < 10) {
				noefen = "0" + noefen
			}
			if(nowmiao < 10) {
				nowmiao = "0" + nowmiao
			}
			if(mouth < 10) {
				mouth = "0" + mouth
			}
			if(day < 10) {
				day = "0" + day
			}
			_self.$data.shenqing = year + "-" + mouth + "-" + day
			_self.$data.nowtime = nowshi + ":" + noefen + ":" + nowmiao
			//						_self.form.MissionStartDate = formDate('');
		},
		//时间选择
		selectDate: function(t) {
			var o = this;
			// hx
			if(t == "s") {
				if(o.form.MissionStartDate != "") {
					opt.value = o.form.MissionStartDate;
				}
			} else if(t === 'e') {
				if(o.form.MissionEndDate != "") {
					opt.value = o.form.MissionEndDate;
				}
			} else if(t === 'd') {
				if(o.form.datejiexiang != "") {
					opt.value = o.form.datejiexiang;
				}
			}
			var picker = new mui.DtPicker(opt);
			picker.show(function(rs) {
				/*
				 * rs.value 拼合后的 value
				 * rs.text 拼合后的 text
				 * rs.y 年，可以通过 rs.y.vaue 和 rs.y.text 获取值和文本
				 * rs.m 月，用法同年
				 * rs.d 日，用法同年
				 * rs.h 时，用法同年
				 * rs.i 分（minutes 的第二个字母），用法同年
				 */
				opt["value"] = rs.value; //控件同步
				if(t == "s") {
					o.form.MissionStartDate = rs.value;
				} else if(t === 'e') {
					o.form.MissionEndDate = rs.value;
				} else if(t === 'd') {
					o.form.datejiexiang = rs.value;
				}
				picker.dispose(); //释放资源
			})
		},

		//选承诺人
		chengnuo: function() {
			var _self = this
			_self.$data.gsdifferent = 1
			window.appApi.openProjectContactSelectPage(projectSn, '', _self.$data.personAcceptID, 1, false, false, false) //默认为true,设置false,过滤掉本方人员
		},
		//选被承诺人
		beichengnuo: function() {
			var _self = this
			_self.$data.gsdifferent = 2
			//						alert(_self.$data.personDistributeID)
			window.appApi.openProjectContactSelectPage(projectSn, '', _self.$data.personDistributeID, 1, false, false, false) //默认为true,设置false,过滤掉本方人员
		},
		xuanren: function(n) {
			var _self = this
			_self.$data.type = n
		},
		//点击遮罩
		mask: function() {
			app.deleyewu()
		},
		//点击第一步
		step1: function(n) {
			var _self = this
			if(_self.$data.personAccept == '') {
				ludan("请选择承诺人", 1, 1)
			} else if(_self.$data.personDistribute == '') {
				ludan("请选择被承诺人", 1, 1)
			} else {

				//						if(_self.$data.personDistribute == '') {
				//							ludan("请选择被承诺人", 1, 1)
				//							return;
				//						}
				_self.$data.beizhuzhuan = _self.$data.beizhu.replace(/<\/?.+?>/g, "#.%#");
				_self.$data.beizhuzhuan = _self.$data.beizhu.replace(/[\r\n]/g, "#.%#");
				_self.$data.backicon = n
				appApi.hideBack()
			}
			app.sendyewu()

		},
		//点击第二步
		step2: function(n) {
			var _self = this
			appApi.hideBack()
			if(_self.$data.nowCompany.length == 0) {
				ludan("请选择接收单位", 1, 1)
			} else {
				_self.$data.backicon = n
			}
		},
		//点击返回按钮
		back: function() {
			var _self = this
			if(_self.$data.backicon == 1) {
				setTimeout(function() {
					appApi.showBack()
				}, 100)
			}
			if(_self.$data.backicon > 0) {
				_self.$data.backicon = _self.$data.backicon - 1
			}

		},
		//提交更改的业务类别信息
		sendyewu: function() {
			var _self = this
			var yewuname = []
			for(i in _self.$data.sites) {
				yewuname.push(_self.$data.sites[i].name)
			}
			var param = {
				"type": "1",
				"companyName": isRoomName,
				"companyID": isRoomCreditCode,
				"names": yewuname.toString(),
			}
			var urlcan = "type=1&companyName=" + isRoomName + "&companyID=" + isRoomCreditCode + "&names=" + yewuname.toString()

			console.log(getUrl() + "/chart/column/insert_w_danjutypecfg?" + urlcan)
			axios.post(getUrl() + "/chart/column/insert_w_danjutypecfg?" + urlcan).then(function(response) {
				console.log(response)
				if(response.data.code == 200) {
					console.log(response)
				}
			}).catch(function(error) {
				ludan(error, 1, 3);
			})
		},
		//从原生获取选人信息
		selectMan: function(CONTENT) {
			var _self = this
			if(_self.$data.gsdifferent == 1) {
				_self.$data.xsbitian = 1
				_self.$data.personAccept = JSON.parse(CONTENT.result).nickName
				_self.$data.personAcceptID = JSON.parse(CONTENT.result).userId
				_self.$data.companySaleName = JSON.parse(CONTENT.result).roomName
				if(JSON.parse(CONTENT.result).companyId = '') {
					_self.$data.companySaleID = JSON.parse(CONTENT.result).roomName
				} else {
					_self.$data.companySaleID = JSON.parse(CONTENT.result).companyId
				}
				_self.$data.companySaleRoomID = JSON.parse(CONTENT.result).roomId
				_self.$data.cnroomImId = JSON.parse(CONTENT.result).roomImId
				if(JSON.parse(CONTENT.result).userId != userid) { //Userroomimid 当前用户不是承诺人
					_self.$data.personDistributeID = userid
					_self.$data.personDistribute = decodeURI(username)
					_self.$data.companyBuyName = _self.$data.UserName
					_self.$data.companyBuyID = _self.$data.Userid
					_self.$data.companyBuyRoomID = _self.$data.Userroomid
					_self.$data.bcnroomImId = JSON.parse(CONTENT.result).roomImId
					//								_self.$data.touserid=
				}
				//							app.usermains(JSON.parse(CONTENT.result).userId)
				//							app.usermains(JSON.parse(CONTENT.result).userId)
				//							app.usermains(JSON.parse(CONTENT.result).userId)
			} else if(_self.$data.gsdifferent == 2) {
				_self.$data.gmbitian = 1
				_self.$data.personDistribute = JSON.parse(CONTENT.result).nickName
				_self.$data.personDistributeID = JSON.parse(CONTENT.result).userId
				_self.$data.companyBuyName = JSON.parse(CONTENT.result).roomName
				if(JSON.parse(CONTENT.result).companyId == '') {
					_self.$data.companyBuyID = JSON.parse(CONTENT.result).roomName
				} else {
					_self.$data.companyBuyID = JSON.parse(CONTENT.result).companyId
				}
				_self.$data.companyBuyRoomID = JSON.parse(CONTENT.result).roomId
				if(JSON.parse(CONTENT.result).userId != userid) {
					_self.$data.personAcceptID = userid
					_self.$data.personAccept = decodeURI(username)
					_self.$data.companySaleName = _self.$data.UserName
					//								alert(isRoomCreditCode)
					_self.$data.companySaleID = _self.$data.Userid
					_self.$data.companySaleRoomID = _self.$data.Userroomid
					_self.$data.bcnroomImId = JSON.parse(CONTENT.result).roomImId
				}
				//							app.usermains(_self.$data.personDistributeID)
				_self.$data.bcnroomImId = JSON.parse(CONTENT.result).roomImId
				//							app.usermains(_self.$data.personDistributeID)
				//_self.$data.bcnroomImId = JSON.parse(CONTENT.result).roomImId
				//							app.usermains(_self.$data.personDistributeID)
			}

			//判断被承诺人
			//						if(userid==_self.$data.personDistributeID){
			//							_self.$data.touserid=_self.$data.personAccept
			//						}else{
			//							_self.$data.touserid=_self.$data.personDistribute
			//						}
		},
		//剪切板
		cliptext: function(CONTENT) {
			var _self = this
			if(CONTENT.result.split("=")[0] == "jyxr") {
				_self.$data.beizhu = CONTENT.result.split("=")[1]
				appApi.copyText("")
			}
		},
		//查询用户信息
		usermains: function(n) {
			var _self = this
			axios.post(getUrl() + "/pcontact_api/getroombyprojectsn?projectSn=" + n + "&userId=" + userid).then(function(response) {
				var result = response.data.result;

				if(response.data.code == 0) {
					//								_self.$data.startroomimid=response.data.result.roomImId
					//当前用户的companyname/id/roomid
					_self.$data.UserName = response.data.result.roomName
					if(response.data.result.companyCreditCode == '') {
						_self.$data.Userid = response.data.result.roomName
						_self.$data.companySaleID = response.data.result.roomName
					} else {
						_self.$data.companySaleID = response.data.result.companyCreditCode
						_self.$data.Userid = response.data.result.companyCreditCode
					}
					_self.$data.Userroomid = response.data.result.roomId
					_self.$data.Userroomimid = response.data.result.roomImId
					_self.$data.Userroomclass = response.data.result.roomClassName
					//								_self.$data.companySaleID=response.data.result.companyCreditCode
				}
			})
		},
		//上传文件
		upfile: function(event) {
			this.hideDiv();
			loading("上传中")
			sessionStorage.removeItem("cunnews")
			var _self = this
			var file = document.getElementById(event.target.id).files;
			var zrid = document.getElementById(event.target.id).getAttribute("id")
			var url = getUrl() + "/sass_api/upload_file";
			var form = new FormData();
			var forimg = []
			var forfile = []
			for(var i = 0; i < file.length; i++) {
				form.append("file", file[i]);
				//读取图片数据
				var f = document.getElementById(event.target.id).files[i];
				var imgtype = f.type.split('/')[0]
				if(zrid == "file") {
					var reader = new FileReader();
					reader.onload = function(e) {
						var data = e.target.result;
						//加载图片获取图片真实宽度和高度
						var image = new Image();
						image.onload = function() {
							width = image.width;
							height = image.height;

						};
						image.src = data;
						forimg.push({
							src: image.src
						})
					};
					sessionStorage.setItem("cunnews", "1")
					reader.readAsDataURL(f);
				} else if(zrid == "files") {
					sessionStorage.setItem("cunnews", "2")
					var na = file[i].name
					forfile.push({
						name: f.name
					})
					console.log(_self.$data.fujians)
				}

			}
			_self.$data.imgsrc = forimg
			if(sessionStorage.getItem("cunnews") == 1) {
				form.append("type", "1");
			} else {
				form.append("type", "2");
			}
			form.append("module", "contractnote");
			form.append("userid", userid);
			xhr = new XMLHttpRequest();
			xhr.open("post", url, true);
			xhr.onload = function(evt) {
				//请求完成
				layer.close(loading("上传中"))
			};
			xhr.onreadystatechange = function(evt) {
				if(xhr.readyState == 4 && xhr.status == 200) {
					console.log(xhr.responseText);
					var data = JSON.parse(evt.target.responseText);
					var rtnfiles = data.result.success;
					if(sessionStorage.getItem("cunnews") == 1) {
						_self.$data.imgs = _self.$data.imgs.concat(rtnfiles)
						for(var i = 0; i < rtnfiles.length; i++) {
							imgid.push(rtnfiles[i].fileId);
						}
						console.log(imgid)
						if(imgid.toString()) {
							_self.$data.zrimg = imgid.toString().split(',')
						}
					} else {
						for(var i = 0; i < rtnfiles.length; i++) {
							fujianid.push(rtnfiles[i].fileId);
						}
						_self.$data.fujians = _self.$data.fujians.concat(forfile)
						if(fujianid.toString()) {
							_self.$data.zrfujian = fujianid.toString().split(',')
							console.log(fujianid.toString())
						}

					}
					ludan("上传成功", 1, 1)
				} else if(xhr.readyState == 4 && xhr.status == 500) {
					ludan("上传失败", 1, 1)
				}
			}
			xhr.onerror = function(evt) {
				//请求失败
				var data = JSON.parse(evt.target.responseText);
				ludan("请求失败", 1, 1)
				console.log("data");
			};
			xhr.send(form);

		},
		//删除图片
		moveimg: function(n) {
			var _self = this;
			axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + imgid[n - 1]).then(function(response) {
				if(response.data.code == 0) {
					console.log(response.data)
					ludan("删除成功", 1, 2)
					document.getElementById("file").value = ""; //清除input内容，防止出现不能重复上传的问题
				}
			}).catch(function(error) {
				ludan(error, 1, 3);
			})
			imgid.splice(n - 1, 1)
			_self.$data.imgs.splice(n - 1, 1)
			_self.$data.zrimg.splice(n - 1, 1)
		},
		//删除附件
		movefj: function(n) {
			var _self = this;
			axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + fujianid[n - 1]).then(function(response) {
				if(response.data.code == 0) {
					console.log(response.data)
					ludan("删除成功", 1, 2)
					document.getElementById("files").value = ""; //清除input内容，防止出现不能重复上传的问题
				}
			}).catch(function(error) {
				ludan(error, 1, 3);
			})
			fujianid.splice(n - 1, 1)
			_self.$data.fujians.splice(n - 1, 1)
			//						console.log(n-1)
			_self.$data.zrfujian.splice(n - 1, 1)
			console.log(_self.$data.zrfujian)
			console.log(typeof JSON.stringify(_self.$data.zrfujian))
		},
		save: function() {
			var _self = this
			btnStop()
			var target = event.currentTarget
			ludan("保存中", 0, 1)
			//						if(_self.$data.tijao != 1) {
			_self.$data.tijao = 1
			app.getimgurl(0, target)
			//						} else {
			//							ludan("已保存", 2, 1)
			//						}

		},
		sends: function() {
			var _self = this
            if(_self.$data.postStatus) {
                _self.$data.postStatus = false;
                btnStop()
                var target = event.currentTarget
                ludan("提交中", 0, 1)
                //						if(_self.$data.baocun != 1) {
                _self.$data.baocun = 1
                app.getimgurl(1, target)
            }
			//						} else {
			//							ludan("已提交", 2, 1)
			//						}
		},
		//获取上传图片的url
		getimgurl: function(n, target) {
			var _self = this;
			_self.$data.imgurl = []
			console.log(_self.$data.zrimg)
			if(_self.$data.zrimg != '') {
				axios.post(getUrl() + "/sass_api/ get_uploadfile_info?fileIdStr=" + _self.$data.zrimg).then(function(response) {
					if(response.data.code == 200) {
						console.log(response.data.result)
						if(_self.$data.tijao == 1 && _self.$data.baocun != 1) { //保存不提交
							for(var i = 0; i < response.data.result.length; i++) {
								_self.$data.imgurl.push({
									src: response.data.result[i].thumbnailurl
								})

							}
							app.savenews(n, target)
						} else if(_self.$data.tijao != 1 && _self.$data.baocun == 1) { //直接提交
							for(var i = 0; i < response.data.result.length; i++) {
								_self.$data.imgurl.push({
									src: response.data.result[i].thumbnailurl
								})

							}
							app.savenews(n, target)
						} else if(_self.$data.tijao == 1 && _self.$data.baocun == 1) { //保存 再提交
							for(var i = 0; i < response.data.result.length; i++) {
								_self.$data.imgurl.push({
									src: response.data.result[i].thumbnailurl
								})

							}
							//										app.sendtodo()
							app.savenews(n, target)
						}

					}
				})
			} else {
				if(_self.$data.tijao == 1 && _self.$data.baocun != 1) { //保存不提交
					//									for(var i = 0; i < response.data.result.length; i++) {
					//										_self.$data.imgurl.push({
					//											src: response.data.result[i].longurl
					//										})
					//
					//									}
					app.savenews(n, target)
				} else if(_self.$data.tijao != 1 && _self.$data.baocun == 1) { //直接提交
					//									for(var i = 0; i < response.data.result.length; i++) {
					//										_self.$data.imgurl.push({
					//											src: response.data.result[i].longurl
					//										})
					//
					//									}
					app.savenews(n, target)
				} else if(_self.$data.tijao == 1 && _self.$data.baocun == 1) { //保存 再提交
					//								app.sendtodo()
					app.savenews(n, target)
				}
			}
		},
		savenews: function(n, target) {
			//获取数据
			var _self = this;
			var saveType='update';
			if(n==1){
				saveType='update';
			}else{
				saveType='save';
			}
			var fjid;
			if(_self.$data.attachmentIds == '') {
				_self.$data.attachmentIds = ''
			} else {
				_self.$data.attachmentIds = "," + _self.$data.attachmentIds
			}
			if(imgid.toString() == '') {
				fjid = fujianid.toString()
			} else if(fujianid.toString() == '') {
				fjid = imgid.toString()
			} else {
				fjid = imgid.toString() + "," + fujianid.toString()
			}
			//判断推送方向  _self.$data.personAcceptID _self.$data.personDistributeID
			//						if(userid!=_self.$data.personAcceptID && userid!=_self.$data.personDistributeID){
			//
			//						}
			//						imgid = _self.$data.zrimg.length + _self.$data.zrfujian.length
			//						if(_self.$data.tuistatus == 1) {
			//
			//							_self.$data.pa_cigid = _self.$data.tuicfgid
			//							_self.$data.pa_projectsn = _self.$data.tuiprojectSn
			//							_self.$data.pa_isroomid = _self.$data.tuiroomid
			//							_self.$data.pa_isroomname = _self.$data.tuiroomname
			//							_self.$data.pa_isRoomCreditCode = _self.$data.tuicompanySaleID
			//							_self.$data.pa_projectName = _self.$data.tuiprojectName
			//							_self.$data.currRoomImId = _self.$data.tuicurrRoomImId
			//							_self.$data.currRoomClassName = _self.$data.tuicurRoomName
			//						}
			//						if(_self.$data.chenk2 != 1) {
			//							_self.$data.tuiroomimid = _self.$data.starroomimid
			//						}
			//						alert(_self.$data.boforeroomImId)
			var chengnuiriqi
			if(_self.$data.form.MissionStartDate == '') {
				chengnuiriqi = null
			} else {
				chengnuiriqi = _self.$data.form.MissionStartDate + " " + _self.$data.nowtime
			}
			var title;
			if(_self.$data.type == "单方承诺") {
				title = _self.$data.personAccept + '向' + _self.$data.personDistribute + '的个人承诺'
			} else {
				title = _self.$data.personAccept + "与" + _self.$data.personDistribute + '的双向承诺'
			}

			var tablefields = {
				userName: decodeURI(username),
				userID: userid,

				personAccept: _self.$data.personAccept,
				personAcceptID: _self.$data.personAcceptID,
				personDistribute: _self.$data.personDistribute,
				personDistributeID: _self.$data.personDistributeID,
				companySaleName: _self.$data.companySaleName,
				companySaleID: _self.$data.companySaleID,
				companySaleRoomID: _self.$data.companySaleRoomID,
				companyBuyName: _self.$data.companyBuyName,
				companyBuyID: _self.$data.companyBuyID,
				companyBuyRoomID: _self.$data.companyBuyRoomID,

				name: title,
				dateShenqing: _self.$data.shenqing + " " + _self.$data.nowtime,
				projectName: _self.$data.pa_projectName,
				projectSN: _self.$data.pa_projectsn,
				bcnroomImId: _self.$data.bcnroomImId,
				//							companySaleName: _self.$data.pa_isroomname,
				//							companySaleID: _self.$data.pa_isRoomCreditCode,
				//							companySaleRoomID: _self.$data.pa_isroomid,
				//							companyBuyName: _self.$data.nowCompanyname.toString(),
				//							companyBuyID: _self.$data.nowCompanyid.toString(),
				//							companyBuyRoomID: _self.$data.nowCompanyroomid.toString(),
				//							name: _self.$data.title,
				type: _self.$data.type,
				dateChengnuo: chengnuiriqi,
				beizhu: _self.$data.beizhuzhuan,
				confirmStatus: "", //确认状态
				confirmPersonName: "",
				confirmPersonID: "",
			}
			if(_self.$data.id != '') {
				tablefields["id"] = _self.$data.id
			}
			//						alert(JSON.stringify(tablefields))
			if(n == 0) {
				//使用单据状态判断，无法满足需求。2018-5-21新增字段postType(提交保存状态)0=保存 1=提交
				_self.$data.confirm = '0';
			} else {
				_self.$data.confirm = '1';
				_self.$data.postType = '1';
			}
			var param = {
				table: {
					id: _self.$data.pa_cigid,
					projectid: _self.$data.pa_projectsn,
					roomid: _self.$data.pa_isroomid,
					roomname: _self.$data.pa_isroomname,
					userId: userid,
					//								uid:'10395'
				},
				confirm: _self.$data.confirm,
				postType: _self.$data.postType,
				ludancompanyName: _self.$data.UserName,
				attachment: fjid + _self.$data.attachmentIds,
				toroomimid: _self.$data.bcnroomImId,
				//							gongsialllei: _self.$data.nowCompany,
				currRoomImId: _self.$data.Userroomimid,
				//							gongsialllei: _self.$data.nowCompany,
				//							gongsialllei: _self.$data.nowCompany,
				//							currRoomImId: _self.$data.currRoomImId,
				curRoomName: _self.$data.currRoomClassName,
				roomid: _self.$data.pa_isroomid,
				toImid: _self.$data.bcnroomImId,
				imgs: _self.$data.imgurl,
				imgid: _self.$data.zrimg,
				fujians: _self.$data.fujians,
				fjid: _self.$data.zrfujian,
				//				uid: "10395",
				tablefields: tablefields,
				subtablefields: [],
				createRoomId: paramMap.currRoomId,
				typeName: "个人承诺",
				title: title,
				saveType:saveType,
			}
			console.log(param)
			//						alert(JSON.stringify(param))
			axios.post(getUrl() + "/contract/save", param).then(function(response) {
				if(response.data.code == 200) {
					_self.$data.first = 1
					_self.$data.id = response.data.result.id
					var succname = []
					var faliename = []
					if(n == 1) {
						closeLoading()
						//										layer.close(ludan("提交中", 0, 1))
						app.sendtodo(target)
					} else {
						closeLoading()
						//										layer.close(ludan("保存中", 0, 1))
						ludan("保存成功", 2, 2, function() {
							btnstart(target)
						})
					}
				} else {
					closeLoading()
					ludan("保存失败", 2, 1)
					btnstart(target)
				}
			}).catch(function(error) {
				closeLoading()
				ludan(error, 2, 1);
				btnstart(target)
			})
		},
		sendtodo: function(target) {
			var _self = this
			var title
			if(_self.$data.type == "单方承诺") {
				title = _self.$data.personAccept + '向' + _self.$data.personDistribute + '的个人承诺'
			} else {
				title = _self.$data.personAccept + "与" + _self.$data.personDistribute + '的双向承诺'
			}
			if(_self.$data.roomType == "2") {
				_self.$data.bcnroomImId += "," + paramMap.currRoomImId;
			}
			//						alert(_self.$data.Userroomclass + "-" + _self.$data.UserName)
			var titletype = encodeURIComponent(encodeURIComponent("个人承诺"));
			var titles = encodeURIComponent(encodeURIComponent(_self.$data.personAccept + "的个人承诺"));
			var todojson = {
				"title": title,
				"titileTwo": _self.$data.Userroomclass + "-" + _self.$data.UserName,
				"content": "承诺日期=" + _self.$data.shenqing,
				"fileCount": "0",
				"url": '/static/newwebstatic/chengnuo/transfer.html?id=' + _self.$data.id,
				"colorString": "",
				"todoViewableMember": "0",
				"toImId": _self.$data.bcnroomImId,
				"formuserid": userid,
				"currentRoomImid": _self.$data.Userroomimid,
				"chatType": "2",
				"relation": _self.$data.id,
				"score": "", //评分待办必要参数，设置分数
				"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
				"setButton": [{
					"type": 1, //按钮点击类型 1=请求url 2=打开url
					"name": "确认",
					"url": "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&projectSn=" + _self.$data.pa_projectsn + "&userid=" + userid + "&sendtype=1" + "&titletype=" + titletype + "&docType=chengnuo",
				}, {
					"type": 1, //按钮点击类型 1=请求url 2=打开url
					"name": "退回",
					"url": "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id + "&projectSn=" + _self.$data.pa_projectsn + "&userid=" + userid + "&title=" + titles + "&titletype=" + titletype + "&sendtype=1" + "&docType=chengnuo",
				}]

			}

			var parame = new FormData();
			parame.append("url", '/static/newwebstatic/chengnuo/transfer.html?id=' + _self.$data.id)
			parame.append("userId", getCookie("userid"))
			axios.post(getUrl() + "/sass_api/update_withdraw_todo", parame).then(function(response) {

			});

			window.appApi.sendTodo(todojson)
			ludan("提交成功", 2, 2)
			//						btnstart(target)
		},
		//查询房间信息
		findRoomInfo: function(roomid) {
			var _self = this;
			var formdata = new FormData();
			formdata.append("roomId", roomid)
			axios.post(getUrl() + "/pcontact_api/findroominfo", formdata).then(function(response) {
				if(response.data.code == 200) {
					var result = response.data.result;
					_self.$data.roomType = result.roomType;
				}
			}).catch(function(error) {
				msg(error)
			})
		},
		//					send: function() {
		//
		//					},
		//判断文件类型
	}
})
var app = new Vue({
    el: '#app',
    data: {
        todojsoan: '',
        //					sites: [],
        //					pinpai: '',
        //					mingcheng: "",
        typ: paramMap.typ,
        input1:"",
        urlcan: urlcan,
        nes: nes,
        imgs: [],
        fujians: [],
        zrimg: [],
        zrfujian: [],
        printTime: '',
        closewindow: '',
        cunnews: '',
        score:0,
        input11:'',
        btnStatus:true,
    },
    created: function() {
        var _self = this
//					if(this.typ==3){
//						setTimeout(function(){
//							appApi.hideBack()
//						},500)
//
//					}
        //					this.initData();
        var getTime = new Date()
        var nowTime = getTime.toLocaleDateString()
        var year = nowTime.split("/")[0]
        var mouth = nowTime.split("/")[1]
        var day = nowTime.split("/")[2]
        var nowshi = getTime.getHours()
        var noefen = getTime.getMinutes()
        var nowmiao = getTime.getSeconds()
        if(mouth < 10) {
            mouth = "0" + mouth
        }
        if(day < 10) {
            day = "0" + day
        }
        if(nowshi < 10) {
            nowshi = "0" + nowshi
        }
        if(noefen < 10) {
            noefen = "0" + noefen
        }
        if(nowmiao < 10) {
            nowmiao = "0" + nowmiao
        }
        _self.$data.nowtime = nowshi + ":" + noefen + ":" + nowmiao
        _self.$data.printTime = year + "-" + mouth + "-" + day
        //获取参数
    },
    // 在 `methods` 对象中定义方法
    methods: {

        fjFileType : function(){
            $(".mui-backdrop").show();
            $(".pop-up").show();
        },
        hideDiv : function(){
            $(".mui-backdrop").hide();
            $(".pop-up").hide();
        },
        showCloudFile:function(){
            //打开项目列表
            appApi.openNewWindow(getUrl() + "/static/newwebstatic/file_gui/project_list.html?entrance=bill&projectSN="+paramMap.projectid,"我的项目");

        },
        back: function() {
            var _self = this
            appApi.showBack()
            window.location.href = "newInfo.html?id="+paramMap.id

        },
        masktishi: function() {
            msg("数据提交中，请勿重复点击")
        },
        mask: function() {
            /* $(".mask").css({
                 "display": "block",
                 "opacity": "0.6"
             })*/
        },
        sendbtn: function() {
            var _self = this
            if(_self.$data.btnStatus) {
                _self.$data.btnStatus = false;
                var target = event.currentTarget
                btnStop()
                _self.$data.closewindow = 1
                app.mask()
                app.initData(target)
            }

        },
        initData: function(target) {
            //						 this.$options.methods.upfile(event)
            //获取数据
            var _self = this;
            //						var fjid = imgid.toString()
            _self.$data.input11 = _self.$data.input1.replace(/[\r\n]/g, "#.%#");
            var fjid
            if(_self.$data.zrimg.toString() == '') {
                fjid = _self.$data.zrfujian.toString()
            } else if(_self.$data.zrfujian.toString() == '') {
                fjid = _self.$data.zrimg.toString()
            } else {
                fjid = _self.$data.zrimg.toString() + "," + _self.$data.zrfujian.toString()
            }
            //						alert(fjid)
            //评论内容
            //						var id="5a6ecbda70474ea263ddfbb5";
            //						var uid='10392';
            var param = {
                attachment: fjid,
                content: _self.$data.input11,
                type: typ,
                uid: userid,
                docid: paramMap.id,
                roomid: paramMap.roomid,
                roomname: paramMap.roomname,
                projectid: paramMap.projectid,
                score: _self.$data.score

            }
            //						alert(JSON.stringify(param))
            console.log(param)
            //						alert(JSON.stringify(param))
            //						alert(fjid+"/"+_self.$data.input1+"/"+typ+"/"+userid+"/"+ paramMap.wendangid+"/"+paramMap.roomId+"/"+paramMap.roomName+"/"+paramMap.projectSn)
            if(typ == 99){//撤回功能
                var parm = {
                    "id": paramMap.id,
                    attachment: fjid,
                    content: _self.$data.input11,
                }
                axios.post(getUrl() + "/contract/withdrawcontent", parm).then(function (res) {
                    if(res.data.code==200){
                        ludan("撤回成功", 2, 2, function() {
                            appApi.closeNewWindow();
//                                      setTimeout(function(){
//                                      	btnstart(target)
//                                      })

                        })
                    }else if(res.data.code==500){
                        ludan(res.data.message, 2, 2, function() {
                            appApi.closeNewWindow();
//                                      setTimeout(function(){
//                                      	window.location.reload()
//                                      	,200})
                        })
                    }
                })
            }else {
                axios.post(getUrl() + "/contract/save_note", param).then(function (response) {
                    if (response.data.code == 200) {
                        console.log(response.data)
                        //								alert(JSON.stringify(_self.$data.noteList))
                        //								_self.$data.sites = response.data.result.tablefields;s
                        //									var wenfou =  window.location.href.split("?")[1]
                        //									window.appApi.closeNewWindow()
                        //									alert(_self.$data.urlcan)
                        //									alert(paramMap.fromcurrRoomName + "-" + paramMap.roomName)
                        if (_self.$data.typ == 4) {
                            // alert(JSON.stringify(paramMap))
                            // var parm = {
                            //     "toImId": paramMap.formroomimid,
                            //     "chatType": "2",
                            //     "toNickName": "",
                            //     "toAvatarUrl": "",
                            //     "content": paramMap.roomname + "已退回" + paramMap.fromroomname + "的个人承诺",
                            // }
                            // console.log(parm)
                            // appApi.sendNotifyMsg(parm)
                            var todojson = {
                                //											"title": decodeURI(username) + "退回的收发件",
                                "title": "个人承诺退回:" + paramMap.title + "的个人承诺",
                                "titileTwo": paramMap.roomclass + "-" + paramMap.fromroomname,
                                // "content": "被承诺人=" + paramMap.fromuser + "|类别=" + paramMap.leibie,
                                "content": "类别=" + paramMap.leibie + "|日期=" + _self.$data.printTime,
                                //											"fileCount": imgid.length+fujianid.length,
                                "fileCount": 0,
                                "url": '/static/newwebstatic/chengnuo/transfer.html?id=' + paramMap.id,
                                "colorString": "",
                                "todoViewableMember": "0",
                                "toImId": paramMap.formroomimid,
                                //										"toImId":'43371363106817',
                                "formuserid": userid,
                                "currentRoomImid": paramMap.nowroomImId,
                                "chatType": "2",
                                "relation": paramMap.id,
                                // "score": _self.$data.score, //评分待办必要参数，设置分数
                                "score":"" , //退回后评分应该设置为空
                                //										"confirmUrl": "456", //有确认按钮必要参数
                                //										"refusedUrl": "231", //有拒绝按钮必要参数
                                "todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
                                "setButton": [{
                                    "type": 2, //按钮点击类型 1=请求url 2=打开url
                                    "name": "查看",
                                    "url": "/static/newwebstatic/chengnuo/transfer.html?id=" + paramMap.id
                                    //												"pingfen":"",
                                    //												"docid":"",
                                    //												"roomId":"",
                                    //												"roomName":"",
                                    //												"projectSn":"",
                                    //												"userid":""
                                }]

                            }
                            //
                            console.log(JSON.stringify(todojson))
                            _self.$data.todojsoan = JSON.stringify(todojson)
                            window.appApi.sendTodo(todojson)
                            setTimeout(function () {
                                returnSuccess();
                            },2000)
                            // ludan("退回成功", 0,2, function() {//pingjiaToimid
                            //     window.appApi.openChat(paramMap.nowroomImId, "", paramMap.roomname, 2)
                            // })
                            //										window.location.href = getUrl()+'/static/newwebstatic/chengnuo/work_content.html?'+urllast
                        } else if (typ == 1) { //										appApi.refreshData(2)
                            //										window.appApi.closeNewWindow()
                            var parm = {
                                "toImId": paramMap.formroomimid,
                                "chatType": "2",
                                "toNickName": "",
                                "toAvatarUrl": "",
                                //														myExtType: 'notify_type',
                                "content": paramMap.roomname + "已确认" + paramMap.formroomname + "的个人承诺",
                            }
                            console.log(parm)
                            appApi.sendNotifyMsg(parm)
                            //判断承诺类型  确认评价推送方
                            var todojson = {
                                //											"title": decodeURI(username) + "退回的收发件",
                                "title": paramMap.title + "的个人承诺",
                                "titileTwo": paramMap.roomclass + "-" + paramMap.formroomname,
                                "content": "被承诺人=" + paramMap.fromuser + "|承诺类型=" + paramMap.leibie,
                                //											"fileCount": imgid.length+fujianid.length,
                                "fileCount": 0,
                                "url": '/static/newwebstatic/chengnuo/transfer.html?id=' + paramMap.id,
                                "colorString": "",
                                "todoViewableMember": "0",
                                "toImId": paramMap.pingjiaToimid,
                                //										"toImId":'43371363106817',
                                "formuserid": userid,
//                                          "currentRoomImid": paramMap.nowroomImId,
                                "currentRoomImid":'',
                                "chatType": "2",
                                "relation": paramMap.id,
                                "score": _self.$data.score, //评分待办必要参数，设置分数
                                //										"confirmUrl": "456", //有确认按钮必要参数
                                //										"refusedUrl": "231", //有拒绝按钮必要参数
                                "todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
                                chengnuotype:paramMap.chengnuotype,
                                "setButton": [/*{
                                                "type": 1, //按钮点击类型 1=请求url 2=打开url
                                                "name": "确认",
                                                "url": "/contract/do_todobtu?type=4&pingfen=0&docid=" + paramMap.id + "&projectSn=" + paramMap.projectid + "&userid=" + userid,
                                                //												"pingfen":"",
                                                //												"docid":"",
                                                //												"roomId":"",
                                                //												"roomName":"",
                                                //												"projectSn":"",
                                                //												"userid":""
                                            }, {
                                                "type": 1, //按钮点击类型 1=请求url 2=打开url
                                                "name": "退回",
                                                "url": "/contract/do_todobtu?type=4&pingfen=0&docid=" + paramMap.id + "&projectSn=" + paramMap.projectid + "&userid=" + userid,
                                            }*/{
                                    "type": 2, //按钮点击类型 1=请求url 2=打开url
                                    "name": "查看",
                                    "url": "/static/newwebstatic/chengnuo/transfer.html?id=" + paramMap.id,
                                }]

                            }
                            //
                            console.log(todojson)
                            window.appApi.sendTodo(todojson)
                            setTimeout(function () {
                                confirmSuccess();
                            },2000)


                            //										appApi.openNewWindow(getUrl()+'/static/newwebstatic/chengnuo/work_kan.html?id='+paramMap.id)
                            //										window.location.href=getUrl()+'/static/newwebstatic/chengnuo/work_kan.html?'+_self.$data.urlcan
                            $(".mask").css({
                                "display": "none",
                                "opacity": "0.6"
                            })
                        } else if (typ == 3) {
                            ludan("评论成功", 2, 2, function () {
//                                      	window.history.go(-1)
//                                      	window.location.href = "newInfo.html?id="+paramMap.id
                                appApi.closeNewWindow()
//                                          window.appApi.openChat(paramMap.nowroomImId, "", paramMap.roomname, 2)
//                                             btnstart(target)
                            })

                            //										appApi.openNewWindow(getUrl()+'/static/newwebstatic/chengnuo/work_kan.html?id='+paramMap.id)
                            //										window.location.href=getUrl()+'/static/newwebstatic/chengnuo/work_kan.html?'+_self.$data.urlcan
                            $(".mask").css({
                                "display": "none",
                                "opacity": "0.6"
                            })
                        } else if (typ == 6) {
                            ludan("评价成功", 2, 2, function () {
                                appApi.closeNewWindow()
//                                          window.appApi.openChat(paramMap.nowroomImId, "", paramMap.roomname, 2)
//                                             btnstart(target)
                            })

                            //										appApi.openNewWindow(getUrl()+'/static/newwebstatic/chengnuo/work_kan.html?id='+paramMap.id)
                            //										window.location.href=getUrl()+'/static/newwebstatic/chengnuo/work_kan.html?'+_self.$data.urlcan
                            $(".mask").css({
                                "display": "none",
                                "opacity": "0.6"
                            })
                        }

                    } else {
                        btnstart(target)
                        //							msg("获取云盘目录信息失败")
                    }
                })
            }
        },
        //评论五星
        wuxing:function(event){
            var _self=this
            _self.$data.score=event.target.name
            $(event.target).attr("src","../../images/wuxing.png")
            $(event.target).prevAll().attr("src","../../images/wuxing.png")
            $(event.target).nextAll().attr("src","../../images/wuxing1.png")
        },
        //上传文件
        upfile: function(event) {
            this.hideDiv();
            loading("上传中")
            var _self = this
            var file = document.getElementById(event.target.id).files;
            var zrid = document.getElementById(event.target.id).getAttribute("id")
            var url = getUrl() + "/sass_api/upload_file";
            var form = new FormData();
            var forimg = []
            var forfile = []
            for(var i = 0; i < file.length; i++) {
                form.append("file", file[i]);
                //读取图片数据
                var f = document.getElementById(event.target.id).files[i];
                var imgtype = f.type.split('/')[0]
                if(zrid == "file") {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        var data = e.target.result;
                        //加载图片获取图片真实宽度和高度
                        var image = new Image();
                        image.onload = function() {
                            width = image.width;
                            height = image.height;

                        };
                        image.src = data;
                        /*_self.$data.imgs.push({
                            src: image.src
                        })*/
                    };
                    _self.$data.cunnews = 1
                    reader.readAsDataURL(f);
                } else if(zrid == "files") {
                    _self.$data.cunnews = 2
                    var na = file[i].name
                    /*_self.$data.fujians.push({
                        name: f.name
                    })*/
                    console.log(_self.$data.fujians)
                }
                //							reader.readAsDataURL(f);

            }
            if(_self.$data.cunnews == 1) {
                form.append("type", "1");
            } else {
                form.append("type", "2");
            }
            form.append("module", "contractnote");
            form.append("userid", userid);
            xhr = new XMLHttpRequest();
            xhr.open("post", url, true);
            xhr.onload = function(evt) {
                layer.close(loading("上传中"))
            };
            xhr.onreadystatechange = function(evt) {
                console.log(xhr)
                if(xhr.readyState == 4 && xhr.status == 200) {
                	ludan("上传成功",1,2)
                    console.log(xhr.responseText);
                    var data = JSON.parse(evt.target.responseText);
                    var rtnfiles = data.result.success;
                    console.log(data)
                    if(zrid == "file") {
                        for(var i=0;i<rtnfiles.length;i++){
                            imgid.push(rtnfiles[i].fileId);
                            _self.$data.imgs.push({
                                src: rtnfiles[i].src,
                                fileId: rtnfiles[i].fileId
                            })
                        }
                        console.log(imgid)
                        if(imgid.toString()){
                            _self.$data.zrimg = imgid.toString().split(',')
                        }
                    } else if(zrid == "files") {
                        for(var i=0;i<rtnfiles.length;i++){
                            fujianid.push(rtnfiles[i].fileId);
                            _self.$data.fujians.push({
                                name: rtnfiles[i].fileName,
                                fileId:rtnfiles[i].fileId
                            })
                        }
                        if(fujianid.toString()){
                            _self.$data.zrfujian = fujianid.toString().split(',')
                        }

                        console.log(fujianid.toString())
                    }

                } else if(xhr.readyState == 4 && xhr.status == 500) {
                    msg("上传失败")
                }
            }
            xhr.onerror = function(evt) {
                //请求失败
                var data = JSON.parse(evt.target.responseText);
                console.log(data);
            };
            xhr.send(form);

        },
        moveimg: function(fileId,n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + fileId).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功",1,2)
                }
            }).catch(function(error) {
                ludan(error, 1, 3);
            })
            //var index = _self.$data.imgs.indexOf(fileId);
//                      _self.$data.imgs.splice(index, 1)
            _self.$data.imgs.splice(n, 1)
            //						console.log(n-1)
            var indexs = _self.$data.zrimg.indexOf(fileId);
            _self.$data.zrimg.splice(indexs, 1)
            console.log(_self.$data.zrimg)
            console.log(typeof JSON.stringify(_self.$data.zrimg))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        },
        movefj: function(fileId,n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + fileId).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功",1,2)
                }
            }).catch(function(error) {
                ludan(error, 1, 3);
            })
            // var index = _self.$data.fujians.indexOf(fileId);
//                      _self.$data.fujians.splice(index, 1)
            _self.$data.fujians.splice(n, 1)
            //						console.log(n-1)
            var indexs = _self.$data.zrfujian.indexOf(fileId);
            _self.$data.zrfujian.splice(indexs, 1)
            console.log(_self.$data.zrfujian)
            console.log(typeof JSON.stringify(_self.$data.zrfujian))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        },
        changeImgIds : function(dishImgIds){//得到广播回来的ID
            var _self = this;
            var forfile = []
            this.hideDiv();

            var parm = {
                dishIds :dishImgIds,
            }
            axios.post(getUrl()+"/contract/copydishinfo",parm).then(function(response){
                var rtnfiles = response.data.result.success;
                for(var i=0;i<rtnfiles.length;i++){
                    fujianid.push(rtnfiles[i].fileId);
                    forfile.push({
                        name: rtnfiles[i].fileName,
                        fileId: rtnfiles[i].fileId
                    })
                }
                _self.$data.fujians = _self.$data.fujians.concat(forfile)
                if(fujianid.toString()){
                    _self.$data.zrfujian = fujianid.toString().split(',')
                }
            })
        },
    },
})
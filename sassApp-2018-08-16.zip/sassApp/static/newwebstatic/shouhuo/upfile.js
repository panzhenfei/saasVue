function upfile(event) {
	alert(5)
	console.log("////"+_self.$data.zrimg)
						loading("上传中")
						sessionStorage.removeItem("cunnews")
						var _self = this
						var file = document.getElementById(event.target.id).files;
						var zrid = document.getElementById(event.target.id).getAttribute("id")
						var url = getUrl() + "/sass_api/upload_file";
						var form = new FormData();
						var forimg = []
						var forfile = []
						for(var i = 0; i < file.length; i++) {
							form.append("file", file[i]);
							//读取图片数据
							var f = document.getElementById(event.target.id).files[i];
							var imgtype = f.type.split('/')[0]
							if(zrid == "file") {
								var reader = new FileReader();
								reader.onload = function(e) {
									var data = e.target.result;
									//加载图片获取图片真实宽度和高度
									var image = new Image();
									image.onload = function() {
										width = image.width;
										height = image.height;

									};
									image.src = data;
									forimg.push({
										src: image.src
									})
								};
								sessionStorage.setItem("cunnews", "1")
								reader.readAsDataURL(f);
							} else if(zrid == "files" || zrid == "excelFile") {
								sessionStorage.setItem("cunnews", "2")
								var na = file[i].name
								forfile.push({
									name: f.name
								})
								console.log(_self.$data.fujians)
							}

						}
						if(sessionStorage.getItem("cunnews") == 1) {
							form.append("type", "1");
						} else {
							form.append("type", "2");
						}
						form.append("module", "contractnote");
						form.append("userid", userid);
						xhr = new XMLHttpRequest();
						xhr.open("post", url, true);
						xhr.onload = function(evt) {
							//请求完成
							layer.close(loading("上传中"))
						};
						xhr.onreadystatechange = function(evt) {
							console.log(xhr)
							if(xhr.readyState == 4 && xhr.status == 200) {
								console.log(xhr.responseText);
								var data = JSON.parse(evt.target.responseText);
								if(sessionStorage.getItem("cunnews") == 1) {
									_self.$data.imgs = _self.$data.imgs.concat(forimg)
									if(data.result.success.indexOf(",") == -1) {
										imgid.push(data.result.success)
									} else {
										imgid = imgid.concat(data.result.success.split(","))
									}

									console.log(imgid)
									_self.$data.zrimg = imgid.toString().split(',')
								} else {
									if(data.result.success.indexOf(",") == -1) {
										fujianid.push(data.result.success)
									} else {
										fujianid = fujianid.concat(data.result.success.split(","))
									}

									_self.$data.fujians = _self.$data.fujians.concat(forfile)
									_self.$data.zrfujian = fujianid.toString().split(',')
									console.log(fujianid.toString())
								}

							} else if(xhr.readyState == 4 && xhr.status == 500) {
								msg("上传失败")
							}
						}
						xhr.onerror = function(evt) {
							//请求失败
							var data = JSON.parse(evt.target.responseText);
							console.log("data");
						};
						xhr.send(form);

					}
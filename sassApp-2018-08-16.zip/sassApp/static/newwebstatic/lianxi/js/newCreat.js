var app = new Vue({

	el: '#app',
	data: {
		id: '',
		currRoomImId: paramMap.isRoomImId,
		currRoomClassName: paramMap.currRoomClassName,
		sites: [],
		title: '',
		yewu: '',
		delyewu: '',
		tapyewu: false,
		form: {
			// 日期
			MissionStartDate: "",
		},
		confirm: '',
		postType: '',
		yewuchangge: '', //用于判断业务类别是否增加、删除（1）
		addname: "", //增加的业务类别
		nowCompany: [], //存储所选的公司信息
		nowCompanyroomid: [], //存储选择公司的roomid
		nowCompanyroomimid: [], //存储选择公司的roomimid
		nowroomimid: [],
		nowCompanyid: [], //存储选择公司的companyid
		nowCompanyname: [], //存储选择公司的companyname
		isroomname: isRoomName,
		isroomCreditCode: isRoomCreditCode,
		imgs: [],
		imgurl: [],
		fujians: [],
		backicon: 0,
		nowtime: '',
		shenqing: '',
		zrimg: [],
		zrfujian: [],
		attachmentIds: "",
		beizhu: '',
		beizhuzhuan: '',
		//地址拦信息
		pa_cigid: paramMap.cfgid,
		pa_projectsn: paramMap.projectSn,
		pa_isroomid: paramMap.isRoomId,
		pa_isroomname: paramMap.isRoomName,
		pa_projectName: paramMap.projectName,
		pa_isRoomCreditCode: isRoomCreditCode,
		pa_isroomid: paramMap.isRoomId,
		tuistatus: '',
		tijao: "",
		baocun: '',
		first: '',
        postStatus:true,
		imgsrc: [],
		backbtn: 1
	},
	created: function() {
		//					this.informations()
		//					mui.init();
		this.getTime()
		if(paramMap.id != undefined) {
			this.informations()
		} else {
			this.getnews()
		}

	},
	mounted: function() {
		mui.init();
		mui('.mui-scroll-wrapper').scroll({
			deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
		});
		document.getElementById("backdrop").addEventListener('tap', function() {
			//阻止默认事件
			event.detail.gesture.preventDefault();
			// 移除手势滑动
			//												mui('.mui-off-canvas-wrap').offCanvas().close()
		});
		//主界面容器
		document.getElementsByClassName('mui-inner-wrap')[0].addEventListener('drag', function(event) {
			event.stopPropagation();
		});
	},
	methods: {

		//获取初始数据
		informations: function() {
			var _self = this
			var param = {
				id: paramMap.id,
			}
			axios.post(getUrl() + "/contract/get_content", param).then(function(response) {
				if(response.data.code == 200) {
					var norl = JSON.parse(response.data.result.noralJson)
					var cont = JSON.parse(response.data.result.contentJson)
					var data = response.data.result
					console.log(response.data)
					_self.$data.title = norl.tablefields.name
					_self.$data.yewu = norl.tablefields.type
					_self.form.MissionStartDate = formDate(norl.tablefields.dateFasheng)
					norl.tablefields.beizhu = norl.tablefields.beizhu.replace(/#.%#/g, "\n");
					_self.$data.beizhu = norl.tablefields.beizhu
					_self.$data.isroomname = norl.curRoomName
					_self.$data.currRoomImId = norl.currRoomImId
					_self.$data.isRoomCreditCode = norl.tablefields.companySaleID
					app.getnews()
					console.log("123", norl.gongsialllei)
					//接收单位数据
					_self.$data.nowCompany = norl.gongsialllei
					_self.$data.nowCompanyroomid.push(norl.roomid)
					_self.$data.nowCompanyroomid = norl.tablefields.companyBuyRoomID.split(",")
					_self.$data.nowCompanyroomimid = norl.toImid.split(",")
					//图片附件
					_self.$data.imgs = norl.imgs
					_self.$data.fujians = norl.fujians
					if(norl.imgid.toString()) {
						imgid = norl.imgid.toString().split(",")
						_self.$data.zrimg = norl.imgid.toString().split(",")
					}

					if(norl.fjid.toString()) {
						_self.$data.zrfujian = norl.fjid.toString().split(",")
						fujianid = norl.fjid.toString().split(",")
					}

					//提交信息
					_self.$data.id = paramMap.id
					_self.$data.pa_cigid = norl.table.id
					_self.$data.pa_projectsn = data.projectId
					_self.$data.pa_isroomid = data.roomId
					_self.$data.pa_isroomname = data.roomName
					_self.$data.pa_isRoomCreditCode = norl.tablefields.companySaleID
					_self.$data.pa_projectName = norl.tablefields.projectName
					_self.$data.currRoomImId = norl.currRoomImId
					_self.$data.currRoomClassName = norl.curRoomName
					_self.$data.attachmentIds = norl.attachment
					_self.$data.confirm = response.data.result.confirm;
					if(norl.tablefields.companyBuyName.split(",")[1] != undefined) {
						_self.$data.nowCompanyname = norl.tablefields.companyBuyName.split(',')
						_self.$data.nowCompanyid = norl.tablefields.companyBuyID.split(',')
					} else {
						_self.$data.nowCompanyname.push(norl.tablefields.companyBuyName)
						_self.$data.nowCompanyid.push(norl.tablefields.companyBuyID)
					}

				}
			})
		},

		//获取时间
		getTime: function() {
			var _self = this
			var getTime = new Date()
			var nowTime = getTime.toLocaleDateString()
			//						alert("fuckISO时间"+nowTime)
			/**
			 * ios9以下版本获取到的是yyyy年MM月dd日
			 */
			var year = "";
			var mouth = "";
			var day = "";
			if(nowTime.indexOf("年") > 0) {
				year = nowTime.substring(0, nowTime.indexOf("年"));
				mouth = nowTime.substring(nowTime.indexOf("年") + 1, nowTime.indexOf("月"));
				day = nowTime.substring(nowTime.indexOf("月") + 1, nowTime.indexOf("日"));
			} else if(nowTime.indexOf("-") > 0) {
				year = nowTime.split("-")[0]
				mouth = nowTime.split("-")[1]
				day = nowTime.split("-")[2]
			} else {
				year = nowTime.split("/")[0]
				mouth = nowTime.split("/")[1]
				day = nowTime.split("/")[2]
			}
			var nowshi = getTime.getHours()
			var noefen = getTime.getMinutes()
			var nowmiao = getTime.getSeconds()
			if(nowshi < 10) {
				nowshi = "0" + nowshi
			}
			if(noefen < 10) {
				noefen = "0" + noefen
			}
			if(nowmiao < 10) {
				nowmiao = "0" + nowmiao
			}
			if(mouth < 10) {
				mouth = "0" + mouth
			}
			if(day < 10) {
				day = "0" + day
			}
			_self.$data.shenqing = year + "-" + mouth + "-" + day
			_self.$data.nowtime = nowshi + ":" + noefen + ":" + nowmiao
			_self.form.MissionStartDate = formDate(year + "-" + mouth + "-" + day);
		},
		//时间选择
		selectDate: function(t) {
			var o = this;
			// hx
			if(t == "s") {
				if(o.form.MissionStartDate != "") {
					opt.value = o.form.MissionStartDate;
				}
			} else if(t === 'e') {
				if(o.form.MissionEndDate != "") {
					opt.value = o.form.MissionEndDate;
				}
			} else if(t === 'd') {
				if(o.form.datejiexiang != "") {
					opt.value = o.form.datejiexiang;
				}
			}
			var picker = new mui.DtPicker(opt);
			picker.show(function(rs) {
				/*
				 * rs.value 拼合后的 value
				 * rs.text 拼合后的 text
				 * rs.y 年，可以通过 rs.y.vaue 和 rs.y.text 获取值和文本
				 * rs.m 月，用法同年
				 * rs.d 日，用法同年
				 * rs.h 时，用法同年
				 * rs.i 分（minutes 的第二个字母），用法同年
				 */
				opt["value"] = rs.value; //控件同步
				if(t == "s") {
					o.form.MissionStartDate = rs.value;
				} else if(t === 'e') {
					o.form.MissionEndDate = rs.value;
				} else if(t === 'd') {
					o.form.datejiexiang = rs.value;
				}
				picker.dispose(); //释放资源
			})
		},

		//弹出业务列表
		selectyewu: function() {
			mui('.mui-off-canvas-wrap').offCanvas().show()
		},
		//关闭业务列表
		deleyewu: function() {
			mui('.mui-off-canvas-wrap').offCanvas().close()
		},

		//获取业务类别
		getnews: function() {
			var _self = this
			console.log(getUrl() + "/chart/column/table_w_danjutypecfg?used=getName&type=1&companyName=" + _self.$data.isroomname + "&companyId=" + _self.$data.isroomCreditCode)
			axios.post(getUrl() + "/chart/column/table_w_danjutypecfg?used=getName&type=1&companyName=" + _self.$data.isroomname + "&companyId=" + _self.$data.isroomCreditCode).then(function(response) {
				if(response.data.code == 200) {
					//								console.log(response)
					_self.$data.sites = response.data.result;

				} else {
					ludan("获取业务类别失败", 1, 1)
				}
			})

			//会议纪要
			var  type =  paramMap.type;
			if(type&&type==3){
                //将类别默认设置成会议纪要
				_self.$data.yewu = "会议纪要";
				//将选择类别禁止
				this.selectyewu=function(){
				}
				//获取所有的类别

				var roomClassList;
                axios.post(getUrl() + "/pcontact_api/findroomclass?type=1").then(function(response) {
                	if(response.data.code==0){
                    	roomClassList = response.data.result;
                    }
                    //防止roomClassList为空后，不执行后面的JS
					if(roomClassList) {
                        //获取参与的类别
                        axios.post(getUrl() + "/pcontact_api/findMeetingCompanyInfoByMainId?mId=" + paramMap.currRoomId).then(function (response) {
                            if (response.data.code == 0) {
                                console.log(response)
                                var result = response.data.result;
                                _self.$data.nowCompany = [];
                                _self.$data.nowCompanyroomid = [];
                                _self.$data.nowCompanyroomimid = [];
                                _self.$data.nowCompanyname = [];
                                _self.$data.nowCompanyid = [];
                                console.log(result)
                                for (var i = 0; i < result.length; i++) {
                                    if (result[i].roomId != paramMap.isRoomId) {
                                        //根据roomclass 获取到roomclassName
                                        var roomClassName;
                                        for (var j = 0; j < roomClassList.length; j++) {
                                            if (roomClassList[j].roomClass == result[i].roomClass) {
                                                roomClassName = roomClassList[j].roomClassName;
                                            }
                                        }
                                        _self.$data.nowCompany.push({
                                            "roomclass": roomClassName,
                                            "name": result[i].name
                                        })
                                        _self.$data.nowCompanyroomimid.push(result[i].roomImId)
                                        _self.$data.nowCompanyroomid.push(result[i].roomId)
                                        if (result.companyId == '') {
                                            _self.$data.nowCompanyid.push(result[i].name)
                                        } else {
                                            _self.$data.nowCompanyid.push(result[i].companyId)
                                        }

                                        _self.$data.nowCompanyname.push(result[i].name)
                                    }
                                }
                                console.log(_self.$data.nowCompany)
                            } else {

                            }
                        })
                    }

				});


			}


		},
		//编辑业务
		makeyewu: function(n) {
			var _self = this
			if(_self.$data.tapyewu) {
				app.sendyewu()
			}
			_self.$data.tapyewu = !_self.$data.tapyewu
		},
		//选择业务类别
		yewulist: function(event) {
			var _self = this
			//						_self.$data.checktitle = false
			_self.$data.yewu = event.target.innerHTML
			app.deleyewu()
		},
		//增加业务类别
		addlianxi: function() {
			var _self = this
			_self.$data.yewuchangge = 1
			if(_self.$data.addname != '') {
				_self.$data.sites.unshift({
					"name": _self.$data.addname
				})
			}
			_self.$data.addname = ''
		},
		//删除对应业务类别
		delateyewu: function(n) {
			var _self = this
			_self.$data.yewuchangge = 1
			if(_self.$data.sites.length > 1) {
				_self.$data.sites.splice(n, 1)
			}
			if(_self.$data.sites.length == 1) {
				_self.$data.delyewu = 1
			}
		},
		//点击遮罩
		mask: function() {
			app.deleyewu()
		},
		//点击第一步
		step1: function(n) {
			var _self = this
			_self.backbtn = 2
			if(_self.$data.title == '') {
				ludan("请输入标题", 1, 1)
			} else if(_self.$data.yewu == '') {
				ludan("请选择类别", 1, 1)
			} else {
				appApi.hideBack()
				//							_self.$data.beizhuzhuan = _self.$data.beizhu.replace(/<\/?.+?>/g, "#.%#");

                if(_self.$data.beizhu&&_self.$data.beizhu!=''&&_self.$data.beizhu.length>0) {
                    _self.$data.beizhuzhuan = _self.$data.beizhu.replace(/[\r\n]/g, "#.%#");
                }
				_self.$data.backicon = n
				app.sendyewu()
			}
			//						app.sendyewu()

		},
		//点击第二步
		step2: function(n) {
			var _self = this
			appApi.hideBack()
//			if(_self.$data.nowCompany.length == 0) {
//				ludan("请选择接收单位", 1, 1)
//			} else {
//				_self.$data.backicon = n
//			}
			 _self.$data.backicon = n
		},
		//点击返回按钮
		back: function() {
			var _self = this
			if(_self.$data.backicon == 1) {
				setTimeout(function() {
					appApi.showBack()
				}, 100)

				_self.backbtn = 1
			}
			if(_self.$data.backicon > 0) {
				_self.$data.backicon = _self.$data.backicon - 1
			}

		},
		//提交更改的业务类别信息
		sendyewu: function() {
			var _self = this
			var yewuname = []
			for(i in _self.$data.sites) {
				yewuname.push(_self.$data.sites[i].name)
			}
			//						var param = {
			//							"type": "1",
			//							"companyName": _self.$data.isroomname,
			//							"companyID": _self.$data.isroomCreditCode,
			//							"names": yewuname.toString(),
			//						}
			var params = new FormData();
			params.append("type", "1");
			params.append("companyName", _self.$data.isroomname);
			params.append("companyID", _self.$data.isroomCreditCode);
			params.append("names", yewuname.toString());
			var urlcan = "type=1&companyName=" + _self.$data.isroomname + "&companyID=" + _self.$data.isroomCreditCode + "&names=" + yewuname.toString()
			console.log(getUrl() + "/chart/column/insert_w_danjutypecfg?" + urlcan)
			axios.post(getUrl() + "/chart/column/insert_w_danjutypecfg", params).then(function(response) {
				if(response.data.code == 0) {
					console.log(response)
				}
			}).catch(function(error) {
				ludan(error, 1, 3);
			})
		},
		//从原生获取接收单位信息
		selectCompany: function(CONTENT) {
			var _self = this
			//						var newcompany = []
			//						var companyroomimid = []
			//						var companyroomid = []
			//						var companyid = []
			//						var companyname = []
			_self.$data.nowCompany = [];
			_self.$data.nowCompanyroomid = [];
			_self.$data.nowCompanyroomimid = [];
			_self.$data.nowCompanyname = [];
			_self.$data.nowCompanyid = [];

			for(var i = 0; i < JSON.parse(CONTENT.result).length; i++) {
				_self.$data.nowCompany.push({
					"roomclass": JSON.parse(CONTENT.result)[i].roomClassName,
					"name": JSON.parse(CONTENT.result)[i].roomName
				})
				_self.$data.nowCompanyroomimid.push(JSON.parse(CONTENT.result)[i].roomImId)
				_self.$data.nowCompanyroomid.push(JSON.parse(CONTENT.result)[i].roomId)
				if(JSON.parse(CONTENT.result)[i].companyId == '') {
					_self.$data.nowCompanyid.push(JSON.parse(CONTENT.result)[i].roomName)
				} else {
					_self.$data.nowCompanyid.push(JSON.parse(CONTENT.result)[i].companyId)
				}

				_self.$data.nowCompanyname.push(JSON.parse(CONTENT.result)[i].roomName)
			}
		},
		//选接收单位
		xuangongsi: function() { //xiaoshou
			var _self = this
			window.appApi.openProjectContactSelectPage(_self.$data.pa_projectsn, '', _self.$data.nowCompanyroomid.toString(), 3, true, false, false)
		},
		//删除接收单位
		delcompany: function(index) {
			var _self = this
			_self.$data.nowCompany.splice(index, 1) //删除对应的名字
			_self.$data.nowCompanyroomid.splice(index, 1) //删除对应的 roomid
			_self.$data.nowCompanyroomimid.splice(index, 1) //删除对应的 roomimid
		},
		//上传文件
		upfile: function(event) {

			this.hideDiv();

			loading("上传中")
			sessionStorage.removeItem("cunnews")
			var _self = this
			var file = document.getElementById(event.target.id).files;
			var zrid = document.getElementById(event.target.id).getAttribute("id")
			var url = getUrl() + "/sass_api/upload_file";
			var form = new FormData();
			var forimg = []
			var forfile = []
			var imgName = [];
			for(var i = 0; i < file.length; i++) {
				form.append("file", file[i]);
				//读取图片数据
				var f = document.getElementById(event.target.id).files[i];
				var imgtype = f.type.split('/')[0]
				if(zrid == "file") {
					imgName.push(file[i].name);
					var reader = new FileReader();
					reader.onload = function(e) {
						var data = e.target.result;
						//加载图片获取图片真实宽度和高度
						var image = new Image();
						image.onload = function() {
							width = image.width;
							height = image.height;

						};

						image.src = data;
						forimg.push({
							src: image.src
						})
					};
					sessionStorage.setItem("cunnews", "1")
					reader.readAsDataURL(f);
				} else if(zrid == "files") {
					sessionStorage.setItem("cunnews", "2")
					var na = file[i].name
					forfile.push({
						name: f.name
					})
					console.log(_self.$data.fujians)
				}

			}
			_self.$data.imgsrc = forimg
			if(sessionStorage.getItem("cunnews") == 1) {
				form.append("type", "1");
			} else {
				form.append("type", "2");
			}
			form.append("module", "contractnote");
			form.append("userid", userid);
			xhr = new XMLHttpRequest();
			xhr.open("post", url, true);
			xhr.onload = function(evt) {
				//请求完成
				layer.close(loading("上传中"))
			};
			xhr.onreadystatechange = function(evt) {
				if(xhr.readyState == 4 && xhr.status == 200) {
					console.log(xhr.responseText);
					var data = JSON.parse(evt.target.responseText);
					// var imgs = data.result.success;
					// if(sessionStorage.getItem("cunnews") == 1) {
					// 	_self.$data.imgs = _self.$data.imgs.concat(forimg)
					// 	if(data.result.success.indexOf(",") == -1) {
					// 		imgid.push(data.result.success)
					// 	} else {
					// 		imgid = imgid.concat(data.result.success.split(","))
					// 	}
					//
					// 	//										imgid.push(data.result.success)
					// 	console.log(imgid)
					// 	_self.$data.zrimg = imgid.toString().split(',')
					// } else {
					// 	if(data.result.success.indexOf(",") == -1) {
					// 		fujianid.push(data.result.success)
					// 	} else {
					// 		fujianid = fujianid.concat(data.result.success.split(","))
					// 	}
					//
					// 	//										fujianid.push(data.result.success)
					// 	_self.$data.fujians = _self.$data.fujians.concat(forfile)
					// 	_self.$data.zrfujian = fujianid.toString().split(',')
					// 	console.log(fujianid.toString())
					// }
					var rtnfiles = data.result.success;
					if(sessionStorage.getItem("cunnews") == 1) {
						_self.$data.imgs = _self.$data.imgs.concat(rtnfiles)
						for(var i = 0; i < rtnfiles.length; i++) {
							imgid.push(rtnfiles[i].fileId);
						}
						console.log(imgid)
						if(imgid.toString()) {
							_self.$data.zrimg = imgid.toString().split(',')
						}
					} else {
						for(var i = 0; i < rtnfiles.length; i++) {
							fujianid.push(rtnfiles[i].fileId);
						}
						_self.$data.fujians = _self.$data.fujians.concat(forfile)
						if(fujianid.toString()) {
							_self.$data.zrfujian = fujianid.toString().split(',')
							console.log(fujianid.toString())
						}

					}
					ludan("上传成功", 1, 1)
				} else if(xhr.readyState == 4 && xhr.status == 500) {
					ludan("上传失败", 1, 1)
				}
			}
			xhr.onerror = function(evt) {
				//请求失败
				var data = JSON.parse(evt.target.responseText);
				ludan("请求失败", 1, 1)
				console.log("data");
			};
			xhr.send(form);

		},
		//删除图片
		moveimg: function(n) {
			var _self = this;
			axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + imgid[n - 1]).then(function(response) {
				if(response.data.code == 0) {
					console.log(response.data)
					ludan("删除成功", 1, 2)
					document.getElementById("file").value = ""; //清除input内容，防止出现不能重复上传的问题
				}
			}).catch(function(error) {
				ludan(error, 1, 3);
			})
			imgid.splice(n - 1, 1)
			_self.$data.imgs.splice(n - 1, 1)
			_self.$data.zrimg.splice(n - 1, 1)
		},
		//删除附件
		movefj: function(n) {
			var _self = this;
			axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + fujianid[n - 1]).then(function(response) {
				if(response.data.code == 0) {
					console.log(response.data)
					ludan("删除成功", 1, 2)
					document.getElementById("files").value = ""; //清除input内容，防止出现不能重复上传的问题
				}
			}).catch(function(error) {
				ludan(error, 1, 3);
			})
			fujianid.splice(n - 1, 1)
			_self.$data.fujians.splice(n - 1, 1)
			//						console.log(n-1)
			_self.$data.zrfujian.splice(n - 1, 1)
			console.log(_self.$data.zrfujian)
			console.log(typeof JSON.stringify(_self.$data.zrfujian))
		},
		save: function() {
			var _self = this
			btnStop()
			var target = event.currentTarget
			_self.$data.tijao = 1
			app.getimgurl(0, target)

		},
		sends: function() {
			var _self = this
            var selectCompany=_self.$data.nowCompany.length;
            if(selectCompany==0){
//					closeLoading();
                ludan("请先选择接收单位再进行提交", 2, 2);
                return
            }
            if(_self.$data.postStatus){
                _self.$data.postStatus = false;
			btnStop()
			var target = event.currentTarget
			//						if(_self.$data.baocun!=1){
			_self.$data.baocun = 1
			app.getimgurl(1, target)
            }
			//						}else{
			//							ludan("已提交",2,1)
			//						}
		},
		//获取上传图片的url
		getimgurl: function(n, target) {
			var _self = this;
			_self.$data.imgurl = []
			console.log(_self.$data.zrimg)
			if(_self.$data.zrimg != '') {
				axios.post(getUrl() + "/sass_api/get_uploadfile_info?fileIdStr=" + _self.$data.zrimg).then(function(response) {
					if(response.data.code == 200) {
						console.log(response.data.result)
						if(_self.$data.tijao == 1 && _self.$data.baocun != 1) { //保存不提交
							for(var i = 0; i < response.data.result.length; i++) {
								_self.$data.imgurl.push({
									src: response.data.result[i].thumbnailurl
								})

							}
							app.savenews(n, target)
						} else if(_self.$data.tijao != 1 && _self.$data.baocun == 1) { //直接提交
							for(var i = 0; i < response.data.result.length; i++) {
								_self.$data.imgurl.push({
									src: response.data.result[i].thumbnailurl
								})

							}
							app.savenews(n, target)
						} else if(_self.$data.tijao == 1 && _self.$data.baocun == 1) { //保存 再提交
							for(var i = 0; i < response.data.result.length; i++) {
								_self.$data.imgurl.push({
									src: response.data.result[i].longurl
								})

							}
							//										app.sendtodo()
							app.savenews(n, target)
						}

					}
				})
			} else {
				if(_self.$data.tijao == 1 && _self.$data.baocun != 1) { //保存不提交
					//								_self.$data.imgurl.push({
					//									src: response.data.result[i].longurl
					//								})
					//									for(var i = 0; i < response.data.result.length; i++) {
					//										_self.$data.imgurl.push({
					//											src: response.data.result[i].longurl
					//										})
					//
					//									}
					app.savenews(n, target)
				} else if(_self.$data.tijao != 1 && _self.$data.baocun == 1) { //直接提交
					//								_self.$data.imgurl.push({
					//									src: response.data.result[i].longurl
					//								})
					//									for(var i = 0; i < response.data.result.length; i++) {
					//										_self.$data.imgurl.push({
					//											src: response.data.result[i].longurl
					//										})
					//
					//									}
					app.savenews(n, target)
				} else if(_self.$data.tijao == 1 && _self.$data.baocun == 1) { //保存 再提交
					//								_self.$data.imgurl.push({
					//									src: response.data.result[i].longurl
					//								})
					app.savenews(n, target)
					//								app.sendtodo()
				}
			}
		},
		savenews: function(n, target) {
		var _self = this;
		var saveType='update';//
			if(n == 1) {
					ludan("提交中", 0, 1)
				saveType='update';//提交
			} else {
				saveType='save';//保存
				ludan("保存中", 0, 1)
			}
			//获取数据
			
			console.log(_self.$data.pa_cigid)
			var fjid
			if(_self.$data.attachmentIds == '') {
				_self.$data.attachmentIds = ''
			} else {
				_self.$data.attachmentIds = "," + _self.$data.attachmentIds
			}
			console.log("图片11", imgid);
			if(imgid.toString() == '') {
				fjid = fujianid.toString()
			} else if(fujianid.toString() == '') {
				fjid = imgid.toString()
			} else {
				fjid = imgid.toString() + "," + fujianid.toString()
			}
			//						imgid = _self.$data.zrimg.length + _self.$data.zrfujian.length
			//						if(_self.$data.tuistatus == 1) {
			//
			//							_self.$data.pa_cigid = _self.$data.tuicfgid
			//							_self.$data.pa_projectsn = _self.$data.tuiprojectSn
			//							_self.$data.pa_isroomid = _self.$data.tuiroomid
			//							_self.$data.pa_isroomname = _self.$data.tuiroomname
			//							_self.$data.pa_isRoomCreditCode = _self.$data.tuicompanySaleID
			//							_self.$data.pa_projectName = _self.$data.tuiprojectName
			//							_self.$data.currRoomImId = _self.$data.tuicurrRoomImId
			//							_self.$data.currRoomClassName = _self.$data.tuicurRoomName
			//						}
			//						if(_self.$data.chenk2 != 1) {
			//							_self.$data.tuiroomimid = _self.$data.starroomimid
			//						}
			//						alert(_self.$data.boforeroomImId)
			if(n == 0) {
				//使用单据状态判断，无法满足需求。2018-5-21新增字段postType(提交保存状态)0=保存 1=提交
				_self.$data.confirm = '0';
			} else {
				_self.$data.confirm = '1';
				_self.$data.postType = '1';
			}
			var tablefields = {
				userName: decodeURI(username),
				userID: userid,
				dateShenqing: _self.$data.shenqing + " " + _self.$data.nowtime,
				projectName: _self.$data.pa_projectName,
				projectSN: _self.$data.pa_projectsn,
				companySaleName: _self.$data.pa_isroomname,
				companySaleID: _self.$data.pa_isRoomCreditCode,
				companySaleRoomID: _self.$data.pa_isroomid,
				companyBuyName: _self.$data.nowCompanyname.toString(),
				companyBuyID: _self.$data.nowCompanyid.toString(),
				companyBuyRoomID: _self.$data.nowCompanyroomid.toString(),
				name: _self.$data.title,
				type: _self.$data.yewu,
				dateFasheng: _self.$data.form.MissionStartDate + " " + _self.$data.nowtime,
				beizhu: _self.$data.beizhuzhuan,
				confirmStatus: "", //确认状态

				confirmPersonName: "",
				confirmPersonID: "",
			}
			if(_self.$data.id != '') {
				tablefields["id"] = _self.$data.id
			}
			//						alert(5)
			//						alert(JSON.stringify(tablefields))
			/*if(n==0){
			    _self.$data.confirm = '2';
			}else{
			    _self.$data.confirm = '0';
			}*/
			var param = {
				table: {
					id: _self.$data.pa_cigid,
					projectid: _self.$data.pa_projectsn,
					roomid: _self.$data.pa_isroomid,
					roomname: _self.$data.pa_isroomname,
					userId: userid,
					//								uid:'10395'
				},
				confirm: _self.$data.confirm,
				postType: _self.$data.postType,
				attachment: fjid + _self.$data.attachmentIds,
				toroomimid: _self.$data.nowCompanyroomimid.toString(),
				gongsialllei: _self.$data.nowCompany,
				currRoomImId: _self.$data.currRoomImId,
				curRoomName: _self.$data.currRoomClassName,
				roomid: _self.$data.pa_isroomid,
				toImid: _self.$data.nowCompanyroomimid.toString(),
				imgs: _self.$data.imgurl,
				imgid: _self.$data.zrimg,
				fujians: _self.$data.fujians,
				fjid: _self.$data.zrfujian,
				//				uid: "10395",
				tablefields: tablefields,
				subtablefields: [],
				createRoomId: paramMap.currRoomId,
				typeName: "收发件",
				title: _self.$data.title,
				saveType:saveType,//提交类型，区分是保存还是提交
			}
			//alert(JSON.stringify(param))
			//保存一次或给attachmentIds清空，防止再次点击重复
			_self.$data.attachmentIds = ''
			
			console.log(param)
			// alert(JSON.stringify(param))
			// return
			axios.post(getUrl() + "/contract/save", param).then(function(response) {
				if(response.data.code == 200) {
					_self.$data.first = 1
					_self.$data.id = response.data.result.id
					var succname = []
					var faliename = []
					if(n == 1) {
						app.sendtodo(target)
					} else {
						//                      layer.close(ludan("保存中",0,1))
						closeLoading()
						ludan("保存成功", 2, 2, function() {
							btnstart(target)
						})
					}
					//								if(n == 1) {
					//									var todojson = {
					//										"title": decodeURI(username) + "的收发件：" + _self.$data.title,
					//										"titileTwo": _self.$data.currRoomClassName + "-" + _self.$data.pa_isroomname,
					//										"content": "类别=" + _self.$data.yewu + "|日期=" + _self.$data.form.MissionStartDate,
					//										"fileCount": "0",
					//										"url": getUrl() + '/static/newwebstatic/lianxi/transfer.html?id=' + _self.$data.id,
					//										"colorString": "",
					//										"todoViewableMember": "0",
					//										"toImId": _self.$data.nowCompanyroomimid.toString(),
					//										"formuserid": userid,
					//										"currentRoomImid": paramMap.currRoomImId,
					//										"chatType": "2",
					//										"relation": response.data.result.id,
					//										"score": "", //评分待办必要参数，设置分数
					//										"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
					//										"setButton": [{
					//											"type": 1, //按钮点击类型 1=请求url 2=打开url
					//											"name": "确认",
					//											"url": getUrl() + "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&roomId=" + paramMap.roomId + "&roomName=" + paramMap.roomName + "&projectSn=" + paramMap.projectSn + "&userid=" + userid,
					//										}, {
					//											"type": 1, //按钮点击类型 1=请求url 2=打开url
					//											"name": "退回",
					//											"url": getUrl() + "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id,
					//										}]
					//
					//									}
					//									window.appApi.sendTodo(todojson, function(d) {
					//										if(d.code == 200) {
					//											ludan("提交成功", 2, 2, function() {
					//												window.appApi.closeNewWindow()
					//											})
					//										}
					//
					//									})
					//								} else {
					//									ludan("保存成功", 2, 2)
					//								}
				} else {
					closeLoading()
					ludan("保存失败", 2, 1, function() {
						btnstart(target)
					})
				}
			}).catch(function(error) {
				closeLoading()
				ludan(error, 2, 1, function() {
					btnstart(target)
				});
			})
		},
		fjFileType: function() {
			$(".mui-backdrop").show();
			$(".pop-up").show();
		},
		showCloudFile: function() {
			//打开项目列表
			appApi.openNewWindow(getUrl() + "/static/newwebstatic/file_gui/project_list.html?entrance=bill&projectSN=" + paramMap.projectSn);

		},
		sendtodo: function(target) {
			var _self = this
			//type==3的时候，则是会议纪要类型，则需要获取当前房间的信息，拼接到消息发送信息中。
            var  type =  paramMap.type;
            if(type&&type==3){
                _self.$data.nowCompanyroomimid = _self.$data.nowCompanyroomimid +","+paramMap.currRoomImId;
			}
			var titletype = encodeURIComponent(encodeURIComponent("收发件"));
			var title = encodeURIComponent(encodeURIComponent(_self.$data.title));
			var todojson = {
				"title": decodeURI(username) + "的收发件：" + _self.$data.title,
				"titileTwo": _self.$data.currRoomClassName + "-" + _self.$data.pa_isroomname,
				"content": "类别=" + _self.$data.yewu + "|日期=" + _self.$data.form.MissionStartDate,
				"fileCount": "0",
				"url": '/static/newwebstatic/lianxi/transfer.html?id=' + _self.$data.id,
				"colorString": "",
				"todoViewableMember": "0",
				"toImId": _self.$data.nowCompanyroomimid.toString(),
				"formuserid": userid,
				"currentRoomImid": _self.$data.currRoomImId,
				"chatType": "2",
				"relation": _self.$data.id,
				"score": "", //评分待办必要参数，设置分数
				"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
				"setButton": [{
					"type": 1, //按钮点击类型 1=请求url 2=打开url
					"name": "确认",
					"url": "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&projectSn=" + _self.$data.pa_projectsn + "&sendtype=1" + "&titletype=" + titletype,
				}, {
					"type": 1, //按钮点击类型 1=请求url 2=打开url
					"name": "退回",
					"url": "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id + "&projectSn=" + _self.$data.pa_projectsn + "&title=" + title + "&titletype=" + titletype + "&sendtype=1",
				}]

			}
			var parame = new FormData();
			parame.append("url", '/static/newwebstatic/lianxi/transfer.html?id=' + _self.$data.id)
			parame.append("userId", getCookie("userid"))
			axios.post(getUrl() + "/sass_api/update_withdraw_todo", parame).then(function(response) {

			});

			window.appApi.sendTodo(todojson)
			closeLoading()
			// btnstart(target)
		},
		hideDiv: function() {
			$(".mui-backdrop").hide();
			$(".pop-up").hide();
		},
		changeImgIds: function(dishImgIds) { //得到广播回来的ID

			var _self = this;
			var forfile = []
			this.hideDiv();

			var parm = {
				dishIds: dishImgIds,
			}
			axios.post(getUrl() + "/contract/copydishinfo", parm).then(function(response) {
				var rtnfiles = response.data.result.success;
				for(var i = 0; i < rtnfiles.length; i++) {
					fujianid.push(rtnfiles[i].fileId);
					forfile.push({
						name: rtnfiles[i].fileName,
						fileId: rtnfiles[i].fileId
					})
				}
				_self.$data.fujians = _self.$data.fujians.concat(forfile)
				if(fujianid.toString()) {
					_self.$data.zrfujian = fujianid.toString().split(',')
				}
			})
		}
		//					send: function() {
		//
		//					},
	}

})
var app = new Vue({
    el: '#app',
    //数据定义区
    data: {
        rooms: [],
        imgs: [],
        imgSrcs: [],
        pics: [],
        picNames: [],
        imgs: [],
        fujians: [],
        zrimg: [],
        zrfujian: [],
        content: "",
        type: "1",
        typeName: "本群公告",
        beforeroomid: []
    },
    created: function () {
        this.type = gonggaoType
        if (gonggaoType == 1) {
            this.typeName = "本群公告";
        } else {
            this.typeName = "项目公告";
            setTimeout(function () {
                $(".project").click();
            }, 100)
        }

    },
    //过滤器定义区
    filters: {
        //获取单位第一个字
        getRoomClassNameHeader: function (value) {
            return value.substring(0, 1);
        }
    },
    //定义方法区
    methods: {
        //删除选择的房间
        deleteRoom: function (index, roomId) {
            var _self = this;
//						alert(JSON.stringify(_self.beforeroomid))s
            for (var i = 0; i < _self.$data.beforeroomid.length; i++) {
                if (_self.beforeroomid[i] == roomId) {
                    _self.$data.beforeroomid.splice(i, 1)
                }
            }
            _self.$data.rooms.splice(index, 1)

        },
        //选择房间
        selctdRooms: function (content) {
            var _self = this;
            var roomid
            _self.beforeroomid = []
            _self.$data.rooms = JSON.parse(content.result)
            _self.$data.rooms.forEach(function (v) {
                //									roomid.push(v.roomId)
                _self.beforeroomid.push(v.roomId)

            })
            console.log(content)
        },
        //点击遮罩层
        mask: function () {
            $(".mui-backdrop").css("display", "none")
            $(".mui-backdrop").animate({
                left: "0%"
            })
            $("#noticeType").hide();
        },
        //打开选择房间页面
        showSelectdRoom: function () {
            var _self = this
            window.appApi.openProjectContactSelectPage(param_map.projectSn, '', _self.beforeroomid.toString(), 3, true, false, false)
        },
        //展现公告类型
        showType: function () {
            if (param_map.loginType == 1) { //权限控制  管理员才能选择
                $(".mui-backdrop").show();
                $("#noticeType").show();
            }
        },
        //选择公告类型
        selectdType: function (type) {
            console.log(type);
            var _self = this;
            if (type == 1) {
                _self.$data.typeName = "本群公告"
                $("#selectdRoom").slideUp("slow")
            } else {
                $("#selectdRoom").slideDown("slow")
                _self.$data.typeName = "项目公告"
            }
            _self.$data.type = type;
            _self.mask();
        },
        //发布公告
        submitData: function () {
            var _self = this;
            if (_self.$data.content == "") {
                alert("请填写公告内容！");
                return false;
            }
            var fileall = _self.$data.imgs.concat(_self.$data.pics)

            var fileId = [];

            console.log(fileall)
            if (fileall.length > 0) {
                for (var i = 0; i < fileall.length; i++) {
                    fileId.push(fileall[i].fileId);
                }
            }
            console.log("<><><><>><><>", fileId)
            var fjid
            if (_self.$data.zrimg.toString() == '') {
                fjid = _self.$data.zrfujian.toString()
            } else if (_self.$data.zrfujian.toString() == '') {
                fjid = _self.$data.zrimg.toString()
            } else {
                fjid = _self.$data.zrimg.toString() + "," + _self.$data.zrfujian.toString()
            }
            var param = {
                //								attachmen : _self.$data.imgs.toString()+"|"+_self.$data.pics.toString(), //合并图片和附件数组
                attachmen: fjid,
                isRoomId: param_map.isRoomId,
                toImIds: [],
                content: _self.$data.content,
                type: _self.$data.type,
                userIcon: user_icon,
                userId: user_id,
                userName: user_name,
                roomIds: [],
                projectSn: param_map.projectSn,
                projectName: param_map.projectName,
            }
            //获取消息接收方
            var toomid = []
            var roomid = []
            if (_self.$data.type == 1) {
                //								param.toImIds.push(param_map.currRoomImId)
                //								param.roomIds.push(param_map.isRoomId)
                param.toImIds = param_map.currRoomImId
                param.roomIds = param_map.isRoomId
            } else {
                _self.$data.rooms.forEach(function (v) {
                    toomid.push(v.roomImId)
                    roomid.push(v.roomId)
                })
                param.toImIds = toomid.toString()
                param.roomIds = roomid.toString()
                if (!param.roomIds) {
                    alert("请选择要发布的房间")
                    return;
                }
            }
            //alert(param.roomIds)
            console.log(param)
            // return
            axios
                .post(getUrl() + "/notice_api/save_notice", param)
                .then(
                    function (response) {
                        console.log(response)
                        if (response.data.code == 200) {
                            console.log(response)
                            var content = _self.$data.content.substring(0, 20);
                            var todojson = {
                                "title": decodeURI(user_name) + "发布的公告",
                                "titileTwo": param_map.currRoomClassName + "-" + param_map.currRoomName,
                                "content": content,
                                "fileCount": "0", //_self.$data.imgs.length+_self.$data.pics.length,
                                "url": getUrl() +
                                '/static/newwebstatic/gonggao/gonggao_detail.html?id=' +
                                response.data.result.id,
                                "colorString": "",
                                "todoViewableMember": "0",
                                "toImId": param.toImIds
                                    .toString(),
                                "formuserid": user_id,
                                "currentRoomImid": param_map.currRoomImId,
                                "chatType": "2",
                                "relation": response.data.result.docId,
                                //"score" : "", //评分待办必要参数，设置分数
                                //"confirmUrl" : "456", //有确认按钮必要参数
                                //"refusedUrl" : "231", //有拒绝按钮必要参数
                                "todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
                                "setButton": [{
                                    "type": 2, //按钮点击类型 1=请求url 2=打开url
                                    "name": "查看",
                                    "url": getUrl() +
                                    '/static/newwebstatic/gonggao/gonggao_detail.html?id=' +
                                    response.data.result.id
                                }]
                            }
                            //alert(JSON.stringify(todojson))
                            window.appApi.sendTodo(todojson)

                        } else {
                            alert("公告发布失败")
                            //							msg("获取云盘目录信息失败")
                        }
                    })
            //alert(JSON.stringify(param))
        },
        fjFileType: function () {
            $(".mui-backdrop").show();
            $(".pop-up").show();
        },
        showCloudFile: function () {
            //打开项目列表
            appApi.openNewWindow(getUrl() + "/static/newwebstatic/file_gui/project_list.html?entrance=bill&projectSN=" + param_map.projectSn,"我的项目");

        },
        //删除文件
        //						deleteFile: function(index, type) {
        //							var _self = this;
        //							alert(0)
        //							if(type == 1) {
        //								_self.$data.picNames.splice(index, 1)
        //								_self.$data.pics.splice(index, 1)
        //							}
        //							if(type == 0) {
        //								_self.$data.imgSrcs.splice(index, 1)
        //								console.log(_self.$data.imgs)
        //								_self.$data.imgs.splice(index, 1)
        //								console.log(_self.$data.imgs)
        //							}
        //							console.log(_self.$data.picNames);
        //							console.log(_self.$data.pics);
        ////							console.log(_self.$data.imgSrcs.toString());
        //							console.log(_self.$data.imgs);
        ////							alert(JSON.stringify(_self.$data.imgs))
        //						},s
        //上传文件
        hideDiv: function () {
            $(".mui-backdrop").hide();
            $(".pop-up").hide();
            $("#noticeType").hide();
        },
        upfile: function (event) {
            loading("上传中")
            var _self = this
            var file = document.getElementById(event.target.id).files;
            var zrid = document.getElementById(event.target.id).getAttribute("id")
            var url = getUrl() + "/sass_api/upload_file";
            var form = new FormData();
            var forimg = []
            var forfile = []
            for (var i = 0; i < file.length; i++) {
                form.append("file", file[i]);
                //读取图片数据
                var f = document.getElementById(event.target.id).files[i];
                var imgtype = f.type.split('/')[0]
                if (zrid == "file") {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        var data = e.target.result;
                        //加载图片获取图片真实宽度和高度
                        var image = new Image();
                        image.onload = function () {
                            width = image.width;
                            height = image.height;

                        };
                        image.src = data;
                        /*_self.$data.imgs.push({
                        src: image.src
                    })*/
                    };
                    _self.$data.cunnews = 1
                    reader.readAsDataURL(f);
                } else if (zrid == "files") {
                    _self.$data.cunnews = 2
                    var na = file[i].name
                    /*_self.$data.fujians.push({
                    name: f.name
                })*/
                    console.log(_self.$data.fujians)
                }
                //							reader.readAsDataURL(f);

            }
            if (_self.$data.cunnews == 1) {
                form.append("type", "1");
            } else {
                form.append("type", "2");
            }
            form.append("module", "contractnote");
            form.append("userid", userid);
            xhr = new XMLHttpRequest();
            xhr.open("post", url, true);
            xhr.onload = function (evt) {
                layer.close(loading("上传中"))
            };
            xhr.onreadystatechange = function (evt) {
                console.log(xhr)
                if (xhr.readyState == 4 && xhr.status == 200) {
                    ludan("上传成功", 1, 2)
                    _self.hideDiv();
                    console.log(xhr.responseText);
                    var data = JSON.parse(evt.target.responseText);
                    var rtnfiles = data.result.success;
                    console.log(data)
                    if (zrid == "file") {
                        for (var i = 0; i < rtnfiles.length; i++) {
                            imgid.push(rtnfiles[i].fileId);
                            _self.$data.imgs.push({
                                src: rtnfiles[i].src,
                                fileId: rtnfiles[i].fileId
                            })
                        }
                        console.log("///////", _self.$data.imgs)
                        if (imgid.toString()) {
                            _self.$data.zrimg = imgid.toString().split(',')
                        }
                    } else if (zrid == "files") {
                        for (var i = 0; i < rtnfiles.length; i++) {
                            fujianid.push(rtnfiles[i].fileId);
                            _self.$data.fujians.push({
                                name: rtnfiles[i].fileName,
                                fileId: rtnfiles[i].fileId
                            })
                        }
                        if (fujianid.toString()) {
                            _self.$data.zrfujian = fujianid.toString().split(',')
                        }

                        console.log(fujianid.toString())
                    }

                } else if (xhr.readyState == 4 && xhr.status == 500) {
                    msg("上传失败")
                }
            }
            xhr.onerror = function (evt) {
                //请求失败
                var data = JSON.parse(evt.target.responseText);
                console.log(data);
            };
            xhr.send(form);

        },
        changeImgIds: function (dishImgIds) {//得到广播回来的ID
            var _self = this;
            var forfile = []
            this.hideDiv();

            var parm = {
                dishIds: dishImgIds,
            }
            axios.post(getUrl() + "/contract/copydishinfo", parm).then(function (response) {
                var rtnfiles = response.data.result.success;
                for (var i = 0; i < rtnfiles.length; i++) {
                    fujianid.push(rtnfiles[i].fileId);
                    forfile.push({
                        name: rtnfiles[i].fileName,
                        fileId: rtnfiles[i].fileId
                    })
                }
                _self.$data.fujians = _self.$data.fujians.concat(forfile)
                if (fujianid.toString()) {
                    _self.$data.zrfujian = fujianid.toString().split(',')
                }
            })
        },
        moveimg: function (fileId, n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + fileId).then(function (response) {
                if (response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功", 1, 2)
                    document.getElementById("file").value = "";//清除input内容，防止出现不能重复上传的问题
                }
            }).catch(function (error) {
                ludan(error, 1, 3);
            })
            var index = _self.$data.imgs.indexOf(fileId);
            //                      _self.$data.imgs.splice(index, 1)
            _self.$data.imgs.splice(n, 1)
            //						console.log(n-1)
            var indexs = _self.$data.zrimg.indexOf(fileId);
            _self.$data.zrimg.splice(indexs, 1)
            console.log(_self.$data.zrimg)
            console.log(typeof JSON.stringify(_self.$data.zrimg))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        },
        movefj: function (fileId, n) {
            var _self = this;
            axios.post(getUrl() + "/sass_api/delete_file?userId=userid&fileId=" + fileId).then(function (response) {
                if (response.data.code == 0) {
                    console.log(response.data)
                    ludan("删除成功", 1, 2)
                    document.getElementById("files").value = "";//清除input内容，防止出现不能重复上传的问题
                }
            }).catch(function (error) {
                ludan(error, 1, 3);
            })
            var index = _self.$data.fujians.indexOf(fileId);
            //                      _self.$data.fujians.splice(index, 1)
            _self.$data.fujians.splice(n, 1)
            //						console.log(n-1)
            var indexs = _self.$data.zrfujian.indexOf(fileId);
            _self.$data.zrfujian.splice(indexs, 1)
            console.log(_self.$data.zrfujian)
            console.log(typeof JSON.stringify(_self.$data.zrfujian))
            //						console.log(imgid[1])
            //						imgid.remove(n-1)
        },
    }
});
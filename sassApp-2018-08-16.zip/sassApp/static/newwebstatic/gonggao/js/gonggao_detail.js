var app = new Vue({
    el: '#app',
    data: {

        //公告
        notice: {},
        imgs : [],
        imgUrl :[],
        pics : [],
        but_text: "",
        imgid:[],
        data:''

    },
    created: function() {
        _self = this;
        _self.getNotice();
        appApi.imgPreview.init();
    },
    //定义方法区
    methods: {
        open_file:function(id){
            appApi.openFile(getUrl()+'/sass_api/file/download?id='+id);
        },
        //时间过滤
        formatDate: function(value) {
            var getTime = new Date();
            var nowTime = getTime.toLocaleDateString()
            var currentDateString = Date.parse(nowTime + " 23:59")
            var currentDate = new Date(currentDateString);
            var fallDate = currentDate.getTime() -
                new Date(value).getTime(); //时间差的毫秒数
            //计算出相差天数
            var days = Math.floor(fallDate / (24 * 3600 * 1000))
            if(days == 0) {
                return "今天";
            } else if(days == 1) {
                return "昨天";
            } else {
                return new Date(value).toLocaleDateString().replace(
                    /\//g, '-');
            }
        },
        getNotice: function() {
            var _self = this;
            var param = {
                getType: "4",
                id: param_map.id,
                userId: user_id,
            }
            axios.post(getUrl() + "/notice_api/getNotice", param).then(
                function(response) {
                    console.log(response)
                    if(response.data.code == 200) {
                        console.log(response)
                        _self.$data.notice = response.data.result
                        if(_self.$data.notice.noticeStatus == 0) {
                            _self.$data.but_text = "已&nbsp;&nbsp;&nbsp;&nbsp;阅"
                        } else {
                            _self.$data.but_text = "我&nbsp;&nbsp;&nbsp;&nbsp;已&nbsp;&nbsp;&nbsp;&nbsp;阅"
                        }
                        var formData=new FormData();
                        formData.append("fileIdStr",response.data.result.attachmenIds)
                        axios.post(getUrl() + "/sass_api/get_uploadfile_info", formData).then(
                            function(response) {
                                console.log("tup",response)
                                _self.data=response.data.result

                                for(var i=0;i<_self.data.length;i++){
                                    if(_self.data[i].type==1){//图片
                                        _self.imgs.push({
                                            Url:_self.data[i].newThumbnailTurl,
                                            longurl:_self.data[i].longurl
                                        })
                                    }else{//附件
                                        _self.pics.push({
                                            id:_self.data[i].id,
                                            name:_self.data[i].filename,
                                            Url:_self.data[i].newThumbnailTurl,
                                        })
                                    }
                                }
                                console.log(_self.pics)

                            })

                        console.log("><><><>",_self.data)
                    } else {
                    }
                })
        },
        disposeLogImg: function(index, datas) {
            var _self = this;
            var imgsData = [];
            for(var i in datas) {
                // 图片
                imgsData.push(datas[i].longurl);
            }
            appApi.imgPreview.open(index, imgsData);
        },
        haveNotice: function() {
            var _self = this;
            if(_self.$data.notice.noticeStatus == 1) {
                return;
            }
            var param = {
                type: "1",
                userId: user_id,
                status: "1",
                noticeId: _self.notice.id,
            }
            axios.post(getUrl() + "/notice_api/updateNotice", param)
                .then(function(response) {
                    console.log(response)
                    if(response.data.code == 200) {
                        console.log(response)
                        _self.$data.but_text = "我&nbsp;&nbsp;&nbsp;&nbsp;已&nbsp;&nbsp;&nbsp;&nbsp;阅"
                        //将公告信息转到代办
                        var have_param = { //请求参数
                            docId: _self.$data.notice.docId,
                            userid: user_id,
                        }
                        $.ajax({
                            type: "post",
                            data: have_param,
                            url: getUrl() + "/todo_api/status",
                            success: function(data) {
                                console.log(data)
                            }
                        })
                    } else {
                        //							msg("获取云盘目录信息失败")
                    }
                })
        }
    }
});
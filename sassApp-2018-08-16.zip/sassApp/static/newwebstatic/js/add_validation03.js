var applymain = new Vue({
    el: '#app',
    data: {
        form: {
            type: 2,
            myDuty: "",
            roomName: "",
            companyCreditCode: "",
            roomClassId: "",
            roomClass: "",
            roomClassName: "",
            gongtouUserId: "",
            gongtouName: "",
            projectSn: "",
            projectName: "",
            projectImg: "",
            description: "",
            roomId: "",
            status: ""
        },
        projectInfo: {},
        // guanxi : "",
        // guanxis : [],
        yaoqing: "",
        yaoqingRoomName: "",
        yaoqingRoomId: "",
        yaoqingRoomClass: "",
        roomClass: [],
        Url: UPLOAD_SERVER_ADDRESS,
        isExist: 0,
    },
    created: function() {
        this.initData();
//							appApi.stopBack();
    },
    // 在 `methods` 对象中定义方法
    methods: {
        initData: function() {
            //获取数据
            var _self = this;
            axios.post(getUrl() + "/pcontact_api/getinviteinfo?inviteCode=" + paramMap.inviteCode).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data.result);
                    if(response.data.result.type == 3) {
                        //进入房间的时候，首先将 - 邀请方 与 被邀请方 - 共享（相互可见）
                        var parm = {
                            thisRoomId: response.data.result.roomInfo.room.roomId,
                            newRoomId: response.data.result.roomInfo.roomId,
                        }
                        //给邀请方和被邀请方创建消息入口
                        axios.post(getUrl() + "/pcontact_api/bothshare", parm).then(function(res) {
                        window.appApi.openChat(response.data.result.roomInfo.roomImId, "", response.data.result.roomInfo.roomName, 2)
                        window.appApi.closeNewWindow()
                        })
                    } else {
                        _self.$data.projectInfo = response.data.result.projectInfo;
                        _self.$data.roomClass = response.data.result.roomClass;
                        _self.$data.form.type = response.data.result.type;
                        _self.yaoqingRoomName = response.data.result.roomInfo.room.name;
                        _self.yaoqingRoomId = response.data.result.roomInfo.room.roomId;
                        _self.yaoqingRoomClass = response.data.result.roomInfo.room.roomClass;
                        _self.yaoqingRoomClassName = response.data.result.roomInfo.roomClassName;
                        _self.yaoqing = _self.yaoqingRoomClassName + " - " + _self.yaoqingRoomName;
                        var roomClassType = response.data.result.roomClassType;
                        if(roomClassType == '1') {
                            _self.form.roomClassName = response.data.result.roomClassTo.roomClassName;
                            _self.form.roomClass = response.data.result.roomClassTo.roomClass;
                            console.log(response.data.result.roomClassTo)
                            //如果邀请方设定了被邀请方的组织类型，则将选择组织类型选择器关闭
                            myLeibie = false;
                            var parame = new FormData();
                            parame.append("roomClass", _self.form.roomClass);
                            parame.append("projectSn", _self.$data.projectInfo.projectSn);
                            axios.post(getUrl() + "/pcontact_api/findroombyroomclass", parame).then(function(resp) {
                                if(resp.data.code == 0 && resp.data.result.isExist == 1) {
                                    console.log(resp.data.result)
                                    _self.$data.form.type = resp.data.result.type
                                    _self.$data.form.roomId = resp.data.result.roomId
                                    _self.$data.form.roomName = resp.data.result.roomName
                                    _self.$data.form.roomClassId = resp.data.result.roomClass
                                    _self.$data.form.companyCreditCode = resp.data.result.companyCreditCode
                                    _self.$data.isExist = 1;
                                    _self.$data.form.status = 1;
                                } else {
                                    _self.$data.form.type = 2
                                    _self.$data.form.roomId = ""
                                    _self.$data.form.roomName = ""
                                    _self.$data.form.companyCreditCode = ""
                                    _self.$data.form.roomClassId = ""
                                    _self.$data.form.status = 2;
                                }
                            })
                        }
                        //需要传递的项目信息参数
                        _self.$data.form.projectSn = response.data.result.projectInfo.projectSn;
                        _self.$data.form.projectName = response.data.result.projectInfo.projectName;
                        _self.$data.form.projectImg = response.data.result.projectInfo.projectImg == null ? "" : response.data.result.projectInfo.projectImg == null;
                    }
                } else {
                    msg(response.data.message);
                }
            })
        },
        leibie: function() {
            if(myLeibie) {
                document.getElementsByClassName("pop-up")[0].style.display = "block"
                document.getElementsByClassName("mui-backdrop")[0].style.display = "block"
            }
        },

        gongtoushow: function() {
            window.appApi.openNewWindow(getUrl() + "/static/newwebstatic/add_gongzhang.html?projectSn=" + this.projectInfo.projectSn + "&userId=" + this.form.gongtouUserId + "&roomId=" + this.yaoqingRoomId);
        },
        //            gongzhangclick: function(item) {
        //                alert(item);
        //                var a = JSON.parse(item);
        //
        //                this.$data.form.gongtouUserId = a.userId;
        //                this.$data.form.gongtouName = a.nickName;
        //            },
        movemask: function() {
            document.getElementsByClassName("pop-up")[0].style.display = "none"
            //document.getElementById("relationship").style.display="none"
            document.getElementsByClassName("mui-backdrop")[0].style.display = "none"
        },
        movetap: function(item) {
            var _self = this
            _self.$data.form.roomClassName = item.roomClassName;
            _self.$data.form.roomClass = item.roomClass;
            _self.$data.form.myDuty = "";
            _self.$data.form.roomName = "";
            _self.$data.form.companyCreditCode = "";
            _self.$data.form.gongtouUserId = "";
            _self.$data.form.gongtouName = "";
            _self.$data.isExist = 0;
            if(item.isOpen == 0) { //查询当前选择组织的房间
                var parame = new FormData();
                parame.append("roomClass", item.roomClass);
                parame.append("projectSn", _self.$data.projectInfo.projectSn);
                axios.post(getUrl() + "/pcontact_api/findroombyroomclass", parame).then(function(resp) {
                    if(resp.data.code == 0 && resp.data.result.isExist == 1) {
                        console.log(resp.data.result)
                        _self.$data.form.type = resp.data.result.type
                        _self.$data.form.roomId = resp.data.result.roomId
                        _self.$data.form.roomName = resp.data.result.roomName
                        _self.$data.form.roomClassId = resp.data.result.roomClass
                        _self.$data.form.companyCreditCode = resp.data.result.companyCreditCode
                        _self.$data.isExist = 1;
                        _self.$data.form.status = 1;
                    } else {
                        _self.$data.form.type = 2
                        _self.$data.form.roomId = ""
                        _self.$data.form.roomName = ""
                        _self.$data.form.companyCreditCode = ""
                        _self.$data.form.roomClassId = ""
                        _self.$data.form.status = 2;
                    }

                    //选择类别后，根据邀请方和被邀请方查询可选择的关系

                    //公司名称等于空的，才去寻找选择项
                    /* if(_self.$data.form.roomName==""){
                         var formdata = new FormData();
                         formdata.append("yaoqingRoomClass",_self.yaoqingRoomClass);//邀请方roomclass
                         formdata.append("roomClass",item.roomClass);//属于方roomclass.
                         axios.post(getUrl() + "/pcontact_api/findsuperiorguanxi", formdata).then(function(res) {
                             if(res.data.code==200){
                                 _self.$data.guanxis = res.data.result;
                                 console.log(_self.$data.guanxis)
                                 if(_self.$data.guanxis.length==1){
                                     _self.guanxi = _self.$data.guanxis[0].text;
                                     _self.$data.form.status =  _self.$data.guanxis[0].value;
                                     document.getElementsByName("yaoqingfang")[0].style.display="block";
                                 }else if(_self.$data.guanxis.length==0){
                                     _self.guanxi = "";
                                     _self.$data.form.status =  "";
                                     document.getElementsByName("yaoqingfang")[0].style.display="block";
                                 }else{
                                     _self.guanxi = "";
                                     _self.$data.form.status =  "";
                                     document.getElementsByName("yaoqingfang")[0].style.display="block";
                                 }
                             }


                         }).catch(function (error) {
                         });
                     }
                     //出现房间时，需要清空关系信息
                     _self.guanxi = "";
                     _self.$data.form.status =  "";
                     document.getElementsByName("yaoqingfang")[0].style.display = "none";*/
                }).catch(function(error) {
                    _self.$data.form.type = 2
                    _self.$data.form.roomId = ""
                    _self.$data.form.roomName = ""
                    _self.$data.form.companyCreditCode = ""

                });
            } else {
                _self.$data.form.type = 2
                _self.$data.form.roomId = ""
                _self.$data.form.roomName = ""
                _self.$data.form.companyCreditCode = ""
                //公司名称等于空的，才去寻找选择项
                /* if(_self.$data.form.roomName=="") {
                     var formdata = new FormData();
                     formdata.append("yaoqingRoomClass", _self.yaoqingRoomClass);//邀请方roomclass
                     formdata.append("roomClass", item.roomClass);//属于方roomclass.
                     axios.post(getUrl() + "/pcontact_api/findsuperiorguanxi", formdata).then(function (res) {
                         if (res.data.code == 200) {
                             _self.$data.guanxis = res.data.result;
                             console.log(_self.$data.guanxis)
                             if (_self.$data.guanxis.length == 1) {
                                 _self.guanxi = _self.$data.guanxis[0].text;
                                 _self.$data.form.status = _self.$data.guanxis[0].value;
                                 document.getElementsByName("yaoqingfang")[0].style.display = "block";
                             } else if (_self.$data.guanxis.length == 0) {
                                 _self.guanxi = "";
                                 _self.$data.form.status = "";
                                 document.getElementsByName("yaoqingfang")[0].style.display = "block";
                             } else {
                                 _self.guanxi = "";
                                 _self.$data.form.status = "";
                                 document.getElementsByName("yaoqingfang")[0].style.display = "block";
                             }
                         }


                     }).catch(function (error) {
                     });
                 }*/
            }

            document.getElementsByClassName("pop-up")[0].style.display = "none"
            document.getElementsByClassName("mui-backdrop")[0].style.display = "none"
        },
        /*movegx:function(gx){
            var _self = this
            _self.guanxi = gx.text;
            _self.$data.form.status =  gx.value;
            document.getElementById("relationship").style.display="none"
            document.getElementsByClassName("mui-backdrop")[0].style.display = "none"
        },*/
        /* choiceguanxi: function(){
             var _self = this
             if(!_self.guanxi){
                 document.getElementById("relationship").style.display="block"
                 document.getElementsByClassName("mui-backdrop")[0].style.display = "block"
             }
             /!*document.getElementById("relationship").style.display="block"
             document.getElementsByClassName("mui-backdrop")[0].style.display = "block"*!/
         },*/

        applyroom: function() {
            var _self = this

            if(_self.$data.form.roomClass == '') {
                msg("请选择所在方性质")
                return;
            } else if(_self.$data.form.roomClass == "banzu_gongtou") { //工头
                if(!_self.$data.form.roomName) {
                    msg("请填写专业")
                    return;
                }

            } else if(_self.$data.form.roomClass == "banzu_gaongren") { //工人
                if(!_self.$data.form.gongtouUserId) {
                    msg("请选择工长")
                    return;
                }
            } else if(_self.$data.form.roomClass == "cailiaoshang") { //材料商
                if(!_self.$data.form.roomName) {
                    msg("请填写公司名称")
                    return;
                }
                if(!_self.$data.form.description) {
                    msg("请填写供应材料")
                    return;
                }

            } else if(_self.$data.form.roomClass == "zhuanxiangfenbao") {
                if(!_self.$data.form.roomName) {
                    msg("请填写公司名称")
                    return;
                }
                if(!_self.$data.form.description) {
                    msg("请填写专业")
                    return;
                }

            } else {
                if(!_self.$data.form.roomName) {
                    msg("请填写公司名称")
                    return;
                }
            }

            var parame = new FormData();
            parame.append("type", _self.$data.form.type);
            /*if(_self.$data.form.status!=null&&_self.$data.form.status!=""){
                parame.append("roomId",  _self.yaoqingRoomId);
            }else{
                parame.append("roomId",  _self.$data.form.roomId);
            }*/
            if(_self.$data.form.status == 1) {
                parame.append("roomId", _self.$data.form.roomId);
            } else {
                parame.append("roomId", _self.yaoqingRoomId);
            }

            //parame.append("roomId",  _self.yaoqingRoomId);
            //parame.append("newRoomId",  _self.$data.form.roomId);

            parame.append("myDuty", _self.$data.form.myDuty);
            parame.append("roomName", _self.$data.form.roomName);
            parame.append("companyCreditCode", _self.$data.form.companyCreditCode);
            parame.append("roomClass", _self.$data.form.roomClass);
            parame.append("gongtouUserId", _self.$data.form.gongtouUserId);
            parame.append("projectSn", _self.$data.form.projectSn);
            parame.append("projectName", _self.$data.form.projectName);
            parame.append("projectImg", _self.$data.form.projectImg);
            parame.append("description", _self.$data.form.description);
            /*parame.append("status", _self.$data.form.status);*/

            //调用加载框，避免用户多次点击

            appApi.showLoading(false);
            axios.post(getUrl() + "/pcontact_api/applyroom", parame).then(function(response) {
                if(response.data.code == 0) {
                    console.log(response.data.result)
                    var data = response.data.result
                    //关闭加载框
                    appApi.hideLoading();
                    window.appApi.closeNewWindow()
                    window.appApi.openChat(data.roomImId, "", data.roomName, 2)
                } else if(response.data.code == 300) {
                    appApi.hideLoading();
                    msg(response.data.message);
                } else {
                    appApi.hideLoading();
                    msg(response.data.message);
                }
            })
        }
    },
})
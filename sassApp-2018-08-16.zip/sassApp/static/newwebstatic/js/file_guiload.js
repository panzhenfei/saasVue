var webPath = getUrl()
var pagepath = getPagePath()
var paramMap = getParam(window.location.href); //获取地址栏参数
//项目sn
//var projectId = paramMap.projectId
//登陆人id
var userid = getCookie("userid")
var listname
var app = new Vue({
	el: '#app',
	data: {
		itemss: [],
		imgurl: "http://res.winfreeinfo.com:8000",
		sites: [],
		fileall: [],
		projectname: "",
		filesize: "0KB", //选中文件的大小
		filesizeshow:'',
		filenum: 0, //选中文件的个数
		soncunt: 0, //点击目录记录相应的indexx
		count: '', //用于返回时候记录div的index
		fileid: [-1], //保存目录id
		oknext: '1',
		fileshares: [],
		filecount: 0,
		section: '',
		projectSn: '',
		listindex: [],
		savalist: [{
			"id": '-1',
			"index": "-1"
		}],
		listnext: '',
		listname: [], //存储点击后的列表
		firstlist: [],
		list2: [],
		parentId: '',
		firindex: '',
		parall:[]
	},
	created: function() {
		this.filelists()
	},
	// 在 `methods` 对象中定义方法
	methods: {
		//判断文件类型
		fileType: function(suffix) {
			var clazz = "label-";
			var fileType = 0;// 1=图片 2=视频 3=文件
			if(suffix && suffix.indexOf(".") > 0) {
				suffix = suffix.substring(suffix.indexOf("."), suffix.length);
			}

			switch(suffix) {
				case ".txt":
					clazz += "txt";
					fileType = 3;
					break;
                case ".TXT":
                    clazz += "txt";
                    fileType = 3;
                    break;
				case ".doc":
					clazz += "word";
					fileType = 3;
					break;
                case ".DOC":
                    clazz += "word";
                    fileType = 3;
                    break;
				case ".docm":
					clazz += "word";
					fileType = 3;
					break;
                case ".DOCM":
                    clazz += "word";
                    fileType = 3;
                    break;
				case ".dotx":
					clazz += "word";
					fileType = 3;
					break;
                case ".DOTX":
                    clazz += "word";
                    fileType = 3;
                    break;
				case ".dotm":
					clazz += "word";
					fileType = 3;
					break;
                case ".DOTM":
                    clazz += "word";
                    fileType = 3;
                    break;
				case ".docx":
					clazz += "word";
					fileType = 3;
                    break;
                case ".DOCX":
                    clazz += "word";
                    fileType = 3;
                    break;
				case ".rtf":
					clazz += "word";
					fileType = 3;
					break;
                case ".RTF":
                    clazz += "word";
                    fileType = 3;
                    break;
				case ".pdf":
					clazz += "pdf";
					fileType = 3;
					break;
                case ".PDF":
                    clazz += "pdf";
                    fileType = 3;
                    break;
				case ".xls":
					clazz += "excel";
					fileType = 3;
					break;
                case ".XLS":
                    clazz += "excel";
                    fileType = 3;
                    break;
				case ".ppt":
					clazz += "ppt";
					fileType = 3;
					break;
                case ".PPT":
                    clazz += "ppt";
                    fileType = 3;
                    break;
				case ".pptx":
					clazz += "ppt";
					fileType = 3;
					break;
                case ".PPTX":
                    clazz += "ppt";
                    fileType = 3;
                    break;
				case ".xlsx":
					clazz += "excel";
					fileType = 3;
					break;
                case ".XLSX":
                    clazz += "excel";
                    fileType = 3;
                    break;
				case ".xlsm":
					clazz += "excel";
					fileType = 3;
					break;
                case ".XLSM":
                    clazz += "excel";
                    fileType = 3;
                    break;
				case ".xltx":
					clazz += "excel";
					fileType = 3;
					break;
                case ".XLTX":
                    clazz += "excel";
                    fileType = 3;
                    break;
				case ".xltm":
					clazz += "excel";
					fileType = 3;
					break;
                case ".XLTM":
                    clazz += "excel";
                    fileType = 3;
                    break;
				case ".xlsb":
					clazz += "excel";
					fileType = 3;
					break;
                case ".XLSB":
                    clazz += "excel";
                    fileType = 3;
                    break;
				case ".xlam":
					clazz += "excel";
					fileType = 3;
					break;
                case ".XLAM":
                    clazz += "excel";
                    fileType = 3;
                    break;
				case ".rm":
					clazz += "video";
					fileType = 2;
					break;
                case ".RM":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".rmvb":
					clazz += "video";
					fileType = 2;
					break;
                case ".RMVB":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".wmv":
					clazz += "video";
					fileType = 2;
					break;
                case ".WMV":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".avi":
					clazz += "video";
					fileType = 2;
					break;
                case ".AVI":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".mp4":
					clazz += "video";
					fileType = 2;
					break;
                case ".MP4":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".3gp":
					clazz += "video";
					break;
                case ".3GP":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".mkv":
					clazz += "video";
					fileType = 2;
					break;
                case ".MKV":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".navi":
					clazz += "video";
					fileType = 2;
					break;
                case ".NAVI":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".mov":
					clazz += "video";
					fileType = 2;
					break;
                case ".MOV":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".asf":
					clazz += "video";
					fileType = 2;
					break;
                case ".ASF":
                    clazz += "video";
                    fileType = 2;
                    break;
				case ".png":
					clazz += "img";
					fileType = 1;
					break;
				case ".jpg":
					clazz += "img";
					fileType = 1;
					break;
				case ".jpeg":
					clazz += "img";
					fileType = 1;
					break;
				case ".gif":
					clazz += "img";
					fileType = 1;
					break;
                case ".JPEG":
                    clazz += "img";
                    fileType = 1;
                    break;
                case ".PNG":
                    clazz += "img";
                    fileType = 1;
                    break;
                case ".JPG":
                    clazz += "img";
                    fileType = 1;
                    break;
                case ".GIF":
                    clazz += "img";
                    fileType = 1;
                    break;
                case ".bmp":
                    clazz += "img";
                    fileType = 1;
                    break;
                case ".BMP":
                    clazz += "img";
                    fileType = 1;
                    break;
				case ".zip":
					clazz += "zip";
					fileType = 3;
					break;
				case ".rar":
					clazz += "zip";
					fileType = 3;
					break;
				case ".arj":
					clazz += "zip";
					fileType = 3;
					break;
				case ".z":
					clazz += "zip";
					fileType = 3;
					break;
                case ".ZIP":
                    clazz += "zip";
                    fileType = 3;
                    break;
                case ".RAR":
                    clazz += "zip";
                    fileType = 3;
                    break;
                case ".ARJ":
                    clazz += "zip";
                    fileType = 3;
                    break;
                case ".Z":
                    clazz += "zip";
                    fileType = 3;
                    break;
                case ".apk":
                    clazz += "apk";
                    fileType = 3;
                    break;
				case ".APK":
					clazz += "apk";
					fileType = 3;
					break;
				case ".mmap":
					clazz += "mmap";
					fileType = 3;
					break;
                case ".MMAP":
                    clazz += "mmap";
                    fileType = 3;
                    break;
				case ".mpg":
					clazz += "mpg";
					fileType = 3;
					break;
                case ".MPG":
                    clazz += "mpg";
                    fileType = 3;
                    break;
				case ".csv":
					clazz += "csv";
					fileType = 3;
					break;
                case ".CSV":
                    clazz += "csv";
                    fileType = 3;
                    break;
				case ".mpp":
					clazz += "mpp";
					fileType = 3;
					break;
                case ".MPP":
                    clazz += "mpp";
                    fileType = 3;
                    break;
				case ".html":
					clazz += "html";
					fileType = 3;
					break;
                case ".HTML":
                    clazz += "html";
                    fileType = 3;
                    break;
				case ".dwg":
					clazz += "dwg";
					fileType = 3;
					break;
                case ".DWG":
                    clazz += "dwg";
                    fileType = 3;
                    break;
				default:
					clazz += "unkown";
					fileType = 3;
					break;
			}
			var data = {
				"clazz":clazz,
				"fileType":fileType
			}
			return data;
		},
		filelists: function() {
			var _self = this
			appApi.showBack()
			axios.post(getUrl() + "/chart/column/table_swprojectinfo?used=getMyPro", {}).then(function(response) {
				if(response.data.code == 200) {
					_self.$data.itemss = response.data.result;
				}
			}).catch(function(error) {
				console.info(error);
			});
		},
		jump: function(projectSn, index) {
			var _self = this
			_self.$data.fileshares=[]
			$(".model1").css("display", "none")
			$(".model2").css("display", "block")
			_self.$data.projectSn = projectSn
			app.init()
		},
		init: function() {
			var _self = this
			appApi.hideBack()
			console.log(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + "&userid=" + userid)
			axios.post(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + "&userid=" + userid).then(function(response) {
				if(response.data.code == 0) {
					console.log(response.data)
					layer.close(loading("加载中"))
					console.log(response.data.result.data.firstList)
					_self.$data.sites=response.data.result.data.firstList
					_self.$data.projectname = response.data.result.data.projectName
					_self.$data.soncunt++
//										_self.$data.parentId=response.data.result.data.firstList[0].parentId
				}else{
					loading("加载中")
				}
			}).catch(function(error) {
				console.info(error);
			});

		},
		//查子目录
		son: function(id, type, cla, parentId) {
			var _self = this
			app.getnews(id)
			_self.$data.parentId = parentId
//			$(event.target).parents("ul").css("display","none")
			console.log(_self.$data.parentId)
			if(parentId==null){
				parentId=0
			}
			_self.$data.parall.push(parentId)
			console.log("..."+_self.$data.parall)
		},
		//点击获取对应子目录
		getnews: function(n, cla) {
			var _self = this
			var typeall = [] //存储子目录的type
			axios.post(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + "&pid=" + n).then(function(response) {
				if(response.data.code == 0) {
					layer.close(loading("加载中"))
					console.log(response.data)
					_self.$data.sites=response.data.result.data.result
					var lenth = _self.$data.sites.length - 1
					console.log(response.data.result.data.result.length)
					if(response.data.result.data.result.length!=0){
						_self.$data.parentId = response.data.result.data.result[0].parentId
					}
					
					app.lastson(typeall)
				}else{
					loading("加载中")
				}
			}).catch(function(error) {
				alert(error);
			});
			//				}
			//			}
			//			
			//			
		},
		//判断时候还有子目录
		lastson: function(typeall) {
			var _self = this
			if(typeall.indexOf(1) != -1) { //存在子目录
				_self.$data.soncunt++
					_self.$data.count = _self.$data.soncunt
			}
		},
		sonflie: function(size, name, urls,fileType) {
//			console.log(fileType+"fileType")
			//是否选中状态
			var checkstatus = $(event.target).parents("li").find("input").prop("checked");
//			$(event.target).parents("li").find("input").attr('checked')
			var _self = this
			$(".nav_foot").css("display", "block")
			var newfile = 0
			var oldfile = 0
			//选中文件的计算
			var newfilesize = _self.$data.filesize.split("K")[1]
			var allsize = size.split("K")[1]
			if(allsize == "B") {
				newfile = Number(size.split("K")[0])
			} else {
				newfile = Number(size.split("M")[0]) * 1024
				//不能选择大于等于10m的
				if (newfile>=10240){
                    return;
				}
			}
			if(newfilesize == "B") {
				oldfile = Number(_self.$data.filesize.split("K")[0])
			} else {
				oldfile = Number(_self.$data.filesize.split("M")[0]) * 1024
			}
//			newfilesize = newfile + Number(_self.$data.filesize)
//			alert("newfilesize="+newfilesize)
			if(checkstatus == false) {
				$(event.target).parents("li").attr("filecount", _self.$data.filecount)
				_self.$data.fileshares.push({
					"name": name,
					"size": size,
					"urls": urls,
					"fileType":fileType
				})
				_self.$data.filecount++
					var lastsize = (newfile*100 + oldfile*100)/100  //去掉浮点运算差
				_self.$data.filenum++
			} else if(checkstatus == true) {
				var lastsize = (oldfile*100 - newfile*100)/100
				var moveindex = $(event.target).parents("li").attr("filecount")
				_self.$data.fileshares.splice(moveindex, 1)
				if(_self.$data.filenum > 0) {
					_self.$data.filenum--
				}

				_self.$data.filecount--
			}
			if(lastsize < 1024 && lastsize >= 0) {
				_self.$data.filesize = lastsize + "KB"
				_self.$data.filesizeshow=lastsize.toFixed(2)+ "KB"
			} else if(lastsize < 0) {
				_self.$data.filesize = "0KB"
				_self.$data.filesizeshow=_self.$data.filesize
			} else if(lastsize > 1024) {
				_self.$data.filesize = parseFloat(lastsize / 1024) + "M"
				_self.$data.filesizeshow=parseFloat(lastsize / 1024).toFixed(2) + "M"
				
			}
		},
		//点击返回按钮
		back: function() {
			var _self = this
			var parm
			console.log(_self.$data.parentId)
			console.log(_self.$data.parall)
			var leng=Number(_self.$data.parall.length)-1
			if(_self.$data.parall[leng]==0){
				parm="&userid=" + userid
			}else{
				parm='&pid='+_self.$data.parall[leng]
			}
			if(parm.split("=")[1]!='undefined'){
			axios.post(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + parm).then(function(response) {
				if(response.data.code == 0) {
					var pap=parm.split('=')[1]
					console.log("pap="+pap)
					var lenth = _self.$data.sites.length - 1
					if(pap!=userid){
						_self.$data.sites=response.data.result.data.result
						_self.$data.parentId = response.data.result.data.result[0].parentId
					}else{
						_self.$data.sites=response.data.result.data.firstList
					}
				}
			}).catch(function(error) {
				alert(error);
			});
			}else{
				$(".model1").css("display", "block")
				$(".model2").css("display", "none")
				_self.$data.filenum=0
				_self.$data.filesize="0KB"
				$(".nav_foot").css("display","none")
				app.filelists()
			}
			
			_self.$data.parall.splice(leng,1)
		},
		//点击确定分享
		share: function() {
			var _self = this
			var param = []
			for(var i = 0; i < _self.$data.fileshares.length; i++) {
//				param.push({
//					"chatType": '1',
//					"type": '0',
//					"title": _self.$data.fileshares[i].name,
//					"content": _self.$data.fileshares[i].size,
//					"url": _self.$data.fileshares[i].urls,
//					"thumbImgUrl": _self.$data.fileshares[i].urls,
//				})
				param.push({
					"fileName":_self.$data.fileshares[i].name,
					"fileUrl":_self.$data.fileshares[i].urls,
					"fileSize":_self.$data.fileshares[i].size,
					"fileType":_self.$data.fileshares[i].fileType
				})
				if(i==(_self.$data.fileshares.length-1)){
//					console.log(param);
					appApi.setSelectData(param);
				}
			}
		},
		getSize:function (size) {
            var allsize = size.split("K")[1];
            var  newfile = 0;
            if(allsize == "B") {
                newfile = Number(size.split("K")[0])
            } else {
                newfile = Number(size.split("M")[0]) * 1024
            }
            return newfile;
        }
	}
})
//阻止点击li冒泡
//mui(".mui-table-view").on('tap', '.mui-table-view-cell', function(event) {
//	event.stopPropagation();
//	event.preventDefault()
//})
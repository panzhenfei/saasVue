var xk_util = {
	/**
	 * 获取对象数组中的特定属性重新组成一个数组
	 * @param {Object} ary 源数组必须是对象数组
	 * @param {Object} property 获取的属性名集合
	 */
	getArrayProperty: function(ary, property) {
		if(typeof ary[0] === "object") {
			var getType = null;
			var newAry = new Array();
			//判断获取的类型
			if(typeof property === "object") {
				if(property instanceof Array) {
					var getPropertyString = "{";
					property.forEach(function(item, index) {
						getPropertyString += "'" + item + "':ary[index]" + "['" + item + "'],"
					})
					getPropertyString = getPropertyString.substring(0, getPropertyString.length - 1); //去除逗号
					getPropertyString += "}"
					for(var index = 0; index < ary.length; index++) {
						console.log(getPropertyString)
						newAry.push(eval("(" + getPropertyString + ")"));
					}
				}
			} else if(typeof property === "string") {
				for(var index = 0; index < ary.length; index++) {
					newAry.push(ary[index][property])
				}
			} else {
				return null;
			}
			return newAry;
		}

	},
	/**
	 * 对象数组属性比较函数  小于返回整数大于返回负数则可以降序,反之升序
	 * @param {Object} prop  指定比较属性
	 * @param {Object} min  小于返回的数值 
	 * @param {Object} max  大于返回的数值
	 */
	compare: function(prop,min,max) {
		return function(obj1, obj2) {
			var val1 = obj1[prop];
			var val2 = obj2[prop];
			if(val1 < val2) {
				return -1;
			} else if(val1 > val2) {
				return 1;
			} else {
				return 0;
			}
		}
	}
}
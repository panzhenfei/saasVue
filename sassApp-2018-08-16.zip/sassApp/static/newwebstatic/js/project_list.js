var webPath = getUrl()
			var pagepath = getPagePath()
			var paramMap = getParam(window.location.href); //获取地址栏参数
			//项目sn
			//var projectId = paramMap.projectId
			//登陆人id
			var userid = getCookie("userid")
			var listname
			var app = new Vue({
				el: '#app',
				data: {
					model: 1,
					items: [],
					listcount: [],
					imgurl: "http://res.winfreeinfo.com:8000",
					sites: [],
					projectname: '',
					fileshares: [],
					filenum: '',
					filesizeshow: '',
					filesizezan:0,
					listsize: [],
					listsizenum: [],
					list: [],
					parentid:[],
					backzr:'',
					backstart:'',
                    projectSN:paramMap.projectSN,
					teamId:"",
					erpProjectSN:"",
                    dbTitle:"",
                    docTitle:"",
					erpPrid:-3,
					submitFalg:false
				},
				created: function() {
					this.filelists()
				},
				// 在 `methods` 对象中定义方法
				methods: {
					//获取列表
					filelists: function() {
						var _self = this
						//						appApi.showBack()
						axios.post(getUrl() + "/chart/column/table_swprojectinfo?used=getMyPro&projectSN="+paramMap.projectSN, {}).then(function(response) {
							if(response.data.code == 200) {
								appApi.showBack()
								_self.$data.items = response.data.result;
								// console.log(_self.$data.list)
							}
						}).catch(function(error) {
							console.info(error);
						});
					},
					getSize:function (size) {
			            var allsize = size.split("K")[1];
			            var  newfile = 0;
			            if(allsize == "B") {
			                newfile = Number(size.split("K")[0])
			            } else {
			                newfile = Number(size.split("M")[0]) * 1024
			            }
			            return newfile;
			        },
					//点击列表
					jump: function(projectSn, index) {
						var _self = this
						appApi.hideBack()
						if(_self.$data.listcount.indexOf(index) == -1) {
							_self.$data.listcount.push(index)
						}
						// console.log(_self.$data.listcount)
						//置空选中的附件
						_self.$data.fileshares = []
						_self.$data.list=[]
						_self.$data.listsize=[]
						_self.$data.parentid=[]
						_self.$data.filesizeshow=''
						_self.$data.filesizezan=0
						_self.$data.filenum=0
						
						_self.$data.model = 2
						_self.$data.backstart=1
						_self.$data.projectSn = projectSn
						app.init(index)
					},
					back: function() {
						var _self = this
						_self.$data.model = 1
					},
					//点击列表跳转对应文件柜
					init: function(index) {
						var _self = this
						//						appApi.hideBack()
						axios.post(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + "&userid=" + userid).then(function(response) {
							if(response.data.code == 0) {
								//								console.log(response.data)
								layer.close(loading("加载中"))
																// console.log(response.data.result.data);
								_self.$data.sites = response.data.result.data.firstList;
//								_self.$data.parentid.push(response.data.result.data.firstList[0].id)
								_self.$data.projectname = response.data.result.data.projectName;
								_self.$data.teamId = response.data.result.data.teamId;
								//										_self.$data.parentId=response.data.result.data.firstList[0].parentId
							} else {
								loading("加载中")
							}
						}).catch(function(error) {
							console.info(error);
						});

					},
					son: function(id, type, cla, parentId,erpProjectSN,name) {
						var _self = this
						// console.log(id)
                        _self.$data.backstart=2
						_self.$data.erpProjectSN = erpProjectSN;
						if (erpProjectSN){
							if (name!="私有系统档案"){
                                if(_self.$data.dbTitle){
                                    _self.$data.docTitle = name;
                                }else{
                                    _self.$data.dbTitle=name;
                                }
                            }
                            $.post("/cdish/erp_file_record",{teamId:_self.$data.teamId,projectSN:erpProjectSN,
                                dbTitle:_self.$data.dbTitle,docTitle:_self.$data.docTitle,sortType:4},function(data){
                                if(data.code==0){
                                    // console.log(data)
									if (data.result.list.length>0){
                                        _self.$data.sites = data.result.list;
                                        _self.$data.parentid.push(_self.$data.erpPrid);
                                        _self.$data.erpPrid+1;
									}
                                }else{
                                    msg(data.message)
                                }
                            })
						}else {
                            axios.post(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + "&pid=" + id).then(function(response) {
                                if(response.data.code == 0) {
                                    // console.log(response.data)
									if (response.data.result.data.result.length>0){
                                        _self.$data.parentid.push(response.data.result.data.result[0].parentId)
                                        _self.$data.sites = response.data.result.data.result
									}
                                }
                            })
						}
					},
                    pathCheck:function(_id,_path,_name,_suffix,_size,_index){
                        var _self = this;
                        _self.$data.backstart=2
                        var checkstatus = $(event.target).parents("li").find("input").prop("checked");
                        if(_self.$data.erpProjectSN){
                            var size = _self.analysisSize(_size)+"";
                            var params = {
                                projectId:_self.$data.projectId,
                                name:_name,
                                size:size,
                                path:_path,
                                suffix:_suffix,
                                type:2
                            };
                            $.ajax({
                                method: "POST",
                                url: "/cdish/saveErpFile",
                                contentType: 'application/json',
                                data:JSON.stringify(params),
                                success: function( data ) {
                                    if(data.code==0){
                                        var id = data.result.id;
                                        _self.$data.sites[_index].id=id;
                                        _self.sonflie(_size,(_name+_suffix),data.result.path,_index,id,2,checkstatus);
                                    }else{
                                        mui.toast(data.message);
                                    }
                                },
                                error:function(error){
                                    mui.toast("获取附件信息失败");
                                }
                            });
                        }else{
                            _self.sonflie(_size,(_name+_suffix),_path,_index,_id,2,checkstatus);
                        }
                    },
					sonflie: function(size, name, urls, index, nameid, fileType,checkstatus) {
						var _self = this;
						//判断附件是否选中
						if(checkstatus == false) {
							//用来记录选中的附件
							if(_self.$data.list.indexOf(nameid) == -1) {
								_self.$data.list.push(nameid)
								_self.$data.listsize.push(size)
								_self.$data.fileshares.push({
									"id":nameid,
									"name": name,
									"size": size,
									"urls": urls,
									"fileType": fileType
								})
							}
						} else {
							//删除取消选中的附件
							_self.$data.list.remove(nameid)
							_self.$data.listsize.remove(size)
							for(var i=0;i<_self.$data.fileshares.length;i++){
								if(_self.$data.fileshares[i].id==nameid){
									_self.$data.fileshares.splice(i,1)
								}
							}

						}
//												console.log(_self.$data.fileshares)
						_self.$data.filenum = _self.$data.list.length
						//filenum filesizeshow 
						app.filesize()
					},
					//计算选中文件的大小
					filesize: function() {
						var _self = this
						_self.$data.filesizezan=0
						_self.$data.filesizeshow = ''
						for(var i = 0; i < _self.$data.listsize.length; i++) {
							var pattKB = new RegExp('KB');
							var pattB = new RegExp('B');
							var pattM = new RegExp('MB');
							
							if(pattM.test(_self.$data.listsize[i])) {
								var size = (parseFloat(_self.$data.listsize[i].split("MB")[0]).toFixed(2) * 100 * 1024 * 1024) / 100
								_self.$data.filesizezan = parseFloat((_self.$data.filesizezan * 100 + size * 100)).toFixed(2) / 100
							}else if(pattB.test(_self.$data.listsize[i])) { // KB 或者 B
								if(pattKB.test(_self.$data.listsize[i])) { //kb
									var size = (parseFloat(_self.$data.listsize[i].split("KB")[0]).toFixed(2) * 100 * 1024) / 100
									_self.$data.filesizezan = parseFloat((_self.$data.filesizezan * 100 + size * 100)).toFixed(2) / 100
								} else if(pattB.test(_self.$data.listsize[i])){ //B
									var size = parseFloat(_self.$data.listsize[i].split("B")[0]).toFixed(2)
									_self.$data.filesizezan = parseFloat((_self.$data.filesizezan * 100 + size * 100)).toFixed(2) / 100
								}
							} 
							
							//转换微正常单位
							if(_self.$data.filesizezan>=1048576){
								_self.$data.filesizeshow=parseFloat((_self.$data.filesizezan*100)/104857600).toFixed(2)+'MB'
							}else if(_self.$data.filesizezan>=1024){
								_self.$data.filesizeshow=parseFloat((_self.$data.filesizezan*100)/102400).toFixed(2)+"KB"
							}else if(_self.$data.filesizezan>0 && _self.$data.filesizezan<1024){
								_self.$data.filesizeshow=_self.$data.filesizezan+"B"
							}

						}
						//						console.log(_self.$data.filesizeshow)
					},
					//点击返回按钮
					back: function() {
						var _self = this;
                        var back;
                        var parm;
                        _self.$data.parentid.splice(_self.$data.parentid.length-1,1);
                        var parid=_self.$data.parentid[_self.$data.parentid.length-1]
                        if(parid==undefined){
                            back="&userid=" + userid
                        }else{
                            back='&pid='+parid
                        }
						if(_self.$data.backstart!=1){
							if (_self.$data.erpProjectSN&&parid!=undefined){
                                if (name!="私有系统档案"){
                                    if(_self.$data.docTitle){
                                        _self.$data.docTitle = "";
                                    }else{
                                        _self.$data.dbTitle="";
                                    }
                                }
                                $.post("/cdish/erp_file_record",{teamId:_self.$data.teamId,projectSN:_self.$data.erpProjectSN,
                                    dbTitle:_self.$data.dbTitle,docTitle:_self.$data.docTitle,sortType:4},function(data){
                                    if(data.code==0){
                                        // console.log(data)
                                        if(parid==undefined){
                                            _self.$data.sites = response.data.result.data.firstList;
                                            _self.$data.backstart=1
                                        }else{
                                            if (data.result.list.length>0){
                                                _self.$data.sites = data.result.list;
                                            }
                                        }
                                    }else{
                                        msg(data.message)
                                    }
                                })
							}else {
								axios.post(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + back).then(function(response) {
									if(response.data.code == 0) {
										// console.log(response.data)
										if(parid==undefined){
											_self.$data.sites = response.data.result.data.firstList;
											_self.$data.backstart=1
										}else{
											_self.$data.sites = response.data.result.data.result
										}
									}
								}).catch(function(error) {
									alert(error);
								});
							}
						}else{
							app.filelists()
							_self.$data.model = 1
						}
					},
					//点击确定分享
					share: function() {
                        var _self = this;
                    	if (!_self.$data.submitFalg){
                            _self.$data.submitFalg = true;
                            var param = []
                            var dishImgIds = "";
                            for(var i = 0; i < _self.$data.fileshares.length; i++) {
//							param.push({
//								"chatType": '1',
//								"type": '0',
//								"title": _self.$data.fileshares[i].name,
//								"content": _self.$data.fileshares[i].size,
//								"url": _self.$data.fileshares[i].urls,
//								"thumbImgUrl": _self.$data.fileshares[i].urls,
//							})
                                param.push({
                                    "fileName":_self.$data.fileshares[i].name,
                                    "fileUrl": getUrl() + "/cdish/file/download?id=" + _self.$data.fileshares[i].id,
                                    "fileSize":_self.$data.fileshares[i].size,
                                    "fileType":_self.$data.fileshares[i].fileType,
                                    "fileId":_self.$data.fileshares[i].id
                                })
                                if(i<(_self.$data.fileshares.length-1)){
                                    dishImgIds += _self.$data.fileshares[i].id + ",";
                                }else{
                                    dishImgIds += _self.$data.fileshares[i].id;
                                }
//							if(i==(_self.$data.fileshares.length-1)){
//			//					console.log(param);
////								appApi.setSelectData(param);
//							}
                            }
//						alert(JSON.stringify(param))
                            if(paramMap.entrance=='bill'){
                                //使用广播方法传输回去
                                appApi.broadcast("obtainDishImgIds('"+dishImgIds+"')");
                                appApi.closeNewWindow();
                            }else{
                                console.log(param)
                                appApi.setSelectData(param)
                            }
						}
					},
					//判断文件类型
					fileType: function(suffix) {
						var clazz = "label-";
						if(suffix && suffix.indexOf(".") > 0) {
							suffix = /\.[^\.]+$/.exec(suffix).toString()
						}
						switch(suffix) {
							case ".txt":
								clazz += "txt";
								break;
							case ".doc":
								clazz += "word";
								break;
							case ".docm":
								clazz += "word";
								break;
							case ".dotx":
								clazz += "word";
								break;
							case ".dotm":
								clazz += "word";
								break;
							case ".docx":
								clazz += "word";
								break;
							case ".rtf":
								clazz += "word";
								break;
							case ".pdf":
								clazz += "pdf";
								break;
							case ".xls":
								clazz += "excel";
								break;
							case ".ppt":
								clazz += "ppt";
								break;
							case ".pptx":
								clazz += "ppt";
								break;
							case ".xlsx":
								clazz += "excel";
								break;
							case ".xlsm":
								clazz += "excel";
								break;
							case ".xltx":
								clazz += "excel";
								break;
							case ".xltm":
								clazz += "excel";
								break;
							case ".xlsb":
								clazz += "excel";
								break;
							case ".xlam":
								clazz += "excel";
								break;
							case ".rm":
								clazz += "video";
								break;
							case ".rmvb":
								clazz += "video";
								break;
							case ".wmv":
								clazz += "video";
								break;
							case ".avi":
								clazz += "video";
								break;
							case ".mp4":
								clazz += "video";
								break;
							case ".3gp":
								clazz += "video";
								break;
							case ".mkv":
								clazz += "video";
								break;
							case ".navi":
								clazz += "video";
								break;
							case ".mov":
								clazz += "video";
								break;
							case ".asf":
								clazz += "video";
								break;
							case ".png":
								clazz += "img";
								break;
							case ".jpg":
								clazz += "img";
								break;
							case ".gif":
								clazz += "img";
								break;
							case ".zip":
								clazz += "zip";
								break;
							case ".rar":
								clazz += "zip";
								break;
							case ".arj":
								clazz += "zip";
								break;
							case ".z":
								clazz += "zip";
								break;
							case ".apk":
								clazz += "apk";
								break;
							case ".mmap":
								clazz += "mmap";
								break;
							case ".mpg":
								clazz += "mpg";
								break;
							case ".csv":
								clazz += "csv";
								break;
							case ".mpp":
								clazz += "mpp";
								break;
							case ".html":
								clazz += "html";
								break;
							case ".dwg":
								clazz += "dwg";
								break;
							default:
								clazz += "unkown";
								break;
						}
						return clazz;
					},
                    analysisSize:function(sizeStr){
                        if(sizeStr.indexOf("B")>0&&sizeStr.indexOf("KB")==-1&&sizeStr.indexOf("MB")==-1
                            &&sizeStr.indexOf("GB")==-1){
                            sizeStr = sizeStr.substring(0,sizeStr.indexOf("B"))
                            return parseInt(sizeStr);
                        }else if(sizeStr.indexOf("KB")>0){
                            sizeStr = sizeStr.substring(0,sizeStr.indexOf("KB"))
                            return parseInt(sizeStr)*1024;
                        }else if(sizeStr.indexOf("MB")>0){
                            sizeStr = sizeStr.substring(0,sizeStr.indexOf("MB"))
                            return parseInt(sizeStr)*1024*1024;
                        }else if(sizeStr.indexOf("GB")>0){
                            sizeStr = sizeStr.substring(0,sizeStr.indexOf("GB"))
                            return parseInt(sizeStr)*1024*1024*1024;
                        }else if(sizeStr.indexOf("T")>0){
                            sizeStr = sizeStr.substring(0,sizeStr.indexOf("T"))
                            return parseInt(sizeStr)*1024*1024*1024*1024;
                        }
                    }
				}
			})

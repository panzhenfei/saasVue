var webPath = getUrl()
var pagepath = getPagePath()
var paramMap = getParam(window.location.href); //获取地址栏参数
var nehrf = location.href
//获取的地址栏参数
var loginType = paramMap.loginType
var projectSn = paramMap.projectSn
var projectName = paramMap.projectName
var currUserPhone = paramMap.currUserPhone
var currRoomId = paramMap.currRoomId
var currRoomName = paramMap.currRoomName
var currRoomCreditCode = paramMap.currRoomCreditCode
var isRoomId = paramMap.isRoomId
var isRoomName = paramMap.isRoomName
var isRoomCreditCode = paramMap.isRoomCreditCode
//			alert(paramMap.currRoomImId+"/////"+paramMap.currRoomClassName)
//当前用户
var userid = getCookie("userid")
var username = getCookie("username")

localStorage.removeItem("urlnews")
var urlnews = location.href.split("?")[1]
localStorage.setItem("urlnews", urlnews)
//选公司回调
window.appApi.callBackFun = function(callFlag, CONTENT) {
	if(callFlag == appApi.callBackFlag.GONGSI) {
		app.aa(CONTENT);
	}
}

var imgid = [] //全局变量获取attachment
var fujianid = [] //全局变量获取attachment
var opt = {
	"type": "date",
	"beginYear": 2000,
	"endYear": new Date().getFullYear() + 10
};
var picker = new mui.DtPicker(opt);
var app = new Vue({
	el: '#app',
	data: {
		currRoomImId: paramMap.isRoomImId,
		currRoomClassName: paramMap.currRoomClassName,
		nes: nehrf,
		checktitle: false,
		addname: "",
		sites: [],
		gongsiall: [],
		gongsialllei: [],
		imgs: [],
		fujians: [],
		zrimg: [],
		zrfujian: [],
		pinpai: '',
		mingcheng: "",
		form: {
			// 开工日期
			MissionStartDate: "",
		},
		biandan1: "",
		biandan2: "",
		biandan3: "",
		biandan4: "",
		chenk2: "",
		beizhu: "",
		printTime: "",
		nowtime: "",
		companySaleName: isRoomName,
		companySaleID: isRoomCreditCode,
		companySaleRoomID: isRoomId,
		boforeroomId: "",
		boforecompanyname: "",
		boforecompanynamelei: "",
		boforeroomImId: "",
		boforecompanyId: "",
		tuisongrooimid: [], //推送roomimid
		tuisong: [],
		id: "",

		tuiroomimid: "",
		tuisongsuccessname: [],
		tuisongfailename: [],
		lururen: decodeURI(username),
		starroomimid: '',
		tuicfgid: '',
		tuiprojectSn: '',
		tuiroomid: '',
		tuiroomname: '',
		tuiprojectName: '',
		tuicompanySaleID: '',
		companySaleName: '',
		companySaleRoomID: '',
		cfgid: "",
		twoimgid: [],
		twofujiannum: 0,

		//选公司
		changename: [],
		changeid: [],
		attachmentIds: "",
		twofujiannumid: "",

	},
	created: function() {
		var _self = this;
		sessionStorage.removeItem("save") //删除判断是否保存的本地判断
		_self.getnews()
		var getTime = new Date()
		var nowTime = getTime.toLocaleDateString()
		var year = nowTime.split("/")[0]
		var mouth = nowTime.split("/")[1]
		var day = nowTime.split("/")[2]
		var nowshi = getTime.getHours()
		var noefen = getTime.getMinutes()
		var nowmiao = getTime.getSeconds()
		if(mouth < 10) {
			mouth = "0" + mouth
		}
		if(day < 10) {
			day = "0" + day
		}
		if(nowshi < 10) {
			nowshi = "0" + nowshi
		}
		if(noefen < 10) {
			noefen = "0" + noefen
		}
		if(nowmiao < 10) {
			nowmiao = "0" + nowmiao
		}
		_self.$data.nowtime = nowshi + ":" + noefen + ":" + nowmiao
		var printTime = year + "-" + mouth + "-" + day
		_self.$data.printTime = printTime
		_self.form.MissionStartDate = formDate(printTime);
		//					_self.form.MissionStartDate = formDate("2018-02-05");
		//					this.initData();
		//获取参数
		if(paramMap.tuihui == 1) {
			this.starnews()
		}

	},
	// 在 `methods` 对象中定义方法
	methods: {
		starnews: function() {
			var _self = this
			var param = {
				id: paramMap.id,
				//														uid: "10395",
			}
			axios.post(getUrl() + "/contract/get_content", param).then(function(response) {
				if(response.data.code == 200) {
					var res = response.data.result
					if(response.data.result.confirm == 2) {
						console.log(res)
						var Json = JSON.parse(res.contentJson)
						_self.$data.biandan2 = Json.type
						_self.$data.biandan1 = Json.name
						_self.$data.form.MissionStartDate = Json.dateFasheng.split(' ')[0]
						_self.$data.beizhu = Json.beizhu
						_self.$data.boforecompanyname = JSON.parse(res.contentJson).companyBuyName
						_self.$data.boforecompanyId = JSON.parse(res.contentJson).companyBuyID
						_self.$data.boforeroomId = JSON.parse(res.contentJson).companyBuyRoomID
						//接收单位

						//								gongsialllei=JSON.parse(res.noralJson).gongsialllei
						//								for(var i = 0; i < response.data.result.flowList.length; i++) {
						_self.$data.gongsiall.push(JSON.parse(res.noralJson).tablefields.companyBuyName.split(",").toString())
						for(var i = 0; i < JSON.parse(res.noralJson).gongsialllei.length; i++) {
							_self.$data.gongsialllei.push(JSON.parse(res.noralJson).gongsialllei[i])
						}
						//									_self.$data.gongsialllei.push(JSON.parse(res.noralJson).gongsialllei)
						//										startuiid.push(response.data.result.flowList[i].)
						//										_self.$data.gongsiall.tuiroomimid
						//								}
						console.log(JSON.parse(res.noralJson))
						_self.$data.starroomimid = JSON.parse(res.noralJson).toImid
						//附件图片
						if(res.attachments == null) {
							res.attachments = []
							_self.$data.twofujiannum = 0
						} else {
							_self.$data.twofujiannumid = "," + res.attachments.attachmentIds
							_self.$data.twofujiannum = res.attachments.length
						}
						for(var i = 0; i < res.attachments.length; i++) {
							if(res.attachments[i].type == 1) {
								_self.$data.imgs.push({
									src: res.attachments[i].thumbnailurl
								});
								_self.$data.twoimgid.push(res.attachments[i].id)
							} else if(res.attachments[i].type == 2) {
								_self.$data.fujians.push({
									src: res.attachments[i].thumbnailurl,
									name: res.attachments[i].filename
								});
								fujianid.push(res.attachments[i].id)
							}
						}
						_self.$data.attachmentIds = res.attachmentIds
						//退回提交信息
						_self.$data.tuicfgid = res.contractId
						_self.$data.tuiprojectSn = JSON.parse(res.contentJson).projectSN
						_self.$data.tuiroomid = res.roomId
						_self.$data.tuiroomname = res.roomName
						_self.$data.tuiprojectName = JSON.parse(res.contentJson).projectName
						_self.$data.tuicompanySaleID = JSON.parse(res.contentJson).companySaleID
						_self.$data.companySaleName = JSON.parse(res.contentJson).companySaleName
						_self.$data.companySaleRoomID = JSON.parse(res.contentJson).companySaleRoomID
						_self.$data.boforeroomImId = JSON.parse(res.noralJson).toImid
						_self.$data.boforeroomId = JSON.parse(res.noralJson).tablefields.companyBuyRoomID
						paramMap.cfgid = res.contractId
						_self.$data.cfgid = res.contractId
					}
				} else {
					msg("获取初始数据失败")
				}
			})
		},
		getnews: function() {
			var _self = this
			axios.post(getUrl() + "/chart/column/table_w_danjutypecfg?used=getName&type=1&companyName=" + isRoomName + "&companyId=" + isRoomCreditCode).then(function(response) {
				if(response.data.code == 200) {
					//								console.log(response)
					_self.$data.sites = response.data.result;

				} else {
					msg("获取业务类别失败")
				}
			})
		},
		selectDate: function(t) {
			$(".mask1").css("display", "block")
			var o = this;
			// hx
			if(t == "s") {
				if(o.form.MissionStartDate != "") {
					opt.value = o.form.MissionStartDate;
				}
			} else if(t === 'e') {
				if(o.form.MissionEndDate != "") {
					opt.value = o.form.MissionEndDate;
				}
			} else if(t === 'd') {
				if(o.form.datejiexiang != "") {
					opt.value = o.form.datejiexiang;
				}
			}

			picker.show(function(rs) {
				/*
				 * rs.value 拼合后的 value
				 * rs.text 拼合后的 text
				 * rs.y 年，可以通过 rs.y.vaue 和 rs.y.text 获取值和文本
				 * rs.m 月，用法同年
				 * rs.d 日，用法同年
				 * rs.h 时，用法同年
				 * rs.i 分（minutes 的第二个字母），用法同年
				 */
				opt["value"] = rs.value; //控件同步
				if(t == "s") {
					o.form.MissionStartDate = rs.value;
				} else if(t === 'e') {
					o.form.MissionEndDate = rs.value;
				} else if(t === 'd') {
					o.form.datejiexiang = rs.value;
				}
				//							picker.dispose(); //释放资源
			})
			$(".mui-dtpicker .mui-btn[data-id=btn-cancel]")[0].addEventListener('tap', function() {
				$(".mask1").css("display", "none")
			})
			$(".mui-dtpicker .mui-btn[data-id=btn-ok]")[0].addEventListener('tap', function() {
				$(".mask1").css("display", "none")
			})
		},

		aa: function(CONTENT) {
			var _self = this
			_self.$data.chenk2 = 1
			var befroecompany = new Array()
			var befroecompanylei = new Array()
			var boforeroomImId = new Array()
			var boforecompanyId = new Array()
			var boforeroomId = new Array()
			var tui = []
			var tuiimid = new Array()
			//						msg(JSON.parse(CONTENT.result).length)
			for(var i = 0; i < JSON.parse(CONTENT.result).length; i++) {
				//							alert(JSON.stringify(CONTENT.result))
				/************************/
				befroecompany.push(JSON.parse(CONTENT.result)[i].roomName)
				alert(JSON.parse(CONTENT.result)[i].roomClassName)
				if(JSON.parse(CONTENT.result)[i].roomClassName = 'undefined') {
					befroecompanylei.push({
						"leibie": JSON.parse(CONTENT.result)[i].roomName,
						"roomName": JSON.parse(CONTENT.result)[i].roomName
					})
				} else {
					befroecompanylei.push({
						"leibie": JSON.parse(CONTENT.result)[i].roomClassName,
						"roomName": JSON.parse(CONTENT.result)[i].roomName
					})
				}
				boforeroomImId.push(JSON.parse(CONTENT.result)[i].roomImId)
				boforecompanyId.push(JSON.parse(CONTENT.result)[i].companyId)
				boforeroomId.push(JSON.parse(CONTENT.result)[i].roomId)
				_self.$data.tuisongrooimid.push(JSON.parse(CONTENT.result)[i].roomImId)
				tuiimid.push(JSON.parse(CONTENT.result)[i].roomImId)
				tui.push({
					"name": JSON.parse(CONTENT.result)[i].roomName,
					"id": JSON.parse(CONTENT.result)[i].roomImId
				})
			}
			//						_self.$data.boforeroomImId = boforeroomImId.toString()
			_self.$data.tuisong = tui

			if(paramMap.tuihui == 1) { //退回状态

				if(_self.$data.starroomimid.length == 0) {
					_self.$data.tuiroomimid = tuiimid.toString()
				} else {
					_self.$data.tuiroomimid = tuiimid.toString() + _self.$data.starroomimid
				}
			} else {
				_self.$data.boforeroomImId = tuiimid.toString()
				//							if(_self.$data.boforeroomImId== '') {
				//								_self.$data.tuiroomimid = tuiimid.toString()
				//							} else {
				//								_self.$data.tuiroomimid = tuiimid.toString()+ ","+ _self.$data.boforeroomImId
				//							}
				//							_self.$data.boforeroomImId = _self.$data.boforeroomImId+","+tuiimid.toString()
			}

			//						msg(typeof _self.$data.tuisong)
			//						msg("//"+_self.$data.tuisong)
			_self.$data.gongsiall = befroecompany
			_self.$data.gongsialllei = befroecompanylei
			_self.$data.boforecompanyname = befroecompany.toString()
			_self.$data.boforecompanynamelei = befroecompanylei
			_self.$data.boforeroomId = boforeroomId.toString()
			//						if(_self.$data.boforecompanyname == '') {
			//							_self.$data.boforecompanyname = befroecompany.toString()
			//						} else {
			//							_self.$data.boforecompanyname += befroecompany.toString()
			//						}
			//						if(_self.$data.boforecompanyId == '') {
			//							_self.$data.boforecompanyId = boforecompanyId.toString()
			//						} else {
			//							_self.$data.boforecompanyId += boforecompanyId.toString()
			//						}
			//						if(_self.$data.boforeroomId == '') {
			//							_self.$data.boforeroomId = boforeroomId.toString()
			//						} else {
			//							_self.$data.boforeroomId =_self.$data.boforeroomId+","+ boforeroomId.toString()
			//						}
		},
		//选公司
		xuangongsi: function() { //xiaoshou
			var _self = this
			window.appApi.openProjectContactSelectPage(projectSn, '', _self.$data.boforeroomId, 3, true,false,false)
		},
		//保存
		save: function() {
			//获取数据
			var _self = this;
			//						alert(_self.$data.cfgid)
			//						var fjid = imgid.toString()imgid fujianid
			var fjid
			//						alert(_self.$data.attachmentIds)
			if(_self.$data.attachmentIds == '') {
				_self.$data.attachmentIds = ''
			} else {
				_self.$data.attachmentIds = "," + _self.$data.attachmentIds
			}
			if(imgid.toString() == '') {
				fjid = fujianid.toString()
			} else if(fujianid.toString() == '') {
				fjid = imgid.toString()
			} else {
				fjid = imgid.toString() + "," + fujianid.toString()
			}
			imgid = _self.$data.zrimg.length + _self.$data.zrfujian.length
			if(paramMap.tuihui == 1) {

				//							var tuicfgid=response.data.result.contractId
				//								var tuiprojectSn=JSON.parse(response.data.result.contentJson).projectSN 
				//								var tuiroomid=response.data.result.roomId
				//								var tuiroomname=response.data.roomName
				//								var tuiprojectName=JSON.parse(response.data.result.contentJson).projectName
				//								var tuicompanySaleID=JSON.parse(response.data.result.contentJson).companySaleID
				//								var companySaleName=JSON.parse(response.data.result.contentJson).companySaleName
				//								var companySaleRoomID=JSON.parse(response.data.result.contentJson).companySaleRoomID
				paramMap.cfgid = _self.$data.tuicfgid
				projectSn = _self.$data.tuiprojectSn
				isRoomId = _self.$data.tuiroomid
				isRoomName = _self.$data.tuiroomname
				isRoomCreditCode = _self.$data.tuicompanySaleID
				projectName = _self.$data.tuiprojectName
			}
			if(_self.$data.chenk2 != 1) {
				_self.$data.tuiroomimid = _self.$data.starroomimid
			}
			//						alert(_self.$data.boforeroomImId)
			var param = {
				table: {
					id: paramMap.cfgid,
					projectid: projectSn,
					roomid: isRoomId,
					roomname: isRoomName

				},
				attachment: fjid + _self.$data.attachmentIds,
				toroomimid: _self.$data.boforeroomImId,
				gongsialllei: _self.$data.gongsialllei,
				currRoomImId: _self.$data.currRoomImId,
				toImid: _self.$data.boforeroomImId,
				kannews: {
					//推送方
					from_roomimid: _self.$data.currRoomImId,
					from_username: decodeURI(username),
					from_roomid: isRoomId,
					//接收方
					toroomid: _self.$data.boforecompanyId,
				},
				//																					uid: "10395",
				tablefields: {
					userName: decodeURI(username),
					userID: userid,
					dateShenqing: _self.$data.printTime + " " + _self.$data.nowtime,
					projectName: projectName,
					projectSN: projectSn,
					companySaleName: isRoomName,
					companySaleID: isRoomCreditCode,
					companySaleRoomID: isRoomId,
					companyBuyName: _self.$data.boforecompanyname,
					companyBuyID: _self.$data.boforecompanyId,
					//								companyBuyID:"121,122,123",
					companyBuyRoomID: _self.$data.boforeroomId,
					name: _self.$data.biandan1,
					type: _self.$data.biandan2,
					dateFasheng: _self.$data.form.MissionStartDate + " " + _self.$data.nowtime,
					beizhu: _self.$data.beizhu,
					confirmStatus: "", //确认状态
					confirmPersonName: "",
					confirmPersonID: "",
					//								id: paramMap.id
				},
				subtablefields: [],
			}
			//						alert("当前roomimid"+paramMap.currRoomImId)
			console.log(param)
			//						alert(imgid+"///"+_self.$data.twofujiannum)
			//alert(JSON.stringify(param))
			axios.post(getUrl() + "/contract/save", param).then(function(response) {
				if(response.data.code == 200) {
					_self.$data.id = response.data.result.id
					var succname = []
					var faliename = []
					//								var todojson = {
					////									"title": decodeURI(username) + "的收发件",
					//									"title": "收发件："+_self.$data.biandan1,
					//									"titileTwo": paramMap.currRoomClassName + "-" + isRoomName,
					//									"content": "业务类别=" + _self.$data.biandan2 + "|发生日期=" + _self.$data.form.MissionStartDate,
					////									"fileCount": imgid+_self.$data.twofujiannum,
					//									"fileCount":"0",
					//									"url": getUr()+ '/static/newwebstatic/lianxi/work_kan.html?id=' + response.data.result.id + "&formroomimid="+_self.$data.currRoomImId+"&fromcurrRoomName="+_self.$data.currRoomClassName,
					//									"colorString": "",
					//									"todoViewableMember": "0",
					//									"toImId": _self.$data.boforeroomImId,
					////									"toImId":'44252288581633',
					//									"formuserid": userid,
					//									"currentRoomImid": paramMap.currRoomImId,
					//									"chatType": "2",
					//									"relation": response.data.result.id,
					//									"score": "", //评分待办必要参数，设置分数
					//									"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
					//									"setButton": [{
					//										"type": 1, //按钮点击类型 1=请求url 2=打开url
					//										"name": "确认",
					//										"url": getUr()+"/contract/do_todobtu?type=1&pingfen=0&docid="+paramMap.cfgid+"&roomId="+paramMap.currRoomId+"&roomName="+paramMap.currRoomName+"&projectSn="+paramMap.projectSn+"&userid="+userid,
					//									}, {
					//										"type": 1, //按钮点击类型 1=请求url 2=打开url
					//										"name": "确认",
					//										"url": getUr()+"/contract/do_todobtu?type=1&pingfen=0&docid="+paramMap.cfgid+"&roomId="+paramMap.currRoomId+"&roomName="+paramMap.currRoomName+"&projectSn="+paramMap.projectSn+"&userid="+userid,
					//									}]
					//
					//								}
					//								alert(JSON.stringify(todojson))
					//		
					//								window.appApi.sendTodo(todojson,function(d){
					//									if(d.code==200){
					sessionStorage.setItem("save", "save")
					msg("保存成功")
					//										remin("保存成功",2,function(){
					//											window.appApi.closeNewWindow()
					//										})
					//									}

					//								})

				} else {
					msg("提交失败")
				}
			}).catch(function(error) {
				msg(error);
			})
		},
		//提交
		mask2tishi: function() {
			msg("数据提交中，请勿重复点击")
		},
		maskk: function() {
			$(".mask2").css({
				"display": "block",
				"opacity": "0.6"
			})
		},
		sendbtn: function() {
			var _self = this
			app.maskk()
			app.initData()

		},
		sendbtn0: function() {
			var _self = this
			app.maskk()
			app.save()

		},
		initData: function() {

			//获取数据
			var _self = this;
			//						alert(_self.$data.cfgid)
			//						var fjid = imgid.toString()imgid fujianid
			var fjid
			//						alert(_self.$data.attachmentIds)
			if(_self.$data.attachmentIds == '') {
				_self.$data.attachmentIds = ''
			} else {
				_self.$data.attachmentIds = "," + _self.$data.attachmentIds
			}
			if(imgid.toString() == '') {
				fjid = fujianid.toString()
			} else if(fujianid.toString() == '') {
				fjid = imgid.toString()
			} else {
				fjid = imgid.toString() + "," + fujianid.toString()
			}
			imgid = _self.$data.zrimg.length + _self.$data.zrfujian.length
			if(paramMap.tuihui == 1) {

				//							var tuicfgid=response.data.result.contractId
				//								var tuiprojectSn=JSON.parse(response.data.result.contentJson).projectSN 
				//								var tuiroomid=response.data.result.roomId
				//								var tuiroomname=response.data.roomName
				//								var tuiprojectName=JSON.parse(response.data.result.contentJson).projectName
				//								var tuicompanySaleID=JSON.parse(response.data.result.contentJson).companySaleID
				//								var companySaleName=JSON.parse(response.data.result.contentJson).companySaleName
				//								var companySaleRoomID=JSON.parse(response.data.result.contentJson).companySaleRoomID
				paramMap.cfgid = _self.$data.tuicfgid
				projectSn = _self.$data.tuiprojectSn
				isRoomId = _self.$data.tuiroomid
				isRoomName = _self.$data.tuiroomname
				isRoomCreditCode = _self.$data.tuicompanySaleID
				projectName = _self.$data.tuiprojectName
			}
			if(_self.$data.chenk2 != 1) {
				_self.$data.tuiroomimid = _self.$data.starroomimid
			}
			//						alert(_self.$data.boforeroomImId)
			var param = {
				table: {
					id: paramMap.cfgid,
					projectid: projectSn,
					roomid: isRoomId,
					roomname: isRoomName

				},
				attachment: fjid + _self.$data.attachmentIds,
				toroomimid: _self.$data.boforeroomImId,
				gongsialllei: _self.$data.gongsialllei,
				//							toImid:"43371363106817",
				currRoomImId: _self.$data.currRoomImId,
				toImid: _self.$data.boforeroomImId,
				//							toImid:'44252288581633',
				uid: "10395",
				tablefields: {
					userName: decodeURI(username),
					userID: userid,
					dateShenqing: _self.$data.printTime + " " + _self.$data.nowtime,
					projectName: projectName,
					projectSN: projectSn,
					companySaleName: isRoomName,
					companySaleID: isRoomCreditCode,
					companySaleRoomID: isRoomId,
					companyBuyName: _self.$data.boforecompanyname,
					companyBuyID: _self.$data.boforecompanyId,
					//								companyBuyID:"121,122,123",
					companyBuyRoomID: _self.$data.boforeroomId,
					name: _self.$data.biandan1,
					type: _self.$data.biandan2,
					dateFasheng: _self.$data.form.MissionStartDate + " " + _self.$data.nowtime,
					beizhu: _self.$data.beizhu,
					confirmStatus: "", //确认状态
					confirmPersonName: "",
					confirmPersonID: "",
					//								id: paramMap.id
				},
				subtablefields: [],
			}
			//						alert("当前roomimid"+paramMap.currRoomImId)
			console.log(param)
			//						alert(imgid+"///"+_self.$data.twofujiannum)
			//alert(JSON.stringify(param))
			axios.post(getUrl() + "/contract/save", param).then(function(response) {
				if(response.data.code == 200) {
					_self.$data.id = response.data.result.id
					var succname = []
					var faliename = []
					var todojson = {
						"title": decodeURI(username) + "的收发件：" + _self.$data.biandan1,
						"titileTwo": paramMap.currRoomClassName + "-" + isRoomName,
						"content": "类别=" + _self.$data.biandan2 + "|日期=" + _self.$data.form.MissionStartDate,
						"fileCount": "0",
						"url": getUrl() + '/static/newwebstatic/lianxi/work_kan.html?id=' + _self.$data.id + "&formroomimid=" + _self.$data.currRoomImId + "&fromcurrRoomName=" + _self.$data.currRoomClassName,
						"colorString": "",
						"todoViewableMember": "0",
						"toImId": _self.$data.boforeroomImId,
						"formuserid": userid,
						"currentRoomImid": paramMap.currRoomImId,
						"chatType": "2",
						"relation": response.data.result.id,
						"score": "", //评分待办必要参数，设置分数
						"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
						"setButton": [{
							"type": 1, //按钮点击类型 1=请求url 2=打开url
							"name": "确认",
							"url": getUrl() + "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&roomId=" + paramMap.roomId + "&roomName=" + paramMap.roomName + "&projectSn=" + paramMap.projectSn + "&userid=" + userid,
						}, {
							"type": 1, //按钮点击类型 1=请求url 2=打开url
							"name": "退回",
							"url": getUrl() + "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id,
						}]

					}

					window.appApi.sendTodo(todojson)

				} else {
					msg("提交失败")
				}
			}).catch(function(error) {
				msg(error);
			})
			//								var todojson = {
			////									"title": decodeURI(username) + "的收发件",
			//									"title": decodeURI(username)+"的收发件："+_self.$data.biandan1,
			//									"titileTwo": paramMap.currRoomClassName + "-" + isRoomName,
			//									"content": "类别=" + _self.$data.biandan2 + "|日期=" + _self.$data.form.MissionStartDate,
			////									"fileCount": imgid+_self.$data.twofujiannum,
			//									"fileCount":"0",
			//									"url": getUr()+ '/static/newwebstatic/lianxi/work_kan.html?id=' + _self.$data.id + "&formroomimid="+_self.$data.currRoomImId+"&fromcurrRoomName="+_self.$data.currRoomClassName,
			//									"colorString": "",
			//									"todoViewableMember": "0",
			//									"toImId": _self.$data.boforeroomImId,
			////									"toImId":'44252288581633',
			//									"formuserid": userid,
			//									"currentRoomImid": paramMap.currRoomImId,
			//									"chatType": "2",
			//									"relation": response.data.result.id,
			//									"score": "", //评分待办必要参数，设置分数
			//									"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
			//									"setButton": [{
			//										"type": 1, //按钮点击类型 1=请求url 2=打开url
			//										"name": "确认",
			//										"url": getUr()+"/contract/do_todobtu?type=1&pingfen=0&docid="+paramMap.cfgid+"&roomId="+paramMap.currRoomId+"&roomName="+paramMap.currRoomName+"&projectSn="+paramMap.projectSn+"&userid="+userid,
			//									}, {
			//										"type": 1, //按钮点击类型 1=请求url 2=打开url
			//										"name": "确认",
			//										"url": getUr()+"/contract/do_todobtu?type=1&pingfen=0&docid="+paramMap.cfgid+"&roomId="+paramMap.currRoomId+"&roomName="+paramMap.currRoomName+"&projectSn="+paramMap.projectSn+"&userid="+userid,
			//									}]
			//
			//								}
			//		
			//								window.appApi.sendTodo(todojson,function(d){
			//									if(d.code==200){
			//										remin("提交成功",2,function(){
			//											window.appApi.closeNewWindow()
			//										})
			//									}
			//									
			//								})

		},

		//点击业务类别的编辑按钮
		titler: function() {
			var _self = this
			_self.$data.checktitle = !_self.$data.checktitle
			$(".two_2top").slideToggle()
			$(".two_2top_xia").slideToggle()
			//						$(".mui-btn-move").toggle()
			//						$(".mui-btn-move").css("display", "block")
		},
		changeht: function() {
			var _self = this

			//						$(".section1").addClass("toleftmain")
			$(".titler").css("display", "block")
			$(".mask").css("display", "block")
			$(".section2").removeClass("toright")
			$(".section2").addClass("toleft")
			$(".mask").removeClass("torightmain")
			$(".mask").addClass("toleftmain")

		},
		//增加业务类别
		addlianxi: function() {
			var _self = this
			_self.$data.sites.unshift({
				"name": _self.$data.addname
			})
			_self.$data.addname = ''
			//						if(_self.$data.checktitle){

			//						}
		},
		//删除业务类别
		movelianxi: function(n) {
			var _self = this
			if(_self.$data.sites.length > 1) {
				_self.$data.sites.splice(n, 1)
			}
		},
		mask: function() {
			app.addordele()
			//						$(".mask").addClass("torightmain")
			$(".section2").addClass("toright")
			$(".section2").removeClass("toleft")
			$(".mask").addClass("torightmain")
			$(".mask").css("display", "none")
			$(".titler").css("display", "none")
			$(".mui-btn-move").css("display", "none")
			$(".two_2top").css("display", "none")
			//						$(".mask").css("display", "none")
			//						$(".titler").css("display", "none")
			//						$(".two_2top").css("display", "none")
			//						$(".two_2top_xia").css("display", "none")
			//						$(".mui-btn-move").css("display", "none")
			//						$(".addlei").val("")
			//						$(".mask").animate({
			//							left: "0%"
			//						})
			//						$(".section1").animate({
			//							left: "0%"
			//						})
			//						$(".section2").animate({
			//							left: "100%"
			//						})
		},
		//选择业务类别
		yewu: function(event) {
			app.addordele()
			var _self = this
			_self.$data.checktitle = false
			_self.$data.biandan2 = event.target.innerHTML
			$(".section2").removeClass("toleft")
			$(".section2").addClass("toright")
			$(".mask").removeClass("toleftmain")
			$(".mask").addClass("torightmain")
			$(".mask").css("display", "none")
			$(".titler").css("display", "none")
			$(".mui-btn-move").css("display", "none")
			$(".two_2top").css("display", "none")
			//						$(".two_2top").css("display", "none")
			//						$(".two_2top_xia").css("display", "none")
			//						$(".mui-btn-move").css("display", "none")
			//						$(".addlei").val("")
			//						$(".mask").animate({
			//							left: "0%"
			//						})
			//						$(".section1").animate({
			//							left: "0%"
			//						})
			//						$(".section2").animate({
			//							left: "100%"
			//						})

		},
		//跳到第二步
		jump2: function() {
			var _self = this
			if(_self.$data.biandan1 == "") {
				msg("请填写标题")
			} else if(_self.$data.biandan2 == "") {
				msg("请选择类别")
			} else {
				$(".section3").css("display", "block")
				$(".section3").siblings("section").css("display", "none")
			}
		},
		//跳到第1步
		jump1: function() {
			$(".section1").css("display", "block")
			$(".section1").siblings("section").css("display", "none")
		},
		//跳到第3步
		jump3: function() {
			var _self = this
			var jienum = $(".jieshoubox").length
			if(_self.$data.chenk2 != 1 && jienum == 0) {
				msg("请选择接收单位")
			} else {
				$(".section5").css("display", "block")
				$(".section5").siblings("section").css("display", "none")
			}
		},
		//增减业务类别
		addordele: function() {
			var _self = this
			var yewuname = []
			for(i in _self.$data.sites) {
				yewuname.push(_self.$data.sites[i].name)
			}
			var param = {
				"type": "1",
				"companyName": isRoomName,
				"companyID": isRoomCreditCode,
				"names": yewuname.toString(),
			}
			var urlcan = "type=1&companyName=" + isRoomName + "&companyID=" + isRoomCreditCode + "&names=" + yewuname.toString()

			console.log(getUrl() + "/chart/column/insert_w_danjutypecfg?" + urlcan)
			axios.post(getUrl() + "/chart/column/insert_w_danjutypecfg?" + urlcan).then(function(response) {
				console.log(response)
				if(response.data.code == 200) {
					console.log(response)
				}
			}).catch(function(error) {
				msg(error);
			})
		},
		//上传文件
		upfile: function(event) {
			loading("上传中")
			sessionStorage.removeItem("cunnews")
			var _self = this
			var file = document.getElementById(event.target.id).files;
			var zrid = document.getElementById(event.target.id).getAttribute("id")
			var url = getUrl() + "/sass_api/upload_file";
			var form = new FormData();
			var forimg = []
			var forfile = []
			for(var i = 0; i < file.length; i++) {
				form.append("file", file[i]);
				//读取图片数据
				var f = document.getElementById(event.target.id).files[i];
				var imgtype = f.type.split('/')[0]
				if(zrid == "file") {
					var reader = new FileReader();
					reader.onload = function(e) {
						var data = e.target.result;
						//加载图片获取图片真实宽度和高度
						var image = new Image();
						image.onload = function() {
							width = image.width;
							height = image.height;

						};
						image.src = data;
						//									_self.$data.imgs.push({
						//										src: image.src
						//									})
						forimg.push({
							src: image.src
						})
					};
					sessionStorage.setItem("cunnews", "1")
					reader.readAsDataURL(f);
				} else if(zrid == "files") {
					sessionStorage.setItem("cunnews", "2")
					var na = file[i].name
					//								_self.$data.fujians.push({
					//									name: f.name
					//								})
					forfile.push({
						name: f.name
					})
					console.log(_self.$data.fujians)
				}
				//							reader.readAsDataURL(f);

			}
			if(sessionStorage.getItem("cunnews") == 1) {
				form.append("type", "1");
			} else {
				form.append("type", "2");
			}
			form.append("module", "contractnote");
			form.append("userid", userid);
			xhr = new XMLHttpRequest();
			xhr.open("post", url, true);
			xhr.onload = function(evt) {
				//请求完成
				//							var data = JSON.parse(evt.target.responseText);
				//							if(sessionStorage.getItem("cunnews") == 1) {
				//								imgid.push(data.result.success)
				//								_self.$data.zrimg = imgid.toString().split(',')
				//							} else {
				//								fujianid.push(data.result.success)
				//								_self.$data.zrfujian = fujianid.toString().split(',')
				//								console.log(fujianid.toString())
				//							}
				layer.close(loading("上传中"))
			};
			xhr.onreadystatechange = function(evt) {
				console.log(xhr)
				if(xhr.readyState == 4 && xhr.status == 200) {
					console.log(xhr.responseText);
					var data = JSON.parse(evt.target.responseText);
					if(sessionStorage.getItem("cunnews") == 1) {
						_self.$data.imgs = _self.$data.imgs.concat(forimg)
						if(data.result.success.indexOf(",") == -1) {
							imgid.push(data.result.success)
						} else {
							imgid = imgid.concat(data.result.success.split(","))
						}

						//										imgid.push(data.result.success)
						console.log(imgid)
						_self.$data.zrimg = imgid.toString().split(',')
					} else {
						if(data.result.success.indexOf(",") == -1) {
							fujianid.push(data.result.success)
						} else {
							fujianid = fujianid.concat(data.result.success.split(","))
						}

						//										fujianid.push(data.result.success)
						_self.$data.fujians = _self.$data.fujians.concat(forfile)
						_self.$data.zrfujian = fujianid.toString().split(',')
						console.log(fujianid.toString())
					}

				} else if(xhr.readyState == 4 && xhr.status == 500) {
					msg("上传失败")
				}
			}
			xhr.onerror = function(evt) {
				//请求失败
				var data = JSON.parse(evt.target.responseText);
				msg("请求失败")
				console.log("data");
			};
			xhr.send(form);

		},
		moveimg: function(n) {
			var _self = this;
			console.log(n)
			imgid.splice(n - 1, 1)
			console.log(imgid)
			console.log(imgid.toString())
			//						console.log(_self.$data.imgs)
			_self.$data.imgs.splice(n - 1, 1)
			//						console.log(_self.$data.imgs)
			//						console.log(n-1)
			//						console.log(_self.$data.zrimg)
			_self.$data.zrimg.splice(n - 1, 1)
			//						console.log(_self.$data.zrimg)
			//						console.log(typeof JSON.stringify(_self.$data.zrimg))
			//						console.log(imgid[1])
			//						imgid.remove(n-1)
		},
		movefj: function(n) {
			var _self = this;
			fujianid.splice(n - 1, 1)
			_self.$data.fujians.splice(n - 1, 1)
			//						console.log(n-1)
			_self.$data.zrfujian.splice(n - 1, 1)
			console.log(_self.$data.zrfujian)
			console.log(typeof JSON.stringify(_self.$data.zrfujian))
			//						console.log(imgid[1])
			//						imgid.remove(n-1)
		}
	},
})

function formDate(value) {
	var date = new Date(value);
	Y = date.getFullYear(),
		m = date.getMonth() + 1,
		d = date.getDate(),
		H = date.getHours(),
		i = date.getMinutes(),
		s = date.getSeconds();
	if(m < 10) {
		m = '0' + m;
	}
	if(d < 10) {
		d = '0' + d;
	}
	if(H < 10) {
		H = '0' + H;
	}
	if(i < 10) {
		i = '0' + i;
	}
	if(s < 10) {
		s = '0' + s;
	}
	//		<!-- 获取时间格式 2017-01-03 10:13:48 -->
	// var t = Y+'-'+m+'-'+d+' '+H+':'+i+':'+s;
	//		<!-- 获取时间格式 2017-01-03 -->
	var t = Y + '-' + m + '-' + d;
	return t;
}

function submitSuccess(d) {
    if(d.code == 200) {
        remin("提交成功", 2, function() {
            $(".mask2").css({
                "display": "none",
                "opacity": "0.6"
            })
        })
		setTimeout(function () {
            window.appApi.closeNewWindow()
        },200)
    }
}
var webPath = getUrl()
var pagepath = getPagePath()
var paramMap = getParam(window.location.href); //获取地址栏参数
var nehrf = location.href
//获取的地址栏参数
var loginType = paramMap.loginType
var projectSn = paramMap.projectSn
var projectName = paramMap.projectName
var currUserPhone = paramMap.currUserPhone
var currRoomId = paramMap.currRoomId
var currRoomName = paramMap.currRoomName
var currRoomCreditCode = paramMap.currRoomCreditCode
var isRoomId = paramMap.isRoomId
var isRoomName = paramMap.isRoomName
var isRoomCreditCode = paramMap.isRoomCreditCode
//			alert(paramMap.currRoomImId+"/////"+paramMap.currRoomClassName)
//当前用户
var userid = getCookie("userid")
var username = getCookie("username")

localStorage.removeItem("urlnews")
var urlnews = location.href.split("?")[1]
localStorage.setItem("urlnews", urlnews)
//选公司回调
window.appApi.callBackFun = function(callFlag, CONTENT) {
	if(callFlag == appApi.callBackFlag.GONGSI) {
		app.aa(CONTENT);
	}
}

var imgid = [] //全局变量获取attachment
var fujianid = [] //全局变量获取attachment
var opt = {
	"type": "date",
	"beginYear": 2000,
	"endYear": new Date().getFullYear() + 10
};
var picker = new mui.DtPicker(opt);
var app = new Vue({
	el: '#app',
	data: {
		currRoomImId: paramMap.isRoomImId,
		currRoomClassName: paramMap.currRoomClassName,
		nes: nehrf,
		checktitle: false,
		addname: "",
		sites: [],
		gongsiall: [],
		gongsialllei: [],
		imgs: [],
		fujians: [],
		zrimg: [],
		zrfujian: [],
		pinpai: '',
		mingcheng: "",
		form: {
			// 开工日期
			MissionStartDate: "",
		},
		biandan1: "",
		biandan2: "",
		biandan3: "",
		biandan4: "",
		chenk2: "",
		beizhu: "",
		printTime: "",
		nowtime: "",
		companySaleName: isRoomName,
		companySaleID: isRoomCreditCode,
		companySaleRoomID: isRoomId,
		boforeroomId: "",
		boforecompanyname: "",
		boforecompanynamelei: "",
		boforeroomImId: "",
		boforecompanyId: "",
		tuisongrooimid: [], //推送roomimid
		tuisong: [],
		id: "",

		tuiroomimid: "",
		tuisongsuccessname: [],
		tuisongfailename: [],
		lururen: decodeURI(username),
		starroomimid: '',
		tuicfgid: '',
		tuiprojectSn: '',
		tuiroomid: '',
		tuiroomname: '',
		tuiprojectName: '',
		tuicompanySaleID: '',
		companySaleName: '',
		tuicurrRoomImId: '',
		tuicurRoomName: '',
		companySaleRoomID: '',
		cfgid: "",
		twoimgid: [],
		twofujiannum: 0,

		//选公司
		changename: [],
		changeid: [],
		attachmentIds: "",
		twofujiannumid: "",
		tuihui: '',
		tijao: '',
		//地址拦信息
		pa_cigid: paramMap.cfgid,
		pa_projectsn: paramMap.projectSn,
		pa_isroomid: paramMap.isRoomId,
		pa_isroomname: paramMap.isRoomName,
		pa_projectName: paramMap.projectName,
		pa_isRoomCreditCode: paramMap.isRoomCreditCode,
		pa_isroomid: paramMap.isRoomId,
		tuistatus: '',
		firstsave:''

	},
	created: function() {
		var _self = this;
		sessionStorage.removeItem("save") //删除判断是否保存的本地判断
		_self.getnews()
		var getTime = new Date()
		var nowTime = getTime.toLocaleDateString()
		var year = nowTime.split("/")[0]
		var mouth = nowTime.split("/")[1]
		var day = nowTime.split("/")[2]
		var nowshi = getTime.getHours()
		var noefen = getTime.getMinutes()
		var nowmiao = getTime.getSeconds()
		if(mouth < 10) {
			mouth = "0" + mouth
		}
		if(day < 10) {
			day = "0" + day
		}
		if(nowshi < 10) {
			nowshi = "0" + nowshi
		}
		if(noefen < 10) {
			noefen = "0" + noefen
		}
		if(nowmiao < 10) {
			nowmiao = "0" + nowmiao
		}
		_self.$data.nowtime = nowshi + ":" + noefen + ":" + nowmiao
		var printTime = year + "-" + mouth + "-" + day
		_self.$data.printTime = printTime
		_self.form.MissionStartDate = formDate(printTime);
		//					_self.form.MissionStartDate = formDate("2018-02-05");
		//					this.initData();
		//获取参数
		this.fromto()
	},
	// 在 `methods` 对象中定义方法
	methods: {
		fromto: function() {
			var _self = this
			var param = {
				id: paramMap.id,
			}
			axios.post(getUrl() + "/contract/get_content", param).then(function(response) {
				if(response.data.code == 200) {
					var res = response.data.result
					if(res.confirm == 2) {
						_self.$data.tuihui = 1
						app.starnews()
					}
				}
			})
		},

		starnews: function() {
			var _self = this
			var param = {
				id: paramMap.id,
			}
			axios.post(getUrl() + "/contract/get_content", param).then(function(response) {
				if(response.data.code == 200) {
					var res = response.data.result
					_self.$data.tuistatus = 1
					if(response.data.result.confirm == 2) {
						console.log(res)
						var Json = JSON.parse(res.contentJson)
						_self.$data.biandan2 = Json.type
						_self.$data.biandan1 = Json.name
						_self.$data.form.MissionStartDate = Json.dateFasheng.split(' ')[0]
						_self.$data.beizhu = Json.beizhu
						_self.$data.boforecompanyname = JSON.parse(res.contentJson).companyBuyName
						_self.$data.boforecompanyId = JSON.parse(res.contentJson).companyBuyID
						_self.$data.boforeroomId = JSON.parse(res.contentJson).companyBuyRoomID
						//接收单位
						_self.$data.gongsiall.push(JSON.parse(res.noralJson).tablefields.companyBuyName.split(",").toString())
						for(var i = 0; i < JSON.parse(res.noralJson).gongsialllei.length; i++) {
							_self.$data.gongsialllei.push(JSON.parse(res.noralJson).gongsialllei[i])
						}
						//						console.log(JSON.parse(res.noralJson))
						_self.$data.starroomimid = JSON.parse(res.noralJson).toImid
						//附件图片
						if(res.attachments == null) {
							res.attachments = []
							_self.$data.twofujiannum = 0
						} else {
							_self.$data.twofujiannumid = "," + res.attachments.attachmentIds
							_self.$data.twofujiannum = res.attachments.length
						}
						for(var i = 0; i < res.attachments.length; i++) {
							if(res.attachments[i].type == 1) {
								_self.$data.imgs.push({
									src: res.attachments[i].thumbnailurl
								});
								_self.$data.twoimgid.push(res.attachments[i].id)
							} else if(res.attachments[i].type == 2) {
								_self.$data.fujians.push({
									src: res.attachments[i].thumbnailurl,
									name: res.attachments[i].filename
								});
								fujianid.push(res.attachments[i].id)
							}
						}
						_self.$data.attachmentIds = res.attachmentIds
						//退回提交信息
						_self.$data.tuicfgid = res.contractId
						_self.$data.tuiprojectSn = JSON.parse(res.contentJson).projectSN
						_self.$data.tuiroomid = res.roomId
						_self.$data.tuiroomname = res.roomName
						_self.$data.tuiprojectName = JSON.parse(res.contentJson).projectName
						_self.$data.tuicompanySaleID = JSON.parse(res.contentJson).companySaleID
						_self.$data.companySaleName = JSON.parse(res.contentJson).companySaleName
						_self.$data.companySaleRoomID = JSON.parse(res.contentJson).companySaleRoomID
						_self.$data.boforeroomImId = JSON.parse(res.noralJson).toImid
						_self.$data.boforeroomId = JSON.parse(res.noralJson).tablefields.companyBuyRoomID
						_self.$data.tuicurrRoomImId = JSON.parse(res.noralJson).currRoomImId
						_self.$data.tuicurRoomName = JSON.parse(res.noralJson).curRoomName
						paramMap.cfgid = res.contractId
						_self.$data.cfgid = res.contractId
					}
				} else {
					msg("获取初始数据失败")
				}
			})
		},
		getnews: function() {
			var _self = this
			axios.post(getUrl() + "/chart/column/table_w_danjutypecfg?used=getName&type=1&companyName=" + isRoomName + "&companyId=" + isRoomCreditCode).then(function(response) {
				if(response.data.code == 200) {
					//								console.log(response)
					_self.$data.sites = response.data.result;

				} else {
					msg("获取业务类别失败")
				}
			})
		},
		selectDate: function(t) {
			$(".mask1").css("display", "block")
			var o = this;
			// hx
			if(t == "s") {
				if(o.form.MissionStartDate != "") {
					opt.value = o.form.MissionStartDate;
				}
			} else if(t === 'e') {
				if(o.form.MissionEndDate != "") {
					opt.value = o.form.MissionEndDate;
				}
			} else if(t === 'd') {
				if(o.form.datejiexiang != "") {
					opt.value = o.form.datejiexiang;
				}
			}

			picker.show(function(rs) {
				/*
				 * rs.value 拼合后的 value
				 * rs.text 拼合后的 text
				 * rs.y 年，可以通过 rs.y.vaue 和 rs.y.text 获取值和文本
				 * rs.m 月，用法同年
				 * rs.d 日，用法同年
				 * rs.h 时，用法同年
				 * rs.i 分（minutes 的第二个字母），用法同年
				 */
				opt["value"] = rs.value; //控件同步
				if(t == "s") {
					o.form.MissionStartDate = rs.value;
				} else if(t === 'e') {
					o.form.MissionEndDate = rs.value;
				} else if(t === 'd') {
					o.form.datejiexiang = rs.value;
				}
				//							picker.dispose(); //释放资源
			})
			$(".mui-dtpicker .mui-btn[data-id=btn-cancel]")[0].addEventListener('tap', function() {
				$(".mask1").css("display", "none")
			})
			$(".mui-dtpicker .mui-btn[data-id=btn-ok]")[0].addEventListener('tap', function() {
				$(".mask1").css("display", "none")
			})
		},

		aa: function(CONTENT) {
			alert(JSON.stringify(CONTENT))
			var _self = this
			_self.$data.chenk2 = 1
			var befroecompany = new Array()
			var befroecompanylei = new Array()
			var boforeroomImId = new Array()
			var boforecompanyId = new Array()
			var boforeroomId = new Array()
			var tui = []
			var tuiimid = new Array()
			for(var i = 0; i < JSON.parse(CONTENT.result).length; i++) {
				/************************/
				befroecompany.push(JSON.parse(CONTENT.result)[i].roomName)
				if(JSON.parse(CONTENT.result)[i].roomClassName = 'undefined') {
					befroecompanylei.push({
						"leibie": JSON.parse(CONTENT.result)[i].roomName,
						"roomName": JSON.parse(CONTENT.result)[i].roomName
					})
				} else {
					befroecompanylei.push({
						"leibie": JSON.parse(CONTENT.result)[i].roomClassName,
						"roomName": JSON.parse(CONTENT.result)[i].roomName
					})
				}
				boforeroomImId.push(JSON.parse(CONTENT.result)[i].roomImId)
				if(JSON.parse(CONTENT.result)[i].companyId == '') {
					boforecompanyId.push(JSON.parse(CONTENT.result)[i].roomName)
				}else{
					boforecompanyId.push(JSON.parse(CONTENT.result)[i].companyId)
				}
				
				boforeroomId.push(JSON.parse(CONTENT.result)[i].roomId)
				_self.$data.tuisongrooimid.push(JSON.parse(CONTENT.result)[i].roomImId)
				tuiimid.push(JSON.parse(CONTENT.result)[i].roomImId)
				tui.push({
					"name": JSON.parse(CONTENT.result)[i].roomName,
					"id": JSON.parse(CONTENT.result)[i].roomImId
				})
			}
			_self.$data.tuisong = tui

			if(_self.$data.tuihui == 1) { //退回状态

				if(_self.$data.starroomimid.length == 0) {
					_self.$data.tuiroomimid = tuiimid.toString()
				} else {
					_self.$data.tuiroomimid = tuiimid.toString() + _self.$data.starroomimid
				}
			} else {
				_self.$data.boforeroomImId = tuiimid.toString()
			}

			_self.$data.gongsiall = befroecompany
			_self.$data.gongsialllei = befroecompanylei
			_self.$data.boforecompanyname = befroecompany.toString()
			_self.$data.boforecompanynamelei = befroecompanylei
			_self.$data.boforeroomId = boforeroomId.toString()
			_self.$data.boforecompanyId=boforecompanyId.toString()
		},
		//选公司
		xuangongsi: function() { //xiaoshou
			var _self = this
			window.appApi.openProjectContactSelectPage(projectSn, '', _self.$data.boforeroomId, 3, true,false,false)
		},
		//保存
		save: function() {
			//获取数据
			var _self = this;
			var fjid
			if(_self.$data.attachmentIds == '') {
				_self.$data.attachmentIds = ''
			} else {
				_self.$data.attachmentIds = "," + _self.$data.attachmentIds
			}
			if(imgid.toString() == '') {
				fjid = fujianid.toString()
			} else if(fujianid.toString() == '') {
				fjid = imgid.toString()
			} else {
				fjid = imgid.toString() + "," + fujianid.toString()
			}
			imgid = _self.$data.zrimg.length + _self.$data.zrfujian.length
			if(_self.$data.tuistatus == 1) {

				_self.$data.pa_cigid = _self.$data.tuicfgid
				_self.$data.pa_projectsn = _self.$data.tuiprojectSn
				_self.$data.pa_isroomid = _self.$data.tuiroomid
				_self.$data.pa_isroomname = _self.$data.tuiroomname
				_self.$data.pa_isRoomCreditCode = _self.$data.tuicompanySaleID
				_self.$data.pa_projectName = _self.$data.tuiprojectName
				_self.$data.currRoomImId = _self.$data.tuicurrRoomImId
				_self.$data.currRoomClassName = _self.$data.tuicurRoomName
			}
			if(_self.$data.chenk2 != 1) {
				_self.$data.tuiroomimid = _self.$data.starroomimid
			}
			//						alert(_self.$data.boforeroomImId)

			var tablefields = {
				userName: decodeURI(username),
				userID: userid,
				dateShenqing: _self.$data.printTime + " " + _self.$data.nowtime,
				projectName: _self.$data.pa_projectName,
				projectSN: _self.$data.pa_projectsn,
				companySaleName: _self.$data.pa_isroomname,
				companySaleID: _self.$data.pa_isRoomCreditCode,
				companySaleRoomID: _self.$data.pa_isroomid,
				companyBuyName: _self.$data.boforecompanyname,
				companyBuyID: _self.$data.boforecompanyId,
				companyBuyRoomID: _self.$data.boforeroomId,
				name: _self.$data.biandan1,
				type: _self.$data.biandan2,
				dateFasheng: _self.$data.form.MissionStartDate + " " + _self.$data.nowtime,
				beizhu: _self.$data.beizhu,
				confirmStatus: "", //确认状态
				confirmPersonName: "",
				confirmPersonID: "",
			}
			if(_self.$data.id != '') {
				tablefields["id"] = _self.$data.id
			}
			var param = {
				table: {
					id: _self.$data.pa_cigid,
					projectid: _self.$data.pa_projectsn,
					roomid: _self.$data.pa_isroomid,
					roomname: _self.$data.pa_isroomname,
					userId: userid,
				},
				attachment: fjid + _self.$data.attachmentIds,
				toroomimid: _self.$data.boforeroomImId,
				gongsialllei: _self.$data.gongsialllei,
				currRoomImId: _self.$data.currRoomImId,
				curRoomName: _self.$data.currRoomClassName,
				roomid: _self.$data.pa_isroomid,
				toImid: _self.$data.boforeroomImId,

				//				uid: "10395",
				tablefields: tablefields,
				subtablefields: [],
			}
			console.log(param)
			axios.post(getUrl() + "/contract/save", param).then(function(response) {
				if(response.data.code == 200) {
					$(".mask2").css("display","none")
					_self.$data.firstsave=1
					_self.$data.id = response.data.result.id
					var succname = []
					var faliename = []
//					if(_self.$data.tijao == 1) {
//						var todojson = {
//							"title": decodeURI(username) + "的收发件：" + _self.$data.biandan1,
//							"titileTwo": _self.$data.currRoomClassName + "-" + _self.$data.pa_isroomname,
//							"content": "类别=" + _self.$data.biandan2 + "|日期=" + _self.$data.form.MissionStartDate,
//							"fileCount": "0",
//							"url": getUrl() + '/static/newwebstatic/lianxi/work_kan.html?id=' + _self.$data.id,
//							"colorString": "",
//							"todoViewableMember": "0",
//							"toImId": _self.$data.boforeroomImId,
//							"formuserid": userid,
//							"currentRoomImid": paramMap.currRoomImId,
//							"chatType": "2",
//							"relation": _self.$data.id,
//							"score": "", //评分待办必要参数，设置分数
//							"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
//							"setButton": [{
//								"type": 1, //按钮点击类型 1=请求url 2=打开url
//								"name": "确认",
//								"url": getUrl() + "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&roomId=" + paramMap.roomId + "&roomName=" + paramMap.roomName + "&projectSn=" + paramMap.projectSn + "&userid=" + userid,
//							}, {
//								"type": 1, //按钮点击类型 1=请求url 2=打开url
//								"name": "退回",
//								"url": getUrl() + "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id,
//							}]
//
//						}
//						window.appApi.sendTodo(todojson, function(d) {
//							if(d.code == 200) {
//								remin("提交成功", 2, function() {
//									$(".mask2").css({
//										"display": "none",
//										"opacity": "0.6"
//									})
//									window.appApi.closeNewWindow()
//								})
//							}
//
//						})
//					} else {
						msg("保存成功")
//					}
				} else {
					msg("保存失败")
				}
			}).catch(function(error) {
				msg(error);
			})
		},
		//tuisong
		todo:function(){
			//获取数据
			var _self = this;
			var fjid
			if(_self.$data.attachmentIds == '') {
				_self.$data.attachmentIds = ''
			} else {
				_self.$data.attachmentIds = "," + _self.$data.attachmentIds
			}
			if(imgid.toString() == '') {
				fjid = fujianid.toString()
			} else if(fujianid.toString() == '') {
				fjid = imgid.toString()
			} else {
				fjid = imgid.toString() + "," + fujianid.toString()
			}
			imgid = _self.$data.zrimg.length + _self.$data.zrfujian.length
			if(_self.$data.tuistatus == 1) {

				_self.$data.pa_cigid = _self.$data.tuicfgid
				_self.$data.pa_projectsn = _self.$data.tuiprojectSn
				_self.$data.pa_isroomid = _self.$data.tuiroomid
				_self.$data.pa_isroomname = _self.$data.tuiroomname
				_self.$data.pa_isRoomCreditCode = _self.$data.tuicompanySaleID
				_self.$data.pa_projectName = _self.$data.tuiprojectName
				_self.$data.currRoomImId = _self.$data.tuicurrRoomImId
				_self.$data.currRoomClassName = _self.$data.tuicurRoomName
			}
			if(_self.$data.chenk2 != 1) {
				_self.$data.tuiroomimid = _self.$data.starroomimid
			}
			//						alert(_self.$data.boforeroomImId)

			var tablefields = {
				userName: decodeURI(username),
				userID: userid,
				dateShenqing: _self.$data.printTime + " " + _self.$data.nowtime,
				projectName: _self.$data.pa_projectName,
				projectSN: _self.$data.pa_projectsn,
				companySaleName: _self.$data.pa_isroomname,
				companySaleID: _self.$data.pa_isRoomCreditCode,
				companySaleRoomID: _self.$data.pa_isroomid,
				companyBuyName: _self.$data.boforecompanyname,
				companyBuyID: _self.$data.boforecompanyId,
				companyBuyRoomID: _self.$data.boforeroomId,
				name: _self.$data.biandan1,
				type: _self.$data.biandan2,
				dateFasheng: _self.$data.form.MissionStartDate + " " + _self.$data.nowtime,
				beizhu: _self.$data.beizhu,
				confirmStatus: "", //确认状态
				confirmPersonName: "",
				confirmPersonID: "",
			}
			if(_self.$data.id != '') {
				tablefields["id"] = _self.$data.id
			}
			var param = {
				table: {
					id: _self.$data.pa_cigid,
					projectid: _self.$data.pa_projectsn,
					roomid: _self.$data.pa_isroomid,
					roomname: _self.$data.pa_isroomname,
					userId: userid,
				},
				attachment: fjid + _self.$data.attachmentIds,
				toroomimid: _self.$data.boforeroomImId,
				gongsialllei: _self.$data.gongsialllei,
				currRoomImId: _self.$data.currRoomImId,
				curRoomName: _self.$data.currRoomClassName,
				roomid: _self.$data.pa_isroomid,
				toImid: _self.$data.boforeroomImId,

				//				uid: "10395",
				tablefields: tablefields,
				subtablefields: [],
			}
			console.log(param)
			axios.post(getUrl() + "/contract/save", param).then(function(response) {
				if(response.data.code == 200) {
					$(".mask2").css("display","none")
					_self.$data.firstsave=1
					_self.$data.id = response.data.result.id
					var succname = []
					var faliename = []
					if(_self.$data.tijao == 1) {
						var todojson = {
							"title": decodeURI(username) + "的收发件：" + _self.$data.biandan1,
							"titileTwo": _self.$data.currRoomClassName + "-" + _self.$data.pa_isroomname,
							"content": "类别=" + _self.$data.biandan2 + "|日期=" + _self.$data.form.MissionStartDate,
							"fileCount": "0",
							"url": getUrl() + '/static/newwebstatic/lianxi/work_kan.html?id=' + _self.$data.id,
							"colorString": "",
							"todoViewableMember": "0",
							"toImId": _self.$data.boforeroomImId,
							"formuserid": userid,
							"currentRoomImid": paramMap.currRoomImId,
							"chatType": "2",
							"relation": _self.$data.id,
							"score": "", //评分待办必要参数，设置分数
							"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
							"setButton": [{
								"type": 1, //按钮点击类型 1=请求url 2=打开url
								"name": "确认",
								"url": getUrl() + "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&roomId=" + paramMap.roomId + "&roomName=" + paramMap.roomName + "&projectSn=" + paramMap.projectSn + "&userid=" + userid,
							}, {
								"type": 1, //按钮点击类型 1=请求url 2=打开url
								"name": "退回",
								"url": getUrl() + "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id,
							}]

						}
						window.appApi.sendTodo(todojson)
					} else {
						msg("保存成功")
					}
				} else {
					msg("保存失败")
				}
			}).catch(function(error) {
				msg(error);
			})
		},
		//提交
		mask2tishi: function() {
			msg("数据提交中，请勿重复点击")
		},
		maskk: function() {
			$(".mask2").css({
				"display": "block",
				"opacity": "0.6"
			})
		},
		sendbtn: function() { //tijiao
			var _self = this
			_self.$data.tijao = 1
				app.todo()
//			}else{
//				app.maskk()
				_self.$data.tijao = 1
//				app.maskk()
//				app.save()
		},
		sendbtn0: function() { //baocun
			var _self = this
//			if(_self.$data.firstsave==1){
//				msg("已保存")
//			}else{
				_self.$data.tijao = 0
				app.maskk()
				app.save()
//			}
			

		},
		//		initData: function() {
		//
		//			//获取数据
		//			var _self = this;
		//			var fjid
		//			if(_self.$data.attachmentIds == '') {
		//				_self.$data.attachmentIds = ''
		//			} else {
		//				_self.$data.attachmentIds = "," + _self.$data.attachmentIds
		//			}
		//			if(imgid.toString() == '') {
		//				fjid = fujianid.toString()
		//			} else if(fujianid.toString() == '') {
		//				fjid = imgid.toString()
		//			} else {
		//				fjid = imgid.toString() + "," + fujianid.toString()
		//			}
		//			imgid = _self.$data.zrimg.length + _self.$data.zrfujian.length
		//			if(_self.$data.tuihui == 1) {
		//
		//				paramMap.cfgid = _self.$data.tuicfgid
		//				projectSn = _self.$data.tuiprojectSn
		//				isRoomId = _self.$data.tuiroomid
		//				isRoomName = _self.$data.tuiroomname
		//				isRoomCreditCode = _self.$data.tuicompanySaleID
		//				projectName = _self.$data.tuiprojectName
		//			}
		//			if(_self.$data.chenk2 != 1) {
		//				_self.$data.tuiroomimid = _self.$data.starroomimid
		//			}
		//			//						alert(_self.$data.boforeroomImId)
		//			var param = {
		//				
		//				pa_cigid:paramMap.cfgid,
		//				pa_projectsn:paramMap.projectSn,
		//				pa_isroomid:paramMap.isRoomId,
		//				pa_isroomname:paramMap.isRoomName,
		//				pa_projectName: paramMap.projectName,
		//				pa_isRoomCreditCode:paramMap.isRoomCreditCode,
		//				pa_isroomid:paramMap.isRoomId,
		//				
		//				
		//				
		//				table: {
		//					id: _self.$data.pa_cigid,
		//					projectid: _self.$data.pa_projectsn,
		//					roomid: _self.$data.pa_isroomid,
		//					roomname: _self.$data.pa_isroomname
		//
		//				},
		//				attachment: fjid + _self.$data.attachmentIds,
		//				toroomimid: _self.$data.boforeroomImId,
		//				gongsialllei: _self.$data.gongsialllei,
		//				currRoomImId: _self.$data.currRoomImId,
		//				curRoomName:_self.$data.currRoomClassName,
		//				toImid: _self.$data.boforeroomImId,
		//				uid: "10395",
		//				tablefields: {
		//					userName: decodeURI(username),
		//					userID: userid,
		//					dateShenqing: _self.$data.printTime + " " + _self.$data.nowtime,
		//					projectName: _self.$data.pa_projectName,
		//					projectSN: _self.$data.pa_projectsn,
		//					companySaleName: _self.$data.pa_isroomname,
		//					companySaleID: _self.$data.pa_isRoomCreditCode,
		//					companySaleRoomID: _self.$data.pa_isroomid,
		//					companyBuyName: _self.$data.boforecompanyname,
		//					companyBuyID: _self.$data.boforecompanyId,
		//					companyBuyRoomID: _self.$data.boforeroomId,
		//					name: _self.$data.biandan1,
		//					type: _self.$data.biandan2,
		//					dateFasheng: _self.$data.form.MissionStartDate + " " + _self.$data.nowtime,
		//					beizhu: _self.$data.beizhu,
		//					confirmStatus: "", //确认状态
		//					confirmPersonName: "",
		//					confirmPersonID: "",
		//				},
		//				subtablefields: [],
		//			}
		//			console.log(param)
		//			axios.post(getUrl() + "/contract/save", param).then(function(response) {
		//				if(response.data.code == 200) {
		//					_self.$data.id = response.data.result.id
		//					var succname = []
		//					var faliename = []
		//					var todojson = {
		//						"title": decodeURI(username) + "的收发件：" + _self.$data.biandan1,
		//						"titileTwo": _self.$data.currRoomClassName + "-" + _self.$data.pa_isroomname,
		//						"content": "类别=" + _self.$data.biandan2 + "|日期=" + _self.$data.form.MissionStartDate,
		//						"fileCount": "0",
		//						"url": getUrl() + '/static/newwebstatic/lianxi/work_kan.html?id=' + _self.$data.id ,
		//						"colorString": "",
		//						"todoViewableMember": "0",
		//						"toImId": _self.$data.boforeroomImId,
		//						"formuserid": userid,
		//						"currentRoomImid": paramMap.currRoomImId,
		//						"chatType": "2",
		//						"relation": response.data.result.id,
		//						"score": "", //评分待办必要参数，设置分数
		//						"todoType": "3", //1评分待办，生成带有确认按钮待办，生成带有确认拒绝待办，必要参数
		//						"setButton": [{
		//							"type": 1, //按钮点击类型 1=请求url 2=打开url
		//							"name": "确认",
		//							"url": getUrl() + "/contract/do_todobtu?type=1&pingfen=0&docid=" + _self.$data.id + "&roomId=" + paramMap.roomId + "&roomName=" + paramMap.roomName + "&projectSn=" + paramMap.projectSn + "&userid=" + userid,
		//						}, {
		//							"type": 1, //按钮点击类型 1=请求url 2=打开url
		//							"name": "退回",
		//							"url": getUrl() + "/contract/do_todobtu?type=4&pingfen=0&docid=" + _self.$data.id,
		//						}]
		//
		//					}
		//
		//					window.appApi.sendTodo(todojson, function(d) {
		//						if(d.code == 200) {
		//							remin("提交成功", 2, function() {
		//								$(".mask2").css({
		//									"display": "none",
		//									"opacity": "0.6"
		//								})
		//								window.appApi.closeNewWindow()
		//							})
		//						}
		//
		//					})
		//
		//				} else {
		//					msg("提交失败")
		//				}
		//			}).catch(function(error) {
		//				msg(error);
		//			})
		//
		//		},

		//点击业务类别的编辑按钮
		titler: function() {
			var _self = this
			_self.$data.checktitle = !_self.$data.checktitle
			$(".two_2top").slideToggle()
			$(".two_2top_xia").slideToggle()
			$(".titler").css("display", "block")
			$(".mask").css("display", "block")
			$(".section2").removeClass("toright")
			$(".section2").addClass("toleft")
			$(".mask").removeClass("torightmain")
			$(".mask").addClass("toleftmain")

		},
		changeht: function() {
			var _self = this
			$(".titler").css("display", "block")
			$(".mask").css("display", "block")
			$(".section2").removeClass("toright")
			$(".section2").addClass("toleft")
			$(".mask").removeClass("torightmain")
			$(".mask").addClass("toleftmain")
		},
		//增加业务类别
		addlianxi: function() {
			var _self = this
			_self.$data.sites.unshift({
				"name": _self.$data.addname
			})
			_self.$data.addname = ''
		},
		//删除业务类别
		movelianxi: function(n) {
			var _self = this
			if(_self.$data.sites.length > 1) {
				_self.$data.sites.splice(n, 1)
			}
		},
		mask: function() {
			app.addordele()
			//						$(".mask").addClass("torightmain")
			$(".section2").addClass("toright")
			$(".section2").removeClass("toleft")
			$(".mask").addClass("torightmain")
			$(".mask").css("display", "none")
			$(".titler").css("display", "none")
			$(".mui-btn-move").css("display", "none")
			$(".two_2top").css("display", "none")
		},
		//选择业务类别
		yewu: function(event) {
			app.addordele()
			var _self = this
			_self.$data.checktitle = false
			_self.$data.biandan2 = event.target.innerHTML
			$(".section2").removeClass("toleft")
			$(".section2").addClass("toright")
			$(".mask").removeClass("toleftmain")
			$(".mask").addClass("torightmain")
			$(".mask").css("display", "none")
			$(".titler").css("display", "none")
			$(".mui-btn-move").css("display", "none")
			$(".two_2top").css("display", "none")

		},
		//跳到第二步
		jump2: function() {
			var _self = this
			if(_self.$data.biandan1 == "") {
				msg("请填写标题")
			} else if(_self.$data.biandan2 == "") {
				msg("请选择类别")
			} else {
				$(".section3").css("display", "block")
				$(".section3").siblings("section").css("display", "none")
			}
		},
		//跳到第1步
		jump1: function() {
			$(".section1").css("display", "block")
			$(".section1").siblings("section").css("display", "none")
		},
		//跳到第3步
		jump3: function() {
			var _self = this
			var jienum = $(".jieshoubox").length
			if(_self.$data.chenk2 != 1 && jienum == 0) {
				msg("请选择接收单位")
			} else {
				$(".section5").css("display", "block")
				$(".section5").siblings("section").css("display", "none")
			}
		},
		//增减业务类别
		addordele: function() {
			var _self = this
			var yewuname = []
			for(i in _self.$data.sites) {
				yewuname.push(_self.$data.sites[i].name)
			}
			var param = {
				"type": "1",
				"companyName": isRoomName,
				"companyID": isRoomCreditCode,
				"names": yewuname.toString(),
			}
			var urlcan = "type=1&companyName=" + isRoomName + "&companyID=" + isRoomCreditCode + "&names=" + yewuname.toString()

			console.log(getUrl() + "/chart/column/insert_w_danjutypecfg?" + urlcan)
			axios.post(getUrl() + "/chart/column/insert_w_danjutypecfg?" + urlcan).then(function(response) {
				console.log(response)
				if(response.data.code == 200) {
					console.log(response)
				}
			}).catch(function(error) {
				msg(error);
			})
		},
		//上传文件
		upfile: function(event) {
			loading("上传中")
			sessionStorage.removeItem("cunnews")
			var _self = this
			var file = document.getElementById(event.target.id).files;
			var zrid = document.getElementById(event.target.id).getAttribute("id")
			var url = getUrl() + "/sass_api/upload_file";
			var form = new FormData();
			var forimg = []
			var forfile = []
			for(var i = 0; i < file.length; i++) {
				form.append("file", file[i]);
				//读取图片数据
				var f = document.getElementById(event.target.id).files[i];
				var imgtype = f.type.split('/')[0]
				if(zrid == "file") {
					var reader = new FileReader();
					reader.onload = function(e) {
						var data = e.target.result;
						//加载图片获取图片真实宽度和高度
						var image = new Image();
						image.onload = function() {
							width = image.width;
							height = image.height;

						};
						image.src = data;
						forimg.push({
							src: image.src
						})
					};
					sessionStorage.setItem("cunnews", "1")
					reader.readAsDataURL(f);
				} else if(zrid == "files") {
					sessionStorage.setItem("cunnews", "2")
					var na = file[i].name
					forfile.push({
						name: f.name
					})
					console.log(_self.$data.fujians)
				}

			}
			if(sessionStorage.getItem("cunnews") == 1) {
				form.append("type", "1");
			} else {
				form.append("type", "2");
			}
			form.append("module", "contractnote");
			form.append("userid", userid);
			xhr = new XMLHttpRequest();
			xhr.open("post", url, true);
			xhr.onload = function(evt) {
				//请求完成
				layer.close(loading("上传中"))
			};
			xhr.onreadystatechange = function(evt) {
				console.log(xhr)
				if(xhr.readyState == 4 && xhr.status == 200) {
					console.log(xhr.responseText);
					var data = JSON.parse(evt.target.responseText);
					if(sessionStorage.getItem("cunnews") == 1) {
						_self.$data.imgs = _self.$data.imgs.concat(forimg)
						if(data.result.success.indexOf(",") == -1) {
							imgid.push(data.result.success)
						} else {
							imgid = imgid.concat(data.result.success.split(","))
						}

						//										imgid.push(data.result.success)
						console.log(imgid)
						_self.$data.zrimg = imgid.toString().split(',')
					} else {
						if(data.result.success.indexOf(",") == -1) {
							fujianid.push(data.result.success)
						} else {
							fujianid = fujianid.concat(data.result.success.split(","))
						}

						//										fujianid.push(data.result.success)
						_self.$data.fujians = _self.$data.fujians.concat(forfile)
						_self.$data.zrfujian = fujianid.toString().split(',')
						console.log(fujianid.toString())
					}

				} else if(xhr.readyState == 4 && xhr.status == 500) {
					msg("上传失败")
				}
			}
			xhr.onerror = function(evt) {
				//请求失败
				var data = JSON.parse(evt.target.responseText);
				msg("请求失败")
				console.log("data");
			};
			xhr.send(form);

		},
		newwebapp: function() {
			appApi.openNewWindow(getUrl() + '/static/newwebstatic/lianxi/newCreat.html?' + urlnews)
		},
		moveimg: function(n) {
			var _self = this;
			console.log(n)
			imgid.splice(n - 1, 1)
			console.log(imgid)
			console.log(imgid.toString())
			_self.$data.imgs.splice(n - 1, 1)
			_self.$data.zrimg.splice(n - 1, 1)
		},
		movefj: function(n) {
			var _self = this;
			fujianid.splice(n - 1, 1)
			_self.$data.fujians.splice(n - 1, 1)
			//						console.log(n-1)
			_self.$data.zrfujian.splice(n - 1, 1)
			console.log(_self.$data.zrfujian)
			console.log(typeof JSON.stringify(_self.$data.zrfujian))
		}
	},
})

function formDate(value) {
	var date = new Date(value);
	Y = date.getFullYear(),
		m = date.getMonth() + 1,
		d = date.getDate(),
		H = date.getHours(),
		i = date.getMinutes(),
		s = date.getSeconds();
	if(m < 10) {
		m = '0' + m;
	}
	if(d < 10) {
		d = '0' + d;
	}
	if(H < 10) {
		H = '0' + H;
	}
	if(i < 10) {
		i = '0' + i;
	}
	if(s < 10) {
		s = '0' + s;
	}
	//		<!-- 获取时间格式 2017-01-03 10:13:48 -->
	// var t = Y+'-'+m+'-'+d+' '+H+':'+i+':'+s;
	//		<!-- 获取时间格式 2017-01-03 -->
	var t = Y + '-' + m + '-' + d;
	return t;
}

function submitSuccess() {
    if(d.code == 200) {
        remin("提交成功", 2, function() {
            $(".mask2").css({
                "display": "none",
                "opacity": "0.6"
            })
        })
		setTimeout(function () {
            window.appApi.closeNewWindow()
        },200)
    }
}
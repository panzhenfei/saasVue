var common = {
	/**
	 * 附件图标类样式适配
	 * @param {Object} suffix
	 */
	fileType: function(suffix) {
		var clazz = "label-";
		if(suffix && suffix.indexOf(".") > 0) {
			suffix = /\.[^\.]+$/.exec(suffix).toString()
			suffix=suffix.toLowerCase()
		}
		switch(suffix) {
			case ".txt":
				clazz += "txt";
				break;
			case ".doc":
				clazz += "word";
				break;
			case ".docm":
				clazz += "word";
				break;
			case ".dotx":
				clazz += "word";
				break;
			case ".dotm":
				clazz += "word";
				break;
			case ".docx":
				clazz += "word";
				break;
			case ".rtf":
				clazz += "word";
				break;
			case ".pdf":
				clazz += "pdf";
				break;
			case ".xls":
				clazz += "excel";
				break;
			case ".ppt":
				clazz += "ppt";
				break;
			case ".pptx":
				clazz += "ppt";
				break;
			case ".xlsx":
				clazz += "excel";
				break;
			case ".xlsm":
				clazz += "excel";
				break;
			case ".xltx":
				clazz += "excel";
				break;
			case ".xltm":
				clazz += "excel";
				break;
			case ".xlsb":
				clazz += "excel";
				break;
			case ".xlam":
				clazz += "excel";
				break;
			case ".rm":
				clazz += "video";
				break;
			case ".rmvb":
				clazz += "video";
				break;
			case ".wmv":
				clazz += "video";
				break;
			case ".avi":
				clazz += "video";
				break;
			case ".mp4":
				clazz += "video";
				break;
			case ".3gp":
				clazz += "video";
				break;
			case ".mkv":
				clazz += "video";
				break;
			case ".navi":
				clazz += "video";
				break;
			case ".mov":
				clazz += "video";
				break;
			case ".asf":
				clazz += "video";
				break;
			case ".png":
				clazz += "img";
				break;
			case ".jpg":
				clazz += "img";
				break;
			case ".jpeg":
				clazz += "img";
				break;
			case ".JPG":
				clazz += "img";
				break;
			case ".gif":
				clazz += "img";
				break;
			case ".zip":
				clazz += "zip";
				break;
			case ".rar":
				clazz += "zip";
				break;
			case ".arj":
				clazz += "zip";
				break;
			case ".z":
				clazz += "zip";
				break;
			case ".apk":
				clazz += "apk";
				break;
			case ".mmap":
				clazz += "mmap";
				break;
			case ".mpg":
				clazz += "mpg";
				break;
			case ".csv":
				clazz += "csv";
				break;
			case ".mpp":
				clazz += "mpp";
				break;
			case ".html":
				clazz += "html";
				break;
			case ".dwg":
				clazz += "dwg";
				break;
			default:
				clazz += "unkown";
				break;
		}
		return clazz;
	}
}
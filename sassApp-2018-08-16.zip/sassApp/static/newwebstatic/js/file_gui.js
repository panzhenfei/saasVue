var webPath = getUrl()
var pagepath = getPagePath()
var paramMap = getParam(window.location.href); //获取地址栏参数
//项目sn
//var projectId = paramMap.projectId
//登陆人id
var userid = getCookie("userid")
var listname
var app = new Vue({
	el: '#app',
	data: {
		itemss:[],
		imgurl:"http://res.winfreeinfo.com:8000",
		sites: [],
		fileall:[],
		projectname: "",
		filesize: "0KB", //选中文件的大小
		filenum: 0,//选中文件的个数
		soncunt:0,//点击目录记录相应的indexx
		count:'',//用于返回时候记录div的index
		fileid:[-1],//保存目录id
		oknext:'1',
		fileshares:[],
		filecount:0,
		section:'',
		projectSn:'',
		listindex:[],
		savalist:[{"id":'-1',"index":"-1"}],
		listnext:'',
		listname:[],//存储点击后的列表
		firstlist:[],
		list2:[],
		parentId:'',
		firindex:''
	},
	created: function() {
		this.filelists()
		appApi.showBack()
	},
	// 在 `methods` 对象中定义方法
	methods: {
		filelists:function(){
			var _self=this
			axios.post(getUrl() + "/chart/column/table_swprojectinfo?used=getMyPro", {}).then(function(response) {
				if(response.data.code==200){
					_self.$data.itemss = response.data.result;
					console.log(_self.$data.itemss)
				}
			}).catch(function(error) {
				console.info(error);
			});
		},
		jump:function(projectSn,index){
			var _self=this
			$(".model1").css("display","none")
			$(".model2").css("display","block")
			_self.$data.soncunt=0
			_self.$data.projectSn=projectSn
			_self.$data.firindex=index
			if(_self.$data.firstlist.indexOf(index)==-1){//第一次点击一级目录
				_self.$data.firindex=index
				_self.$data.listname.push({  //第一级目录
					"name":'name0_'+index,
				})
				$(event.target).parents('ul').addClass("name"+index)
//				name='name0'
//				var clickindex='name0_'+index
//				app.init(index,clickindex)
			}
			var clickindex='name0_'+index
				app.init(index,clickindex)
				$(".model2 ul").css("display","none")
			_self.$data.firstlist.push(index)
		},
		//判断是否是第一次点击目录
		OnceorTwo:function(obj,index,array){
			if(obj.indexOf(index)==-1){//第一次
				
			}
		},
		init: function(par) {
			var _self = this
			axios.post(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + "&userid=" + userid).then(function(response) {
				if(response.data.code == 0) {
					layer.close(loading("加载中"))
					_self.$data.sites.push(response.data.result.data.firstList)
					_self.$data.projectname = response.data.result.data.projectName
					_self.$data.soncunt++
					_self.$data.parentId=response.data.result.data.firstList[0].parentId
					console.log(response.data.result.data.firstList)
				}else{
					loading("加载中")
				}
			}).catch(function(error) {
				console.info(error);
			});

		},
		//查子目录
		son: function(id,type,cla,parentId) {
			var _self = this
				_self.$data.listname.push({  
					"name":'name1_'+cla,
					"parent":name,
					"index":cla
				})	
				loading("加载中")
				if(parentId==null){
					parentId=1
					$(event.target).parents('ul').addClass("name11")
				}else{
					$(event.target).parents('ul').removeClass("name1")
				}
				if(_self.$data.fileid.indexOf(id)==-1){
					app.getnews(id,cla)
				}
				_self.$data.fileid.push(id)
				_self.$data.list2.push(parentId)
				
				$(event.target).parents('ul').addClass("name"+parentId)
				$(event.target).parents('ul').removeClass("ulactive")
//				$(event.target).parents('ul').css("display","none")
		},
		//点击获取对应子目录
		getnews:function(n,cla){
			var _self = this
					var typeall=[] //存储子目录的type
					axios.post(getUrl() + "/cdish/data?projectId=" + _self.$data.projectSn + "&pid=" + n).then(function(response) {
							if(response.data.code == 0) {
								_self.$data.sites.push(response.data.result.data.result)
								var lenth=_self.$data.sites.length-1
								console.log("加载了")
								_self.$data.parentId=response.data.result.data.result[0].parentId
								console.log(response.data.result.data.result)
								app.lastson(typeall)
							}
						}).catch(function(error) {
							alert(error);
						});
//				}
//			}
//			
//			
		},
		//判断时候还有子目录
		lastson:function(typeall){
			var _self = this
			if(typeall.indexOf(1)!=-1){//存在子目录
				_self.$data.soncunt++
				_self.$data.count=_self.$data.soncunt
			}
		},
		sonflie: function(size,name,urls) {
			//是否选中状态
			var checkstatus=$(event.target).parents("li").find("input").prop("checked")
			if(checkstatus==false){
				alert(0)
			}
			var _self = this
			$(".nav_foot").css("display","block")
			var newfile=0
			var oldfile=0
			//选中文件的计算
			
			var newfilesize=_self.$data.filesize.split("K")[1]
			var allsize=size.split("K")[1]
			if(allsize=="B"){
				newfile=Number(size.split("K")[0])
			}else{
				newfile=Number(size.split("M")[0])*1024
			}
			if(newfilesize=="B"){
				oldfile=Number(_self.$data.filesize.split("K")[0])
			}else{
				oldfile=Number(_self.$data.filesize.split("M")[0])*1024
			}
			newfilesize=newfile+Number(_self.$data.filesize)
			if(checkstatus==false){
				$(event.target).parents("li").attr("filecount",_self.$data.filecount)
				_self.$data.fileshares.push({
					"name":name,
					"size":size,
					"urls":urls,
				})
				_self.$data.filecount++
				var lastsize=newfile+oldfile
				_self.$data.filenum++
			}else if(checkstatus==true){
				var lastsize=oldfile-newfile
				var moveindex=$(event.target).parents("li").attr("filecount")
				_self.$data.fileshares.splice(moveindex,1)
				if(_self.$data.filenum>0){
					_self.$data.filenum--
				}
				
				_self.$data.filecount--
			}
			if(lastsize<1024 && lastsize>=0){
				_self.$data.filesize=lastsize+"KB"
			}else if(lastsize<0){
				_self.$data.filesize="0KB"
			}else if(lastsize>1024){
				_self.$data.filesize=parseFloat(lastsize/1024).toFixed(2)+"M"
			}
		},
		//点击返回按钮
		back:function(){
			var _self = this
//			console.log(_self.$data.count)
//			
//			console.log("soncunt="+_self.$data.soncunt)
//			if(_self.$data.count>0){
//				_self.$data.count--
//				_self.$data.soncunt--
//			}
			if(_self.$data.parentId==null){
				$(".model2").css("display","none")
				$(".model1").css("display","block")
				_self.$data.filenum=0
				_self.$data.filesize=0
				$(".nav_foot").css("display","none")
//				appApi.showBack()
				
//				$(".model2 ul").remove()
			}else if($(".ulactive").hasClass("name11")){
				$(".model2").css("display","none")
				$(".model1").css("display","block")
				_self.$data.filenum=0
				_self.$data.filesize=0
				$(".nav_foot").css("display","none")
//				appApi.showBack()
//				$(".model2 ul").remove()
			}else{
				$(".ulactive").addClass('midactive')
				$(".midactive").prev("ul").addClass('ulactive')
				$(".midactive").removeClass("ulactive")
			}
//			if(_self.$data.count==0 && _self.$data.section==3){
//				$(".model1").css("display","block")
//				$(".model2").css("display","none")
//			}
//			if(_self.$data.count==0){
//				_self.$data.section=3
//				_self.$data.soncunt=-1
//				appApi.showBack()
//			}
//			$(".model2 .ul"+_self.$data.count).css("display","block")
//			$(".model2 .ul"+_self.$data.count).siblings("ul").css("display","none")
		},
		//点击确定分享
		share:function(){
			var _self=this
			var param=[]
			for(var i=0;i<_self.$data.fileshares.length;i++){
				param.push({
					"chatType":'1',
					"type":'0',
					"title":_self.$data.fileshares[i].name,
					"content":_self.$data.fileshares[i].size,
					"url":_self.$data.fileshares[i].urls,
					"thumbImgUrl":_self.$data.fileshares[i].urls,
				})
			}
			appApi.setSelectData(param)
		}
	}
})
//阻止点击li冒泡
mui(".mui-table-view").on('tap','.mui-table-view-cell',function(event){     
	event.stopPropagation();
	event.preventDefault()
})
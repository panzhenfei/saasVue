/**
 * 选择工人
 *
 */
var paramMap= getParam(window.location.href);//获取地址栏参数
var userName = decodeURI(getCookie("username"));
var userId = getCookie("userid");
var projectSN=paramMap.projectSN;
    //实例vue
    var app =new Vue({
        el:"#app",
        data:{ //数据
            form:{
                serialNum:"",
            },
            data:{
                selectType:[],
                zuzhiList:[],
            },
            project:{}

        },
        created:function() {

            var _self = this;
            alert(projectSN)
            _self.showRecordById();

        },
        methods:{
           showRecordById:function () {//初始化组织类型
               var _self=this;
               _self.form.serialNum=projectSN;
               var formdata=new FormData();
               formdata.append("json",JSON.stringify(_self.form));
               axios.post(getUrl()+"/project_room_api/find_project",formdata).then(function (response) {
                   if(response.data.code==200){
                       var result=response.data.result;
                       if(result.length>0){
                           _self.project=result[0];
                           _self.project.missionStartDate=formDate(result[0].missionStartDate);
                           _self.project.missionEndDate=formDate(result[0].missionEndDate);

                       }else {
                           msg("未查询到项目信息，请核对记录ID是否正确!")
                           return
                       }

                      console.log(result)
                   }else {
                       msg("查询项目失败!")
                   }
               }).catch(function (error) {
                   console.info(error);
               });
           },

        }
    });


function formDate(value) {
    var date = new Date(value);
    Y = date.getFullYear(),
        m = date.getMonth() + 1,
        d = date.getDate(),
        H = date.getHours(),
        i = date.getMinutes(),
        s = date.getSeconds();
    if (m < 10) {
        m = '0' + m;
    }
    if (d < 10) {
        d = '0' + d;
    }
    if (H < 10) {
        H = '0' + H;
    }
    if (i < 10) {
        i = '0' + i;
    }
    if (s < 10) {
        s = '0' + s;
    }
//  <!-- 获取时间格式 2017-01-03 10:13:48 -->
    // var t = Y+'-'+m+'-'+d+' '+H+':'+i+':'+s;
//  <!-- 获取时间格式 2017-01-03 -->
    var t = Y + '-' + m + '-' + d;
    return t;
}
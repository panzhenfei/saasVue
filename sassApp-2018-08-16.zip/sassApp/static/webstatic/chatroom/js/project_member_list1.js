/**
 * 选择子管理员列表
 *
 */

var paramMap= getParam(window.location.href);//获取地址栏参数
var projectSN=paramMap.projectSN;
var method=paramMap.method;
    //实例vue
    var app =new Vue({
        el:"#app",
        data:{ //数据
            form:{
            },
            data:{
                memberList:[],//项目成语列表
                recivememberList:[],//项目成语列表
                selectIdList:[],
                selectUserList:[],
            },
            selectSize:0,
            createDate:"",
            recordType:"",
            imghost:UPLOAD_SERVER_ADDRESS,
        },
        created:function() {//初始化方法
            var _self = this;
            if(method=="list"){
                _self.findroomuserlist();
            }
            if(method=="add"){
                document.getElementById("selectSize").innerHTML=0;
                _self.addprojectmanage();
            }
        },
        methods:{
            findroomuserlist:function () {//查询项目子管理员
                var _self = this;
                var formdata = new FormData();
                var ary = paramMap.project;
                ary = JSON.parse(ary);
                if(ary.length>0){
                    for(var i=0;i<ary.length;i++){
                        if(ary[i]!=null){
                            _self.data.recivememberList.push(ary[i]);
                        }
                    }
                }
                if(ary.length==0){
                formdata.append("projectSn", projectSN)
                axios.post(getUrl() + "/pcontact_api/findprojectmanage", formdata).then(function (response) {
                    if (response.data.code == 0) {
                        var result = response.data.result;
                        if (result != null && result.length > 0) {
                            _self.data.recivememberList = result;
                        }
                    }
                }).catch(function (error) {
                    msg(error)
                    console.info(error);
                });
                }
            },
            addprojectmanage:function () {//查询所有子管理员
                var _self=this;
                var formdata=new FormData();
                formdata.append("projectSn",projectSN)
                axios.post(getUrl()+"/pcontact_api/findprojectmember",formdata).then(function (response) {
                    if(response.data.code==0){
                        var result=response.data.result;
                        if(result!=null&&result.length>0){
                            _self.data.memberList=result;
                            var userIdList=JSON.parse(paramMap.param);
                                    for (var i=0;i<userIdList.length;i++){
                                        _self.data.memberList.removeUser(userIdList[i]);
                                    }

                        }



                    }
                }).catch(function (error) {
                    msg(error)
                    console.info(error);
                });

            },
             returnXiangMuInfo:function(){//返回管理员列表
                 var _self=this;
                 var ary=_self.data.recivememberList

                 setTimeout(function(){
                     appApi.broadcast("setProjectManageChildList("+JSON.stringify(ary)+")");//返回上一页并设置标准工资页面
                     appApi.closeNewWindow();

                 },100);

            },
            addProjectMember:function(){
                var _self=this;
                var selectuserIdList=[];
                var param=null;
                var select = _self.data.recivememberList;
                for(var i in select){
                    if(select[i].userId){
                        selectuserIdList.push(select[i].userId);
                    }

                }

                appApi.openNewWindow(pagepath+'/chatroom/project_member_add.html?projectSN='+projectSN+"&method=add&param="+JSON.stringify(selectuserIdList));
            },


            selectUser:function () {//选择工人
                var _self=this;
                setTimeout(function () {
                    _self.data.selectIdList=_self.getSelectVal();
                    document.getElementById("selectSize").innerHTML=_self.data.selectIdList.length;
                },200)

            },
            cancel:function () {//取消选中
                var _self=this;
                _self.data.selectIdList=[];
                _self.selectSize=0;
            },
            getSelectVal: function() {//选择工人
                var _self=this
                //获取所有返回的值
                var obj = document.getElementsByName("selectItem");
                var select_arr = [];
                _self.data.selectUserList=[];
                for(var k in obj) {
                    if(obj[k].checked && undefined != obj[k].value){
                        var userobj=new Object();
                        userobj.userId=obj[k].value;
                        userobj.cellPhone=obj[k].getAttribute("cellPhone");
                        userobj.imId=obj[k].getAttribute("imId");
                        userobj.nickName=obj[k].getAttribute("nickName");
                        userobj.userIcon=obj[k].getAttribute("userIcon");
                        _self.data.selectUserList.push(userobj);
                        select_arr.push(obj[k].value);
                    }

                }
                console.info(select_arr);
                return select_arr;
            },
            popup:function(content){
                msg(content);
            },
            deleteMember:function(val){
                var _self=this;
                _self.data.recivememberList.remove(val);
            },

        }
    });

    /**
     * 确认
     */
    window.confirm=function () {
        if(app.data.selectUserList.length<=0){
            msg("请选择工人")
            return;
        }
        localStorage.setItem("lastname", JSON.stringify(app.data.selectUserList));
        setTimeout(function () {
            appApi.closeNewWindow();
            appApi.broadcast("setMemberList("+JSON.stringify(app.data.selectUserList)+")");//返回上一页并设置标准工资页面
        },100);
    }






//*********移除数组元素******开始**********

Array.prototype.indexOfUser = function (val) {
    for (var i = 0; i < this.length; i++) {
        if (this[i].userId == val) return i;
    }
    return -1;
};


Array.prototype.removeUser = function (val) {
    var index = this.indexOfUser(val);
    if (index > -1) {
        this.splice(index, 1);
    }
};

//*********移除数组元素******结束**********


/**
 * 接收选择的项目成员列表
 * @param ary
 */
function setMemberList(ary) {
    if(ary.length>0){
        for(var i=0;i<ary.length;i++){
            if(ary[i]!=null){
                app.data.recivememberList.push(ary[i]);
            }
        }
    }

}





var app = new Vue({
	el: "#file_detail",
	data: {
		from:"list",
		status:false,
		curInfo:{},
		reqParams:{
			id:"",
			shareId:"",
			affirmId:""
		},
        isOpe:false
	},
	created: function () {
		var _self = this;
		//获取参数
		var params = getParam(window.location.href);
		if (params.hasOwnProperty("id")) {
			if (params.hasOwnProperty("from")) {
				_self.$data.from = params.from;
				if(_self.$data.from == "share"  && params.hasOwnProperty("shareId")){
					_self.$data.reqParams.shareId = params.shareId;
				}
				if(_self.$data.from == "affirm" && params.hasOwnProperty("affirmId")){
					_self.$data.reqParams.affirmId = params.affirmId;
				}
			}
			if (params.isOpe=='false'||params.isOpe==false){
                _self.$data.isOpe = true;
			}else{
                _self.$data.isOpe = false;
			}
			_self.initData(params.id);
			_self.downLoadInit();
		}
	},
	methods: {
		initData:function (id) {
			var _self = this;
			//获取数据
			_self.$data.reqParams.id = id;
			axios.post(getUrl() + "/cdish/dish/detail",_self.$data.reqParams).then(function (response) {
				if (response.data.code == 0) {
					var rs = response.data.result;
					_self.$data.curInfo = rs;
					_self.$data.curInfo.createTime = cmApi.timeFormat(_self.$data.curInfo.createTime);
					_self.$data.status = true;
				} else {
					msg(response.data.message)
				}
			})
		},
		rename:function (isOpe) {
			if (isOpe){
				return;
			}
			var _self = this;
			if(_self.$data.curInfo.projectId == null || _self.$data.curInfo.projectId == undefined || _self.$data.curInfo.projectId == ""){
				return;
			}
			appApi.openNewWindow(getPagePath() + "/dish/rename_file.html?id=" + _self.$data.curInfo.id + "&name=" + _self.$data.curInfo.fileName);

		},
		openDirMini:function () {
			var _self = this;
			if(_self.$data.curInfo.projectId == null || _self.$data.curInfo.projectId == undefined || _self.$data.curInfo.projectId == ""){
				return;
			}
			var url = getPagePath() + "/dish/open_dir.html?id=" + _self.$data.curInfo.dirId + "&projectSN=" +  _self.$data.curInfo.projectId;
			if(_self.$data.curInfo.sys){
				url = url + "&isSys=true";
			}
			window.appApi.openNewWindow(url);
		},
		downLoadInit:function () {
			//下载初始化
			var _self = this;
			var html =  '<iframe id="downloadWidget" class="mui-hidden"></iframe>';
			document.getElementById("file_detail").insertAdjacentHTML('afterend', html);
			downloadWidget = document.getElementById("downloadWidget");
		},
		getFileUrl:function (id) {
			return getUrl() + "/cdish/file/download?id=" + id;
		},
		downloadFile:function () {
			var _self = this;
			var id = _self.$data.curInfo.id;
			if(isApp){
				appApi.openFile( _self.getFileUrl(id));
			}else{
				downloadWidget.src = _self.getFileUrl(id);
			}
			_self.$data.showEditBox = false;
		},
	}
});
Array.prototype.contains = function (obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
}
Vue.filter('formDate', function (value) {//value为13位的时间戳
	return app.formDate(value);
});

var app = new Vue({
	el: "#move_select",
	data: {
		loadStatus:false,
		imageHost:UPLOAD_SERVER_ADDRESS,
		curInfo:{},
		curList:[],
		moveType:0,//0 待归档文件移动（不包括文件夹）（全部显示）  1 标准目录内进行文件移动 （显示标准目录）2 待归档目录下文件和文件夹移动  （显示待归档目录）
		reqParams:{
			nodeId:-1, //文件夹id
			projectId:""
		},
		moveParams:{
			batchIds:"", //多文件（夹）
			id:0, //单文件夹
			projectId:"",
			parentId:0,//目标文件夹id
		},
		isSys:false, //判断是否为待归档目录
		createBtnStatus:false, //新建文件夹显示状态
		moveBtnStatus:false, //移动显示状态
		lastDirId:0, //上一个文件夹id
		curDirId:0 //当前文件夹id
	},
	created: function () {
		var _self = this;
		//获取参数
		var params = getParam(window.location.href);
		if (params.hasOwnProperty("moveType") && params.hasOwnProperty("moveItems") &&  undefined != params.moveItems && params.hasOwnProperty("projectId")) {
			_self.$data.moveType = params.moveType;
			_self.$data.moveParams.batchIds = params.moveItems;
			/*if(params.moveItems.indexOf(",") >-1){

			}else if(!isNaN(params.moveItems)){
				_self.$data.moveParams.id = parseInt(params.moveItems);
			}else{
				return;
			}*/
			_self.$data.moveParams.projectId = params.projectId;
			_self.$data.reqParams.projectId = params.projectId;
			_self.initData(); //加载目录结构
		}
	},
	methods: {
		initData:function (id) {
			loading("正在加载目录信息...")
			var _self = this;
			//获取数据
			if(id){
				_self.$data.reqParams.nodeId = id;
				_self.$data.lastDirId = id;
				_self.$data.moveBtnStatus = true;
			}else{
				_self.$data.moveBtnStatus = false;
			}
			axios.post(getUrl() + "/cdish/mlist", _self.$data.reqParams).then(function (response) {
				if (response.data.code == 0) {
					var list = response.data.result;
					if(undefined == id && _self.$data.moveType != 0){
						//说明此时仅显示标准目录或且待归档目录
						for(var i=0;i<list.length;i++){
							if(list[i].sysDir && _self.$data.moveType == 1){
								_self.$data.curList.push(list[i])
							}else if(!list[i].sysDir && _self.$data.moveType == 2){
								_self.$data.curList.push(list[i])
							}
						}
					}else{
						_self.$data.curList = list;
					}
					_self.$data.loadStatus = true;
				} else {
					msg("获取云盘目录信息失败")
				}
				layer.closeAll();
			})
		},
		fileType:function (suffix) {
			var clazz = "label-";
			if(suffix && suffix.indexOf(".") > 0){
				suffix = suffix.substring(suffix.indexOf("."),suffix.length);
			}
			switch (suffix){
                case ".txt":
                    clazz += "txt";
                    break;
                case ".doc":
                    clazz += "word";
                    break;
                case ".docm":
                    clazz += "word";
                    break;
                case ".dotx":
                    clazz += "word";
                    break;
                case ".dotm":
                    clazz += "word";
                    break;
                case ".docx":
                    clazz += "word";
                    break;
                case ".rtf":
                    clazz += "word";
                    break;
                case ".pdf":
                    clazz += "pdf";
                    break;
                case ".xls":
                    clazz += "excel";
                    break;
                case ".ppt":
                    clazz += "ppt";
                    break;
                case ".pptx":
                    clazz += "ppt";
                    break;
                case ".xlsx":
                    clazz += "excel";
                    break;
                case ".xlsm":
                    clazz += "excel";
                    break;
                case ".xltx":
                    clazz += "excel";
                    break;
                case ".xltm":
                    clazz += "excel";
                    break;
                case ".xlsb":
                    clazz += "excel";
                    break;
                case ".xlam":
                    clazz += "excel";
                    break;
                case ".rm":
                    clazz += "video";
                    break;
                case ".rmvb":
                    clazz += "video";
                    break;
                case ".wmv":
                    clazz += "video";
                    break;
                case ".avi":
                    clazz += "video";
                    break;
                case ".mp4":
                    clazz += "video";
                    break;
                case ".3gp":
                    clazz += "video";
                    break;
                case ".mkv":
                    clazz += "video";
                    break;
                case ".navi":
                    clazz += "video";
                    break;
                case ".mov":
                    clazz += "video";
                    break;
                case ".asf":
                    clazz += "video";
                    break;
                case ".png":
                    clazz += "img";
                    break;
                case ".gif":
                    clazz += "img";
                    break;
                case ".zip":
                    clazz += "zip";
                    break;
                case ".rar":
                    clazz += "zip";
                    break;
                case ".arj":
                    clazz += "zip";
                    break;
                case ".z":
                    clazz += "zip";
                    break;
                case ".apk":
                    clazz += "apk";
                    break;
                case ".mmap":
                    clazz += "mmap";
                    break;
                case ".mpg":
                    clazz += "mpg";
                    break;
                case ".csv":
                    clazz += "csv";
                    break;
                case ".mpp":
                    clazz += "mpp";
                    break;
                case ".html":
                    clazz += "html";
                    break;
                case ".dwg":
                    clazz += "dwg";
                    break;
                default:
                    clazz += "unkown";
                    break;
			}
			return clazz;
		},
		formDate: function (value) {
			var date = new Date(value);
			Y = date.getFullYear(),
				m = date.getMonth() + 1,
				d = date.getDate(),
				H = date.getHours(),
				i = date.getMinutes(),
				s = date.getSeconds();
			if (m < 10) {
				m = '0' + m;
			}
			if (d < 10) {
				d = '0' + d;
			}
			if (H < 10) {
				H = '0' + H;
			}
			if (i < 10) {
				i = '0' + i;
			}
			if (s < 10) {
				s = '0' + s;
			}
			//<!-- 获取时间格式 2017-01-03 10:13:48 -->
			//var t = Y+'-'+m+'-'+d+' '+H+':'+i+':'+s;
			//<!-- 获取时间格式 2017-01-03 -->
			//var t = Y + '-' + m + '-' + d;
			var t = Y + '/' + m + '/' + d + ' ' + H + ':' + i;
			return t;
		},
		nextDir: function (id,type,name,sysDir,status,event) {
			var _self = this;
			var arrs = _self.$data.moveParams.batchIds.split(",");
			console.log(arrs)
			var a = new Array
            console.log(a.contains(1))
			if(arrs.contains(id)){
				msg("无法移动到此文件夹");
				return;
			}
			if(type == 1){
				_self.$data.lastDirId = _self.$data.curDirId;
				_self.$data.curDirId = id;
				_self.$data.moveParams.parentId = id;
				_self.initData(id);
				if(sysDir){
					//标准目录不允许创建文件夹
					_self.$data.createBtnStatus = false;
					_self.$data.isSys = true;
				}else{
					_self.$data.createBtnStatus = true;
					_self.$data.isSys = false;
				}
			}
		},
		createDir: function () {
			var _self = this;
			if(_self.$data.isSys == true ||  _self.$data.isSys == "true"){
				msg("系统目录下不可新建文件夹")
				return;
			}
			appApi.openNewWindow(getPagePath() + "/dish/create_dir.html?pid=" + _self.$data.curDirId);
		},
		doMove:function () {
			loading("移动中...");
			var _self = this;
			_self.$data.moveParams.parentId = _self.$data.curDirId;
			axios.post(getUrl() + "/cdish/batch/move", _self.$data.moveParams).then(function (response) {
				if (response.data.code == 0) {
					var rs = response.data.result;
					if(rs.fail_code == 5018){
						layer.closeAll();
						msg(rs.fail_message);
						return;
					}
					if(rs.fail_num!=0){
						msg("已成功移动" + rs.success_num + "项，" +  rs.fail_num + "项移动失败！");
					}else{
						msg("已成功移动" + rs.success_num + "项");
					}
					setTimeout(function () {
						layer.closeAll();
						appApi.broadcast("refreshPage()");
						if(isApp){
							appApi.closeNewWindow();
						}
						_self.openDirMini(_self.$data.moveParams.parentId,_self.$data.isSys);
					},2000)
				} else {
					msg(response.data.message)
				}

				setTimeout(function () {
					layer.closeAll()
				},1000)
			})
		},
		openDirMini:function (id,isSys) {
			var _self = this;
			var url = getPagePath() + "/dish/open_dir.html?id=" + id + "&projectSN=" + _self.$data.moveParams.projectId;
			if(isSys){
				url = url + "&isSys=true";
			}
			window.appApi.openNewWindow(url);
		},
	}
});

var refreshPage = function () {
	app.initData(app.$data.curDirId);
}
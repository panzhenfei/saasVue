/*文件夹相关操作 wyj 2017-8-20*/

var app = new Vue({
	el: "#dir_info",
	data: {
		status:false,
		name:"",
		curInfo:{}
	},
	created: function () {
		var _self = this;
		//获取参数
		var params = getParam(window.location.href);
		if (params.hasOwnProperty("pid")) {
			 //添加文件夹
			var callBack = function (rs) {
				_self.$data.curInfo = rs.data;
        }
			_self.initData(params.pid,callBack);
		}
		if (params.hasOwnProperty("name")) {
			//修改文件夹
			_self.$data.name = params.name;
		}

		if (params.hasOwnProperty("id")) {
			//修改文件夹
			var callBack = function (rs) {
				_self.$data.curInfo = rs.data;
				_self.$data.name = _self.$data.curInfo.name;
			}
			_self.initData(params.id,callBack);
		}
	},
	methods: {
		initData:function (dirId,callBack) {
			var _self = this;
			//获取数据
			axios.get(getUrl() + "/cdish/data?dirId=" + dirId).then(function (response) {
				if (response.data.code == 0) {
					var rs = response.data.result;
					if(callBack) callBack(rs)
				} else {
					msg(response.data.message)
				}
			})
		},
		addDir:function () {
			var _self = this;
			if(_self.$data.status){
				return;
			}
			_self.$data.status = true;
			if(_self.$data.name == ""){
				warm("请输入文件名")
				_self.$data.status = false;
				return;
			}
			//添加文件夹
			var params = {
				projectId:_self.$data.curInfo.projectId,
				name:_self.$data.name,
				parentId:_self.$data.curInfo.id,
				sysDir:_self.$data.curInfo.sysDir,
				// roomId:_self.$data.curInfo.roomId
			};
			axios.post(getUrl() + "/cdish/dir/add",params).then(function (response) {
				if (response.data.code == 0) {
					//所有页面刷新
					if(isApp){
						appApi.broadcast("refreshPage()");
						appApi.closeNewWindow();
					}else{
						window.history.back();
					}
				} else {
					msg(response.data.message)
				}
				/*_self.$data.status = false;*/
			})

		},
		renameDir:function () {
			var _self = this;
			if(_self.$data.status){
				return;
			}
			_self.$data.status = true;
			if(_self.$data.name == ""){
				warm("请输入文件名")
				_self.$data.status = false;
				return;
			}
			var params = getParam(window.location.href);
			if(_self.$data.name == params.name){
				//未修改
				appApi.closeNewWindow();
				return;
			}
			//修改文件夹
			var params = {
				name:_self.$data.name,
				id:_self.$data.curInfo.id
			};
			axios.post(getUrl() + "/cdish/dir/rename",params).then(function (response) {
				if (response.data.code == 0) {
					//所有页面刷新
					if(isApp){
						appApi.broadcast("refreshPage()");
						appApi.closeNewWindow();
					}else{
						window.history.back();
					}
				} else {
					msg(response.data.message)
				}
				_self.$data.status = false;
			})

		}

	}
});
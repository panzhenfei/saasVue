/*文件夹相关操作 wyj 2017-8-20*/
var app = new Vue({
	el: "#file_info",
	data: {
		status:false,
		name:"",
		curInfo:{}
	},
	created: function () {
		var _self = this;
		//获取参数
		var params = getParam(window.location.href);
		if (params.hasOwnProperty("pid")) {
			 //添加文件夹
			_self.initData(params.pid);
		}
		if (params.hasOwnProperty("name")) {
			//修改文件夹
			_self.$data.name = params.name;
		}
		if (params.hasOwnProperty("id")) {
			//修改文件夹
			_self.initData(params.id);
		}
	},
	methods: {
		initData:function (dirId) {
			var _self = this;
			//获取数据
			axios.get(getUrl() + "/cdish/data?dirId=" + dirId).then(function (response) {
				if (response.data.code == 0) {
					var rs = response.data.result;
					_self.$data.curInfo = rs.data;
					_self.$data.name = _self.$data.curInfo.name;
				} else {
					msg(response.data.message)
				}
			})
		},
		renameFile:function () {
			var _self = this;
			if(_self.$data.status){
				return;
			}
			_self.$data.status = true;
			if(_self.$data.name == ""){
				warm("请输入文件名")
				_self.$data.status = false;
				return;
			}
			var params = getParam(window.location.href);
			if(_self.$data.name == params.name){
				//未修改
				appApi.closeNewWindow();
				return;
			}
			//修改文件夹
			var params = {
				name:_self.$data.name,
				id:_self.$data.curInfo.id
			};
			axios.post(getUrl() + "/cdish/file/rename",params).then(function (response) {
				if (response.data.code == 0) {
					_self.$data.status = false;
					//所有页面刷新
					if(isApp){
						appApi.broadcast("refreshPage()");
						appApi.closeNewWindow();
					}else{
						window.history.back();
					}
				} else {
					_self.$data.status = false;
					msg(response.data.message)
				}
			})

		}

	}
});

Vue.filter('formDate', function (value) {//value为13位的时间戳
	return app.formDate(value);
});

var app = new Vue({
	el: "#upload_select",
	data: {
		loadStatus:false,
		imageHost:UPLOAD_SERVER_ADDRESS,
		curInfo:{},
		curList:[],
		projectId:"",
		reqParams:{
			nodeId:-1, //文件夹id
			projectId:""
		},
		isSys:false, //判断是否为待归档目录
		createBtnStatus:false, //新建文件夹显示状态
		uploadBtnStatus:false, //移动上传状态
		lastDirId:0, //上一个文件夹id
		curDirId:0 //当前文件夹id
	},
	created: function () {
		var _self = this;
		//获取参数
		var params = getParam(window.location.href);
		if (params.hasOwnProperty("projectId")) {
			_self.$data.projectId = params.projectId;
			_self.$data.reqParams.projectId = params.projectId;
			_self.initData(); //加载目录结构
		}
	},
	methods: {
		initData:function (id) {
			loading("正在加载目录信息...")
			var _self = this;
			//获取数据
			if(id){
				_self.$data.reqParams.nodeId = id;
				_self.$data.lastDirId = id;
				_self.$data.uploadBtnStatus = true;
			}else{
				_self.$data.uploadBtnStatus = false;
			}
			axios.post(getUrl() + "/cdish/mlist", _self.$data.reqParams).then(function (response) {
				if (response.data.code == 0) {
					var list = response.data.result;
					_self.$data.curList = list;
					_self.$data.loadStatus = true;
				} else {
					msg("获取云盘目录信息失败")
				}
				layer.closeAll();
			})
		},
		formDate: function (value) {
			var date = new Date(value);
			Y = date.getFullYear(),
				m = date.getMonth() + 1,
				d = date.getDate(),
				H = date.getHours(),
				i = date.getMinutes(),
				s = date.getSeconds();
			if (m < 10) {
				m = '0' + m;
			}
			if (d < 10) {
				d = '0' + d;
			}
			if (H < 10) {
				H = '0' + H;
			}
			if (i < 10) {
				i = '0' + i;
			}
			if (s < 10) {
				s = '0' + s;
			}
			//<!-- 获取时间格式 2017-01-03 10:13:48 -->
			//var t = Y+'-'+m+'-'+d+' '+H+':'+i+':'+s;
			//<!-- 获取时间格式 2017-01-03 -->
			//var t = Y + '-' + m + '-' + d;
			var t = Y + '/' + m + '/' + d + ' ' + H + ':' + i;
			return t;
		},
		nextDir: function (id,type,name,sysDir,status,event) {
			var _self = this;
			if(type == 1){
				_self.$data.lastDirId = _self.$data.curDirId;
				_self.$data.curDirId = id;
				_self.initData(id);
				if(sysDir){
					//标准目录不允许创建文件夹
					_self.$data.createBtnStatus = false;
					_self.$data.isSys = true;
				}else{
					_self.$data.createBtnStatus = true;
					_self.$data.isSys = false;
				}
			}
		},
		fileType:function (suffix) {
			var clazz = "label-";
			if(suffix && suffix.indexOf(".") > 0){
				suffix = suffix.substring(suffix.indexOf("."),suffix.length);
			}
			switch (suffix){
                case ".txt":
                    clazz += "txt";
                    break;
                case ".doc":
                    clazz += "word";
                    break;
                case ".docm":
                    clazz += "word";
                    break;
                case ".dotx":
                    clazz += "word";
                    break;
                case ".dotm":
                    clazz += "word";
                    break;
                case ".docx":
                    clazz += "word";
                    break;
                case ".rtf":
                    clazz += "word";
                    break;
                case ".pdf":
                    clazz += "pdf";
                    break;
                case ".xls":
                    clazz += "excel";
                    break;
                case ".ppt":
                    clazz += "ppt";
                    break;
                case ".pptx":
                    clazz += "ppt";
                    break;
                case ".xlsx":
                    clazz += "excel";
                    break;
                case ".xlsm":
                    clazz += "excel";
                    break;
                case ".xltx":
                    clazz += "excel";
                    break;
                case ".xltm":
                    clazz += "excel";
                    break;
                case ".xlsb":
                    clazz += "excel";
                    break;
                case ".xlam":
                    clazz += "excel";
                    break;
                case ".rm":
                    clazz += "video";
                    break;
                case ".rmvb":
                    clazz += "video";
                    break;
                case ".wmv":
                    clazz += "video";
                    break;
                case ".avi":
                    clazz += "video";
                    break;
                case ".mp4":
                    clazz += "video";
                    break;
                case ".3gp":
                    clazz += "video";
                    break;
                case ".mkv":
                    clazz += "video";
                    break;
                case ".navi":
                    clazz += "video";
                    break;
                case ".mov":
                    clazz += "video";
                    break;
                case ".asf":
                    clazz += "video";
                    break;
                case ".png":
                    clazz += "img";
                    break;
                case ".gif":
                    clazz += "img";
                    break;
                case ".zip":
                    clazz += "zip";
                    break;
                case ".rar":
                    clazz += "zip";
                    break;
                case ".arj":
                    clazz += "zip";
                    break;
                case ".z":
                    clazz += "zip";
                    break;
                case ".apk":
                    clazz += "apk";
                    break;
                case ".mmap":
                    clazz += "mmap";
                    break;
                case ".mpg":
                    clazz += "mpg";
                    break;
                case ".csv":
                    clazz += "csv";
                    break;
                case ".mpp":
                    clazz += "mpp";
                    break;
                case ".html":
                    clazz += "html";
                    break;

                default:
                    clazz += "unkown";
                    break;
			}
			return clazz;
		},
		createDir: function () {
			var _self = this;
			if(_self.$data.isSys == true ||  _self.$data.isSys == "true"){
				msg("系统目录下不可新建文件夹")
				return;
			}
			appApi.openNewWindow(getPagePath() + "/dish/create_dir.html?pid=" + _self.$data.curDirId);
		},
		doUpload:function () {
			var _self = this;
			var id = _self.$data.curDirId;
			var sys = _self.$data.isSys;
			var script = "uploadTarget('"+ id + "','" + sys +"')"
			appApi.broadcast(script);
			//localStorage.setItem("uploadDirId",_self.$data.curDirId);
			setTimeout(function () {
				appApi.closeNewWindow();
			},600)
		}
	}
});

var refreshPage = function () {
	app.initData(app.$data.curDirId);
}
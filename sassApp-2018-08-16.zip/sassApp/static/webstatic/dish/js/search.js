var localSearch = {
	HISTORY_KEY: "CLOUD_DISH_SEARCH_HISTORY_LIST_" + Number(getCookie("userid")) ,
	getSearchHistory:function () {
		var h = localStorage.getItem(this.HISTORY_KEY);
		if(h){
			var j = JSON.parse(h);
			if(j.hasOwnProperty("keywords")){
				return j.keywords;
			}
		}
		return [];
	},
	saveSearchHistory:function (keyword) {
		var h = localStorage.getItem(this.HISTORY_KEY);
		if(h){
			var j = JSON.parse(h);
			if(j.hasOwnProperty("keywords")){
				console.info("save keyword success:" + keyword);
				keywords = 	j.keywords;
				var newKeywords = [];
				for(var i in keywords){
					if(keyword != keywords[i] && !(keywords[i] instanceof Function)){
						newKeywords.push(keywords[i]);
					}
				}
				newKeywords.insert(0,keyword);
				j.keywords = newKeywords;
				localStorage.setItem(this.HISTORY_KEY,JSON.stringify(j));
				console.info("save history success:" + JSON.stringify(j));
			}
		}else{
			localStorage.setItem(this.HISTORY_KEY,JSON.stringify({keywords:[keyword]}));
		}
	},
	clear:function () {
		localStorage.removeItem(this.HISTORY_KEY);
	}
}

var search = new Vue({
	el: "#js-head-search",
	data: {
		keyword:"",
		projectId:"",
	},
	created: function () {
		var _self = this;
		//获取参数
		var params = getParam(window.location.href);
		if (params.hasOwnProperty("projectSN")) {
			if(document.getElementById("pullrefresh")){
				document.getElementById("pullrefresh").style.top = "51px";
			}
			_self.$data.projectId = params.projectSN;
			if(params.hasOwnProperty("keyword")){
				_self.$data.keyword = params.keyword;
			}
		}
	},
	watch: {
		'keyword': function (val, oldVal) {
			var _self = this;
			if(val != oldVal){
				_self.changeBtn(val);
			}
		}
	},
	methods: {
		search:function (keyword) {
			var _self = this;
			if(	_self.$data.projectId== ""){
				msg("非法搜索")
				return false;
			}
			if(keyword){
				_self.$data.keyword = keyword;
			}
			if(_self.$data.keyword == ""){
				msg("请输入要搜索的文件或者文件夹")
				return;
			}
			loading("搜索中...");
			setTimeout(function () {
				localSearch.saveSearchHistory(_self.$data.keyword);
				JSearch.$data.searchHistory = localSearch.getSearchHistory();
				if(location.href.indexOf("search_result.html") == -1){
					appApi.openNewWindow(getPagePath() + "/dish/search_result.html?projectSN=" + _self.$data.projectId + "&keyword=" + _self.$data.keyword);
				}else{
					//异步搜索
					if(app){
						app.$data.pageParams.keyword =  _self.$data.keyword;
						app.$data.pageParams.projectId = _self.$data.projectId;
						app.searchData();
					}
					//location.href = url;
				}
				layer.closeAll();
			},200)
			//appApi.openNewWindow(getPagePath() + "/dish/search_result.html?projectSN=" + _self.$data.projectId + "&keyword=" + _self.$data.keyword);
			return false;
		},
		changeBtn:function (val) {
			var _self = this;
			if(val != ""){
				JSearch.$data.showSearch = true;
			}else{
				JSearch.$data.showSearch = false;
			}
			if(document.getElementById("searchBtn")){
				document.getElementById("searchBtn").innerText = '搜索"' + _self.$data.keyword+ '"';
			}
		},
		cleanIpt:function () {
			var _self = this;
			_self.$data.keyword = "";
		}
	}
});

var JSearch = new Vue({
	el: "#JSearch",
	data: {
		showSearch:false,
		searchHistory: []
	},
	created:function () {
		var _self = this;
		//获取搜索历史
		_self.$data.searchHistory = localSearch.getSearchHistory();
	},
	methods:{
		search:function (keyword) {
			search.search(keyword);
		},
		clear:function () {
			var _self = this;
			_self.$data.searchHistory = [];
			localSearch.clear();
			msg("清除成功")
		}
	}
})


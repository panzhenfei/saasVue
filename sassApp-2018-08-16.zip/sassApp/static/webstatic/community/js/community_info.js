/**
 * @author liguancheng
 * @date 2017-8-11 12:07
 */
    //获取参数
var urlParam = window.location.href.split("?")[1];
var webPath = getUrl();
			var pagepath = getPagePath();
var map = {};
if(urlParam){
    var arrays= urlParam.split("&");
    for(i=0; i<arrays.length; i++){
        var param = arrays[i].split("=");
        map[param[0]] = decodeURI(param[1]);
    }
}

// projectSN  项目主页过来需要过滤项目id
var pageParams = {curPage: 1, pageSize: 10, projectSN:map.projectSN};
var type = map.hasOwnProperty("type") && undefined != map.type? map.type:"filter"; //判断筛选还是搜索 默认筛选
/*search:{
				startDate:"请选择", //时间
				endDate:"请选择",
				projectSn:"",//项目
			},
			filter: {
				dateType:"all",
				byType:""
			},*/
var loacl  = localStorage.getItem("conditions");
if(undefined != loacl){
	var loaclParams = JSON.parse(loacl);
	if(type == "search"){
	    var searchParams = loaclParams.search;
		if(searchParams.startDate != "请选择"){
			pageParams.startDate = searchParams.startDate + ":00";
		}
		if(searchParams.endDate != "请选择"){
			pageParams.endDate = searchParams.endDate + ":00";
		}
		if(undefined != searchParams.projectSn && searchParams.projectSn != ""){
			pageParams.projectSN = searchParams.projectSn;
		}
	}else if(type == "filter"){
		var filterParams = loaclParams.filter;
		if(undefined != filterParams.dateType){
			pageParams.dateType = filterParams.dateType;
		}
		if(undefined != filterParams.byType){
			pageParams.byType = filterParams.byType;
		}
	}
}
var infoId;//当前评论的日志id
var replyUserId;//被回复的用户id
var replyUserName;//被回复的用户名称
var infoIndex;//当前日志所在数组的下标
var cIndex;//点击回复/删除评论的数组下标
var commentUserId = getCookie("userid");//当前用户的id
var commentUserName = decodeURI(getCookie("username"));//当前用户的昵称
var browseImageArray = [];
var imageHost="";
var widimg=(window.screen.width-30)*0.3+"px";
var infoApp = new Vue({
    el:"#content",
    data:{
        comm_placeholder:"",
        comment_box_display:"none",
        send_content:"",
        items:[],
        liw:widimg,
        temp:[
            {"headimg":"../../images/header3.jpg", "userId":10165, "username":"小懒人", "createTime":"2017-8-13 21:48:22","content":"小懒人，懒只是一种生活态度","praise":true,"praiseNum":55,"commentNum":22, "resourcesJ":"[{\"url\": \"../../images/rizhi01.jpg\",\"width\": 1080,\"height\": 960},{\"url\": \"../../images/rizhi01.jpg\",\"width\": 1080,\"height\": 960},{\"url\": \"../../images/rizhi01.jpg\",\"width\": 1080,\"height\": 960},{\"url\": \"../../images/rizhi01.jpg\",\"width\": 1080,\"height\": 960},{\"url\": \"../../images/banner03.jpg\",\"width\": 80,\"height\": 960},{\"url\": \"../../images/rizhi01.jpg\",\"width\": 1080,\"height\": 960},{\"url\": \"../../images/rizhi01.jpg\",\"width\": 1080,\"height\": 960},{\"url\": \"../../images/banner03.jpg\",\"width\": 50,\"height\": 960},{\"url\": \"../../images/banner03.jpg\",\"width\": 80,\"height\": 960},{\"url\": \"../../images/banner03.jpg\",\"width\": 80,\"height\": 960},{\"url\": \"../../images/banner03.jpg\",\"width\": 80,\"height\": 960}]","commentJ":"[{\"commentUserId\":10165,\"commentUserName\":\"小懒人\",\"content\":\"经典,满满的文艺范\"},{\"commentUserId\":10165,\"commentUserName\":\"阳阳\",\"replyUserId\":60,\"replyUserName\":\"小懒人\",\"content\":\"经典,满满的文艺范\"},{\"commentUserId\":10165,\"commentUserName\":\"小小\",\"replyUserId\":60,\"replyUserName\":\"阳阳\",\"content\":\"老李,这一波装的可以喔,满满的文艺范\"},{\"commentUserId\":10165,\"commentUserName\":\"小懒人\",\"replyUserId\":60,\"replyUserName\":\"小小\",\"content\":\"小李子,满满的文艺范\"}]"},
        ]
    },
    created:function () {
        this.initMui();
        this.initCommentParam();
    },
    filters: {

    },
    methods: {
    	 //发布日志
        selectrizhi:function(){
        	location.href= getUrl()+"/static/webstatic/community/community_send_info.html"
        },
        initMui:function(){//初始化mui的分页插件
            var _self = this;

	        /*document.querySelector('.mui-scroll-wrapper' ).addEventListener("swipeleft",function(){
		        console.log("你正在向左滑动");
	        });*/
	        mui.ready(function() {
                mui.init({
                    pullRefresh: {
                        container: '#content',
                        down: {
                            auto: true,
                            callback: function () {
                                //下拉刷新
                                pageParams.curPage = 1;
                                infoApp.loadData();
                            }
                        },
                        up: {
                            contentrefresh: '正在加载...',
                            contentnomore: '没有更多数据',
                            height:50,
                            callback: function () {
                                pageParams.curPage = pageParams.curPage + 1;
                                infoApp.loadData();
                            }
                        }
                    }
                });
		        document.querySelector('.mui-scroll-wrapper').addEventListener('scroll', function (e ) {
		        	$(".mui-scroll-wrapper").attr("pointer-events","none")
			        _self.hideInput();
		        })
                mui("#content").on('tap','.icon-zan', function () {//绑定点赞事件
                    var a = this.getAttribute("data-a");
                    infoApp.clickPraise(a);
                });
                mui("#content").on('tap','.log-header', function () {//绑定头像事件
                    var a = this.getAttribute("data-a");
                    infoApp.lookUserInfo(a);
                });
                mui("#content").on('tap','.name', function () {//绑定评论姓名事件
                    var a = this.getAttribute("data-a");
                    infoApp.lookUserInfo(a);
                });
                mui("#content").on('tap','.comment-content', function () {//绑定评论内容，点击回复
                    infoId = this.getAttribute("data-a");
                    replyUserId = this.getAttribute("data-b");
                    replyUserName = this.getAttribute("data-c");
                    infoIndex = this.getAttribute("data-i");
                    cIndex = this.getAttribute("data-cindex");
                     $(".fixed-bottom").css("display","block")
                    $("#commentIpt").focus()
	                $(".mui-backdrop").css("display","block")
                    infoApp.replyComment();

                });
                mui("#content").on('tap','.icon-commented', function () {//绑定评论
                    infoId = this.getAttribute("data-a");
                    infoIndex = this.getAttribute("data-i");
	                cIndex = this.getAttribute("data-cindex");
	                $(".fixed-bottom").css("display","block")
	                $("#commentIpt").focus()
	                $(".mui-backdrop").css("display","block")
                    infoApp.replyComment();

                });
                mui("#content").on('tap','.img-item',function() {//绑定图片点击事件
                    //获取id
                    var a = this.getAttribute("data-a");
                    var b = this.getAttribute("data-b");
                    openPhotoSwipe(b,browseImageArray[a]);
                });
	            mui("#content").on('tap','.icon-share', function () {//绑定更多事件
		            var url = this.getAttribute("data-url");
		            var name = this.getAttribute("data-name");
		            var content = this.getAttribute("data-content");
		            var logo = getUrl() + "/static/images/app-logo.jpg";
		            appApi.share(0,name + "发布了一篇不错的日记，赶快来看看吧",content,getUrl() + "/static/webstatic/mycenter/share_detail.html",logo,null);
	            });

            })
        },
        loadData: function () { //获取列表数据
            axios.post(getUrl() + "/community/info/findpage",
                pageParams,{
		            headers: {
			            'Content-Type': 'application/json'
		            }
                }).then(function (response) {
                console.info(response.data);
                if (response.data.code == 0) {
                    imageHost = response.data.result.imageHost;
                    if(!response.data.result.page){
                        mui('#content').pullRefresh().endPulldownToRefresh();
                        mui('#content').pullRefresh().endPullupToRefresh(true);
                        return;
                    }
                    var page = response.data.result.page;
                    var allPage = page.endPage;
                    var all = page.totalPage
                    if(all == 0){
	                    mui('#content').pullRefresh().endPullupToRefresh(true);
                        var emp = '<div id="empty-view" class="no-group">' +
	                        '<div class="no-record-img no-record-cloud"></div>' +
	                        '<p>无记录</p>' +
	                        '</div>';
	                    document.getElementById('content').innerHTML = emp;
                    }else{
	                    if (pageParams.curPage == 1) {
		                    //首次 加载一次
		                    infoApp.$data.items = [];
		                    browseImageArray = [];
		                    infoApp.conductData(page.list);
		                    mui('#content').pullRefresh().endPulldownToRefresh();
		                    mui('#content').pullRefresh().refresh(true);//重置上拉加载
	                    } else {
		                    if(page.list) {
                    			infoApp.conductData(page.list);
		                    }
	                    }
	                    mui('#content').pullRefresh().endPullupToRefresh(pageParams.curPage >= allPage);
                    }

                } else {
                    mui('#content').pullRefresh().endPullupToRefresh(true);
                    msg("系统出了点小状况，请稍后再试");
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        lookUserInfo:function (userId) {//查看用户资料
            window.appApi.openNewWindow(getPagePath() + "/contacts/eg_details.html?userId="+userId);
        },
        clickPraise:function(a){//点赞
            var v = infoApp.$data.items[a];
            v.praise = !v.praise;
            v.praiseNum = v.praiseNum + (v.praise ? 1:-1);
            var param = new FormData();
            param.append("id", v.id);
            param.append("praise", v.praise);
            axios.post(getUrl() + "/community/info/praise", param).then(function (response) {
                console.info(response.data);
            });
        },
        replyComment: function () {//回复/评论点击
        	  $("#commentIpt").focus()
        	document.getElementById("commentIpt").focus();
//      	infoApp.replyComment();
		    var _self =  infoApp.$data;
//		    console.info(replyUserId+"======="+commentUserId);
		    if(replyUserId==commentUserId  && cIndex != undefined){//自己的评论再次点击是删除
			    confirmLayer("是否删除该条评论？", function(){
				    layer.closeAll();
				    //组装请求参数
				    var param = new FormData();
				    var tid =  _self.comments[cIndex].id;
				    param.append("id",tid);
				    param.append("communityId", _self.item.id);
				    _self.comments.splice(cIndex, 1);
				    //删除子评论
				    /*var newArr = [];
				    for(var i =0;i<_self.comments.length;i++) {
					    if(_self.comments[i].id != tid && tid != _self.comments[i].replyId){
						    newArr.push(_self.comments[i])
					    }
				    }
				    _self.comments = newArr;*/
				    infoApp.initCommentParam();
				    axios.post(getUrl() + "/community/video/delcomment", param).then(function (resp) {
					    console.info(resp.data);
					    _self.item.commentNum = _self.item.commentNum - 1;
					    cIndex ="";
				    })
			    })
		    }else if(replyUserId && replyUserId != ""){//回复
//		    	var stopmove=document.getElementsByClassName("stopmove")[0];
//		    	stopmove.style.overflow="hidden";
			    _self.comment_box_display="block";
			    
			    document.getElementById("commentIpt").innerText= "";
			    _self.comm_placeholder = "回复"+replyUserName+"：";
			    document.getElementById("commentIpt").focus();
//			    var commentIptq=document.getElementById("commentIpt");
//				     commentIptq.addEventListener('touchstart',function(){
//				        commentIptq.focus();                                       
//				})
			    po_Last_Div(document.getElementById("commentIpt"));
		    }else{//评论
//		    	var stopmove=document.getElementsByClassName("stopmove")[0];
//		    	stopmove.style.overflow="hidden";
				document.getElementById("commentIpt").innerText= "";
			    _self.comment_box_display="block";
			    _self.comm_placeholder = "请输入";
				document.getElementById("commentIpt").focus();
			    infoApp.inputtext()
			    
//			     var commentIptq=document.getElementById("commentIpt");
//				     commentIptq.addEventListener('touchstart',function(){
//				        commentIptq.focus();                                       
//				})
			    po_Last_Div(document.getElementById("commentIpt"));
		    }
	    },
	     inputtext:function(){
	    	var msgText =  document.getElementById("commentIpt");
	    	var pinmsdk=document.getElementsByClassName("pinlun")[0];
	    	pinmsdk.style.overflow="hidden"
			document.body.classList.add("addtext");
        	document.getElementsByTagName("html")[0].classList.add("addtext");
	    	$('.mui-backdrop').on("touchmove",function(e){
                e.preventDefault();
     		});
	    	msgText.addEventListener('tap',function () {
				var target=this
//				this.focus()
				
			setTimeout(function(){
				target.scrollIntoView(true)
			},100)
                // 光标移动到最后
                msgTextLastPos(msgText);
                // 获得输入框键盘焦点
                msgTextFocus(msgText);          
            })
	    	// 获得输入框键盘焦点
            var msgTextFocus = function(obj){
                obj.focus();
                setTimeout(function() {
                    obj.focus();
                }, 150);
            }
            // 光标移动到最后
            function msgTextLastPos(obj) {
                if (window.getSelection) {//ie11 10 9 ff safari
                    obj.focus(); //解决ff不获取焦点无法定位问题
                    var range = window.getSelection();//创建range
                    range.selectAllChildren(obj);//range 选择obj下所有子内容
                    range.collapseToEnd();//光标移至最后
                }
                else if (document.selection) {//ie10 9 8 7 6 5
                    var range = document.selection.createRange();//创建选择对象
                    range.moveToElementText(obj);//range定位到obj
                    range.collapse(false);//光标移至最后
                    range.select();
                }
            }
	    },
        sendComment:function () {//发送评论信息
            var _data = infoApp.$data;
            var _self = this;
            var msgText =  document.getElementById("commentIpt");
	    	var pinmsdk=document.getElementsByClassName("pinlun")[0];
	    	pinmsdk.style.overflow="auto"
			document.body.classList.remove("addtext");
        	document.getElementsByTagName("html")[0].classList.remove("addtext");
//		    _data.send_content = document.getElementById("commentIpt").innerText;
		    _data.send_content = document.getElementById("commentIpt").innerText;
		    var chat=document.getElementsByClassName("chat-btn")[0];
				     chat.addEventListener('touchstart',function(){
				        commentIptq.blur();                                       
				})
            if(!_data.send_content || _data.send_content==""){
                msg("评论内容不能为空！");
                return;
            }
            _data.comment_box_display="none";
            var commentJson = _data.items[infoIndex].commentJ;
            var reId = undefined == cIndex ? "":commentJson[cIndex].id;
            var comment_format = {
                communityId:infoId,
                commentUserId:commentUserId,
                commentUserName:commentUserName,
	            replyId:reId,
                replyUserId:replyUserId,
                replyUserName:replyUserName,
                commentContent:_data.send_content};//重置评论json
            if(commentJson){
                _data.items[infoIndex].commentJ = commentJson.concat(comment_format);
            }else{
                _data.items[infoIndex].commentJ = [comment_format];
            }
	        _self.items[infoIndex].commentNum = _self.items[infoIndex].commentNum + 1;
            axios.post(getUrl() + "/community/info/savecomment", comment_format).then(function (resp) {
                console.info(resp.data);

            })

            infoApp.initCommentParam();

        },
        format_Date: function (val) {//格式化时间
            return new Date(val).Format("yyyy-MM-dd hh:mm:ss ");
        },
        conductData:function (array) {//处理获取的列表数据
            for(var i=0; i<array.length; i++){
                console.info(array.length);
                var s = array[i];
                s.createTime = new Date(s.createTime).Format("yyyy-MM-dd hh:mm:ss");
                s.userIcon = imageHost + s.userIcon;
                var imgJson= JSON.parse(s.resourcesJ);
	            var imgArray = [];
                if(imgJson && imgJson != "" && imgJson.length > 0) {
                    var picIndex = 0;
                    for (var j = 0; j < imgJson.length; j++) {
                        var im = imgJson[j];
                        im["picIndex"] = j;
                        im.url = imageHost + im.url;
                        var browsePic = {"src": im.url, "w": im.width, "h": im.height, "msrc": im.url, "el": {}};
                        imgArray.push(browsePic)
                        console.log(imgArray)
                    }
                    browseImageArray.push(imgArray);
                }else{
	                browseImageArray.push(imgArray);
                }
                s.resourcesJ = imgJson;
                if(s.commentJ!="")  s.commentJ = JSON.parse(s.commentJ);
            }
            infoApp.$data.items = infoApp.$data.items.concat(array);
        },
        initCommentParam:function () {
            infoId = null;//当前评论的日志id
            replyUserId = null;//被回复的用户id
            replyUserName = null;//被回复的用户名称
            infoIndex = null;//当前日志所在数组的下标
            this.send_content="";
        },
        hideInput:function () {
            var _self = this;
            $('.mui-backdrop').on("tap",function(e){
                $(".mui-backdrop").css("display","none")
                $(".group-chat").css("display","none")
     		});
            _self.$data.comment_box_display = "none";
	        //_self.$data.send_content = "";
	        _self.$data.comm_placeholder = "";

        }
    },

});

var refreshPage = function () {
	pageParams.curPage = 1;
	infoApp.loadData();
}
function po_Last_Div(that) {
	window.setTimeout(function () {
		var sel, range;
		if (window.getSelection && document.createRange) {
			range = document.createRange();
			range.selectNodeContents(that);
			range.collapse(true);
			range.setEnd(that, that.childNodes.length);
			range.setStart(that, that.childNodes.length);
			sel = window.getSelection();
			sel.removeAllRanges();
			sel.addRange(range);
		} else if (document.body.createTextRange) {
			range = document.body.createTextRange();
			range.moveToElementText(that);
			range.collapse(true);
			range.select();
		}
		/*if(isApp){
			appApi.showKeyboard()
		}*/
	}, 1)
}
var params = getParam(window.location.href);
var type = params.hasOwnProperty("type") ? params.type :"filter";
var flag = params.hasOwnProperty("flag") ? params.flag :"info";
var FILTER_KEY = "conditions_" + Number(getCookie("userid"));
var app = new Vue({
	el: "#app",
	data:{
		params:{
			filter: {
				startDate:"", //时间
				endDate:"",
				projectSn:"",//项目
				project:"",//项目
				dateType:"all",
				byType:"all"
			}
		},
		projectLoad:false
	},
	created:function () {
		console.info("初始化创建获取缓存参数完成");
		var _self = this;
		if(undefined != localStorage.getItem(FILTER_KEY)){
			_self.params = JSON.parse(localStorage.getItem(FILTER_KEY));
		}
	},
	watch: {
		'params.filter.project': function (val, oldVal) {
			var _self = this;
			if(val != oldVal){
				_self.saveParams();
			}
		}
	},
	methods:{
		selectDate:function (type) {
			var _self = this;
			_self.params.filter.dateType = type;
			if(_self.params.filter.dateType != "custom"){
				_self.params.filter.startDate = "";
				_self.params.filter.endDate = "";
			}
			_self.saveParams();
		},
		selDate:function (type) {
			var _self = this;
			var opt = {"type": "date",value:"",
				"beginYear":1975,"endYear":new Date().getFullYear()};
			if(type == "start" && "起始日期" != _self.params.filter.startDate){
				opt.value = _self.params.filter.startDate;
			}else if(type == "end" && "结束日期" != _self.params.filter.endDate){
				opt.value = _self.params.filter.endDate;
			}
			var picker = new mui.DtPicker(opt);
			picker.show(function (rs) {
				if(type == "start"){
					//判断是否大于开始时间
					if("" != _self.params.filter.endDate && _self.params.filter.endDate !="结束日期"){
						var end = new Date(_self.params.filter.endDate + ":00").Format("yyyy-MM-dd hh:mm:ss");
						var cur = new Date(rs.value + ":00").Format("yyyy-MM-dd hh:mm:ss");
						if(cur > end){
							msg("开始时间不能大于结束时间");
							return false;
						}
					}
					_self.params.filter.startDate = rs.value;
				}else{
					//判断是否大于开始时间
					if("" != _self.params.filter.startDate && _self.params.filter.startDate !="起始日期"){
						var start = new Date(_self.params.filter.startDate + ":00").Format("yyyy-MM-dd hh:mm:ss");
						var cur = new Date(rs.value + ":00").Format("yyyy-MM-dd hh:mm:ss");
						if(start > cur){
							msg("结束时间不能小于开始时间");
							return false;
						}
					}
					_self.params.filter.endDate = rs.value;
				}
				picker.dispose(); //释放资源
				_self.saveParams();
			})

		},
		selProject:function () {
			var _self = this;
			if(!_self.projectLoad){
				//loading("正在加载项目...")
				axios.get(getUrl() + "/work_api/projectname").then(function (resp) {
					if (resp.data.code == 0) {
						var array = resp.data.result;
						if (array) {
							var htmlstr = array.length == 0 ? ' <li class="mui-table-view-cell">未参与任何项目</li>' :'<li class="mui-table-view-cell" onclick="app.selCallBack(\'\',\'请选择\')">不选择项目</li>';
							for (var i = 0; i < array.length; i++) {
								htmlstr += '<li class="mui-table-view-cell" onclick="app.selCallBack(\''+array[i].serialNum+'\',\''+array[i].ProjectName+'\')">'+array[i].ProjectName+'</li>'
							}
							document.getElementById("project_list").innerHTML = htmlstr;
						}
						layer.closeAll();
						_self.projectLoad = true;
						document.getElementById("shade").style.display = "block";
						document.getElementById("add-style").style.display = "block";
					} else {
						msg("系统报错:" + resp.data.message);
					}
				}).catch(function (err) {
					console.log(err);
				})
			}else{
				document.getElementById("shade").style.display = "block";
				document.getElementById("add-style").style.display = "block";
			}


		},
		selCallBack : function (id,name) {
			var _self = this;
			console.info(id + "====" + name);
			_self.params.filter.projectSn = id;
			_self.params.filter.project = name;
			self.hideProject();
			_self.saveParams();
		},
		hideProject:function () {
			document.getElementById("shade").style.display = "none";
			document.getElementById("add-style").style.display = "none";
		},
		selectBy:function (type) {
			var _self = this;
			_self.params.filter.byType = type;
			_self.saveParams();
		},
		saveParams:function () {
			var _self = this;
			localStorage.setItem(FILTER_KEY,JSON.stringify(_self.params));
			if(type == "filter"){
				//筛选

			}else{
				//搜索
				/*var params = {endDate:_self.params.endDate,startDate:_self.params.startDate,project:_self.params.project};
				localStorage.setItem(FILTER_KEY,JSON.stringify(params));*/

			}
		},
		resetParams:function () {
			var _self = this;
			_self.params.filter.dateType = "all";
			_self.params.filter.byType = "all";
			localStorage.removeItem(FILTER_KEY);
			_self.doFilter();
		},
		doFilter:function () {
			appApi.refreshNav(0);
			//appApi.popToMainTab(0,"refreshPage('"+flag+"')");
			//appApi.broadcast("filterCallBack()");
			appApi.closeNewWindow(getPagePath() + "/community/community_main.html?flag=" + flag)
		},
		saveFilter:function () {
			var _self = this;
			if(_self.params.filter.dateType == 'custom'){
				if(_self.params.filter.startDate == '' && _self.params.filter.endDate == ''){
					msg("请选择自定义时间");
					return;
				}
			}
			_self.doFilter();
		},
		doSearch:function () {
			var url = getPagePath();
			if(flag == "info"){
				url += "/community/community_info.html?type=" + type;
			}else{
				url += "/community/community_video.html?type=" + type;
			}
			appApi.openNewWindow(url);
		}
	}
})

Date.prototype.Format = function(fmt) {
	var o = {
		"M+": this.getMonth() + 1, //月份
		"d+": this.getDate(), //日
		"h+": this.getHours(), //小时
		"m+": this.getMinutes(), //分
		"s+": this.getSeconds(), //秒
		"q+": Math.floor((this.getMonth() + 3) / 3), //季度
		"S": this.getMilliseconds() //毫秒
	};
	if(/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for(var k in o)
		if(new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
}
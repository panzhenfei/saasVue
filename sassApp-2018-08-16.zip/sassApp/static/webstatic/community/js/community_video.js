/**
 * @author liguancheng
 * @date 2017-8-11 12:07
 */
var map = getParam(window.location.href);
var psn = map.projectSN === undefined ? "" : map.projectSN; //当前选择的项目sn
var psn = map.projectSn === undefined ? psn : map.projectSn; //当前选择的项目sn
var FILTER_KEY = "conditions_" + Number(getCookie("userid"));
var share_key = "SHARE_KEY";
var pageParams = {
	curPage: 1,
	pageSize: 10,
	projectSN: psn,
	project:""
};
var type = map.hasOwnProperty("type") && undefined != map.type ? map.type : "filter"; //判断筛选还是搜索 默认筛选
/*search:{
				startDate:"请选择", //时间
				endDate:"请选择",
				projectSn:"",//项目
			},
			filter: {
				dateType:"all",
				byType:""
			},*/
var loacl = localStorage.getItem(FILTER_KEY);
if(undefined != loacl && psn == "") {
	var loaclParams = JSON.parse(loacl);
	var params = loaclParams.filter;
	if(undefined != params.projectSn && params.projectSn != "") {
		pageParams.projectSN = params.projectSn;
	}
	if(undefined != params.project && params.project != "") {
		pageParams.project = params.project;
	}
	if(undefined != params.dateType) {
		pageParams.dateType = params.dateType;
		if(pageParams.dateType == "custom"){
			if(params.startDate != "") {
				pageParams.startDate = params.startDate + " 00:00:00";
			}
			if(params.endDate != "") {
				pageParams.endDate = params.endDate + " 23:59:59";
			}
		}
	}
	if(undefined != params.byType) {
		pageParams.byType = params.byType;
	}

}
function video_zan(j){
	if(j==1){
		videoApp.clearitem()
	}
////	videoApp.clearitem()
}
 var videoApp = new Vue({
	el: "#video_list",
	data: {
		items:[],
		nodata:false
	},
	created: function() {
		this.initMui()
	},
	methods: {
	clearitem:function(){
//		this.items=[]
		for(var i=0;i<this.items.length;i++){
			this.items[i].praiseNum=[]
		}
		this.loadData("up")
	},
	seticonZan:function(){},
		initMui: function() { //初始化mui的分页插件
			var _self=this;
			$(function() {
				$("#video_list").on('click', '.icon-zan', function() { //绑定点赞事件
					alert(1111)
					//var a = this.getAttribute("data-a");
					var a = $(this).attr("data-a");
					videoApp.clickPraise(a);
				});
				//
				$("#video_list").on('click', '.icon-comment', function() { //绑定评论事件
					var a = $(this).attr("data-a");
					var v = videoApp.$data.items[a];
//					v.seeNum = v.seeNum;
					window.appApi.openVideo(getPagePath() + "/community/community_comment.html?autoComment=1&id="+v.id,v.videoUrl,"视频详情",v.thumbImage);

				});
				//
				$("#video_list").on('click', '.icon-share', function() { //绑定更多事件
					var url = $(this).attr("data-url");
					var img = $(this).attr("data-img");
					var name = $(this).attr("data-name");
					var project = $(this).attr("data-project");
					if(project == undefined || project == ""){
						project = "非项目视频"
					}
					var logo = getUrl() + "/static/images/app-logo.jpg";
					if(img == undefined || img == ""){
						img = logo;
					}
					var id = $(this).attr("data-id");
					localStorage.setItem(share_key,SHARE_OPERATE.VIDEO_SHARE);
					var shareUrl = getPagePath() + "/community/community_comment.html?type=share&id="+id;
					appApi.shareVideo(0, name + "发布了一段工程项目的形象视频，赶快来看看吧", project, shareUrl, img, url,"视频详情", null);
				});
				//
				$("#video_list").on('click', '.user-info', function() { //绑定头像
					var a = $(this).attr("data-a");
					window.appApi.openNewWindow(getPagePath() + "/contacts/eg_details.html?userId=" + a);
				});
				$("#video_list").on('click', '.icon-shoucang', function() { //绑定头像
					var a = $(this).attr("data-a");
					videoApp.collect(a);
				});
				//
				$("#video_list").on('click', '.video-pic', function() { //绑定视频播放事件
					
					var a = $(this).attr("data-a");
					var v = videoApp.$data.items[a];
					
//					v.seeNum = v.seeNum;
					//更新播放数量
					var param = new FormData();
					param.append("id", v.id);
//					axios.post(getUrl() + "/community/video/seenum", param).then(function (response) {
////						console.info(response);
//						
//					});
					BackCookie.setCookie("videoUrl", v.videoUrl);
					window.appApi.openVideo(getPagePath() + "/community/community_comment.html?id="+v.id,v.videoUrl,"视频详情",v.thumbImage);
					//window.appApi.openNewWindow(getPagePath() + "/community/community_comment.html?autoplay=1&id="+v.id);

				});
				_self.loadData()
				// dropload
//				$('.content').dropload({
//					scrollArea: window,
//					domUp: {
//						domClass: 'dropload-up',
//						domRefresh: '<div class="dropload-refresh"><i class="mui-icon mui-icon-arrowthindown" style="font-size:16px;c"></i>下拉刷新</div>',
//						domUpdate: '<div class="dropload-update"><i class="mui-icon mui-icon-arrowthinup" style="font-size:16px;font-weight:bold"></i> 释放更新</div>',
//						domLoad: '<div class="dropload-load"><i class="mui-spinner" style="width:20px;height:20px;margin-right:5px;vertical-align: middle;"></i>加载中...</div>'
//					},
//					domDown: {
//						domClass: 'dropload-down',
//						domRefresh: '<div class="dropload-refresh"><i class="mui-icon mui-icon-arrowthinup" style="font-size:16px;font-weight:bold"></i>上拉加载  </div>',
//						domLoad: '<div class="dropload-load"><i class="mui-spinner" style="width:20px;height:20px;margin-right:5px;vertical-align: middle;"></i>加载中</div>',
//						domNoData: '<div class="dropload-noData">没有更多数据</div>'
//					},
//					// 下拉刷新
//					loadUpFn: function(me) {
//
//						pageParams.curPage = 1;
//					    videoApp.loadData("up",me);
					
//					},
//					// 上拉加载更多
//					loadDownFn: function(me) {
//						videoApp.loadData("down",me);
//					},
//					threshold: 200
//				});
			});
		},
		// 加载数据
		loadData: function(type,me) {
			var _self = this;
			axios.post(getUrl() + "/community/video/find_page",
				pageParams, {
					headers: {
						'Content-Type': 'application/json'
					},
				}).then(function(response) {
//					if(type == "up"){
//						$('.lists').empty();
//                      videoApp.$data.items = [];
//                      videoApp.$data.items=response.data.result.list
//					}
//				var page = response.data.result;
//				var curPage=pageParams.curPage
				console.log(response);
//				console.log(videoApp)
				if(response.data.result.list.length==0){
					_self.nodata=true
//					var html=''
//							html+='<div id="empty-view" class="no-group"><div class="no-record-img no-record-cloud"></div><p>无记录</p></div>'
//							$(".content").empty()
//							$("#video_list").append(html)
				}else{
				_self.nodata=false
					videoApp.$data.items=response.data.result.list
				}
				// 渲染数据
//				_self.diposeData(page);
//				if(page.list && page.list.length > 0) {
                    // 页数加1
//                  pageParams.curPage = pageParams.curPage + 1;

                    // 上拉刷新
//                  if (type == "up") {
                       /* // 更新分页插件
                        me.resetload();*/

                        // 解锁loadDownFn里锁定的情况
//                      me.unlock();

                       /* me.noData(false);*/

//                  } else {
//                      // 更新分页插件
//                      me.resetload();
//                      me.lock();
//                  }
                    // 如果没有数据
//              }
                    /*} else {
                        if(pageParams.curPage == 1){
    //						alert(type);
    //						alert(2);
                            // 无数据div显示
                            console.log($("#empty-view").length)
                            if($("#empty-view").length == 0){
                                var html=''
                                html+='<div id="empty-view" class="no-group"><div class="no-record-img no-record-cloud"></div><p>无记录</p></div>'
                                $(".content").empty()
                                $("#video_list").append(html)
                            }
                            // 锁定
                                me.lock();
                                                        // 更新分页插件
                                me.resetload();

                                // 无数据,不会再执行加载
                                me.noData();

                        }else{
                            // 下拉刷新
                            if(type == "up") {
                                // 更新分页插件
                                me.resetload();

                                me.noData(true);
                                // 上拉加载
                            } else {
                                // 锁定
                                me.lock();
                                // 无数据
                                me.noData();
                                // 更新分页插件
                                me.resetload();
                            }
                        }
                    }*/


			}).catch(function(error) {
//				console.log(error);
				// 即使加载出错，也得重置
//				me.resetload();
			});

		},
		diposeData: function(page) {
			videoApp.$data.items = videoApp.$data.items.concat(page.list);
			$("img.lazy").delayLoading({
						defaultImg:  "",                      // 预加载前显示的图片
					//	errorImg: defaultImg,                         // 读取图片错误时替换图片(默认：与defaultImg一样)
						imgSrcAttr: "originalSrc",                    // 读取图片的src
						setImg: "data-src",              // 记录图片路径的属性(默认：originalSrc，把页面img的src属性值传给originalSrc属性)
						beforehand: 300,                      // 预先提前多少像素加载图片(默认：0)
						event: "scroll",                      // 触发加载图片事件(默认：scroll)
						duration: 300,                        // 三种预定淡出(入)速度之一的字符串("slow", "normal", or "fast")或表示动画时长的毫秒数值(如：1000),默认:"normal"
						container: window,                    // 对象加载的位置容器(默认：window)
						success: function (imgObj) {
							imgObj.parent().css("background","#FFFFFF");
						},       // 加载图片成功后的回调函数(默认：不执行任何操作)
						error: function (imgObj) { }         // 加载图片失败后的回调函数(默认：不执行任何操作)
					});

				
				

		},
		clickPraise: function(a) {
			var v = videoApp.$data.items[a];
			v.praise = !v.praise;
			if(v.praise) {
				v.praiseNum = v.praiseNum + 1;
				//v.seeNum = v.seeNum + 1;
			}else{
				v.praiseNum = v.praiseNum - 1;
				//v.seeNum = v.seeNum+1;
			}
			var param = new FormData();
			param.append("id", v.id);
			param.append("praise", v.praise);
			axios.post(getUrl() + "/community/video/praise", param).then(function (response) {
//				console.info(response.data);
			});
		},

		format_Date: function(val) {
			//      	console.log(new Date(1508223161000).Format("yyyy-MM-dd hh:mm:ss "))
			return new Date(val).Format("yyyy-MM-dd hh:mm:ss ");
			// return val;
		},
		collect:function (a) {
			var _self = this;
			var v = videoApp.$data.items[a];
			axios.get(getUrl() + "/collect/do?id=" + v.id +"&type=5" ).then(function (response) {
				if (response.data.code == 4001) { // 收藏成功
					v.collect = true;
				}else if(response.data.code == 4003){ //取消收藏
					v.collect = false;
				}else{
					msg(response.data.message);
				}
				layer.closeAll();
				msg(response.data.message);
			}).catch(function (error) {
				layer.closeAll();
				warm("收藏出错")
			});
		}
	}

});
Date.prototype.Format = function(fmt) {
	var o = {
		"M+": this.getMonth() + 1, //月份
		"d+": this.getDate(), //日
		"h+": this.getHours(), //小时
		"m+": this.getMinutes(), //分
		"s+": this.getSeconds(), //秒
		"q+": Math.floor((this.getMonth() + 3) / 3), //季度
		"S": this.getMilliseconds() //毫秒
	};
	if(/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for(var k in o)
		if(new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
}
var refreshPage = function () {
	pageParams.curPage = 1;
	alert(videoApp)
	videoApp.loadData();
}
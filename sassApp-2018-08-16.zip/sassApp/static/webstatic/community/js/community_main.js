/**
 * @author liguancheng
 * @date 2017-8-11 12:07
 */
//window.onload=function(){
//	
//}
setTimeout(function() {
	appApi.setPullRefresh(false);
}, 1000)



// addEventListener('touchstart', function(e){
//     // e.preventDefault();
//     e.stopPropagation();
// }, false);
//Adaptive.adpPage(true, "gcq");
var params = getParam(window.location.href);
var flag = params.hasOwnProperty("flag") ? params.flag : "video";
var projectSN = params.projectSn;
mui.ready(function() {
	//为选项卡加上点击事件
	mui("#segmentedControl").on("tap", "a", function() {
		flag = this.getAttribute("flag");
	});
	var s = document.getElementById("segmentedControl");
	var i = 0;
	console.info(s)
	var cf = s.firstElementChild;
	var cl = s.lastElementChild;
	if(cf.getAttribute("flag") == flag) {
		addClass(cf, "mui-active");
	} else {
		i = 1;
		addClass(cl, "mui-active")
	}
	//addClass(document.getElementById(flag),"mui-active");
	var slider = mui('#slider').slider();
	//slider.gotoPage(i,100);
})
//===================

//项目列表显示
function showProject() {
	document.getElementsByTagName("html")[0].style.overflow = "hidden"
	document.body.style.overflow = "hidden"
	document.getElementById("shade").style.display = "block";
	document.getElementById("add-style").style.display = "block";
	/*axios.get(getUrl() + "/work_api/projectname").then(function (resp) {
        if (resp.data.code == 0) {
            var array = resp.data.result;
	        if(flag == "info" &&array && array.length == 0){
		        window.appApi.openNewWindow(getPagePath() + "/community/community_send_info.html");
		        return;
	        }

            if (array) {
                var ht = '<li class="mui-table-view-cell" onclick="javascript:projectClick(\'$projectSN\')">$text</li>';
                var htmlstr = (flag == "info" ? '<li class="mui-table-view-cell" onclick="javascript:projectClick()">不选项目</li>' : (flag == "video" && array.length > 0 ? '' : '<li class="mui-table-view-cell">没有参与的项目</li>'));
                for (var i = 0; i < array.length; i++) {
                    htmlstr += ht.replace("$projectSN", array[i].serialNum).replace("$text", array[i].ProjectName);
                }
                document.getElementById("project_list").innerHTML = htmlstr;
            }
        } else {
            msg("系统报错:" + resp.data.message);
        }
    }).catch(function (err) {
        console.log(err);
    })*/
}

//项目列表隐藏
function hideProject() {
	document.getElementsByTagName("html")[0].setAttribute("style", "overflow:")
	document.body.setAttribute("style", "overflow:")
	document.getElementById("shade").style.display = "none";
	document.getElementById("add-style").style.display = "none";
}

function projectClick(sn) {
	hideProject();
	if(flag == "video") {
		projectSN = sn;
		document.getElementById("upfile").click();
		console.info("发布视频" + sn);
	} else {
		if(undefined == sn) projectSN = "";
		window.appApi.openNewWindow(getPagePath() + "/community/community_send_info.html?projectSN=" + sn);
	}
}
var refreshPage = function(type) {
	document.getElementById(type + '-iframe').contentWindow.location.reload(true);
	//	document.getElementById(type + "-iframe").contentWindow.location.reload(true).refreshPage();
}

//function uploadImageAndVideo(th) {
//	hideProject();
//	if(th.files[0].size <= 15728640) {
//		if(th.files[0] == null || th.files[0].type.indexOf("video") == -1) {
//			msg("请选择视频类型");
//		} else {
//			layer.open({
//				content: "后台运行中，处理完自动更新",
//				skin: 'msg',
//				time: 3 //3秒后自动关闭
//			});
//			var html = '';
//			html += '<span>视频处理中</span><span class=' + "mui-loading" + '><div class=' + "mui-spinner" + '></div></span>';
//			document.getElementById("cus-title").innerHTML = html;
//			uploadFile(th, getUrl() + '/community/video/save', {
//				projectSN: projectSN
//			}, function(resp) {
//				if(resp.code == 0) {
//					msg("上传成功！");
//					document.getElementById("cus-title").innerText = "形象视频";
//					setTimeout(function() {
//						location.reload()
//					}, 100)
//				}
//			})
//
//		}
//	} else {
//		msg("上传视频过大，请重试")
//	}
//}
var selectProject = function(type) {
	hideProject();
	if(type == 0){
		//不选择项目
		document.getElementById("upfile").click();
	}else{
		//projectSN, projectName, projectNameShort("测试5")
		var projectSN, projectName, projectNameShort;
		document.getElementById("upfile").click();
//			window.appApi.openNewWindow(getPagePath() + "/work/project_list_for_video.html");
	}
}

//上传视屏
function uploadImageAndVideo(th) {
	if(th.files[0].size<=15728640){
		if (th.files[0] == null || th.files[0].type.indexOf("video") == -1) {
			msg("请选择视频类型");
		} else {
			// var index_ = layer.open({
			// 	type: 2
			// 	, content: '上传中'
			// });
			// uploadFile(th, getUrl() + '/community/video/save', {projectSN: psn}, function (resp) {
			// 	console.info(resp);
			// 	if (resp.code == 0) {
			// 		msg("上传成功");
			// 		setTimeout(function () {
			// 			projectSN = "";
			// 			layer.closeAll();
			// 			//refreshPage("video");
			// 			appApi.refreshNav(0);
			// 			appApi.closeNewWindow();
			// 			th.value = "";
			// 		}, 1000);
			// 	} else {
			// 		layer.closeAll();
			// 		msg(resp.message);
			// 	}
			// })
			layer.open({
				content: "后台运行中，处理完自动更新"
				,skin: 'msg'
				,time: 3 //3秒后自动关闭
			});
//			alert(projectSN)
			var html='';
			html+='<span>视频处理中</span><span class='+"mui-loading"+'><div class='+"mui-spinner"+'></div></span>';
			document.getElementsByClassName("mui-title")[0].innerHTML=html;
			uploadFile(th, getUrl() + '/community/video/save', {projectSN: projectSN}, function (resp) {
				if (resp.code == 0) {
					msg("上传成功！");
					document.getElementsByClassName("mui-title")[0].innerText = "形象视频";
					setTimeout(function(){
						projectSN = "";
						layer.closeAll();
						appApi.refreshNav(0);
//			    		appApi.closeNewWindow();
						th.value = "";
                        location.reload(true)
					},1000);
				}else{
					layer.closeAll();
					msg(resp.message);
				}
			 })
		}
	}else{
		msg("视频超过一分钟，请重新拍摄")
	}
}

/**
 * 搜索
 */
function openSearch() {
	var url = getPagePath() + "/community/community_search.html?type=search&flag=" + flag;
	appApi.openNewWindow(url)
}
/**
 * 筛选
 */
function openFilter() {
	var url = getPagePath() + "/community/community_filter.html?type=filter&flag=" + flag;
	appApi.openNewWindow(url)
}
/*
function filterCallBack(type) {
	//showProject();
	loading("正在筛选中...")
	document.getElementById(type + '-iframe').contentWindow.location.reload(true);
}*/
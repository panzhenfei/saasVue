/**
 * @author liguancheng
 * @date 2017-8-11 12:07
 */
var map = getParam(window.location.href);
var projectSN = map.projectSN===undefined ? "" : map.projectSN;//当前选择的项目sn
var sendInfo = new Vue({
    el:"#send_info",
    data:{
	    showBtn:true,
        sendContent:"",//发布内容
        items:[], //发布的图片集合
    },
    methods:{
        deleteClick:function (a) {
	        var _self = this;
	        _self.items.splice(a,1);
	        //显示上传按钮
	        _self.$data.showBtn = true;
        },
        selectImg:function () {
	        var _self = this;
            if(_self.$data.items.length >= 9){
                msg("最多只能选择9张");
                return false;
            }else{
	            var limit = 9 - _self.$data.items.length; //只能上传的数量
	            window.appApi.openCamera(3,0,limit);
            }
        },
        viewImg:function(th) {
            var _self = this;
            var files = th.files;
            for(var i = 0; i < 9 - _self.$data.items.length;i++){
                var file = files[i];
	            if (file) {
		            if(file.type.indexOf("image") == -1) {
			            msg("只能选择图片");
		            }else {
		                var type = file.type;
			            var reader = new FileReader();
			            reader.readAsDataURL(file);
			            reader.onload = function (e) {
				            var json = {imgData:e.target.result, fileType:type};
				            console.log(json)
				            _self.$data.items.push(json);
				            th.value = "";
				            if(9 - _self.$data.items.length <= 0){
					            //显示上传按钮
					            _self.$data.showBtn = false;
				            }
			            }
		            }
	            }
            }
        },
        sendClick: function () {
            var _self = this;
            var btn = document.getElementById("sendBtn");
            if(_self.sendContent=="" && _self.items.length==0 ){
                msg("发布内容不能为空");
            }else{
	            if(btn.getAttribute("disabled") && btn.getAttribute("disabled") == "disabled"){
                    return;
	            }
                btn.setAttribute("disabled","disabled");
               var param = {projectSN:  projectSN, sendContent:_self.sendContent, imgDatas:_self.items};
                axios.post(getUrl() + "/community/info/send", param).then(function (response) {
                  msg("发送成功，返回后刷新页面");
//                setTimeout(function () {
//	                  if(isApp){
//		                  appApi.broadcast("refreshPage('info')");
//		                  appApi.closeNewWindow();
//	                  }else{
//		                  window.history.back();
//	                  }
//                }, 1500);
					window.history.back();
                });
            }

        }
    }

});



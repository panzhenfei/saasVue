/**
 * @author liguancheng
 * @date 2017-8-11 12:07
 */
var map = getParam(window.location.href);
var id = map.id===undefined ? "" : map.id;//当前id
var infoId = id;//当前评论的日志id
var autoComment = map.autoComment===undefined ? false : true;//进入是否自动播放
var replyUserId;//被回复的用户id
var replyUserName;//被回复的用户名称
var infoIndex;//当前日志所在数组的下标
var cIndex;//点击回复/删除评论的数组下标
var commentUserId = getCookie("userid");//当前用户的id
var commentUserName = decodeURI(getCookie("username"));//当前用户的昵称
var imageHost="";
var share_key = "SHARE_KEY";
localStorage.setItem(share_key,2);
window.appApi.callBackFun = function() {
	if(callFlag == appApi.callBackFlag.BACKFUN) {
		alert(0)
//		app.selectCompany(CONTENT);
	}
}
//点击原生返回,执行的方法
function onClickBack(){
	appApi.closeNewWindow()
	appApi.broadcast("video_zan(1)");
}
var infoApp = new Vue({
    el:"#comment_list",
    data:{
	    comm_placeholder:"",
	    comment_box_display:"none",
	    send_content:"",
	    imgHost:UPLOAD_SERVER_ADDRESS,
        item:{
	    	commentNum: 0,
	        title: ""},
        comments:[],
	    vshow:false,
	    hasUser:undefined == commentUserId || commentUserId == "" ?false:true,
	    bodyH:$("body").height()
    },
    created:function () {
	    var _self = this;
	    _self.getDetail(_self.initEvent);
	    appApi.stopBack()
	    $(".pinlun").css("height",this.bodyH-130+"px")
    },

    methods: {
    	doPlay:function () {
		    var _self = this;
		    var obj = _self.$data.item;
		    if(isApp){
			    window.appApi.openVideo(window.location.href,obj.videoUrl,"视频详情",obj.thumbImage);
		    }else{
			    BackCookie.setCookie("videoUrl", obj.videoUrl);
			    window.appApi.openNewWindow(getPagePath() + "/community/play_video.html");
		    }
	    },
        initEvent:function () {
    		var _self = this;
        	/*if(autoPlay && isApp){
        		//自动播放
		        _self.doPlay();
	        }*/
        	if(autoComment){
        		//自动打开评论
		       // infoIndex = this.getAttribute("data-i");
		       setTimeout( infoApp.replyComment,500)
		        //appApi.showKeyboard();

	        }

            //绑定事件
	        mui.ready(function() {
		        if(!isApp){
			        mui(".device-flag")[0].classList.remove("mui-hidden");
//			        mui(".device-flag")[1].classList.remove("mui-hidden");
		        }else{
			        document.getElementById("comment_list").style.paddingTop = "0px"
		        }
		        mui("#comment_list").on('tap','.icon-zan', function () {//绑定点赞事件
			        infoApp.clickPraise();
		        });
		        mui("#comment_list").on('tap','.log-header', function () {//绑定头像事件
			        infoApp.lookUserInfo();
		        });
		        mui("#comment_list").on('tap','.name', function () {//绑定评论姓名事件
			        var user_id = this.getAttribute("data-a");
			        infoApp.lookUserInfo(user_id);
		        });
		        mui("#comment_list").on('tap','.comment-content', function () {//绑定评论内容，点击回复
			        //infoId = this.getAttribute("data-a");
			        replyUserId = this.getAttribute("data-b");
			        replyUserName = this.getAttribute("data-c");
			        infoIndex = this.getAttribute("data-i");
			        cIndex = this.getAttribute("data-cindex");
			        infoApp.replyComment();

		        });
		        mui("#comment_list").on('tap','.icon-comment', function () {//绑定评论
			        //infoId = this.getAttribute("data-a");
			        infoIndex = this.getAttribute("data-i");
			        infoApp.replyComment();

		        });
		        mui("#comment_list").on('tap','.icon-share', function () {//绑定更多事件
			        var url = this.getAttribute("data-url");
			        var img = this.getAttribute("data-img");
			        var name = this.getAttribute("data-name");
			        var project = this.getAttribute("data-project");
			        if(project == undefined || project == ""){
				        project = "非项目视频"
			        }
			        var logo = getUrl() + "/static/images/app-logo.jpg";
			        if(img == undefined || img == ""){
			        	img = logo;
			        }
			        var id = this.getAttribute("data-id");
			        localStorage.setItem(share_key,SHARE_OPERATE.VIDEO_SHARE);
			        var shareUrl = getPagePath() + "/community/community_comment.html?id="+id;
			        appApi.shareVideo(0, name + "发布了一段工程项目的形象视频，赶快来看看吧", project, shareUrl, img, url,"视频详情", null);
		        });
		        mui("#comment_list").on('tap','.video-pic', function () {//绑定视频播放事件
			        _self.doPlay();
		        });
		        document.getElementById("comment_list").addEventListener("swipeup",function(){
			        _self.hideInput();
		        })
		        document.getElementById("comment_list").addEventListener("swipedown",function(){
			        _self.hideInput();
		        })
	        })
        },
        getDetail:function (callback) {
            var _self = this;
            //获取视频详情
	        axios.get(getUrl() + "/community/video/detail", {
		        params: {id:id}
	        }).then(function (response) {
		        if (response.data.code == 0) {
		            var rs = response.data.result;
			        _self.item = rs.item;
			        console.log("??????????",_self.item)
			        _self.comments = rs.comments;
			        _self.vshow = true;
			        if(callback) callback();
		        }else{
		            warm(response.data.message)
                }
	        }).catch(function (error) {
		        console.log(error);
	        });
        },
	    lookUserInfo:function (userId) {//查看用户资料
		    window.appApi.openNewWindow(getPagePath() + "/contacts/eg_details.html?userId="+userId);
	    },
	    clickPraise:function(){//点赞
	    	appApi.broadcast()
		    var v = infoApp.$data.item;
		    v.praise = !v.praise;
		    //v.seeNum = v.seeNum+1;
		    v.praiseNum = v.praiseNum + (v.praise ? 1:-1);
		    var param = new FormData();
		    param.append("id", v.id);
		    param.append("praise", v.praise);
		    axios.post(getUrl() + "/community/video/praise", param).then(function (response) {
			    console.info(response.data);
		    });
	    },
	    replyComment: function () {//回复/评论点击
		    var _self =  infoApp.$data;
		    console.info(replyUserId+"======="+commentUserId);
		    if(replyUserId==commentUserId  && cIndex != undefined){//自己的评论再次点击是删除
			    confirmLayer("是否删除该条评论？", function(){
				    layer.closeAll();
				    //组装请求参数
				    var param = new FormData();
				    var tid =  _self.comments[cIndex].id;
				    param.append("id",tid);
				    param.append("communityId", _self.item.id);
				    _self.comments.splice(cIndex, 1);
				    //删除子评论
				    /*var newArr = [];
				    for(var i =0;i<_self.comments.length;i++) {
					    if(_self.comments[i].id != tid && tid != _self.comments[i].replyId){
						    newArr.push(_self.comments[i])
					    }
				    }
				    _self.comments = newArr;*/
				    infoApp.initCommentParam();
				    axios.post(getUrl() + "/community/video/delcomment", param).then(function (resp) {
					    console.info(resp.data);
					    _self.item.commentNum = _self.item.commentNum - 1;
					    cIndex ="";
				    })
			    })
		    }else if(replyUserId && replyUserId != ""){//回复
//		    	var stopmove=document.getElementsByClassName("stopmove")[0];
//		    	stopmove.style.overflow="hidden";
			    _self.comment_box_display="block";
			    document.getElementById("commentIpt").innerText= "";
			    _self.comm_placeholder = "回复"+replyUserName+"：";
			    document.getElementById("commentIpt").focus();
//			    var commentIptq=document.getElementById("commentIpt");
//				     commentIptq.addEventListener('touchstart',function(){
//				        commentIptq.focus();                                       
//				})
			    po_Last_Div(document.getElementById("commentIpt"));
		    }else{//评论
//		    	var stopmove=document.getElementsByClassName("stopmove")[0];
//		    	stopmove.style.overflow="hidden";
			    _self.comment_box_display="block";
			    _self.comm_placeholder = "";
//			    document.getElementById("commentIpt").innerText= "";
			    infoApp.inputtext()
//			    document.getElementById("commentIpt").focus();
//			     var commentIptq=document.getElementById("commentIpt");
//				     commentIptq.addEventListener('touchstart',function(){
//				        commentIptq.focus();                                       
//				})
			    po_Last_Div(document.getElementById("commentIpt"));
		    }
	    },
	    inputtext:function(){
	    	var msgText =  document.getElementById("commentIpt");
	    	var pinmsdk=document.getElementsByClassName("pinlun")[0];
	    	pinmsdk.style.overflow="hidden"
			document.body.classList.add("addtext");
        	document.getElementsByTagName("html")[0].classList.add("addtext");
	    	$('.mui-backdrop').on("touchmove",function(e){
                e.preventDefault();
     		});
	    	msgText.addEventListener('tap',function () {
				var target=this
				
			setTimeout(function(){
				target.scrollIntoView(true)
			},100)
                // 光标移动到最后
                msgTextLastPos(msgText);
                // 获得输入框键盘焦点
                msgTextFocus(msgText);          
            })
	    	// 获得输入框键盘焦点
            var msgTextFocus = function(obj){
                obj.focus();
                setTimeout(function() {
                    obj.focus();
                }, 150);
            }
            // 光标移动到最后
            function msgTextLastPos(obj) {
                if (window.getSelection) {//ie11 10 9 ff safari
                    obj.focus(); //解决ff不获取焦点无法定位问题
                    var range = window.getSelection();//创建range
                    range.selectAllChildren(obj);//range 选择obj下所有子内容
                    range.collapseToEnd();//光标移至最后
                }
                else if (document.selection) {//ie10 9 8 7 6 5
                    var range = document.selection.createRange();//创建选择对象
                    range.moveToElementText(obj);//range定位到obj
                    range.collapse(false);//光标移至最后
                    range.select();
                }
            }
	    },
	    sendComment:function () {//发送评论信息
		    var _data = infoApp.$data;
		    var _self = this;
		    var msgText =  document.getElementById("commentIpt");
	    	var pinmsdk=document.getElementsByClassName("pinlun")[0];
	    	pinmsdk.style.overflow="auto"
			document.body.classList.remove("addtext");
        	document.getElementsByTagName("html")[0].classList.remove("addtext");
//		    _data.send_content = document.getElementById("commentIpt").innerText;
		    _data.send_content = document.getElementById("commentIpt").innerText;
		    var chat=document.getElementsByClassName("chat-btn")[0];
				     chat.addEventListener('touchstart',function(){
				        commentIptq.blur();                                       
				})
		    if(!_data.send_content || _data.send_content==""){
			    msg("评论内容不能为空！");
//			    var stopmove=document.getElementsByClassName("stopmove")[0];
//		    	stopmove.style.overflow="hidden";
			    return;
		    }
		    _data.comment_box_display="none";
		    var reId = undefined == cIndex || "" == cIndex   ? "":_data.comments[cIndex].id;
		    var comment_format = {
			    communityId:infoId,
			    commentUserId:commentUserId,
			    commentUserName:commentUserName,
			    replyId:reId,
			    replyUserId:replyUserId,
			    replyUserName:replyUserName,
			    commentContent:_data.send_content};//重置评论json
		    axios.post(getUrl() + "/community/video/savecomment", comment_format).then(function (resp) {
			    console.info(resp.data);
			    comment_format.id = resp.data.result;
			    if(_data.comments){
				    _data.comments = _data.comments.concat(comment_format);
			    }else{
				    _data.comments = [comment_format];
			    }
			    _self.item.commentNum = _self.item.commentNum + 1;
			    _self.getDetail(function () {
				    msg("评论成功")
				    _self.hideInput();
			    });
//			    var stopmove=document.getElementsByClassName("stopmove")[0];
//		    	stopmove.style.overflow="hidden";
		    	document.getElementById("commentIpt").innerText= "";
		    })
		    infoApp.initCommentParam();

	    },
	    format_Date: function (val) {//格式化时间
		    if(!val){
		    	return "";
		    }
		    return new Date(val).Format("yyyy-MM-dd hh:mm:ss ");
	    },
	    conductData:function (array) {//处理获取的列表数据
		    for(var i=0; i<array.length; i++){
			    console.info(array.length);
			    var s = array[i];
			    s.createTime = new Date(s.createTime).Format("yyyy-MM-dd hh:mm:ss");
			    s.userIcon = imageHost + s.userIcon;
			    var imgJson= JSON.parse(s.resourcesJ);
			    if(imgJson && imgJson != "" && imgJson.length > 0) {
				    var picIndex = 0;
				    var imgArray = [];
				    for (var j = 0; j < imgJson.length; j++) {
					    var im = imgJson[j];
					    im["picIndex"] = j;
					    im.url = imageHost + im.url;
					    var browsePic = {"src": im.url, "w": im.width, "h": im.height, "msrc": im.url, "el": {}};
					    imgArray.push(browsePic)
				    }
				    browseImageArray.push(imgArray);
			    }
			    s.resourcesJ = imgJson;
			    s.commentJ = JSON.parse(s.commentJ);
		    }
		    infoApp.$data.items = infoApp.$data.items.concat(array);
	    },
	    initCommentParam:function () {
		    //infoId = null;//当前评论的日志id
		    replyUserId = null;//被回复的用户id
		    replyUserName = null;//被回复的用户名称
		    infoIndex = null;//当前日志所在数组的下标
		    this.send_content="";
	    },
	    hideInput:function () {
		    var _self = this;
		    var msgText =  document.getElementById("commentIpt");
	    	var pinmsdk=document.getElementsByClassName("pinlun")[0];
	    	pinmsdk.style.overflow="auto"
			document.body.classList.remove("addtext");
        	document.getElementsByTagName("html")[0].classList.remove("addtext");
		    _self.$data.comment_box_display = "none";
		    //_self.$data.send_content = "";
		    _self.$data.comm_placeholder = "";
//		    document.getElementById("commentIpt").innerText = "";
//		     var stopmove=document.getElementsByClassName("stopmove")[0];
//		    	stopmove.style.overflow="hidden";
	    },
	    collect:function () {
		    var _self = this;
		    axios.get(getUrl() + "/collect/do?id=" + id +"&type=5" ).then(function (response) {
			    if (response.data.code == 4001) { // 收藏成功
				    _self.item.collect = true;
			    }else if(response.data.code == 4003){ //取消收藏
				    _self.item.collect = false;
			    }else{
				    msg(response.data.message);
			    }
			    layer.closeAll();
			    appApi.broadcast()
			    msg(response.data.message);
		    }).catch(function (error) {
			    layer.closeAll();
			    warm("收藏出错")
		    });
	    }
    }

});

function po_Last_Div(that) {
	window.setTimeout(function () {
		var sel, range;
		if (window.getSelection && document.createRange) {
			range = document.createRange();
			range.selectNodeContents(that);
			range.collapse(true);
			range.setEnd(that, that.childNodes.length);
			range.setStart(that, that.childNodes.length);
			sel = window.getSelection();
			sel.removeAllRanges();
			sel.addRange(range);
		} else if (document.body.createTextRange) {
			range = document.body.createTextRange();
			range.moveToElementText(that);
			range.collapse(true);
			range.select();
		}
		/*if(isApp){
			appApi.showKeyboard()
		}*/
	}, 1)
}
//var winHeight = $(window).height();
//$(window).resize(function(){
//var thisHeight=$(this).height();
//alert(1)
//if(winHeight - thisHeight >50){
// alert(0)}
//}
//)
//edit.focus();


$(document).on('focusin', function () {
//alert(0)
//	$(".group-chat").css("bottom",$("body").scrollTop()+"px")
//		$(".pinlun").scrollIntoViewIfNeeded();
//		clearInterval(timer);
//    var index = 0;
//    timer = setInterval(function() {
//      if(index>5) {
//        $('body').scrollTop(1000000);
//        clearInterval(timer);
//      }
//      index++;
//    }, 50)
});
 
//$(document).on('focusout', function () {
//$(".group-chat").css("bottom","0px")
//});

var c=0
$(document).scroll(function() {
	c+=10
	$('body').scrollTop(c);
})
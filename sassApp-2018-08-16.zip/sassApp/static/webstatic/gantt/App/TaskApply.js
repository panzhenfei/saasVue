/**
 huangjianwei 2015-09-23
 */
var projectpath = getDbDir() + "swprojectinfo.nsf";
var managerfield = "ManagerInput";
var taskCount = 0;
var projectsn = "";
var ganttsn = "";
var importmode = "";
var flowsn = "";
var isCanImport = true;
var isInputed = false;
var isPublished = false;
/*
 转换JSON
 */
function toJson(str) {
    return (new Function("return " + str))();
}
/*
 获取表单字段
 */
function getCustomFormDetail() {
    var data = [];
    var cfd = "";
    var o = $("CustomFormDetail")[0];
    var oo = $("#DIV_CustomFormDetail");

    if (typeof(o) === "undefined") {
        if (typeof(oo) === "undefined" || oo === null) {
            return "";
        } else {
            cfd = oo.innerHTML.replace(/\r|\n|<br>|<BR>/g, "");
        }
    } else {
        cfd = o.value.replace(/\r|\n|<br>|<BR>/g, "");
    }

    var fb = cfd.split("§");
    for (var i = 0; i < fb.length; i++) {
        if (fb[i] !== "" && fb[i] !== " ") {
            data.push(fb[i]);
        }
    }
    return data;
}
/*
 检测是否已经导入甘特图或者已经存在顶层任务。
 */
function checkCanImport() {
    projectsn = $("ProjectSN")[0].value;
    if (typeof $("ImportMode")[0] === "undefined") {
        importmode = "自甘特图导入";
    } else {
        importmode = $("ImportMode")[0].value;
    }
    if (projectsn === "") {
        alert("请先选择项目！");
        return false;
    }
    if (importmode === "全部手动创建") {
        isCanImport = false;
        return false;
    }
    var data = getCustomFormDetail();
    if (getValueFromArray("InputStatus", data) === "已导入") {
        isInputed = true;
    }
    var u = "/" + g_sDBDir + "/gantt.nsf/TemplateAgent?OpenAgent&method=check&ganttsn=" + escape(projectsn) + "&projectsn=" + escape(projectsn) + "&rand=" + Math.random();
    var s = _postsync(u, "");
    taskCount = parseInt(s);
    if (!isNaN(taskCount) && taskCount > 0) {
        isCanImport = false;
    }
}
/*
 检查导入的文件
 */
function checkFile() {
    if (getRadioValue("ImporType") === "选择模板") {
        return true;
    }
    // 检测附件列表的内容
    if (winAtt.newFiles() === "" && winAtt.uploadedFiles() === "") {
        alert("请将要导入的项目进度文件添加到附件列表中！");
        return false;
    }
    var arr = Array().concat(winAtt.uploadedFiles().replace(/\|/g, ",").split(","), winAtt.newFiles().replace(/\|/g, ",").split(","));
    if (arr.lnegth === 0) {
        alert("请将要导入的项目进度文件添加到附件列表中！");
        return false;
    }
    for (var x = 0; x < arr.length; x++) {
        if (!arr[x] || arr[x] === "" || winAtt.getDeleteList().match(arr[x])) {
            arr.splice(x, 1);
            x--;
        } else {
            arr[x] = arr[x].rightback("\\");
        }
    }
    if (arr.length != 1 || !arr[0].match(/\.mpp$/i)) {
        alert("只能上传一个MPP格式的文件！");
        return false;
    }
    return true;
}
/*
 如果是上传附件，则检查是否上传了附件
 */
function checkFileBeforeSubmit() {
    try {
        if (g_sAction === "flow" && winFlow.CurrentNode === "制单") {
            var projectsn = winForm.fv("ProjectSN");
            if (projectsn === "") {
                alert("请选择项目！");
                return false;
            }
            var u = "/" + g_sDBDir + "/gantt.nsf/TemplateAgent?OpenAgent&method=checktask&ganttsn=" + escape(projectsn) + "&projectsn=" + escape(projectsn) + "&rand=" + Math.random();
            var s = _postsync(u, "");
            taskCount = parseInt(s);
            if (!isNaN(taskCount) && taskCount > 0) {
                isCanImport = false;
                alert("【提示】\n\n此项目已经发布了任务，无法再次从模板发布任务！\n您可以使用“任务发布”或者“任务分解”继续发布新任务。");
                return false;
            }
            if (winForm.fv("ImportType") === "上传附件") {
                if (winAtt.newFiles() === "" && winAtt.uploadedFiles() === "") {
                    alert("请将要导入的项目进度文件添加到附件列表中！");
                    return false;
                }
                var arr = Array().concat(winAtt.uploadedFiles().replace(/\|/g, ",").split(","), winAtt.newFiles().replace(/\|/g, ",").split(","));
                if (arr.lnegth === 0) {
                    alert("请将要导入的项目进度文件添加到附件列表中！");
                    return false;
                }
                for (var x = 0; x < arr.length; x++) {
                    if (!arr[x] || arr[x] === "" || winAtt.getDeleteList().match(arr[x])) {
                        arr.splice(x, 1);
                        x--;
                    } else {
                        arr[x] = arr[x].rightback("\\");
                    }
                }
                if (arr.length != 1 || !arr[0].match(/\.mpp$/i)) {
                    alert("只能上传一个MPP格式的文件！");
                    return false;
                }
            }
            if (winForm.fv("ImportType") === "选择模板") {
                if (winForm.fv("ProjectTemplate") === "") {
                    alert("请选择任务模板文件！");
                    return false;
                }
            }
        }
        return true;
    } catch (e) {
        alert(e.name + "\n" + e.message);
    }
}
/*
 编辑模板
 提交之前导入
 验证有没有选择项目→有没有选择模板→是否已经发布任务→是否已经暂存
 直接提交
 验证有没有选择项目→有没有选择模板→是否已经发布任务
 */
function EditTaskGantt() {
    isCanImport = true;
    isInputed = false;
    //检查项目
    projectsn = $("ProjectSN")[0].value;
    if (projectsn === "") {
        alert("请先选择项目！");
        return false;
    }
    ganttsn = $("GanttSN")[0].value;
    if (ganttsn === "") {
        ganttsn = projectsn;
        $("GanttSN")[0].value = projectsn;
    }
    var url = "/" + g_sDBDir + "/gantt.nsf/Gantt?ReadForm&ganttsn=" + encodeURI(projectsn) + "&projectsn=";
    url += encodeURI(projectsn) + "&projectpath=" + projectpath + "&managerfield=" + managerfield + "&stage=&gantttype=PLAN&rand=" + Math.random();
    if ($("ImportStatus")[0].value === "已导入") {
        //暂存之后才能编辑
        isInputed = true;
        var gv = window.open(url, "_blank");
        gv.focus();
        return false;
    }
    var s = _postsync("/" + g_sDBDir + "/gantt.nsf/TemplateAgent?OpenAgent&method=check&ganttsn=" + encodeURI(projectsn) + "&projectsn=" + encodeURI(projectsn) + "&rand=" + Math.random(), "");
    taskCount = parseInt(s);
    if (!isNaN(taskCount) && taskCount > 0) {
        alert("【提示】\n\n此项目已经发布任务，不能再次导入！\n您可以通过视图查找相关的流程！");
        return false;
    }
    var tsn = $("ProjectTemplateSN")[0].value;
    if (tsn === "") {
        alert("请选择模板文件！");
        return false;
    }
    //暂存之后才能编辑
    if (g_IsNewDoc) {
        alert("【提示】\n\n文档目前尚未保存，请先点一下“暂存”按钮，之后就可以正常编辑模板了！");
        return false;
    }
    flowsn = winForm.getFieldValue("SN");
    //打开导入窗口，导入成功后跳转到编辑界面
    var obj = {
        plantype: "template",
        unid: encodeURI(tsn),
        plansn: encodeURI(flowsn),
        ganttsn: encodeURI(ganttsn),
        projectsn: encodeURI(projectsn),
        projectpath: projectpath,
        managerfield: managerfield,
        stage: "",
        itype: "auto",
        gantttype: "PLAN",
        projectmove: encodeURI(getRadioValue("ProjectMove")),
        startdate: $("ProjectStartDate")[0].value,
        enddate: $("ProjectEndDate")[0].value
    };
    showMask("正在自动创建任务，请稍候……");
    _post("/" + g_sDBDir + "/taskapply.nsf/ImportTask?OpenAgent&sn=" + encodeURI(flowsn), "", function (h) {
        if (!_verifyAjax(h)) {
            return false;
        }
        closeMask();
        var s = h.responseText.replace(/\n$/, "");
        if (/SUCCESS/.test(s)) {
            showMask("任务创建成功！若未自动打开甘特图，请[<a href='" + url + "' onclick='return closeMask()' target='blank'>点击这里</a>]！");
            var gv = window.open(url, "GanttView");
            gv.focus();
            window.location.reload();
        } else {
            alert("错误：\n" + s);
        }
    });
}

/**
 * WBS计划变更审批在线编辑甘特图
 * @returns {boolean}
 * @constructor
 */
function EditPlanGantt() {
    projectsn = $("ProjectSN")[0].value;
    if (projectsn === "") {
        alert("请先选择项目！");
        return false;
    }
    ganttsn = $("GanttSN")[0].value;
    if (ganttsn === "") {
        ganttsn = projectsn;
        $("GanttSN")[0].value = projectsn;
    }
    if (g_IsNewDoc) {
        alert("【提示】\n\n文档目前尚未保存，请先点一下“暂存”按钮，之后就可以正常编辑模板了！");
        return false;
    }
    if ($("ImportStatus")[0].value === "已导入") {
        var url = "/" + g_sDBDir + "/gantt.nsf/Gantt?ReadForm&ganttsn=" + encodeURI(ganttsn);
        url += "&projectsn=" + encodeURI(projectsn) + "&projectpath=" + projectpath
        url += "&managerfield=" + managerfield + "&stage=&gantttype=PLAN&rand=" + Math.random();
        var gv = window.open(url, "_blank");
        gv.focus();
    } else {
        if ($("ImportStatus")[0].value == "") {

        }
        alert("此项目尚未导入计划！请使用“按模板发布任务”模块发布任务！");
    }
}

/*
 打开计划甘特图窗口
 */
function OpenPlanGantt(sn) {
    if (typeof sn != "undefined") {
        projectsn = sn;
    }
    return OpenGantt("PLAN");
}
/*
 打开任务甘特图窗口
 */
function OpenTaskGantt(sn) {
    if (typeof sn != "undefined") {
        projectsn = sn;
    }
    return OpenGantt("TASK");
}
/*
打开项目经理专用甘特图
 */
function OpenPMPGantt(sn) {
    if (typeof sn != "undefined") {
        projectsn = sn;
    }
    return OpenGantt("PMP");
}
/*
 根据类型打开甘特图
 */
function OpenGantt(type) {
    isInputed = false;
    isPublished = false;
    if (typeof type != "undeinfed" && type != "") {
        if (typeof g_xIsEditing != "undefined" && g_xIsEditing === "Y") {
            // 先判断是否新文档
            if (g_IsNewDoc === "Y") {
                alert("请先保存文档后再启动甘特图！");
            } else {
                if (projectsn === "") {
                    if (projectpath === "/" + g_sDBPath) {
                        projectsn = sSN;
                    } else {
                        projectsn = $("ProjectSN")[0].value;
                    }
                }
                getStatus();
            }
        } else {
            var data = getCustomFormDetail();
            if (data != "") {
                if (projectsn === "") {
                    if (projectpath === "/" + g_sDBPath) {
                        projectsn = sSN;
                    } else {
                        projectsn = getValueFromArray("ProjectSN", data);
                    }
                    getStatus();
                }
                if (getValueFromArray("InputStatus", data) === "已导入") {
                    isInputed = true;
                }
                //如果已经发布任务，默认为已经导入计划
                if (getValueFromArray("PublishStatus", data) === "已发布") {
                    isPublished = true;
                    isInputed = true;
                }
            } else {
                //在视图上操作
                var u = getDbDir();
                if (projectsn === "") {
                    u += "gantt.nsf/ProjectQuery?OpenAgent&method=getprojectbyname&projectname=" + escape(category.right("/")) + "&random=" + Math.random();
                } else {
                    u += "gantt.nsf/ProjectQuery?OpenAgent&method=getprojectbysn&projectsn=" + escape(projectsn) + "&random=" + Math.random();
                }
                var s = _postsync(u, "");
                var arr = toJson(s);
                if (arr.length = 1) {
                    if (arr[0].InputStatus === "已导入") {
                        isInputed = true;
                    }
                    if (arr[0].PublishStatus === "已发布") {
                        isPublished = true;
                    }
                } else {
                    alert("项目重名无法查看甘特图");
                    return false;
                }
            }
        }
        if (typeof projectsn === "undefined" || projectsn === "") {
            alert("请先选择项目！");
        } else {
            if (type === "PLAN" && !isInputed) {
                alert("任务尚未导入无法查看甘特图！");
                return false;
            }
            if ((type === "TASK" ||type === "PMP")  && !isPublished) {
                alert("任务尚未发布无法查看甘特图！");
                return false;
            }
            var url = "/" + g_sDBDir + "/gantt.nsf/Gantt?ReadForm&ganttsn=" + escape(projectsn) + "&projectsn=" + escape(projectsn) + "&projectpath=" + projectpath + "&managerfield=" + managerfield + "&stage=&gantttype=" + type + "&rand=" + Math.random();
            try {
                var gv = window.open(url, "_blank");
                gv.focus();
            } catch (e) {
                alert("甘特图打开失败！您的浏览器可能禁止脚本打开新窗口，建议您暂时关闭浏览器的广告过滤功能。")
            }
        }
    }
    return false;
}
/*
 获取发布状态
 */
function getStatus() {
    var u = getDbDir() + "gantt.nsf/ProjectQuery?OpenAgent&method=getprojectbysn&projectsn=" + escape(projectsn) + "&random=" + Math.random();
    var s = _postsync(u, "");
    if (s != "") {
        var arr = toJson(s);
        if (arr[0].ProjectSN === projectsn) {
            if (arr[0].InputStatus === "已导入") {
                isInputed = true;
            }
            if (arr[0].PublishStatus === "已发布") {
                isPublished = true;
            }
        }
    } else {
        alert("未取到该项目下甘特图信息！可能未导入进度表。或者未通过进度表审批发布任务！");
        return false;
    }
}

/*
 查看计划版本
 */
function OpenPlanList() {
    alert("查看计划版本")
}
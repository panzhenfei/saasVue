Ext.define('App.store.Assignment',{
    extend : 'Gnt.data.AssignmentStore',
    autoLoad : true,
    autoSync : false,
	model : 'App.model.Assignment',
	proxy : {
		method : 'POST',
		type : 'ajax',
		api : {
			read : 'AssignmentAgent?OpenAgent&method=assignment&jsonid='+a,
			create : 'AssignmentAgent?OpenAgent&method=assignmentCreate&ProjectSN='+encodeURI(projectsn),
			destroy : 'AssignmentAgent?OpenAgent&method=delete&ProjectSN='+encodeURI(projectsn)
		},
		writer : {
			type : 'json',
			root : 'assignmentsdata',
			encode : true,
			allowSingle : false
		},
		reader : {
			type : 'json',
			root : 'assignments'
		}
	},
	listeners : {
		load : function() {
			resourceStore.loadData(this.proxy.reader.jsonData.resources);
		}
	}
});
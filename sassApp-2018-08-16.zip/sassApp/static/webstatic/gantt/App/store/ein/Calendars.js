Ext.define("App.store.ein.Calendars", {
    extend : 'Gnt.data.Calendar',
   	autoLoad : true,
   	autoSync : false,
	model : 'App.model.ein.Calendar',
	proxy : {
		type : 'ajax',
		method : 'POST',
		api : {
			read : 'ProjectCalendar?OpenAgent&method=get&projectsn='+projectsn
		},
		reader : {
			type : 'json'
		}
	}
});
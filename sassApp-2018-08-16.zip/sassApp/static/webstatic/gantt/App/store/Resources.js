Ext.define('App.store.Resources',{
	extend:'Gnt.data.ResourceStore',
	autoLoad:true,
	autoSync : false,
	model:'App.model.Resource',
	proxy:{
		method:'POST',
		type:'ajax',
		api:{
			read:'TaskAgent?OpenAgent&method=list&projectsn='+encodeURI(projectsn)+"&readid="+t,
			careate:'TaskAgent?OpenAgent&method=create&projectsn='+encodeURI(projectsn),
			destroy:'TaskAgent?OpenAgent&method=delete&projectsn='+encodeURI(projectsn),
			update:'TaskAgent?OpenAgent&method=updata&projectsn='+encodeURI(projectsn)
		},
		writer:{
			type : 'json'
		},
		reader:{
			type : 'json'
		}
	}
})
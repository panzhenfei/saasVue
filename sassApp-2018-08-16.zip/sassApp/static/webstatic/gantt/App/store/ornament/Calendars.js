Ext.define("App.store.ornament.Calendars", {
    extend : 'Gnt.data.Calendar',
   	autoLoad : true,
   	autoSync : false,
	model : 'App.model.ornament.Calendar',
	proxy : {
		type : 'ajax',
		method : 'POST',
		api : {
			read : 'ProjectCalendar?OpenAgent&method=get&projectsn='+projectsn
		},
		reader : {
			type : 'json'
		}
	}
});
Ext.define("App.store.Calendars", {
    extend : 'Gnt.data.Calendar',
   	autoLoad : true,
   	autoSync : false,
	model : 'App.model.Calendar',
	proxy : {
		type : 'ajax',
		method : 'POST',
		api : {
			read : 'ProjectCalendar?OpenAgent&method=get&projectsn='+encodeURI(projectsn)
		},
		reader : {
			type : 'json'
		}
	}
});
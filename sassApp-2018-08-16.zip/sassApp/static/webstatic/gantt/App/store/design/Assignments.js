Ext.define('App.store.design.Assignment',{
    extend : 'Gnt.data.AssignmentStore',
    autoLoad : true,
    autoSync : false,
	model : 'App.model.design.Assignment',
	proxy : {
		method : 'POST',
		type : 'ajax',
		api : {
			read : 'AssignmentAgent?OpenAgent&method=assignment&jsonid='+a,
			create : 'AssignmentAgent?OpenAgent&method=assignmentCreate&ProjectSN='+escape(projectsn),
			destroy : 'AssignmentAgent?OpenAgent&method=delete&ProjectSN='+escape(projectsn)
		},
		writer : {
			type : 'json',
			root : 'assignmentsdata',
			encode : true,
			allowSingle : false
		},
		reader : {
			type : 'json',
			root : 'assignments'
		}
	},
	listeners : {
		load : function() {
			resourceStore.loadData(this.proxy.reader.jsonData.resources);
		}
	}
});
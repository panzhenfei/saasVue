Ext.define("App.store.design.Tasks", {
    extend: 'Gnt.data.TaskStore',
    autoLoad: true,
    autoSync: false,
    model: 'App.model.design.Task',
    proxy: {
        method: "POST",
        type: 'ajax',
        api: {
            read: 'TaskAgent?OpenAgent&method=list&projectsn=' + encodeURI(projectsn) + "&ganttsn=" + encodeURI(ganttsn) + "&plansn=" + encodeURI(plansn) + "&gantttype=" + gantttype + "&readid=" + t,
            create: 'TaskAgent?OpenAgent&method=create&projectsn=' + encodeURI(projectsn) + "&ganttsn=" + encodeURI(ganttsn) + "&plansn=" + encodeURI(plansn) + "&gantttype=" + gantttype,
            destroy: 'TaskAgent?OpenAgent&method=delete&projectsn=' + encodeURI(projectsn) + "&ganttsn=" + encodeURI(ganttsn) + "&plansn=" + encodeURI(plansn) + "&gantttype=" + gantttype,
            update: 'TaskAgent?OpenAgent&method=update&projectsn=' + encodeURI(projectsn) + "&ganttsn=" + encodeURI(ganttsn) + "&plansn=" + encodeURI(plansn) + "&gantttype=" + gantttype
        },
        writer: {
            type: 'json',
            root: 'taskdata',
            encode: true,
            allowSingle: false
        },
        reader: {
            type: 'json'
        }
    },
    callBack: function () {
        historySaved = false;
    }
});
Ext.define('App.store.design.Resources',{
	extend:'Gnt.data.ResourceStore',
	autoLoad:true,
	model:'App.model.design.Resource',
	proxy:{
		method:'POST',
		type:'ajax',
		api:{
			read:'TaskAgent?OpenAgent&method=list&projectsn='+escape(projectsn)+"&readid="+t,
			careate:'TaskAgent?OpenAgent&method=create&projectsn='+escape(projectsn),
			destroy:'TaskAgent?OpenAgent&method=delete&projectsn='+escape(projectsn),
			update:'TaskAgent?OpenAgent&method=updata&projectsn='+escape(projectsn)
		},
		writer:{
			type : 'json'
		},
		reader:{
			type : 'json'
		}
	}
})
Ext.define("App.store.design.Calendars", {
    extend : 'Gnt.data.Calendar',
   	autoLoad : true,
   	autoSync : false,
	model : 'App.model.design.Calendar',
	proxy : {
		type : 'ajax',
		method : 'POST',
		api : {
			read : 'ProjectCalendar?OpenAgent&method=get&projectsn='+projectsn
		},
		reader : {
			type : 'json'
		}
	}
});
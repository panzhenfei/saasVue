Ext.define("App.store.Dependencies", {
    extend: 'Gnt.data.DependencyStore',
    autoLoad: true,
    autoSync: false,
    model: 'App.model.Dependency',
    proxy: {
        type: 'ajax',
        method: 'POST',
        api: {
            read: 'DependenciesAgent?OpenAgent&method=list&projectsn=' + escape(projectsn) + "&readid=" + d + "&ganttsn=" + escape(ganttsn) + "&plansn=" + escape(plansn) + "&stage=" + escape(stage) + "&gantttype=" + escape(gantttype),
            create: 'DependenciesAgent?OpenAgent&method=create&projectsn=' + escape(projectsn) + "&ganttsn=" + escape(ganttsn) + "&plansn=" + escape(plansn) + "&stage=" + escape(stage) + "&gantttype=" + escape(gantttype),
            destroy: 'DependenciesAgent?OpenAgent&method=delete&projectsn=' + escape(projectsn) + "&ganttsn=" + escape(ganttsn) + "&plansn=" + escape(plansn) + "&stage=" + escape(stage) + "&gantttype=" + escape(gantttype),
            update: 'DependenciesAgent?OpenAgent&method=update&projectsn=' + escape(projectsn) + "&ganttsn=" + escape(ganttsn) + "&plansn=" + escape(plansn) + "&stage=" + escape(stage) + "&gantttype=" + escape(gantttype)
        },
        reader: {
            //root : 'dependencydata',
            type: 'json'
        },
        writer: {
            root: 'dependencydata',
            type: 'json',
            encode: true,
            allowSingle: false
        }
    },
    callback: function () {
        historySaved = false;
    }
});
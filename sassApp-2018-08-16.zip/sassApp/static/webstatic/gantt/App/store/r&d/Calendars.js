Ext.define("App.store.r&d.Calendars", {
    extend: 'Gnt.data.Calendar',
    autoLoad: true,
    autoSync: false,
    model: 'App.model.r&d.Calendar',
    proxy: {
        type: 'ajax',
        method: 'POST',
        api: {
            read: 'ProjectCalendar?OpenAgent&method=get&projectsn=' + projectsn
        },
        reader: {
            type: 'json'
        }
    }
});
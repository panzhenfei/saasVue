Ext.Loader.setConfig({
    enabled: true,
    disableCaching: true
});

Ext.Loader.setPath('App', '/gantt/app');

/*
 ganttSystemCfg在表单里通过业务系统关键字来判断，默认值为空。
 工装行业专用：ornament
 服装订货会专用：ein
 设计行业专用：design
 研发行业专用：r&d
 项目经理专用：pmp
 咨询行业专用
 地产行业专用
 */
if (typeof ganttSystemCfg != "undefined" && ganttSystemCfg != "") {
    ganttSystemCfg = "." + ganttSystemCfg + ".";
} else {
    ganttSystemCfg = ".";
}

var ganttpanel_classpath = 'App.view' + ganttSystemCfg + "GanttPanel";

Ext.require([ganttpanel_classpath,
    'Ext.data.*',
    'Ext.tip.QuickTipManager',
    'Ext.window.MessageBox',
    'Ext.DomHelper.*'
]);


/*是否保存了版本*/
var historySaved = true;
var callback = function () {
    window.location.reload();
};

var IsDate = function (dateval) {
    var arr = new Array();
    if (typeof dateval == "object" && typeof dateval.toLocaleString == "function") {
        return true;
    }

    if (dateval.indexOf("-") != -1) {
        arr = dateval.toString().split("-");
    } else if (dateval.indexOf("/") != -1) {
        arr = dateval.toString().split("/");
    } else {
        return false;
    }

    // yyyy-mm-dd || yyyy/mm/dd
    if (arr[0].length == 4) {
        var date = new Date(arr[0], arr[1] - 1, arr[2]);
        if (date.getFullYear() == arr[0] && date.getMonth() == arr[1] - 1 && date.getDate() == arr[2]) {
            return true;
        }
    }
    // dd-mm-yyyy || dd/mm/yyyy
    if (arr[2].length == 4) {
        var date = new Date(arr[2], arr[1] - 1, arr[0]);
        if (date.getFullYear() == arr[2] && date.getMonth() == arr[1] - 1 && date.getDate() == arr[0]) {
            return true;
        }
    }
    // mm-dd-yyyy || mm/dd/yyyy
    if (arr[2].length == 4) {
        var date = new Date(arr[2], arr[0] - 1, arr[1]);
        if (date.getFullYear() == arr[2] && date.getMonth() == arr[0] - 1 && date.getDate() == arr[1]) {
            return true;
        }
    }
    return false;
};

var MsgTip = function () {
    var msgCt = null;

    function createBox(t, s) {
        return [
            '<div class="msg">',
            '<div class="x-box-tl"><div class="x-box-tr"><div class="x-box-tc"></div></div></div>',
            '<div class="x-box-ml"><div class="x-box-mr"><div class="x-box-mc"><h3>',
            t,
            '</h3>',
            s,
            '</div></div></div>',
            '<div class="x-box-bl"><div class="x-box-br"><div class="x-box-bc"></div></div></div>',
            '</div>'
        ].join('');
    }

    return {
        msg: function (title, format) {
            if (!msgCt) {
                msgCt = Ext.DomHelper.insertFirst(
                    document.body, {
                        id: 'msg-div',
                        style: 'position:absolute;top:10px;width:300px;margin:0 auto;z-index:20000;'
                    }, true);
            }
            msgCt.alignTo(document, 't-t');
            var s = Ext.String.format.apply(String, Array.prototype.slice.call(
                arguments, 1));
            var m = Ext.DomHelper.append(msgCt, createBox(title, s), true);
            m.hide();
            m.slideIn('t').ghost("t", {
                delay: 2000,
                remove: true
            });
        },

        init: function () {
        }
    };
}();

var onsetbeforeunloadcheck = function () {
    try {
        if (gantttype == "PLAN" && !historySaved) {
            event.returnValue = "【提示】如果您编辑过甘特图的内容，离开当前页面前请保存新版本。如果您需要发布任务，请重新起草进度表审批！";
        }
    } catch (e) {
    }
};

Ext.onReady(function () {
    App.init();
    //App.locale();
    Ext.QuickTips.init();
    Ext.get('ID_MsgBox').remove();

    if (window.ActiveXObject) {
        document.body.onbeforeunload = onsetbeforeunloadcheck;
    } else {
        document.body.setAttribute("onbeforeunload", "return onsetbeforeunloadcheck();");
    }

    // Temp bug fix for Ext 4.2.1 and IE10+ which has gradient background support
    if (!Ext.isIE9m && Ext.versions.extjs.isLessThan("4.2.2")) {
        Ext.getHead().createChild({
            tag: 'style',
            type: 'text/css',
            html: ".x-column-header { background-image : -ms-linear-gradient(top,#f9f9f9,#e3e4e6); }" +
            ".x-column-header-over { background-image : -ms-linear-gradient(top,#ebf3fd,#d9e8fb); }"
        });
    }
});

App = {
    init: function () {
        this.gantt = this.createGantt();

        var vp = Ext.create("Ext.Viewport", {
            layout: 'border',
            items: [this.gantt]
        });
        if (typeof __formDone != "undefined") {
            __formDone = true;
        }
    },

    createGantt: function () {
        var today = new Date();
        var start = null;
        var end = null;
        var readonly = false;
        var funboo = true;
        var visible = false;
        var resize = "both";
        var projectstart = null;

        //项目的开始日期
        if (typeof project_start_date == "object" && IsDate(project_start_date)) {
            projectstart = project_start_date;
        } else {
            projectstart = today;
        }

        // 这里根据项目开始时间设置
        if (typeof gantt_start_date == "object" && IsDate(gantt_start_date)) {
            start = gantt_start_date;
        } else {
            start = new Date(-14);
        }

        if (typeof gantt_end_length != "undefined" && isNaN(gantt_end_length) && gantt_end_length > 0) {
            end = Sch.util.Date.add(start, Sch.util.Date.WEEK, gantt_end_length);
        } else {
            end = Sch.util.Date.add(start, Sch.util.Date.WEEK, 52);
        }

        if (typeof gantttype == "string") {
            if (gantttype == "TASK") {
                readonly = true;
                funboo = false;
                //visible = false;
                resize = "none";
            }
            if (gantttype == "PMP") {
                readonly = false;
                funboo = false;
                resize = "none";
            }
            if (gantttype == "VIEW") {
                readonly = true;
                funboo = false;
                resize = "none";
            }
        }

        var g = Ext.create(ganttpanel_classpath, {
            region: 'center',
            startDate: start,
            endDate: end,

            projectStartDate: projectstart,
            loadMask: true,

            taskStore: Ext.create("App.store" + ganttSystemCfg + "Tasks"),
            dependencyStore: Ext.create("App.store" + ganttSystemCfg + "Dependencies"),
            //calendarStore: Ext.create("App.store" + ganttSystemCfg + "Calendars"),
            //assignmentStore: Ext.create("App.store" + ganttSystemCfg + "Assignments"),
            //resourceStore: Ext.create("App.store" + ganttSystemCfg + "Resources"),

            selModel: new Ext.selection.TreeModel({
                ignoreRightMouseSelection: false,
                mode: 'MULTI'
            }),
            cascadeChanges: true, // 任务联动
            baselineVisible: visible, // 是否显示基线
            readOnly: readonly, // 只读
            multiSelect: funboo, // 是否允许多选
            allowParentTaskMove: funboo, //是否允许移动父任务
            enableProgressBarResize: funboo, // 进度条是否允许拖动
            enableDependencyDragDrop: funboo, // 依赖关系是否允许拖动
            enableTaskDragDrop: funboo,
            resizeHandles: resize, //允许任务拖动的方向
        });

        return g;
    }
};
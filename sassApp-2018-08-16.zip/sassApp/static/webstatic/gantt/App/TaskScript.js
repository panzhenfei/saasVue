/**
 * 任务管理脚本 1、保存时直接导入。 2、导入时，先上传附件并保存表单。 3、只能导入一次。 4、已经存在任务列表时不能再次导入。
 * Date  2013-08-30
 * @author 黄建伟
 * @description 项目单，包含SN 计划单、审批单、任务单、反馈单包含ProjectSN 新建时无法打开 编辑和浏览状态可以打开。
 */
var projectpath = getDbDir() + "swprojectinfo.nsf";
var managerfield = "ManagerInput";
var taskCount = 0;
var projectsn = "";
var importmode = "";
var isCanImport = true;
var isInputed = false;
var isPublished = false;

function _openGannttWindow(u,n) {
	var w = screen.availWidth * 0.9;
	var h = screen.availHeight * 0.9 - 50;
	try{
		window.open(u, n, "height=" + h + ",width=" + w + ",resizable=1,scrollbars=yes,status=no,menubar=no,left=" + ((screen.availWidth - w) / 2) + ",top=" + ((screen.availHeight - h) / 2));
	}catch(e){alert("您的浏览器无法打开新窗口，可能是您安装的安全软件的广告过滤功能拦截了此窗口，或者您的浏览器安装有广告过滤插件拦截了此窗口。\n\n建议您关闭安全软件或者浏览器的的广告过滤功能后再点击此链接。")}
	return false;
}

/*
 * 获取表单字段
 */
function getCustomFormDetail() {
	var data = [];
	var cfd = "";
	var o = $("CustomFormDetail")[0];
	var oo = $("#DIV_CustomFormDetail");

	if (typeof(o) === "undefined") {
		if (typeof(oo) === "undefined" || oo == null) {
			return "";
		} else {
			cfd = oo.innerHTML.replace(/\r|\n|<br>|<BR>/g, "");
		}
	} else {
		cfd = o.value.replace(/\r|\n|<br>|<BR>/g, "");
	}

	var fb = cfd.split("§");
	for (var i = 0; i < fb.length; i++) {
		if (fb[i] != "" && fb[i] != " ") {
			data.push(fb[i]);
		}
	}
	return data;
}
/*
 * 根据类型打开甘特图
 */
function OpenGantt(type) {
	isInputed = false;
	isPublished = false;
	if (typeof type != "undeinfed" && type != "") {
		if (typeof g_xIsEditing != "undefined" && g_xIsEditing == "Y") {
			// 先判断是否新文档
			if (g_IsNewDoc == "Y") {
				alert("请先保存文档后再启动甘特图！");
			} else {
                if (projectsn==""){
	                if (projectpath == "/" + g_sDBPath) {
	                    projectsn = sSN;
	                } else {
	                    projectsn = $("ProjectSN")[0].value;
	                }
                }				
				getStatus();
			}
		} else {
			var data = getCustomFormDetail();
			if (data != "") {
                if(projectsn==""){
                    if (projectpath == "/" + g_sDBPath) {
	                    projectsn = sSN;
	                } else {
	                    projectsn = getValueFromArray("ProjectSN", data);
	                }
                }
				getStatus();
			} else {
				//在视图上操作
				var u = getDbDir();
				if (projectsn == "") {					
					u += "gantt.nsf/ProjectQuery?OpenAgent&method=getprojectbyname&projectname=" + escape(category.right("/")) + "&random=" + Math.random();
				}else{
                    u += "gantt.nsf/ProjectQuery?OpenAgent&method=getprojectbysn&projectsn=" + escape(projectsn) + "&random=" + Math.random();
                }
                var s = _postsync(u, "");
                var arr = toJson(s);
                if (arr.length = 1) {                    
                    if (arr[0].InputStatus == "已导入") {
                        isInputed = true;
                    }
                    if (arr[0].PublishStatus == "已发布") {
                        isPublished = true;
                    }
                } else {
                    alert("项目重名无法查看甘特图");
                    return false;
                }
			}
		}
		if (typeof projectsn == "undefined" || projectsn == "") {
			alert("请先选择项目！");
		} else {
			if (type == "PLAN" && !isInputed) {
				alert("任务尚未导入无法查看甘特图！");
				return false;
			}
			if (type == "TASK" && !isPublished) {
				alert("任务尚未发布无法查看甘特图！");
				return false;
			}
			var url = "/" + g_sDBDir + "/gantt.nsf/Gantt?ReadForm&gantttype=" + type +"&ganttsn="
					+ escape(projectsn) + "&projectsn=" + escape(projectsn) + "&projectpath="
					+ projectpath + "&managerfield=" + managerfield
					+ "&rand=" + Math.random();
			_openGannttWindow(url,"");
		}
	}
	return false;
}
/*
 * 打开计划甘特图窗口
 */
function OpenPlanGantt(sn) {
	if (typeof sn != "undefined"){
		projectsn = sn;
	}
	return OpenGantt("PLAN");
}
/*
 * 打开任务甘特图窗口
 */
function OpenTaskGantt(sn) {
	if(typeof sn != "undefined"){
		projectsn = sn;
	}
	return OpenGantt("TASK");
}
/*
 * 打开计划版本窗口
 */
function OpenPlanList() {
	var projectsn = "";
	if (g_xIsEditing == "Y") {
		// 先判断是否新文档
		if (g_IsNewDoc == "Y") {
			alert("没有版本记录！");
		} else {
			if (projectpath == "/" + g_sDBPath) {
				projectsn = sSN;
			} else {
				projectsn = $("ProjectSN")[0].value;
			}
		}
	} else {
		if (projectpath == "/" + g_sDBPath) {
			projectsn = sSN;
		} else {
			projectsn = getValueFromArray("ProjectSN", getCustomFormDetail());
		}
	}
	if (typeof projectsn == "undefined" || projectsn == "") {
		alert("信息不完整无法查看计划版本！");
	} else {
		var url = "/" + g_sDBDir + "/Gantt.nsf/ContrastForm?OpenForm&unid="
			+ g_sDocUNID + "&ganttsn=" + escape(projectsn) + "&projectsn="
			+ escape(projectsn) + "&projectpath=" + projectpath
			+ "&managerfield=" + managerfield + "&gantttype=PLAN&plansn="
			+ escape(sSN) + +"&rand=" + Math.random();
		_openGannttWindow(url,"ContrastForm");
	}
	return false;
}
/*
 * 导入进度表
 * 根据项目起讫日期，自动移动项目的所有任务
 */
function ImportGantt() {
	checkCanImport();
	if (!isCanImport || isInputed) {
		alert("此项目已经创建了任务列表，无法再次导入。");
		return false;
	}
	if (checkFile()) {
		if (confirm("即将导入进度计划，请确认！\n\n导入后需要审批计划才能发布任务。")) {
			// 导入
			var move = getRadioValue("ProjectMove");
			var start = $("ProjectStartDate")[0].value;
			var end = $("ProjectEndDate")[0].value;
			var id = g_sDocUNID;
			var plantype = "attchment";
			if (getRadioValue("ImporType") == "选择模板"){
				id = $("ProjectTemplateSN")[0].value;
				plantype = "template";
			}
			if(id==""){
				//这里应该不会为空。
				alert("请选择模板文件！");
				return false;
			}
			var url = "/" + g_sDBDir + "/Gantt.nsf/ImportForm?OpenForm&plantype="+plantype+"&unid="
					+ escape(id) + "&ganttsn=" + escape(projectsn)
					+ "&projectsn=" + escape(projectsn) + "&projectpath="
					+ projectpath + "&managerfield=" + managerfield
					+ "&stage=&itype=auto" + "&gantttype=PLAN&projectmove="+escape(move)+"&plansn="
					+ escape(sSN) + "&startdate=" +start +"&enddate=" +end+ "&rand=" + Math.random();
			_openGannttWindow(url,"ImportForm");
		}
	}
	return false;
}
/*
 * 检测是否已经导入甘特图或者已经存在顶层任务。
 */
function checkCanImport() {
	projectsn = $("ProjectSN")[0].value;
	if (typeof $("ImportMode")[0] == "undefined"){		
		importmode = "自甘特图导入";
	}else{
		importmode = $("ImportMode")[0].value;
	}
	if (projectsn == "") {
		alert("请先选择项目！");
		return false;
	}
	if (importmode == "全部手动创建") {
		isCanImport = false;
		return false;
	}
	var data = getCustomFormDetail();
	if (getValueFromArray("InputStatus", data) == "已导入") {
		isInputed = true;
	}
	var u = "/"+g_sDBDir+"/gantt.nsf/TemplateAgent?OpenAgent&method=check&ganttsn="+escape(projectsn)+"&projectsn="+escape(projectsn)+"&rand="+Math.random();
	var s = _postsync(u, "");
	taskCount = parseInt(s);
	if (!isNaN(taskCount) && taskCount > 0) {
		isCanImport = false;
	}
}
/*
 * 检查导入的文件
 */
function checkFile() {
	if (getRadioValue("ImporType") == "选择模板"){
		return true;
	}
	// 检测附件列表的内容
	if (winAtt.newFiles() == "" && winAtt.uploadedFiles() == "") {
		alert("请将要导入的项目进度文件添加到附件列表中！");
		return false;
	}
	var arr = Array().concat(
			winAtt.uploadedFiles().replace(/\|/g, ",").split(","),
			winAtt.newFiles().replace(/\|/g, ",").split(","));
	if (arr.lnegth == 0){
		alert("请将要导入的项目进度文件添加到附件列表中！");
		return false;
	}
	for (var x = 0; x < arr.length; x++) {
		if (!arr[x] || arr[x] == "" || winAtt.getDeleteList().match(arr[x])) {
			arr.splice(x, 1);
			x--;
		} else {
			arr[x] = arr[x].rightback("\\");
		}
	}
	if (arr.length > 1 || !arr[0].match(/\.mpp$/i)) {
		alert("只能上传一个MPP格式的文件！");
		return false;
	}
	return true;
}
/*
 * 获取发布状态
 */
function getStatus() {
	var u = getDbDir()
			+ "gantt.nsf/ProjectQuery?OpenAgent&method=getprojectbysn&projectsn="
			+ escape(projectsn) + "&random=" + Math.random();
	var s = _postsync(u, "");
	if (s != "") {
		var arr = toJson(s);
		if (arr[0].ProjectSN == projectsn) {
			if (arr[0].InputStatus == "已导入") {
				isInputed = true;
			}
			if (arr[0].PublishStatus == "已发布") {
				isPublished = true;
			}
		}
	} else {
		alert("未取到该项目下甘特图信息！可能未导入进度表。或者未通过进度表审批发布任务！");
		return false;
	}
}
/*
 * 保存前的验证
 */
function _beforeSave() {
	checkCanImport();	
	if (!isCanImport || isInputed) {
		alert("此项目已经创建了任务列表，无法再次导入。");
		return false;
	} else {		
		if (getRadioValue("ImporType") == "选择模板"){						
			if($("ProjectTemplateSN")[0].value == ""){
				alert("请选择模板文件！");
				return false;
			}else{
				return true;
			}
		}else{			
			return checkFile();
		}		
	}
}
/*
 * 转换JSON
 */
function toJson(str) {
	var json = (new Function("return " + str))();
	return json;
}
/*
 * 加载完成之后
 */
function afertLoad(){
	//如果已经导入，则不再显示导入链接
	if(g_xIsEditing=="Y"){
		$("#ID_EditHiddenTR").style.display = "none";
	}else{
		$("#ID_EditHiddenTR").style.display = "";
	}
	if (g_IsNewDoc){
		return false;
	}
	checkCanImport();
	if(!isCanImport || isInputed){
		$("#ID_ImportLink").style.display = "none";
		$("#ID_OpenPlanGantt").style.display = "";
		$("#ID_PlanListLink").style.display = "";
	}else{
		$("#ID_ImportLink").style.display = "";
		$("#ID_OpenPlanGantt").style.display = "none";
		$("#ID_PlanListLink").style.display = "none";
	}
}

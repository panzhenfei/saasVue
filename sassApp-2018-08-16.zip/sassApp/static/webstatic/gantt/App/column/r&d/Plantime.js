Ext.define("App.column.r&d.Plantime", {
    extend: "Ext.grid.column.Number",
    alias: "widget.plantimecolumn",
    text: "Plantime",
    dataIndex: "Plantime",
    width: 50,
    align: "left",
    field: {
        xtype: "numberfield"
    },
    format:"0,000.0",
    constructor: function(a) {
        a = a || {};
        var b = a.field || a.editor;
        a.field = b || {
            xtype : "numberfield"
        };
        this.callParent([a]);
    }
});
Ext.define("App.column.ornament.QuantitiesUnit", {
	extend: "Ext.grid.column.Number",
	alias: "widget.quantitiesunitcolumn",
	text: "QuantitiesUnit",
	dataIndex: "QuantitiesUnit",
	width: 70,
	align: "left",
	field: {
		xtype: "numberfield"
	},
    format:"0,000.00",
    renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
        return Ext.util.Format.currency(value, 'гд', 2);
    },
    constructor : function(a) {
        a = a || {};
        var b = a.field || a.editor;
        a.field = b || {
            xtype : "numberfield"
        };
        this.callParent([a]);
    }
});
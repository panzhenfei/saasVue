Ext.define("App.column.ornament.QuantitiesComp", {
    extend: "Ext.grid.column.Column",
    alias: "widget.quantitiescompcolumn",
    text: "QuantitiesComp",
    dataIndex: "QuantitiesComp",
    width: 70,
    align: "left",
    field: {
        xtype: "textfield"
    },
    constructor: function(a) {
        a = a || {};
        var b = a.field || a.editor;
        a.field = b || {
            xtype : "textfield"
        };
        this.callParent([a])
    }
});
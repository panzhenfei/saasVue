Ext.define("App.column.ornament.ProductionPlan", {
	extend: "Ext.grid.column.Number",
	alias: "widget.productionplancolumn",
	text: "ProductionPlan",
	dataIndex: "ProductionPlan",
	width: 50,
	align: "left",
    format:"0,000.00",
    renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
        if (value == 0){
            value = record.getQuantitiesPlan() * record.getQuantitiesUnit();
        }
        return Ext.util.Format.currency(value, 'гд', 2);
    },
	constructor: function(a) {
        a = a || {};
        this.callParent([a]);
	}
});
Ext.define("App.column.ornament.QuantitiesDone", {
	extend: "Ext.grid.column.Number",
	alias: "widget.quantitiesdonecolumn",
	text: "QuantitiesDone",
	dataIndex: "QuantitiesDone",
	width: 70,
	align: "left",
	field: {
		xtype: "numberfield"
	},
    format:"0,000.0",
	constructor: function(a) {
        a = a || {};
        var b = a.field || a.editor;
        a.field = b || {
            xtype : "numberfield"
        };
        this.callParent([a]);
	}
});
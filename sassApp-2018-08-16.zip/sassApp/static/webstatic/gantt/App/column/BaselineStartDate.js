Ext.define("App.column.BaselineStartDate", {
	extend : "Ext.grid.column.Date",
	alias : "widget.baselinestartdatecolumn",
	text : "BaselineStart",
	dataIndex : "BaselineStartDate",
	width : 100,
	align : "left",
	constructor : function(a) {
		a = a || {};
		var b = a.field || a.editor;
		a.field = b || {
			xtype : "datefield",
			format : a.format || this.format || Ext.Date.defaultFormat
		};
		this.callParent([a])
	}
});
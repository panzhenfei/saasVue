Ext.define("Gnt.column.BaselineDuration", {
	extend : "Ext.grid.column.Column",
	alias : "widget.baselinedurationcolumn",
	//requires : ["Gnt.widget.BaselineDurationField", "Gnt.widget.BaselineDurationEditor"],
	text : "Duration",
	dataIndex : "Duration",
	width : 80,
	align : "left",
	decimalPrecision : 2,
	getDurationUnitMethod : "getDurationUnit",
	setDurationMethod : "setDuration",
	constructor : function(a) {
		a = a || {};
		a.editor = a.editor	|| Ext.create("Gnt.widget.DurationEditor", {
							decimalPrecision : a.decimalPrecision || 2,
							getDurationUnitMethod : a.getDurationUnitMethod	|| this.getDurationUnitMethod,
							setDurationMethod : a.setDurationMethod	|| this.setDurationMethod
						});
		if (!a.editor.isFormField) {
			a.editor = Ext.ComponentManager.create(a.editor,"durationcolumneditor");
		}
		this.scope = this;
		this.callParent([a]);
		this.mon(this.editor, "beforestartedit",this.onBeforeStartEdit, this);
	},
	onBeforeStartEdit : function(b) {
		var a = b.context.record;
		return a.isEditable(this.dataIndex);
	},
	renderer : function(b, c, a) {
		if (!Ext.isNumber(b)) {
			return ""
		}
		if (!a.isEditable(this.dataIndex)) {
			c.tdCls = (c.tdCls || "") + " sch-column-readonly"
		}
		b = parseFloat(Ext.Number.toFixed(b, this.decimalPrecision));
		return b+ " "+ Sch.util.Date.getReadableNameOfUnit(	a[this.getDurationUnitMethod](), b > 1)
	}
});
Ext.define("App.column.design.ReportTime", {
    extend : "Ext.grid.column.Date",
    alias : "widget.reporttimecolumn",
    text : "ReportTime",
    dataIndex : "ReportTime",
    width : 100,
    align : "left",
    constructor : function(a) {
        a = a || {};
        var b = a.field || a.editor;
        a.field = b || {
            xtype : "datefield",
            format : a.format || this.format || Ext.Date.defaultFormat
        };
        this.callParent([a])
    }
});

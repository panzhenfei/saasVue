Ext.define("App.column.design.WeiLaiXuGongShi", {
    extend : "Ext.grid.column.Column",
    alias : "widget.weilaixugongshicolumn",
    text : "WeiLaiXuGongShi",
    dataIndex : "weilaixugongshi",
    width : 100,
    align : "left",
    field: {
        xtype: "numberfield"
    },
    format:"0,000.00",
    constructor : function(a) {
        a = a || {};
        var b = a.field || a.editor;
        a.field = b || {
            xtype : "numberfield"
        };
        this.callParent([a]);
    }
});
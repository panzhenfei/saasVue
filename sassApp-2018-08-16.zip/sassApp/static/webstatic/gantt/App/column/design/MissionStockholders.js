Ext.define("App.column.design.MissionStockholders", {
    extend : "Ext.grid.column.Column",
    alias : "widget.missionstockholderscolumn",
    text : "MissionStockholders",
    dataIndex : "MissionStockholders",
    width : 100,
    align : "left",
    field : {
        xtype : "textfield"
    },
    constructor : function(a) {
        a = a || {};
        this.text = a.text;
        Ext.apply(this, a);
        this.callParent(arguments);
    }
});
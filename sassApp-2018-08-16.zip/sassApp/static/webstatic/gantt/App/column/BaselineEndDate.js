Ext.define("App.column.BaselineEndDate", {
	extend : "Ext.grid.column.Date",
	alias : "widget.baselineenddatecolumn",
	text : "BaselineEnd",
	dataIndex : "BaselineEndDate",
	width : 100,
	align : "left",
	constructor : function(a) {
		a = a || {};
		var b = a.field || a.editor;
		a.field = b || {
			xtype : "datefield",
			format : a.format || this.format || Ext.Date.defaultFormat
		};
		this.callParent([a])
	}
});
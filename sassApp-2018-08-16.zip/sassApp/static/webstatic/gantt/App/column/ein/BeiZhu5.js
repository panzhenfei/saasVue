Ext.define("App.column.ein.BeiZhu5", {
	extend : "Ext.grid.column.Column",
	alias : "widget.beizhu5column",
	text : "BeiZhu5",
	dataIndex : "beizhu5",
	width : 100,
	align : "left",
	field : {
		xtype : "textfield"
	},
	constructor : function(a) {
        a = a || {};
        this.text = a.text;
        Ext.apply(this, a);
        this.callParent(arguments);
	}
});
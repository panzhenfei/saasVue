Ext.define("App.column.ein.BeiZhu2", {
	extend : "Ext.grid.column.Column",
	alias : "widget.beizhu2column",
	text : "BeiZhu2",
	dataIndex : "beizhu2",
	width : 100,
	align : "left",
	field : {
		xtype : "textfield"
	},
	constructor : function(a) {
        a = a || {};
        this.text = a.text;
        Ext.apply(this, a);
        this.callParent(arguments);
	}
});
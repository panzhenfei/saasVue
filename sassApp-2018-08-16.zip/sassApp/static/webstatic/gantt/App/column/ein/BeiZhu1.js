Ext.define("App.column.ein.BeiZhu1", {
	extend : "Ext.grid.column.Column",
	alias : "widget.beizhu1column",
	text : "BeiZhu1",
	dataIndex : "beizhu1",
	width : 100,
	align : "left",
	field : {
		xtype : "textfield"
	},
	constructor : function(a) {
        a = a || {};
        this.text = a.text;
        Ext.apply(this, a);
        this.callParent(arguments);
	}
});
Ext.define("App.column.ein.JieShouBuMen", {
	extend : "Ext.grid.column.Column",
	alias : "widget.jieshoubumencolumn",
	text : "JieShouBuMen",
	dataIndex : "jieshoubumen",
	width : 100,
	align : "left",
	constructor : function(a) {
		a = a || {};
		var b = a.field || a.editor;
		a.field = b || {
			xtype : "textfield"
		};
		this.callParent([a]);
	}
});
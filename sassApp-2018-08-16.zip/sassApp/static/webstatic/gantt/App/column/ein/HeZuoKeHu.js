Ext.define("App.column.ein.HeZuoKeHu", {
	extend : "Ext.grid.column.Column",
	alias : "widget.hezuokehucolumn",
	text : "HeZuoKeHu",
	dataIndex : "hezuokehu",
	width : 100,
	align : "left",
	constructor : function(a) {
		a = a || {};
		var b = a.field || a.editor;
		a.field = b || {
			xtype : "textfield"
		};
		this.callParent([a]);
	}
});
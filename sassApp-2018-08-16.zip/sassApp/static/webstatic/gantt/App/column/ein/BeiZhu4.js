Ext.define("App.column.ein.BeiZhu4", {
	extend : "Ext.grid.column.Column",
	alias : "widget.beizhu4column",
	text : "BeiZhu4",
	dataIndex : "beizhu4",
	width : 100,
	align : "left",
	field : {
		xtype : "textfield"
	},
	constructor : function(a) {
        a = a || {};
        this.text = a.text;
        Ext.apply(this, a);
        this.callParent(arguments);
	}
});
Ext.define("App.column.ein.GongYingShang", {
	extend : "Ext.grid.column.Column",
	alias : "widget.gongyingshangcolumn",
	text : "GongYingShang",
	dataIndex : "gongyingshang",
	width : 100,
	align : "left",
	constructor : function(a) {
		a = a || {};
		var b = a.field || a.editor;
		a.field = b || {
			xtype : "textfield"
		};
		this.callParent([a]);
	}
});
Ext.define("App.column.ein.BeiZhu3", {
	extend : "Ext.grid.column.Column",
	alias : "widget.beizhu3column",
	text : "BeiZhu3",
	dataIndex : "beizhu3",
	width : 100,
	align : "left",
	field : {
		xtype : "textfield"
	},
	constructor : function(a) {
        a = a || {};
        this.text = a.text;
        Ext.apply(this, a);
        this.callParent(arguments);
	}
});
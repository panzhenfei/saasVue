Ext.define("App.column.ein.BeiZhu6", {
	extend : "Ext.grid.column.Column",
	alias : "widget.beizhu6column",
	text : "BeiZhu6",
	dataIndex : "beizhu6",
	width : 100,
	align : "left",
	field : {
		xtype : "textfield"
	},
	constructor : function(a) {
        a = a || {};
        this.text = a.text;
        Ext.apply(this, a);
        this.callParent(arguments);
	}
});
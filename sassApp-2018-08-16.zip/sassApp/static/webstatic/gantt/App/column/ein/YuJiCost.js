Ext.define("App.column.ein.YuJiCost", {
	extend : "Ext.grid.column.Column",
	alias : "widget.yujicostcolumn",
	text : "YuJiCost",
	dataIndex : "YujiCost",
	width : 100,
	align : "left",
    format:"0,000.00",
	constructor : function(a) {
		a = a || {};
		var b = a.field || a.editor;
		a.field = b || {
			xtype : "textfield"
		};
		this.callParent([a]);
	}
});
Ext.define("App.column.ein.FuZeRenBuMen", {
	extend : "Ext.grid.column.Column",
	alias : "widget.fuzerenbumencolumn",
	text : "FuZeRenBuMen",
	dataIndex : "fuzerenbumen",
	width : 100,
	align : "left",
	constructor : function(a) {
		a = a || {};
		var b = a.field || a.editor;
		a.field = b || {
			xtype : "textfield"
		};
		this.callParent([a]);
	}
});
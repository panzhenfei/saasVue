Ext.define("App.column.EndDate", {
	extend : "Ext.grid.column.Date",
	alias : "widget.enddatecolumn",
	text : "EndDate",
	dataIndex : "EndDate",
	width : 100,
	align : "left",
	keepDuration : true,
	constructor : function(a) {
		a = a || {};
		var b = a.field || a.editor;
		a.field = b || {
			xtype : "datefield",
			format : a.format || this.format || Ext.Date.defaultFormat
		};
		this.callParent([a])
	}
});
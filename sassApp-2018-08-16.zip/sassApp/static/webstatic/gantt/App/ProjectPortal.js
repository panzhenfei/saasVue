/**
 * @author Honan
 * @version 0.1
 */
(function($) {
	var opts_s = {
		lines: 17,
		length: 8,
		width: 5,
		radius: 15,
		corners: 1,
		rotate: 0,
		color: '#000',
		speed: 1.6,
		trail: 58,
		shadow: false,
		hwaccel: false,
		className: 'spinner',
		zIndex: 2e9,
		top: 'auto',
		left: 'auto'
	};

	var ajaxData = null;

	var loadData = function() {
		ajaxData = null;
		$('.contentpanel').spin(opts_s);
		var url = "/"+g_sDBDir+"/gantt.nsf/projectPortalAgent?OpenAgent&method=manager&username="+UserName;
		$.post(url, function(data, status) {
			if (status == 'success') {
				ajaxData = $.parseJSON(data);
				filter();
			} else if (status == 'error') {
				//alert(message.queryerror);
			}
			$('.contentpanel').data('spinner').stop();
		});
	};

	function filter() {
		if (ajaxData == null) {
			return false;
		}
		var isNormal = false;
		var isExcption = false;
		var isMybusiness = false;
		var newcontent = "";
		$(":checked").each(function() {
			if ($(this).val() == "normal"){
				isNormal = true;
			}
			if ($(this).val() == "excption"){
				isExcption = true;
			}
			if ($(this).val() == "mybusiness"){
				isMybusiness = true;
			}
		});
		for (var i = 0; i < ajaxData.length; i++) {
			if (isMybusiness && ajaxData[i].ManagerInput != UserName){
				continue;
			}
			if (!isExcption && ajaxData[i].isException){
				continue;
			}
			if (!isNormal && !ajaxData[i].isException){
				continue;
			}
			var ProjectSN = escape(ajaxData[i].ProjectSN);
			var url = "/" + g_sDBDir + "/gantt.nsf/formForTaskView?ReadForm&ProjectSN=" + ProjectSN + "&GanttSN=" + ProjectSN + "&type=qb&kind=";			
			newcontent += "<tr><td><a href='/" + g_sDBDir + "/swprojectinfo.nsf/0/" + ajaxData[i].ProjectUNID + "?opendocument' target='_blank'>" + ajaxData[i].ProjectName + "</a></td>";
			newcontent += "<td><b>" + ajaxData[i].PercentDone + "%</b></td>"; //PercentDone

			if (ajaxData[i].TaskTotal > 0) {
				newcontent += "<td><a href='" + url + "all' target='_blank'>" + ajaxData[i].TaskTotal + "</a></td>";
			} else {
				newcontent += "<td>" + ajaxData[i].TaskTotal + "</td>";
			}

			if (ajaxData[i].TaskDoing > 0) {
				newcontent += "<td><a href='" + url + "doing' target='_blank'>" + ajaxData[i].TaskDoing + "</a></td>";
			} else {
				newcontent += "<td>" + ajaxData[i].TaskDoing + "</td>";
			}

			if (ajaxData[i].TaskDone > 0) {
				newcontent += "<td><a href='" + url + "done' target='_blank'>" + ajaxData[i].TaskDone + "</a></td>";
			} else {
				newcontent += "<td>" + ajaxData[i].TaskDone + "</td>";
			}

			if (ajaxData[i].TaskCanDo > 0) {
				newcontent += "<td><a href='" + url + "cando' target='_blank'>" + ajaxData[i].TaskCanDo + "</a></td>";
			} else {
				newcontent += "<td>" + ajaxData[i].TaskCanDo + "</td>";
			}

			if (ajaxData[i].TaskWait > 0) {
				newcontent += "<td><a href='" + url + "wait' target='_blank'>" + ajaxData[i].TaskWait + "</a></td>";
			} else {
				newcontent += "<td>" + ajaxData[i].TaskWait + "</td>";
			}

			if (ajaxData[i].TaskStop > 0) {
				newcontent += "<td><a class='notice' href='" + url + "stop' target='_blank'>" + ajaxData[i].TaskStop + "</a></td>";
			} else {
				newcontent += "<td>" + ajaxData[i].TaskStop + "</td>";
			}

			if (ajaxData[i].TaskDeferred > 0) {
				newcontent += "<td><a class='notice' href='" + url + "yanqi' target='_blank'>" + ajaxData[i].TaskDeferred + "</a></td>";
			} else {
				newcontent += "<td>" + ajaxData[i].TaskDeferred + "</td>";
			}

			if (ajaxData[i].TaskExtended > 0) {
				newcontent += "<td><a class='notice' href='" + url + "chaoqi' target='_blank'>" + ajaxData[i].TaskExtended + "</a></td>";
			} else {
				newcontent += "<td>" + ajaxData[i].TaskExtended + "</td>";
			}
		}
		renderTable(newcontent);
	};

	function renderTable(newcontent) {
		$('.tablesorter tbody').html(newcontent);
		$('.tablesorter tbody tr').bind({
			mouseover: function() {
				$(this).addClass('over');
			},
			mouseout: function() {
				$(this).removeClass('over');
			}
		});
		$('.tablesorter tr:even').addClass('odd');
		try{parent.setIframeHeight(window.frameElement.id);}catch(e){}
	};

	$(function() {
		$(":checkbox").bind("change", filter);

		$(".refresh").bind("click", function() {
			loadData();
		});
		loadData();
	});
})(jQuery);
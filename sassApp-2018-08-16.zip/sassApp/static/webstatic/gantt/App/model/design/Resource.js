Ext.define('App.model.design.Resource',{
	extend : 'Gnt.model.Resource',
	
	fields : [
        { name: 'Company', type : 'string' }
    ],

    getCompany : function () {
        return this.get('Company');
    }
});
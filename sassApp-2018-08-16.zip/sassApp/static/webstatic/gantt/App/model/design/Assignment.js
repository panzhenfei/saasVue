Ext.define("App.model.design.Assignment",{
	extend : "Gnt.model.Assignment",
	associations: [
        { type: 'belongsTo', model: 'App.model.TaskAssignment' }
    ]
});
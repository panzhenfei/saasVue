Ext.define("App.model.Task", {
    extend: "Gnt.model.Task",

    autoCalculatePercentDoneForParentTask : false,

    weightField: "Weight",
    priorityField: "Priority",
    projectSNField: "ProjectSN",
    ganttSNField: 'GanttSN',
    promulgatorField: "Promulgator",
    feedBackField: 'FeedBack',
    remarkField: 'Remark',
    taskStatusField: 'TaskStatus',
    milestoneField: 'Milestone',
    baselineDurationField: 'BaselineDuration',
    baselineDurationUnitField: 'BaselineDurationUnit',
    statusField: 'Status',
    newFeedbackField: 'NewFeedback',
    fuzerenField: 'fuzeren',

    fields: [
        {
            name: 'ProjectSN',
            type: 'string',
            defaultValue: projectsn
        },
        {
            name: 'GanttSN',
            type: 'string',
            defaultValue: ganttsn
        },
        {
            name: 'TaskStatus',
            type: 'string'
        },
        {
            name: 'Duration',
            type: 'float'
        },
        {
            name: 'DurationUnit',
            type: 'string'
        },
        {
            name: 'PercentDone',
            type: 'int'
        },
        {
            name: 'Priority',
            type: 'int',
            defaultValue: 1
        },
        {
            name: 'BaselineStartDate',
            type: 'date',
            dateFormat: 'Y-m-d'
        },
        {
            name: 'BaselineEndDate',
            type: 'date',
            dateFormat: 'Y-m-d'
        },
        {
            name: 'BaselinePercentDone',
            type: 'int',
            defaultValue: 0
        },
        {
            name: 'BaselineDuration',
            type: 'float'
        },
        {
            name: 'BaselineDurationUnit',
            type: 'string'
        },
        {
            name: 'Weight',
            type: 'int',
            defaultValue: 0
        },
        {
            name: 'Promulgator',
            type: 'string'
        },
        {
            name: 'ConstraintType',
            type: 'int'
        },
        {
            name: 'ConstraintDate',
            type: 'date',
            dateFormat: 'Y-m-d'
        },
        {
            name: 'Remark',
            type: 'string'
        },
        {
            name: 'Status',
            type: 'string',
            defaultValue: '2'
        },
        {
            name: 'NewFeedback',
            type: 'string'
        },
        {
            name: 'fuzeren',
            type: 'string'
        }
    ],

    getProjectSN: function () {
        return this.get(this.projectSNField);
    },

    setProjectSN: function (p) {
        this.beginEdit();
        this.set(this.projectSNField, p);
        this.endEdit();
    },

    getGanttSN: function () {
        return this.get(this.ganttSNField);
    },

    setGanttSN: function (s) {
        this.beginEdit();
        this.set(this.ganttSNField, s);
        this.endEdit();
    },

    getWeight: function () {
        return this.get(this.weightField);
    },

    setWeight: function (w) {
        this.beginEdit();
        this.set(this.weightField, w);
        this.endEdit();
    },

    getPriority: function () {
        return this.get(this.priorityField);
    },

    setPriority: function (p) {
        this.beginEdit();
        this.set(this.priorityField, p);
        this.endEdit();
    },

    getFeedBack: function () {
        return this.get(this.feedBackField);
    },

    setRemark: function (r) {
        this.beginEdit();
        this.set(this.remarkField, r);
        this.endEdit();
    },

    getRemark: function () {
        return this.get(this.remarkField);
    },

    getTaskStatus: function () {
        return this.get(this.taskStatusField);
    },

    setTaskStatus: function (s) {
        this.beginEdit();
        this.set(this.taskStatusField, s);
        this.endEdit();
    },

    setBaselineDuration: function (m) {
        this.beginEdit();
        this.set(this.baselinePercentDoneField, m);
        this.endEdit();
    },

    getBaselineDuration: function () {
        return this.get(this.baselineDurationField);
    },

    setBaselineDurationUnit: function (m) {
        this.beginEdit();
        this.set(this.baselineDurationUnitField, m);
        this.endEdit();
    },

    getBaselineDurationUnit: function () {
        return this.get(this.baselineDurationUnitField);
    },

    setStatus: function (s) {
        this.beginEdit();
        this.set(this.statusField, s);
        this.endEdit();
    },

    getStatus: function () {
        return this.get(this.statusField);
    },

    getNewFeedback: function () {
        return this.get(this.newFeedbackField);
    },

    setNewFeedback: function (s) {
        this.beginEdit();
        this.set(this.newFeedbackField, s);
        this.endEdit();
    },

    getFuzeren: function () {
        return this.get(this.fuzerenField);
    },

    setFuzeren: function (f) {
        this.beginEdit();
        this.set(this.fuzerenField, f);
        this.endEdit();
    }
});
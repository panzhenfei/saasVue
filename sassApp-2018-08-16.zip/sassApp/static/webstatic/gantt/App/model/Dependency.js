Ext.define("App.model.Dependency", {
	extend : 'Gnt.model.Dependency',
	idProperty : 'Id',
	projectSNField : 'ProjectSN',
	ganttSNField : 'GanttSN',
	fields : [ 
		{ name : 'Id', type : 'int', useNull : true},
		{ name : 'From', type:'int'},
		{ name : 'To', type:'int'},
		{ name : 'Lag', type:'int'},
		{ name : 'Type', type:'int'},
		{ name : 'ProjectSN', type : 'String', defaultValue : projectsn},
		{ name : 'GanttSN', type : 'String', defaultValue : ganttsn}
	],
	
	getProjectSN : function(){
		return this.projectSNField;
	},
	
	setProjectSN : function(sn){
		this.beginEdit();
		this.projectSNField = sn;
		this.endEdit();
	},
	
	getGanttSN : function(){
		return this.ganttSNField;
	},
	
	setGanttSN : function(sn){
		this.beginEdit();
		this.ganttSNField = sn;
		this.endEdit();
	}
});
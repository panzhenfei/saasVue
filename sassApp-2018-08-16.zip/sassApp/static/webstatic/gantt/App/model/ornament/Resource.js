Ext.define('App.model.ornament.Resource',{
	extend : 'Gnt.model.Resource',
	
	fields : [
        { name: 'Company', type : 'string' }
    ],

    getCompany : function () {
        return this.get('Company');
    }
});
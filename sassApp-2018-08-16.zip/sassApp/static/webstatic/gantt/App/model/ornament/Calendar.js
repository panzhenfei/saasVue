Ext.define("App.model.ornament.Calendar",{
	extend : 'Gnt.model.CalendarDay',
	fileds:[
		{ name:'Id',type:'int',useNull:false},
		{ name:'Date', type : 'date', dateFormat : 'Y-m-d'},
		{ name:'Name', type:'string',useNull:false},
		{ name:'IsWorkingDay', type:'boolean', defaultValue:false},
		{ name:'Cls', type:'string', defaultValue:'gnt-holiday'},
		{ name:'projectsn', type:'string', defaultValue:projectsn}
	],
	projectSnField:'projectsn',
	setProjectSN:function(sn){
		this.projectSnField = sn
	},
	getProjectSN:function(){
		return this.projectSnField
	}
});
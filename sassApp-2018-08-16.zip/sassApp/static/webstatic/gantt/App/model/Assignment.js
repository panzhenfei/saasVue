Ext.define("App.model.Assignment",{
	extend : "Gnt.model.Assignment",
	associations: [
        { type: 'belongsTo', model: 'App.model.TaskAssignment' }
    ]
});
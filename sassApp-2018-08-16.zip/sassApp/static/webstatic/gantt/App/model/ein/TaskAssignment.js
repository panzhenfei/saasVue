Ext.define('App.model.ein.TaskAssignment', {
    extend: 'Gnt.model.Task',
    associations: [
        {model: 'Assignment', type: 'hasMany', primaryKey: 'Id', foreignKey: 'TaskId', associationKey: 'assignments'}
    ]
});
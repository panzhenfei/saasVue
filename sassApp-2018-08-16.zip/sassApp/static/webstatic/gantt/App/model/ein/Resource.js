Ext.define('App.model.ein.Resource',{
	extend : 'Gnt.model.Resource',
	
	fields : [
        { name: 'Company', type : 'string' }
    ],

    getCompany : function () {
        return this.get('Company');
    }
});
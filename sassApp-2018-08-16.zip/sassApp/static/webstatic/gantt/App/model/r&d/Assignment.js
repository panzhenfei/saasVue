Ext.define("App.model.r&d.Assignment",{
	extend : "Gnt.model.Assignment",
	associations: [
        { type: 'belongsTo', model: 'App.model.TaskAssignment' }
    ]
});
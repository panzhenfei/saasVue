Ext.define('App.model.r&d.Resource',{
	extend : 'Gnt.model.Resource',
	
	fields : [
        { name: 'Company', type : 'string' }
    ],

    getCompany : function () {
        return this.get('Company');
    }
});
Ext.define('App.plugin.Printable',{
    extend:'Gnt.plugin.Printable',

    gantt: null,

    initComponent: function() {
        var gantt = this.gantt;
    },

    printRenderer: function (task, tplData) {
        if (task.isMilestone()) {
            return;
        } else if (task.isLeaf()) {
            var availableWidth = tplData.width - 4,
                progressWidth = Math.floor(availableWidth * task.get('PercentDone') / 100);

            return {
                progressBarStyle: Ext.String.format('width:{2}px;border-left:{0}px solid #7971E2;border-right:{1}px solid #E5ECF5;',
                    progressWidth, availableWidth - progressWidth, availableWidth)
            };
        } else {
            var availableWidth = tplData.width - 2,
                progressWidth = Math.floor(availableWidth * task.get('PercentDone') / 100);

            return {
                progressBarStyle: Ext.String.format('width:{2}px;border-left:{0}px solid #FFF3A5;border-right:{1}px solid #FFBC00;',
                    progressWidth, availableWidth - progressWidth, availableWidth)
            };
        }
    },

    beforePrint: function (sched) {
        var v = sched.getSchedulingView();
        this.oldRenderer = v.eventRenderer;
        this.oldMilestoneTemplate = v.milestoneTemplate;
        v.milestoneTemplate = new Gnt.template.Milestone({
            prefix: 'foo',
            printable: true,
            imgSrc: '/resources/images/milestone.png'
        });
        v.eventRenderer = this.printRenderer;
    },

    afterPrint: function (sched) {
        var v = sched.getSchedulingView();
        v.eventRenderer = this.oldRenderer;
        v.milestoneTemplate = this.oldMilestoneTemplate;
    }
})
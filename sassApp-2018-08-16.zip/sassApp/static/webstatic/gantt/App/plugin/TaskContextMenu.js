Ext.define('App.plugin.TaskContextMenu', {
    extend: 'Gnt.plugin.TaskContextMenu',

    ignoreParentClicks: true,
    triggerEvent: "taskcontextmenu",
    fbwin: null,
    grid: null,
    rec: null,

    texts: {
        newTaskText: "新任务",
        newMilestoneText: "新里程碑",
        deleteTask: "删除任务(s)",
        editLeftLabel: "编辑左标签",
        editRightLabel: "编辑右标签",
        add: "添加...",
        deleteDependency: "删除依赖项...",
        addTaskAbove: "插入之前",
        addTaskBelow: "插入之后",
        addMilestone: "里程碑",
        addSubtask: "子任务",
        addSuccessor: "后置任务",
        addPredecessor: "前置任务",
        taskOperation: '操作...',
        editWeight: "权重",
        editPercentDone: '进度',
        editResponsible: '安排责任人',
        editFeedback: '反馈',
        taskOutdent: '升级',
        taskIndent: '降级',
        cutTask: '剪切',
        copyTask: '复制',
        pasteTask: '粘贴',
        OpenSelectType: '人员',
        taskIntoView: '滚动到任务',
        msgTitle: '消息',
        msgModifyTask: '修改任务后需要保存更新。',
        reload: '重新加载',
        stockholders: '添加干系人'
    },

    /**
     * 菜单构造器
     */
    constructor: function () {
        // this.texts.changeColor = '选择任务颜色';
        this.callParent(arguments);
    },

    /**
     * 复制任务
     */
    copyTask: function (c) {
        historySaved = false;
        var uid = this.grid.getLatestId();
        var b = this.grid.getTaskStore().model;
        var a = new b({
            Id: uid,
            id: uid,
            leaf: true
        });
        a.setPercentDone(0);
        a.setName(this.texts.newTaskText);
        a.set(a.startDateField, (c && c.getStartDate()) || null);
        a.set(a.endDateField, (c && c.getEndDate()) || null);
        a.set(a.durationField, (c && c.getDuration()) || null);
        a.set(a.durationUnitField, (c && c.getDurationUnit()) || "d");
        return a;
    },

    /**
     * 创建菜单项
     */
    createMenuItems: function () {
        var arr = [
            {
                // 滚动到任务
                text: this.texts.taskIntoView,
                requiresTask: true,
                scope: this,
                handler: function () {
                    if (this.rec) {
                        this.grid.getSchedulingView().scrollEventIntoView(this.rec, true);
                    }
                }
            }
        ];
        if (typeof gantttype == "string" && gantttype == "PLAN") {
            arr.push({
                // 升级
                text: this.texts.taskOutdent,
                scope: this,
                handler: function (item) {
                    historySaved = false;
                    this.grid.getSelectionModel().selected.each(
                        function (task) {
                            task.outdent();
                        });
                    // MsgTip.msg(this.texts.msgTitle,
                    // this.texts.msgModifyTask);
                }
            });
            arr.push({
                // 降级
                text: this.texts.taskIndent,
                scope: this,
                handler: function (item) {
                    historySaved = false;
                    this.grid.getSelectionModel().selected.each(
                        function (task) {
                            task.indent();
                        });
                    // MsgTip.msg(this.texts.msgTitle,
                    // this.texts.msgModifyTask);
                }
            });
            /*arr.push({
                // 任务操作
                text: this.texts.taskOperation,
                requiresTask: true,
                menu: [{
                        // 进度
                        text: this.texts.editPercentDone,
                        ignoreParentClicks: true,
                        menu: [
                            {
                                xtype: 'buttongroup',
                                columns: 5,
                                showSeparator: false,
                                defaults: {
                                    scale: "large"
                                },
                                items: this.createPercentDone(5)
                            }
                        ]
                    }
                ]
            });*/
            arr.push(this.createReponsibleItem());
            //arr.push(this.createStockholdersItem());
        }

        if (typeof gantttype == "string"){
            if (gantttype == "TASK") {
                arr.push(this.createFeedbackItem());
            }

            if (isManager){
                if (gantttype == "TASK") {
                    arr.push(this.createPercentdoneItem());
                }
            }
            return arr;
        }else{
            return arr.concat(this.callParent(arguments));
        }
    },

    createPercentDoneNew: function (k) {
        var a = new Array();
        for (var i = 0; i <= 100; i += k) {
            a.push({
                text: i + "",
                scope: this,
                showSeparator: false,
                handler: function (item) {
                    historySaved = false;
                    var task = this.grid.getSelectionModel().getSelection()[0];
                    if (task) {
                        task.setPercentDone(item.text);
                        task.setBaselinePercentDone(item.text);
                        //g.taskStore.sync();
                        //g.dependencyStore.sync();
                        //g.getView().refresh();
                        //g.computeDone();
                        // MsgTip.msg('消息', '已确认进度！');
                        // return false;
                        var u = "TaskAgent?OpenAgent&method=querenjindu&projectsn=" + projectsn + "&ganttsn=" + ganttsn + "&taskid=" + task.getId() + "&done=" + item.text + "&stage=" + "" + "&rand=" + Math.random();
                        _post(u, "", function (h) {
                            if (!_verifyAjax(h))
                                return false;
                            var s = h.responseText.replace(/\n+$/, "")
                                .replace(/\s*,\s*/g, "\n");
                            if (s == "ok") {
                                MsgTip.msg('消息', '已确认进度！');
                                //getView().refresh();
                            } else {
                                MsgTip.msg('消息', '确认进度失败！');
                            }
                        });
                    }
                }
            });
        }
        return a;
    },

    /*
     * 确认进度
     */
    createPercentdoneItem: function () {
        return {
            text: '进度',
            //ignoreParentClicks : true,
            menu: [
                {
                    xtype: 'buttongroup',
                    columns: 8,
                    showSeparator: false,
                    //ignoreParentClicks : false,
                    defaults: {
                        scale: "large"
                    },
                    items: this.createPercentDoneNew(5)
                }
            ],
            tooltip: '确认任务进度'
        };
    },

    /**
     * 创建指定责任人选项
     */
    createReponsibleItem: function () {
        return {
            text: this.texts.editResponsible,
            scope: this,
            handler: function () {
                historySaved = false;
                var g = this.grid;
                OpenSelect("Transit", this.texts.OpenSelectType, 1, '', '', '',
                    function () {
                        var el = Ext.get("Transit");
                        g.getSelectionModel().selected.each(function (task) {
                            task.setFuzeren(el.getValue());
                        });
                        el.set({
                            value: ''
                        });
                    });
                // MsgTip.msg(this.texts.msgTitle, this.texts.msgModifyTask);
            }
        };
    },

    /**
     * 指定任务干系人
     */
    /*createStockholdersItem: function () {
        return {
            text: this.texts.stockholders,
            scope: this,
            handler: function () {
                historySaved = false;
                var g = this.grid;
                OpenSelect("Transit", this.texts.OpenSelectType, 1, '', '', '',
                    function () {
                        var el = Ext.get("Transit");
                        g.getSelectionModel().selected.each(function (task) {
                            task.setMissionStockholders(el.getValue());
                        });
                        el.set({
                            value: ''
                        });
                    });
            }
        }
    },*/

    /**
     * 反馈，项目经理可以查看反馈，任务责任人可以进行反馈
     */
    createFeedbackItem: function () {
        return {
            text: this.texts.editFeedback,
            scope: this,
            handler: function () {
                var task = this.grid.getSelectionModel().getSelection()[0];
                if (task) {
                    if (typeof sUserName == "string" && sUserName != "") {
                        if (task.getResponsible() != sUserName && !isManager) {
                            Ext.MessageBox.show({
                                title: this.texts.msgTitle,
                                msg: "您不是当前所选任务的负责人，不能进行反馈！",
                                icon: Ext.MessageBox.INFO,
                                buttons: Ext.Msg.OK
                            });
                            return false;
                        }
                    }
                    var s = encodeURI("&projectsn=" + projectsn + "&ganttsn=" + ganttsn + "&gantttype=" + gantttype + "&taskid=" + task.getId() + "&isManager=" + isManager);
                    var formUrl = "FeedBack?OpenForm";
                    if (this.fbwin && !this.fbwin.closed) {
                        if (this.fbwin.location.search.substring(0,
                            this.fbwin.location.search.indexOf("&rand")) !== s) {
                            this.fbwin.location.replace(formUrl + s + "&rand=" + Math.random());
                        }
                        this.fbwin.focus();
                    } else {
                        this.fbwin = window.open(formUrl + s + "&rand=" + Math.random(), "任务反馈", "width=850,height=450,scroll=no,status=no,help=no,toolbar=no,menubar=no,location=no");
                    }
                } else {
                    Ext.MessageBox.show({
                        title: this.texts.msgTitle,
                        msg: "请选择任务！",
                        icon: Ext.MessageBox.INFO,
                        buttons: Ext.Msg.OK
                    });
                }
            }
        };
    },

    /**
     * 创建完成百分比选项
     */
    createPercentDone: function (j) {
        var a = new Array();
        for (var i = 0; i <= 100; i += 5) {
            a.push({
                text: i + "",
                scope: this,
                showSeparator: false,
                handler: function (item) {
                    this.applyPercentDone(item.text);
                }
            });
        }
        return a;
    },

    /**
     * 创建权重选择项
     */
    createWeightItems: function (j) {
        var a = new Array();
        for (var i = 0; i <= 100; i += j) {
            a.push({
                text: i + "",
                scope: this,
                handler: function (item) {
                    historySaved = false;
                    this.applyWeight(item.text);
                }
            });
        }
        return a;
    },

    /**
     * 设置完成百分比
     */
    applyPercentDone: function (value) {
        if (this.grid.isReadOnly()) {
            return
        } else {
            historySaved = false;
            this.grid.getSelectionModel().selected.each(function (task) {
                task.setPercentDone(value);
            });
        }
    },

    /**
     * 设置权重
     */
    applyWeight: function (value) {
        if (this.grid.isReadOnly()) {
            return
        } else {
            historySaved = false;
            this.grid.getSelectionModel().selected.each(function (task) {
                task.setWeight(value);
            });
        }
    },

    /*
     查看反馈
     */
    openFeedback: function () {
        var task = g.getSelectionModel().getSelection()[0];
        if (task) {
            var s = encodeURI("&projectsn=" + projectsn + "&taskid=" + task.get("Id"));
            var formUrl = "FeedBackView?OpenForm";
            if (fbwin && !fbwin.closed) {
                if (fbwin.location.search.substring(0, fbwin.location.search.indexOf("&rand")) !== s) {
                    fbwin.location.replace(formUrl + s + "&rand=" + Math.random());
                }
                fbwin.focus();
            } else {
                fbwin = window.open(formUrl + s + "&rand=" + Math.random(), "任务反馈", "width=850,height=500,scroll=no,status=no,help=no,toolbar=no,menubar=no,location=no");
            }
        } else {
            Ext.MessageBox.show({
                title: '提示',
                msg: "请选择任务！",
                icon: Ext.MessageBox.INFO,
                buttons: Ext.Msg.OK
            });
        }
    }
});
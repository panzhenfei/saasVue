Ext.define("App.plugin.Toolbar", {
	extend: "Ext.Toolbar",
	gantt: null,
	initComponent: function() {
		var gantt = this.gantt;
		//检查是否关联项目
		var checkProjectsn = function() {
			if (projectsn === "" && tasktype === "") {
				Ext.MessageBox.show("提示", "未关联项目！");
				return false;
			} else {
				return true;
			}
		};
		//创建新任务
		var createNewTask = function() {
			historySaved = false;
			var uid = gantt.getLatestId();
			var newTask = new gantt.taskStore.model({
				id: uid,
				Id: uid,
				Name: '新任务',
				leaf: true,
				ProjectSN: projectsn,
				GanttSN: ganttsn,
				Promulgator: username,
				TaskStatus: '未开始'
			});
			return newTask;
		};
		//获取最新的ID
		var getLatestId = function() {
			historySaved = false;
			var u = "GetLatestIdAgent?OpenAgent&method=getLatestId&formname=MainForm&projectsn=";
			u += projectsn + "&random=" + Math.random() * 100000;
			var id = _postsync(u, "");
			if (id === "undefined" || id === "") {
				id = null;
			}
			return id;
		};
		//保存历史版本
		var saveHistory = function() {
			if (checkProjectsn()) {
				var u = "HistoryAgent?OpenAgent&method=historycreate&projectsn=" + projectsn + "&ganttsn=";
				u += ganttsn + "&plansn=" + plansn + "&stage=" + stage + "&rand=" + Math.random();
				_post(u, "", function(h) {
					if (!_verifyAjax(h)) {
						return false;
					}
					var s = h.responseText.replace(/\n+$/, "").replace(/\s*,\s*/g, "\n");
					if (s == "") {
						MsgTip.msg('消息', '保存修改记录失败！');
					} else {
						historySaved = true;
					}
				});
			}
		};
		gantt.taskStore.on({
			'filter-set': function() {
				this.down('[iconCls*=icon-collapseall]').disable();
				this.down('[iconCls*=icon-expandall]').disable();
			},
			'filter-clear': function() {
				this.down('[iconCls*=icon-collapseall]').enable();
				this.down('[iconCls*=icon-expandall]').enable();
			},
			scope: this
		});
		Ext.apply(this, {
			items: [{
					xtype: 'buttongroup',
					title: '视图导航',
					columns: 3,
					defaults: {
						scale: 'small'
					},
					items: [{
						text: '向前',
						iconCls: 'icon-prev',
						scope: this,
						handler: function() {
							gantt.shiftPrevious();
						},
						tooltip: '根据时间刻度，将甘特图可视区域向更早的时间段移动一周、月、年。'
					}, {
						text: '向后',
						iconCls: 'icon-next',
						scope: this,
						handler: function() {
							gantt.shiftNext();
						},
						tooltip: '根据时间刻度，甘特图可视区域向更晚的时间段移动一周、月、年。'
					}, {
						text: '隐藏子任务',
						iconCls: 'icon-collapseall',
						scope: this,
						handler: function() {
							gantt.collapseAll();
						},
						tooltip: '点击后隐藏所有摘要任务。'
					}, {
						text: '全屏',
						iconCls: 'icon-fullscreen',
						disabled: !this._fullScreenFn,
						handler: function() {
							this.showFullScreen();
						},
						scope: this,
						tooltip: '全屏模式，非IE浏览器支持。'
					}, {
						text: '缩放',
						iconCls: 'zoomfit',
						handler: function() {
							gantt.zoomToFit();
						},
						scope: this,
						tooltip: '缩放到合适的时间跨度，以显示所有任务。'
					}, {
						text: '显示子任务',
						iconCls: 'icon-expandall',
						scope: this,
						handler: function() {
							gantt.expandAll();
						},
						tooltip: '点击后显示所有摘要任务。'
					}]
				}, {
					xtype: 'buttongroup',
					title: '视图分辨率',
					columns: 2,
					defaults: {
						scale: 'small'
					},
					items: [{
						text: '6 周',
						scope: this,
						handler: function() {
							gantt.switchViewPreset('weekAndMonth');
						},
						tooltip: '视图开始时间与结束时间跨度6周'
					}, {
						text: '10 周',
						scope: this,
						handler: function() {
							gantt.switchViewPreset('weekAndDayLetter');
						},
						tooltip: '视图开始时间与结束时间跨度10周'
					}, {
						text: '1 年',
						scope: this,
						handler: function() {
							gantt.switchViewPreset('monthAndYear');
						},
						tooltip: '视图开始时间与结束时间跨度1年'
					}, {
						text: '2 年',
						scope: this,
						handler: function() {
							var start = new Date(this.getStart().getFullYear(), 0);
							gantt.switchViewPreset('monthAndYear', start, Ext.Date.add(start, Ext.Date.YEAR, 5));
						},
						tooltip: '视图开始时间与结束时间跨度2年'
					}]
				},
				this.createTaskGroup(gantt),
				this.craeteFeatureGroup(gantt)
			]
		});
		this.callParent(arguments);
	},
	//创建任务工具栏
	createTaskGroup: function() {
		if (gantttype == "TASK" || gantttype == "VIEW") {
			return {};
		}
		var arr = [{
			text: '插入',
			scope: this,
			handler: function() {
				if (projectsn == "" && tasktype !== "myself") {
					Ext.MessageBox.show({
						title: '提示',
						msg: "未关联项目！",
						icon: Ext.MessageBox.INFO,
						buttons: Ext.Msg.OK
					});
					return false;
				}
				var a = this.gantt.getSelectionModel().selected;
				if (a.getCount() >= 1 && a.first().parentNode) {
					for (var i = 0; i < a.getCount(); i++) {
						a.first().addTaskAbove(createNewTask());
					}
				} else {
					this.gantt.taskStore.getRootNode().appendChild(this.createNewTask());
				}
			},
			tooltip: '<b>插入任务</b><br>在所选任务的上方插入新任务。'
		}, {
			text: '追加',
			scope: this,
			handler: function() {
				if (projectsn === "" && tasktype !== "myself") {
					Ext.MessageBox.show({
						title: '提示',
						msg: "未关联项目！",
						icon: Ext.MessageBox.INFO,
						buttons: Ext.Msg.OK
					});
					return false;
				}
				this.gantt.taskStore.getRootNode().appendChild(this.createNewTask());
			},
			tooltip: '<b>追加任务</b><br>在所选任务的后方追加新任务。'
		}];
		return {
			xtype: 'buttongroup',
			title: '任务操作',
			columns: 4,
			items: [{
				text: '任务',
				menu: arr
			}, {
				text: '人员',
				scope: this,
				handler: function() {
					var a = this.gantt.getSelectionModel().selected;
					if (a.getCount() >= 1 && a.first().parentNode) {
						OpenSelect("Transit", '人员', 1, '', '', '',
							function() {
								var el = Ext.get('Transit');
								this.gantt.getSelectionModel().selected.each(function(task) {
									task.setFuzeren(el.getValue());
								});
								el.set({
									value: ''
								});
								MsgTip.msg('消息', '责任人修改成功！');
							});
					} else {
						MsgTip.msg('消息', '要指定责任人，请选定一个或多个任务。');
					}
				},
				tooltip: '<b>指定责任人</b><br>给选定的一个或多个任务指定责任人。'
			}, {
				text: '删除',
				scope: this,
				handler: function() {
					if (!this.gantt.getSelectionModel().getSelection()[0]) {
						Ext.MessageBox.show({
							title: '提示',
							msg: "请选择任务！",
							icon: Ext.MessageBox.INFO,
							buttons: Ext.Msg.OK
						});
						return false;
					}
					Ext.Msg.confirm('提示', '确定删除任务吗？', function(btn) {
						if (btn == "yes") {
							var a = g.getSelectionModel().selected;
							if (a.getCount() === 1 && a.first().parentNode.childNodes.length == 1) {
								a.first().parentNode.set("leaf", true);
							}
							a.each(function(b) {
								b.remove();
							});
						}
					});
					MsgTip.msg('消息', '任务删除成功');
				},
				tooltip: '<b>删除任务</b><br>将选定任务删除，需要执行保存更新。'
			}, {
				text: '另存版本',
				scope: this,
				loadMask: true,
				handler: function() {
					historySaved = true;
					this.gantt.taskStore.sync();
					this.gantt.dependencyStore.sync();
					this.gantt.assignmentStore.sync();
					this.gantt.getView().refresh();
					if (checkProjectsn()) {
						//_post("TaskAgent?OpenAgent&method=c1&projectsn=" + projectsn);
					}
					MsgTip.msg('消息', '保存版本成功。');
					if (typeof gantttype == 'string' && gantttype != 'TASK') {
						this.gantt.saveHistory(); // 保存操作记录
					}
				},
				tooltip: '<b>保存版本</b><br>新增、修改或删除任务甘特图将自动保存，保存版本产生新的版本记录。'
			}, {
				text: '升级',
				handler: function() {
					g.getSelectionModel().selected.each(function(task) {
						task.outdent();
					});
				},
				tooltip: '<b>任务升级</b><br>一次将所选任务伸出一个级别。<br><br>伸出后的任务将变成任务列表中较低级别下紧跟其后的所有任务的摘要任务。'
			}, {
				text: '降级',
				handler: function() {
					g.getSelectionModel().selected.each(function(task) {
						task.indent();
					});
				},
				tooltip: '<b>任务降级</b><br>一次将所选任务缩进一个级别。<br><br>缩进后的任务将变成任务列表中较高级别下其紧邻的上一个任务的子任务。'
			}, {
				text: '链接',
				handler: function() {
					var c = g.getSelectionModel().selected;
					if (c.getCount() <= 1) {
						MsgTip.msg('消息', '要链接任务，请选定两个以上的任务。');
					} else {
						// 循环将所选任务全部依次链接起来。都使用FS关系。
						var d = g.getDependencyStore();
						for (var i = 1; i < c.getCount(); i++) {
							if (d.isValidDependency(
								g.getSelectionModel().getSelection()[i - 1], g.getSelectionModel().getSelection()[i])) {
								d.add(new d.model({
									fromTask: g.getSelectionModel().getSelection()[i - 1],
									toTask: g.getSelectionModel().getSelection()[i],
									type: d.model.Type.EndToStart
								}));
							}
						}
					}
				},
				tooltip: '<b>链接任务</b><br>链接所选任务，以便一项任务可以在另一项任务完成后再开始。<br><br>您还可以通过其他方式链接任务'
			}, {
				text: '取消链接',
				colspan: 2,
				handler: function() {
					var d = g.getDependencyStore();
					g.getSelectionModel().selected.each(function(task) {
						Ext.each(d.getDependenciesForTask(task),
							function(dep) {
								d.remove(dep);
							});
					});
				},
				tooltip: '<b>取消链接任务</b><br>删除选定任务之间的链接。'
			}]
		};
	},
	craeteFeatureGroup: function() {
		return {
			xtype: 'buttongroup',
			title: '功能',
			columns: 3,
			items: [{
				text: '项目信息',
				scope: this,
				handler: function() {
					var url = projectpath + "/viewBySN/" + encodeURI(projectsn) + "?OpenDocument";
					window.open(url, 'ProjectInfoWindow');
				}
			}, {
				text: '打印',
				scope: this,
				handler: function() {
					this.gantt.zoomToFit();
					this.gantt.print();
				}
			}, {
				iconCls: 'togglebutton',
				text: '显示基线',
				enableToggle: true,
				pressed: this.gantt.baselineVisible, // 是否选中
				handler: function() {
					this.gantt.el.toggleCls('sch-ganttpanel-showbaseline');
				},
				tooltip: '<b>显示基线</b><br>显示任务基准时间'
			}]
		}
	},
	showFullScreen: function() {
		this.gantt.el.down('.x-panel-body').dom[this._fullScreenFn](Element.ALLOW_KEYBOARD_INPUT);
	},
	// Experimental, not X-browser
	_fullScreenFn: (function() {
		var docElm = document.documentElement;
		if (docElm.requestFullscreen) {
			return "requestFullscreen";
		} else if (docElm.mozRequestFullScreen) {
			return "mozRequestFullScreen";
		} else if (docElm.webkitRequestFullScreen) {
			return "webkitRequestFullScreen";
		} else if (docElm.msRequestFullscreen) {
			return "msRequestFullscreen";
		}
	})()
});
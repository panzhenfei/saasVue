Ext.define('App.plugin.Export', {
	extend : 'Gnt.plugin.Export'
});
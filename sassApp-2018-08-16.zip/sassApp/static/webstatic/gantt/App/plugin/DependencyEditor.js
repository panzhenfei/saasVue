Ext.define('App.plugin.DependencyEditor',{
    extend:'Gnt.plugin.DependencyEditor',

    hideOnBlur: true,
    showLag: true,
    constrain: true,

    buttons: [{
        text: '确定',
        scope: this,
        handler: function() {
            var formPanel = this;
            formPanel.getForm().updateRecord(formPanel.dependencyRecord);
            this.collapse();
        }
    }, {
        text: '取消',
        scope: this,
        handler: function() {
            this.collapse();
        }
    }, {
        text: '删除',
        scope: this,
        handler: function() {
            var formPanel = this,
                record = this.dependencyRecord;
            record.store.remove(record);
            formPanel.collapse();
        }
    }]
})
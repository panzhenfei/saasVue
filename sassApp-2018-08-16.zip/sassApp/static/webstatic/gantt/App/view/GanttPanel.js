Ext.define("App.view.GanttPanel", {
    extend: "Gnt.panel.Gantt",
    requires: ['Ext.form.*',
        'Sch.plugin.TreeCellEditing',
        'Sch.plugin.Pan',
        'Gnt.column.StartDate',
        'App.column.EndDate',
        'Gnt.column.Duration',
        'Gnt.column.PercentDone',
        'App.model.Task',
        'App.store.Tasks',
        'App.model.Dependency',
        'App.store.Dependencies',
        'App.model.Calendar',
        'App.store.Calendars',
        'App.plugin.FilterField',
        'App.column.BaselineStartDate',
        'App.column.BaselineEndDate',
        'App.plugin.TaskContextMenu'
    ],

    stripeRows: false,
    enableBaseline: true, // 是否允许显示基线
    highlightWeekends: true,
    showTodayLine: true,
    viewPreset: 'weekAndDayLetter',
    cascadeChanges: true, // 任务联动
    columnLines: true,
    fbwin: null,
    hiswin: null,
    projectMoveWin: null,

    initComponent: function () {

        var g = this;

        //编辑事件
        g.afterdependencydragdrop = function (gantt, eOpts) {
        };
        //拖动事件
        g.aftertaskdrop = function (gantt, eOpts) {
        };

        g.beforedependencydrag = function (gantt, eOpts) {
        };

        g.afterdragcreate = function (view, eOpts) {
        };

        //右键菜单
        var contextMenu = Ext.create("App.plugin.TaskContextMenu");

        var printableMilestoneTpl = new Gnt.template.Milestone({
            prefix: 'foo',
            printable: true,
            imgSrc: '/resources/images/milestone.png'
        });

        //打印
        var printable = new Gnt.plugin.Printable({
            printRenderer: function (task, tplData) {
                if (task.isMilestone()) {
                    return;
                } else if (task.isLeaf()) {
                    var availableWidth = tplData.width - 4,
                        progressWidth = Math.floor(availableWidth * task.get('PercentDone') / 100);

                    return {
                        progressBarStyle: Ext.String.format(
                            'width:{2}px;border-left:{0}px solid #7971E2;border-right:{1}px solid #E5ECF5;',
                            progressWidth, availableWidth - progressWidth, availableWidth)
                    };
                } else {
                    var availableWidth = tplData.width - 2,
                        progressWidth = Math.floor(availableWidth * task.get('PercentDone') / 100);

                    return {
                        progressBarStyle: Ext.String.format(
                            'width:{2}px;border-left:{0}px solid #FFF3A5;border-right:{1}px solid #FFBC00;',
                            progressWidth, availableWidth - progressWidth, availableWidth)
                    };
                }
            },

            beforePrint: function (sched) {
                var v = sched.getSchedulingView();
                this.oldRenderer = v.eventRenderer;
                this.oldMilestoneTemplate = v.milestoneTemplate;
                v.milestoneTemplate = printableMilestoneTpl;
                v.eventRenderer = this.printRenderer;
            },

            afterPrint: function (sched) {
                var v = sched.getSchedulingView();
                v.eventRenderer = this.oldRenderer;
                v.milestoneTemplate = this.oldMilestoneTemplate;
            }
        });

        Ext.apply(this, {

            lockedGridConfig: {
                width: 490
            },

            leftLabelField: {
                dataIndex: 'Name',
                renderer: function (value, record) {
                    return value;
                }
            },

            rightLabelField: {
                dataIndex: 'Duration',
                renderer: function (value, record) {
                    return value + " 天";
                }
            },


            //, this.depEditor
            //根据条件添加插件
            plugins: this.getPlugins(printable, contextMenu),

            viewConfig: {
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        contextMenu.activateMenu(rec, e);
                    }
                }
            },

            tooltipTpl: new Ext.XTemplate(
                '<h4 class="tipHeader">{Name}</h4>',
                '<table class="taskTip">',
                '<tr><td>开始时间:</td> <td align="right">{[Ext.Date.format(values.StartDate, "y-m-d")]}</td></tr>',
                '<tr><td>完成时间:</td> <td align="right">{[Ext.Date.format(values.EndDate, "y-m-d")]}</td></tr>',
                '<tr><td>完成百分比:</td><td align="right">{PercentDone}%</td></tr>',
                '<tr><td>最新进展:</td><td align="right">{NewFeedback}</td></tr>',
                '</table>').compile(),

            //根据条件添加拖动功能
            lockedViewConfig: this.getLockedViewConfig(),

            // 任务分解列
            columns: [
                {xtype: 'rownumberer'},
                {
                    dataIndex: 'fuzeren',
                    header: '责任人',
                    id: 'zerenren',
                    width: 50
                },
                {
                    xtype: 'treecolumn',
                    header: '任务名称',
                    dataIndex: 'Name',
                    width: 190,
                    field: {
                        allowBlank: false
                    },
                    items: new App.plugin.FilterField({
                        store: this.taskStore
                    })
                },
                {
                    xtype: 'startdatecolumn',
                    header: '开始时间',
                    //keepDuration: true,
                    format: 'Y-m-d',
                    width: (gantttype == 'TASK' ? 80 : 85)
                },
                {
                    xtype: 'enddatecolumn',
                    header: '完成时间',
                    //keepDuration: true,
                    format: 'Y-m-d',
                    width: (gantttype == 'TASK' ? 80 : 85)
                },
                {
                    xtype: 'durationcolumn',
                    header: '工期',
                    width: 60
                },
                {
                    xtype: 'percentdonecolumn',
                    header: '进度',
                    id: 'jindu',
                    width: 40,
                    editor: new Ext.form.field.Spinner({
                        allowBlank: false,
                        minValue: 0,
                        maxValue: 100,
                        incrementValue: 10
                    }),
                    hidden: (gantttype == 'PLAN' ? true : false)
                },
                {
                    dataIndex: 'NewFeedback',
                    header: '反馈',
                    id: 'NewFeedback',
                    width: 120,
                    hidden: (gantttype == 'PLAN' ? true : false)
                },
                {
                    dataIndex: 'Status',
                    header: '任务状态',
                    id: 'Status',
                    width: 80,
                    hidden: (gantttype == 'PLAN' ? true : false)
                },
                {
                    xtype: 'baselinestartdatecolumn',
                    header: '基准开始时间',
                    format: 'Y-m-d',
                    hidden: true
                },
                {
                    xtype: 'baselineenddatecolumn',
                    header: '基准完成时间',
                    format: 'Y-m-d',
                    hidden: true
                }
            ],

            // 初始化操作区按钮
            tbar: this.createToolbar(this)
        });

        this.callParent(arguments);
    },

    getPlugins: function (printable, contextMenu) {
        var arr = [printable, contextMenu, Ext.create("Sch.plugin.Pan")];
        if (gantttype == "PLAN"){
            arr.push(Ext.create('Sch.plugin.TreeCellEditing', {
                clicksToEdit: 2
            }));
        }
        if (gantttype != "TASK" && gantttype != "PMP") {
            arr.push(depEditor = new Gnt.plugin.DependencyEditor({
                hideOnBlur: true,
                showLag: true,
                constrain: true,
                buttons: [
                    {
                        text: '确定',
                        scope: this,
                        handler: function () {
                            var formPanel = depEditor;
                            formPanel.getForm().updateRecord(formPanel.dependencyRecord);
                            depEditor.collapse();
                        }
                    },
                    {
                        text: '取消',
                        scope: this,
                        handler: function () {
                            depEditor.collapse();
                        }
                    },
                    {
                        text: '删除',
                        scope: this,
                        handler: function () {
                            var formPanel = depEditor,
                                record = depEditor.dependencyRecord;
                            record.store.remove(record);
                            formPanel.collapse();
                        }
                    }
                ]
            }));
        }
        return arr;
    },

    getLockedViewConfig: function () {
        if (gantttype == "PLAN") {
            return {
                plugins: {
                    ptype: 'treeviewdragdrop'
                }
            };
        } else {
            return {};
        }
    },

    //创建工具栏
    createToolbar: function (g) {
        var arr = [];
        arr.push(this.createNaviGroup(g));
        arr.push(this.createPresetGroup(g));
        if (typeof gantttype == "string") {
            if (gantttype == "PLAN") {
                arr.push(this.createTaskGroup(g));
            }
            if (gantttype == "PMP") {
                arr.push(this.createPMPGroup(g));
            }
        }
        return arr;
    },

    //创建视图导航工具栏
    createNaviGroup: function (g) {
        return {
            xtype: 'buttongroup',
            title: '视图导航',
            columns: 3,
            defaults: {
                scale: 'small'
            },
            items: [
                {
                    text: '向前',
                    iconCls: 'icon-prev',
                    scope: this,
                    handler: function () {
                        g.shiftPrevious();
                    },
                    tooltip: '根据时间刻度，将甘特图可视区域向更早的时间段移动一周、月、年。'
                },
                {
                    text: '向后',
                    iconCls: 'icon-next',
                    scope: this,
                    handler: function () {
                        g.shiftNext();
                    },
                    tooltip: '根据时间刻度，甘特图可视区域向更晚的时间段移动一周、月、年。'
                },
                {
                    text: '隐藏子任务',
                    iconCls: 'icon-collapseall',
                    scope: this,
                    handler: function () {
                        g.collapseAll();
                    },
                    tooltip: '点击后隐藏所有摘要任务。'
                },
                {
                    text: '全屏',
                    iconCls: 'icon-fullscreen',
                    disabled: !this._fullScreenFn,
                    handler: function () {
                        g.showFullScreen();
                    },
                    scope: this,
                    tooltip: '全屏模式，非IE浏览器支持。'
                },
                {
                    text: '缩放',
                    iconCls: 'zoomfit',
                    handler: function () {
                        g.zoomToFit();
                    },
                    scope: this,
                    tooltip: '缩放到合适的时间跨度，以显示所有任务。'
                },
                {
                    text: '显示子任务',
                    iconCls: 'icon-expandall',
                    scope: this,
                    handler: function () {
                        g.expandAll();
                    },
                    tooltip: '点击后显示所有摘要任务。'
                }
            ]
        };
    },

    //创建视图分辨率工具栏
    createPresetGroup: function (g) {
        return {
            xtype: 'buttongroup',
            title: '视图分辨率',
            columns: 2,
            defaults: {
                scale: 'small'
            },
            items: [
                {
                    text: '6 周',
                    scope: this,
                    handler: function () {
                        g.switchViewPreset('weekAndMonth');
                    },
                    tooltip: '视图开始时间与结束时间跨度6周'
                },
                {
                    text: '10 周',
                    scope: this,
                    handler: function () {
                        g.switchViewPreset('weekAndDayLetter');
                    },
                    tooltip: '视图开始时间与结束时间跨度10周'
                },
                {
                    text: '1 年',
                    scope: this,
                    handler: function () {
                        g.switchViewPreset('monthAndYear');
                    },
                    tooltip: '视图开始时间与结束时间跨度1年'
                },
                {
                    text: '2 年',
                    scope: this,
                    handler: function () {
                        var start = new Date(this.getStart().getFullYear(),
                            0);
                        g.switchViewPreset('monthAndYear', start, Ext.Date
                            .add(start, Ext.Date.YEAR, 5));
                    },
                    tooltip: '视图开始时间与结束时间跨度2年'
                }
            ]

        };
    },

    //创建任务工具栏
    createTaskGroup: function (g) {
        var arr = [
            {
                text: '插入',
                scope: this,
                handler: function () {
                    if (projectsn === "" && tasktype !== "myself") {
                        Ext.MessageBox.show({
                            title: '提示',
                            msg: "未关联项目！",
                            icon: Ext.MessageBox.INFO,
                            buttons: Ext.Msg.OK
                        });
                        return false;
                    }
                    var a = g.getSelectionModel().selected;
                    if (a.getCount() >= 1 && a.first().parentNode) {
                        for (var i = 0; i < a.getCount(); i++) {
                            a.first().addTaskAbove(this.createNewTask());
                        }
                    } else {
                        g.taskStore.getRootNode().appendChild(this.createNewTask());
                    }
                },
                tooltip: '<b>插入任务</b><br>在所选任务的上方插入新任务。'
            },
            {
                text: '追加',
                scope: this,
                handler: function () {
                    if (projectsn === "" && tasktype !== "myself") {
                        Ext.MessageBox.show({
                            title: '提示',
                            msg: "未关联项目！",
                            icon: Ext.MessageBox.INFO,
                            buttons: Ext.Msg.OK
                        });
                        return false;
                    }
                    g.taskStore.getRootNode().appendChild(this.createNewTask());
                },
                tooltip: '<b>追加任务</b><br>在所选任务的后方追加新任务。'
            }
        ];

        return {
            xtype: 'buttongroup',
            title: '功能操作',
            columns: 7,
            items: [
                {
                    text: '任务',
                    menu: arr,
                    tooltip: '<b>新增任务</b><br>在当前位置插入任务或在末尾追加任务<br><br>'
                },
                {
                    text: '升级',
                    handler: function () {
                        g.getSelectionModel().selected.each(function (task) {
                            task.outdent();
                        });
                        // MsgTip.msg('消息', '任务修改后需要保存更新。');
                    },
                    tooltip: '<b>任务升级</b><br>一次将所选任务伸出一个级别。<br><br>伸出后的任务将变成任务列表中较低级别下紧跟其后的所有任务的摘要任务。'
                },
                {
                    text: '删除',
                    scope: this,
                    handler: function () {
                        if (!g.getSelectionModel().getSelection()[0]) {
                            Ext.MessageBox.show({
                                title: '提示',
                                msg: "请选择任务！",
                                icon: Ext.MessageBox.INFO,
                                buttons: Ext.Msg.OK
                            });
                            return false;
                        }
                        Ext.Msg.confirm('提示', '确定删除任务吗？', function (btn) {
                            if (btn == "yes") {
                                var a = g.getSelectionModel().selected;
                                if (a.getCount() === 1 && a.first().parentNode.childNodes.length == 1) {
                                    a.first().parentNode.set("leaf", true);
                                }
                                a.each(function (b) {
                                    b.remove();
                                });
                            }
                        });
                    },
                    tooltip: '<b>删除任务</b><br>将选定任务删除，需要执行保存更新。'
                },
                {
                    text: '链接',
                    handler: function () {
                        var c = g.getSelectionModel().selected;
                        if (c.getCount() <= 1) {
                            // Ext.Msg.alert('提示','您选择了“链接任务”命令，但只选定一个任务。要链接任务，请选定两个以上的任务，然后再单击工具栏上的“链接任务”按钮。');
                            MsgTip.msg('消息', '要链接任务，请选定两个以上的任务。');
                        } else {
                            // 循环将所选任务全部依次链接起来。都使用FS关系。
                            var d = g.getDependencyStore();
                            for (var i = 1; i < c.getCount(); i++) {
                                if (d.isValidDependency(
                                        g.getSelectionModel()
                                            .getSelection()[i - 1], g
                                            .getSelectionModel()
                                            .getSelection()[i])) {
                                    d.add(new d.model({
                                        fromTask: g
                                            .getSelectionModel()
                                            .getSelection()[i - 1],
                                        toTask: g
                                            .getSelectionModel()
                                            .getSelection()[i],
                                        type: d.model.Type.EndToStart
                                    }));
                                }
                            }
                        }
                    },
                    tooltip: '<b>链接任务</b><br>链接所选任务，以便一项任务可以在另一项任务完成后再开始。<br><br>您还可以通过其他方式链接任务'
                },
                {
                    text: '取消链接',
                    handler: function () {
                        var d = g.getDependencyStore();
                        g.getSelectionModel().selected.each(function (task) {
                            Ext.each(
                                d.getDependenciesForTask(task),
                                function (dep) {
                                    d.remove(dep);
                                });
                        });
                    },
                    tooltip: '<b>取消链接任务</b><br>删除选定任务之间的链接。'
                },
                {
                    text: '项目信息',
                    scope: this,
                    handler: function () {
                        var url = projectpath + "/viewBySN/" + encodeURI(projectsn) + "?OpenDocument";
                        window.open(url, 'ProjectInfoWindow');
                    }
                },
                {
                    iconCls: 'togglebutton',
                    text: '显示基线',
                    enableToggle: true,
                    pressed: g.baselineVisible, // 是否选中
                    handler: function () {
                        g.el.toggleCls('sch-ganttpanel-showbaseline');
                    },
                    tooltip: '<b>显示基线</b><br>显示任务基准时间'
                },
                {
                    text: '人员',
                    scope: this,
                    handler: function () {
                        var a = g.getSelectionModel().selected;
                        if (a.getCount() >= 1 && a.first().parentNode) {
                            OpenSelect("Transit", '人员', 1, '', '', '',
                                function () {
                                    var el = Ext.get('Transit');
                                    g.getSelectionModel().selected.each(function (task) {
                                        task.setFuzeren(el.getValue());
                                    });
                                    el.set({
                                        value: ''
                                    });
                                    //MsgTip.msg('消息', '责任人修改成功！');
                                });
                        } else {
                            MsgTip.msg('消息', '要指定责任人，请选定一个或多个任务。');
                        }
                    },
                    tooltip: '<b>指定责任人</b><br>给选定的一个或多个任务指定责任人。'
                },
                {
                    text: '降级',
                    handler: function () {
                        g.getSelectionModel().selected.each(function (task) {
                            task.indent();
                        });
                        // MsgTip.msg('消息', '任务修改后需要保存更新。');
                    },
                    tooltip: '<b>任务降级</b><br>一次将所选任务缩进一个级别。<br><br>缩进后的任务将变成任务列表中较高级别下其紧邻的上一个任务的子任务。'
                },
                {
                    text: '保存',
                    scope: this,
                    loadMask: true,
                    handler: function () {
                        g.taskStore.sync();
                        g.dependencyStore.sync();
                        g.assignmentStore.sync();
                        g.getView().refresh();
                        //g.computeDone();
                        MsgTip.msg('消息', '保存成功。');
                    },
                    tooltip: '<b>保存</b><br>新增、修改或删除任务甘特图后保存变更。'
                },
                {
                    text: '打印',
                    scope: this,
                    handler: function () {
                        g.zoomToFit();
                        g.print();
                    }
                },
                {
                    text: '另存版本',
                    scope: this,
                    loadMask: true,
                    handler: function () {
                        historySaved = true;
                        g.taskStore.sync();
                        g.dependencyStore.sync();
                        g.assignmentStore.sync();
                        g.getView().refresh();
                        g.computeDone();
                        MsgTip.msg('消息', '保存版本成功。');
                        if (typeof gantttype == 'string' && gantttype != 'TASK') {
                            g.saveHistory(); // 保存操作记录
                        }
                    },
                    tooltip: '<b>保存版本</b><br>新增、修改或删除任务甘特图将自动保存，保存版本产生新的版本记录。'
                },
                {
                    text: '查看反馈',
                    scope: this,
                    loadMask: true,
                    handler: function () {
                        var task = g.getSelectionModel().getSelection()[0];
                        if (task) {
                            var s = encodeURI("&projectsn=" + projectsn + "&taskid=" + task.get("Id"));
                            var formUrl = "FeedBackView?OpenForm";
                            if (g.fbwin && !g.fbwin.closed) {
                                if (g.fbwin.location.search.substring(0,
                                        g.fbwin.location.search.indexOf("&rand")) !== s) {
                                    g.fbwin.location.replace(formUrl + s + "&rand=" + Math.random());
                                }
                                g.fbwin.focus();
                            } else {
                                g.fbwin = window
                                    .open(
                                    formUrl + s + "&rand=" + Math.random(),
                                    "任务反馈",
                                    "width=850,height=500,scroll=no,status=no,help=no,toolbar=no,menubar=no,location=no");
                            }
                        } else {
                            Ext.MessageBox.show({
                                title: '提示',
                                msg: "请选择任务！",
                                icon: Ext.MessageBox.INFO,
                                buttons: Ext.Msg.OK
                            });
                        }
                    },
                    tooltip: '<b>任务反馈</b><br>任务责任人对任务进行反馈'
                }
            ]
        };
    },

    //创建功能选项
    createFeatureItem: function (g) {
        var arr = [
            /*,{
             text: '导出',
             scope: this,
             handler: function() {
             Ext.MessageBox.show({
             title: '提示',
             msg: "导出PDF",
             icon: Ext.MessageBox.INFO,
             buttons: Ext.Msg.OK
             });
             }
             }*/
        ];
        //如果是任务甘特图并且是管理员
        if (typeof gantttype == "string" && gantttype == "TASK") {
            if (isManager) {
                /*arr.push(this.createPercentdoneItem());*/
            }
        }
        //如果是任计划甘特图
        if (typeof gantttype == "string" && gantttype != "TASK") {
            arr.push({
                text: '移动项目',
                scope: this,
                handler: function () {
                    g.showContactForm(g);
                },
                tooltip: '<b>移动项目</b><br>根据新的项目开始日期<br>调整所有任务的开始和<br>结束日期'
            });
            if (gantttype == "direct") {
                arr.push({
                    text: '发布任务',
                    scope: this,
                    handler: function () {
                        Ext.Msg.confirm('提示', '发布操作将更新正在进行的任务！<br>确定发布任务吗？',
                            function (btn) {
                                // todo 自动保存
                                if (btn == "yes") {
                                    g.GanttPublish();
                                }
                            });
                    },
                    tooltip: '发布任务，任务负责人可以在首页、任务中心看到其名下负责的任务。并且每次发布会立即更新正在进行的任务。'
                });
            }
            //arr.push(this.createTemplateInfo(g));
        } else {
        }
        return {
            xtype: 'buttongroup',
            title: '功能',
            columns: 3,
            items: arr
        };
    },

    //创建流程审批工具栏
    createFlowGroup: function (g) {
        return {
            xtype: 'buttongroup',
            title: '审批发布',
            columns: 2,
            items: [
                {
                    xtype: 'combo',
                    fieldLabel: '状态',
                    labelWidth: 30,
                    id: 'statusCombo',
                    store: new Ext.data.ArrayStore({
                        id: 0,
                        fields: ['Id', 'displayText'],
                        data: [
                            [0, '未发布'],
                            [1, '已发布']
                        ]
                    }),
                    colspan: 2,
                    width: 100,
                    triggerAction: 'all',
                    editable: false,
                    valueField: 'Id',
                    value: ganttStatus,
                    displayField: 'displayText'
                },
                {
                    text: '审批',
                    scope: this,
                    handler: function () {
                        if (Ext.getCmp('statusCombo').getValue() == 0) {
                            if (applyStatus == 2) {
                                Ext.Msg.confirm('提示', '本计划正在审批，是否需要查看审批单？',
                                    function (btn) {
                                        if (btn == "yes") {
                                            var url = "/" + g_sDBDir + "/ganttapply.nsf/0/" + applyFlowUNID + "?openDocument" + "&rand=" + Math.random();
                                            window.open(url,
                                                'ApplyWindow');
                                        }
                                    });
                            } else {
                                Ext.Msg.confirm('提示',
                                    '审批前需要先保存甘特图，确定审批任务计划吗？', function (btn) {
                                        if (btn == "yes") {
                                            var url = "GanttApply?ReadForm&GanttSN=";
                                            url += ganttsn + "&ProjectSN=" + projectsn + "&managerfield=" + ganttmanagerfield + "&rand=" + Math.random();
                                            window.open(url,
                                                'ApplyWindow');
                                        }
                                    });
                            }
                        } else {
                            Ext.MessageBox.show({
                                title: '提示',
                                msg: "本计划已发布，审批前请先将状态修改为未发布！",
                                icon: Ext.MessageBox.INFO,
                                buttons: Ext.Msg.OK
                            });
                            return false;
                        }
                    },
                    tooltip: '起草计划审批单'
                },
                {
                    text: '发布',
                    scope: this,
                    handler: function () {
                        if (Ext.getCmp('statusCombo').getValue() == 0) {
                            if (applyStatus == 2) {
                                Ext.MessageBox.show({
                                    title: '提示',
                                    msg: "本计划正在审批过程中不能发布！",
                                    icon: Ext.MessageBox.INFO,
                                    buttons: Ext.Msg.OK
                                });
                            } else if (applyStatus == 1) {
                                Ext.Msg.confirm('提示',
                                    '本计划已通过审批，确定发布任务计划吗？',
                                    function (btn) {
                                        // todo 自动保存
                                        if (btn == "yes") {
                                            g.GanttPublish();
                                        }
                                    });
                            } else {
                                Ext.Msg.confirm('提示',
                                    '本计划未经过审批，确定发布任务计划吗？',
                                    function (btn) {
                                        // todo 自动保存
                                        if (btn == "yes") {
                                            g.GanttPublish();
                                        }
                                    });
                            }
                        } else {
                            Ext.MessageBox.show({
                                title: '提示',
                                msg: "本计划已发布！",
                                icon: Ext.MessageBox.INFO,
                                buttons: Ext.Msg.OK
                            });
                            return false;
                        }
                    },
                    tooltip: '发布任务计划'
                }
            ]
        };
    },

    createPMPGroup: function (g) {
        return {
            xtype: 'buttongroup',
            title: '面板',
            columns: 2,
            defaults: {
                scale: "large"
            },
            items: [{
                text: '日历面板',
                scope: this,
                handler: function () {
                    var conf = {
                        calendar: this.taskStore.calendar
                    };

                    var editorWindow = new Gnt.widget.calendar.CalendarWindow(conf);
                    editorWindow.show();
                }
            }, {
                text: '任务面板',
                scope: this,
                handler: function () {
                    var st = this.getView().getSelectionModel().getSelection();
                    if (st.length > 0) {

                        this.taskEditor.showTask(st[0]);

                    } else {
                        Ext.Msg.alert('提示', '请选择一个任务');
                    }
                }
            }]
        }
    },

    //确认进度
    createPercentdoneItem: function () {
        return {
            text: '确认进度',
            scope: this,
            handler: function () {
                alert(stage);
                var u = "TaskAgent?OpenAgent&method=querenjindu&projectsn=" + projectsn + "&ganttsn=" + ganttsn + "&stage=" + stage + "&rand=" + Math.random();
                _post(u, "", function (h) {
                    if (!_verifyAjax(h))
                        return false;
                    var s = h.responseText.replace(/\n+$/, "").replace(
                        /\s*,\s*/g, "\n");
                    if (s == "ok") {
                        Ext.Msg.confirm('提示', '确认进度成功，是否需要刷新甘特图？',
                            function (btn) {
                                if (btn == "yes") {
                                    window.location.reload();
                                } else {
                                    MsgTip.msg('消息', '确认进度成功！');
                                }
                            });
                    } else {
                        MsgTip.msg('消息', '确认进度失败！');
                    }
                });
            },
            tooltip: '确认全部任务进度'
        };
    },

    //检查是否关联项目
    checkProjectsn: function () {
        if (projectsn === "" && tasktype === "") {
            Ext.MessageBox.show("提示", "未关联项目！");
            return false;
        } else {
            return true;
        }
    },

    //查看版本
    createTemplateInfo: function (g) {
        return {
            text: '查看版本',
            scope: this,
            handler: function () {
                var s = encodeURI("?ReadForm&projectsn=" + projectsn);
                var formUrl = "History";
                if (g.hiswin && !g.hiswin.closed) {
                    if (g.hiswin.location.search.substring(0,
                            g.hiswin.location.search.indexOf("&rand")) !== s) {
                        g.hiswin.location.replace(formUrl + s + "&rand=" + Math.random());
                    }
                    g.hiswin.focus();
                } else {
                    var u = formUrl + s + "&rand=" + Math.random();
                    g.hiswin = window.open(u, "加载选项");
                }
            },
            tooltip: '<b>查看版本对比</b><br>'
        };
    },

    //计算完成百分比
    computeDone: function (obj, type) {
        historySaved = false;
        if (this.checkProjectsn()) {
            var h;
            var u = "TaskAgent?OpenAgent&method=c1&projectsn=" + projectsn;
            if (window.XMLHttpRequest)
                h = new XMLHttpRequest();
            else
                h = new ActiveXObject("Microsoft.XMLHTTP");
            h.onreadystatechange = function (obj) {
                if (!_verifyAjax(h)) {
                    return false;
                }
            };
            h.open("get", u, true);
            h.send(null);
        }
    },

    //获取最新的ID
    getLatestId: function () {
        historySaved = false;
        var id;
        var u = "GetLatestIdAgent?OpenAgent&method=getLatestId&formname=MainForm&projectsn=" + projectsn + "&random=" + Math.random() * 100000;
        if (typeof(_postsync) == "function") {
            id = _postsync(u, "");
        } else {
            var h;
            if (window.XMLHttpRequest)
                h = new XMLHttpRequest();
            else
                h = new ActiveXObject("Microsoft.XMLHTTP");
            h.open("post", u, false);
            h.setRequestHeader("CONTENT-TYPE",
                "application/x-www-form-urlencoded");
            h.send(null);
            id = h.responseText.replace(/\n*$/g, "");
        }
        if (id == "undefined" || id == "") {
            // id="TASK"+Math.random()*100000;
            id = null;
        }
        return id;
    },

    //创建新任务
    createNewTask: function () {
        historySaved = false;
        var uid = this.getLatestId();
        var newTask = new this.taskStore.model({
            id: uid,
            Id: uid,
            Name: '新任务',
            leaf: true,
            ProjectSN: projectsn,
            Promulgator: username,
            TaskStatus: '未开始',
            GanttSN: ganttsn
        });
        return newTask;
    },

    //保存历史版本
    saveHistory: function () {
        if (this.checkProjectsn()) {
            var u = "HistoryAgent?OpenAgent&method=historycreate&projectsn=" + projectsn + "&ganttsn=" + ganttsn + "&plansn=" + plansn + "&stage=" + stage + "&rand=" + Math.random();
            _post(u, "", function (h) {
                if (!_verifyAjax(h)) {
                    return false;
                }
                var s = h.responseText.replace(/\n+$/, "").replace(
                    /\s*,\s*/g, "\n");
                if (s == "") {
                    MsgTip.msg('消息', '保存修改记录失败！');
                } else {
                    historySaved = true;
                }
            });
        }
    },

    //调整进度
    applyPercentDone: function (value) {
        historySaved = false;
        this.getSelectionModel().selected.each(function (task) {
            task.setPercentDone(value);
            if (value == 0) {
                task.setTaskStatusField('未开始');
            }
            if (value > 0 && value < 100) {
                task.setTaskStatusField('正在执行');
            }
            if (value == 100) {
                task.setTaskStatusField('已完成');
            }
        });
    },

    //发布甘特图
    GanttPublish: function () {
        //historySaved = false;
        var u = "TaskAgent?OpenAgent&method=updatestatus&projectsn=" + projectsn + "&ganttsn=" + ganttsn + "&projectpath=" + projectpath + "&managerfield=" + ganttmanagerfield + "&ganttstatus=1&applystatus=" + applyStatus + "&gantttype=" + gantttype + "&rand=" + Math.random();
        _post(u, "", function (h) {
            if (!_verifyAjax(h)) {
                return false;
            }
            var s = h.responseText.replace(/\n+$/, "").replace(
                /\s*,\s*/g, "\n");
            if (s == "ok") {
                Ext.Msg.confirm('提示', '任务发布成功，是否需要刷新甘特图？',
                    function (btn) {
                        if (btn == "yes") {
                            window.location.reload();
                        } else {
                            MsgTip.msg('消息', '发布成功！');
                        }
                    });
            } else {
                MsgTip.msg('消息', '发布失败！');
            }
        });
    },

    //移动项目对话框,项目的开始日期，和结束日期是固定的。
    showContactForm: function (g) {
        if (!g.projectMoveWin) {
            var form = Ext.widget('form', {
                layout: {
                    type: 'vbox',
                    align: 'stretch'
                },
                border: false,
                bodyPadding: 10,

                fieldDefaults: {
                    labelAlign: 'top',
                    labelWidth: 100,
                    labelStyle: 'font-weight:bold'
                },
                defaults: {
                    margins: '0 0 10 0'
                },

                items: [
                    {
                        xtype: 'displayfield',
                        fieldLabel: '原来的项目开始日期',
                        value: g.startDate.format("yyyy年M月d日")
                    },
                    {
                        xtype: 'datefield',
                        fieldLabel: '新的项目开始日期',
                        name: 'start_date',
                        id: 'project_start_date_new',
                        value: g.startDate,
                        allowBlank: false
                    }
                ],

                buttons: [
                    {
                        text: '确定',
                        handler: function () {
                            if (this.up('form').getForm().isValid()) {
                                var oldstart = g.startDate.format("yyyy-MM-dd");
                                var newstart = this.up('form').getForm()
                                    .findField("project_start_date_new")
                                    .getValue().format("yyyy-MM-dd");
                                if (newstart == oldstart) {
                                    this.up('form').getForm().reset();
                                    this.up('window').hide();
                                    return false;
                                }
                                this.up('window').hide();
                                MsgTip.msg('消息', '正在处理，请稍候……');
                                var u = "TaskAgent?OpenAgent&method=moveproject&projectsn=" + escape(projectsn) + "&ganttsn=" + escape(ganttsn) + "&projectpath=" + projectpath + "&managerfield=" + ganttmanagerfield + "&ganttstatus=1&applystatus=" + applyStatus + "&gantttype=" + gantttype + "&newstart=" + newstart + "&oldstart=" + oldstart + "&rand=" + Math.random();
                                _post(u, "", function (h) {
                                    if (!_verifyAjax(h)) {
                                        return false;
                                    }
                                    var s = h.responseText.replace(/\n+$/,
                                        "").replace(/\s*,\s*/g, "\n");
                                    if (s == "ok") {
                                        window.onbeforeunload = null;
                                        window.location.reload();
                                    } else {
                                        Ext.MessageBox.alert('提示',
                                            '项目移动失败！' + s);
                                    }
                                });
                            }
                        }
                    },
                    {
                        text: '取消',
                        handler: function () {
                            this.up('form').getForm().reset();
                            this.up('window').hide();
                        }
                    }
                ]
            });

            g.projectMoveWin = Ext.widget('window', {
                title: '移动项目',
                closeAction: 'hide',
                width: 300,
                height: 200,
                layout: 'fit',
                resizable: false,
                modal: true,
                items: form
            });
        }
        g.projectMoveWin.show();
    },

    //全屏
    showFullScreen: function () {
        this.el.down('.x-panel-body').dom[this._fullScreenFn]();
    },

    //全屏
    _fullScreenFn: (function () {
        var docElm = document.documentElement;

        if (docElm.requestFullscreen) {
            return "requestFullscreen";
        } else if (docElm.mozRequestFullScreen) {
            return "mozRequestFullScreen";
        } else if (docElm.webkitRequestFullScreen) {
            return "webkitRequestFullScreen";
        }
    })()
});
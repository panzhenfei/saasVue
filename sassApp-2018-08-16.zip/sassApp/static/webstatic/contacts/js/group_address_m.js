/*---------------团队成员查询---------------*/


var app = new Vue({
    el:"#member_list",
    data:{
        add_type:false,
        shade:false,
        items:[]
    },
    created: function () {
        var _self = this;
        var teamId = window.location.href.split("?")[1].split("=")[1];

        setDeptHead('n','n',teamId,0,0);//获取头部信息

        var param = {teamId:teamId};
        axios.post(getUrl()+"/concats_api/query_team_members",param).then(function (response) {
            _self.$data.items = response.data.result;
            console.info(response.data.result);
        }).catch(function (error) {
            console.info(error);
        });

        //deptHtml 获取一级部门
        //var teamId = window.location.href.split('?')[1].split('=')[1];
        var par = {deptId:0,teamId:teamId};
        console.info(par);
        axios.post(getUrl()+"/concats_api/query_dept_list",par).then(function (response) {
            var newJson =response.data.result;
            console.info(newJson);
            var deptHtml = '';
            for(var j=0;j<newJson.length;j++){
                var arrJ = newJson[j];
                var teamId = arrJ.teamId;
                var deptId = arrJ.deptId;
                var deptName = arrJ.deptName;
                var memberNum = arrJ.memberNum;
                deptHtml+='<li class="mui-table-view-cell">'+
                    '<a class="mui-navigate-right" href="javascript:appApi.openNewWindow(getUrl()+\'/static/webstatic/contacts/subdivision.html?org=n&teamId='+teamId+'&deptId='+deptId+'\')">'+deptName+'<span class="mui-badge mui-badge-inverted">'+memberNum+'</span></a>'+
                    '</li>';
            }
            document.getElementById("deptHtml").innerHTML=deptHtml;
        }).catch(function (error) {
            //alert("获取部门信息失败,请联系管理员!");
            console.info(error);
        });

    },
    methods:{
        clickshow: function () {
            return true;
        },
        hide_shade:function () {
            this.shade=true;
        }
    },
    filters: {
        getImageUrl: function (val) {
            if(val==null || val=="") return getUrl()+"/static/images/60x60.gif";
            return val;
        }
    }
});

function addType() {
    app.add_type = true;
}
function reLoad() {
    window.history.go(0);
}
/*---------------组织创建---------------*/

var index_m,uploadStatus = false;
var app = new Vue({
    el:"#team_create",
    data:{
        handwritten:false,
        updateMember:false,
        add_type:false,
        shade:false,
        select_tags:false,
        select_industry:false,
        select_major:false,
        team_name:"",
        teamType:"1",
        majorIds:"",
        majorNames:"请选择",
        staffSize:"",
        tagsIds:0,
        tagsNames:"请选择",
        industry_name:"*必选",
        industry_id:0,
        //industry_name:"",
        region_name:"",
        teamAddress:"",
        teamProfile:"",
	    creditCode:"",
	    orgCode:"",
	    legalPersonName:"",
	    authph_1:"必须与证件上一致(必填)",
	    authph_2:"必须与证件上一致(必填)",
	    authph_3:"法人代表姓名(必填)",
	    accreditImg:"",
        members:[
            //{memberName:"1", phoneNumber:"1"},
            //{}
        ]
    },
    created:function (){
        // axios.post(getUrl()+"/concats_api/query_tags_or_industry?queryType=0").then(function (response) {
        //     var newJson =response.data.result;
        //     console.info(newJson);
        //     var tagsHtml = "";
        //     for(var j=0;j<newJson.length;j++){
        //         var arrJ = newJson[j];
        //         var tagsId = arrJ.tagsId;
        //         var tagsName = arrJ.tagsName;
        //         tagsHtml+='<div class="mui-input-row mui-radio mui-left">'+
        //             '<label>'+tagsName+'</label><input type="radio" name="checkbox1" value="'+tagsId+'-'+tagsName+'"/>'+
        //             '</div>';
        //     }
        //     document.getElementById("tagsHtml").innerHTML=tagsHtml;
        // }).catch(function (error) {
        //     //alert("获取标签失败!");
        //     console.info(error);
        // });

        // axios.post(getUrl()+"/concats_api/query_tags_or_industry?queryType=1").then(function (response) {
        //     var newJson =response.data.result;
        //     console.info(newJson);
        //     var industryHtml = "";
        //     for(var j=0;j<newJson.length;j++){
        //         var arrJ = newJson[j];
        //         var industryId = arrJ.industryId;
        //         var industryName = arrJ.industryName;
        //         industryHtml+='<div class="mui-input-row mui-radio mui-left">'+
        //             '<label>'+industryName+'</span></label><input type="radio" name="radio1" value="'+industryId+'-'+industryName+'"/>'+
        //             '</div>';
        //     }
        //     document.getElementById("industryHtml").innerHTML=industryHtml;
        // }).catch(function (error) {
        //     //alert("获取行业失败!");
        //     console.info(error);
        // });

        //获取专业
        // axios.post(getUrl()+"/concats_api/query_tags_or_industry?queryType=2").then(function (response) {
        //     var newJson =response.data.result;
        //     console.info(newJson);
        //     var majorHtml = "";
        //     for(var j=0;j<newJson.length;j++){
        //         var arrJ = newJson[j];
        //         var majorId = arrJ.majorId;
        //         var majorName = arrJ.majorName;
        //         majorHtml+='<div class="mui-input-row mui-checkbox mui-left">'+
        //             '<label>'+majorName+'</span></label><input type="checkbox" name="checkbox2" value="'+majorId+'-'+majorName+'"/>'+
        //             '</div>';
        //     }
        //     document.getElementById("majorHtml").innerHTML=majorHtml;
        // }).catch(function (error) {
        //     //alert("获取行业失败!");
        //     console.info(error);
        // });

    },
    methods:{
        selectTeamType:function (val) {
            var _self = this;
            if(val == 1){
                //document.getElementById("org_code").style.display="none";//企业时隐藏
	            _self.authph_1 = "必须与证件上一致(必填)";
                document.getElementById("label_code").innerHTML ="社会信用代码";
	            //_self.authph_2 = "必须与证件上一致(可不填)";
	            //_self.authph_3 = "法人代表姓名(必填)";
            }else if(val == 2){
                //document.getElementById("org_code").style.display="block";
	            _self.authph_1 = "必须与证件上一致(必填)";
                document.getElementById("label_code").innerHTML ="社会信用代码(组织机构代码)";
	            //_self.authph_2 = "必须与证件上一致(可不填)";
	            //_self.authph_3 = "法人代表姓名(可不填)";
            }else{
                //document.getElementById("org_code").style.display="block";
	            _self.authph_1 = "必须与证件上一致(可不填)";
                document.getElementById("label_code").innerHTML ="社会信用代码";
	            //_self.authph_2 = "必须与证件上一致(可不填)";
	            //_self.authph_3 = "法人代表姓名(可不填)";
            }
            this.teamType = val;
        },
        hide_shade: function(){
            this.handwritten = false;
            this.updateMember = false;
            this.add_type = false;
            this.shade = false;
            this.select_industry = false;
             this.select_tags = false;
        },
        show_add: function () {
            this.add_type = true;
            this.shade = true;
        },
        show_handwritten: function(){
            this.add_type = false;
            this.shade = true;
            this.handwritten = true;
        },
        show_tags: function () {//选择标签
            this.select_tags = true;
            this.shade=true
        },
        show_industry: function () {//弹出行业选择
            this.select_industry = true;
            //this.shade = true;
        },
        show_major: function () {//选择专业
            this.select_major = true;
        },
        save_major: function () {//保存所选专业
            var majorIds = "";
            var majorNames = "";
            var arrTags = $('input:checkbox[name="checkbox2"]:checked');
            for(var i =0;i<arrTags.length;i++){
                var majorI = arrTags[i].value;
                var majorIarr = majorI.split("-");
                if(i==arrTags.length-1){
                    majorIds+=majorIarr[0];
                    majorNames+=majorIarr[1];
                }else{
                    majorIds+=majorIarr[0]+",";
                    majorNames+=majorIarr[1]+"  ";
                }
            }
            this.majorNames = majorNames;
            this.majorIds = majorIds;
            this.select_major = false;
        },
        save_tags: function () {//确定选中所选标签
            this.select_tags = false;
            var tagsIds = "";
            var tagsNames = "";
            // var arrTags = $('input:checkbox[name="checkbox1"]:checked');
            // for(var i =0;i<arrTags.length;i++){
            //     var tagsI = arrTags[i].value;
            //     var tagsIarr = tagsI.split("-");
            //     if(i==arrTags.length-1){
            //         tagsIds+=tagsIarr[0];
            //         tagsNames+=tagsIarr[1];
            //     }else{
            //         tagsIds+=tagsIarr[0]+",";
            //         tagsNames+=tagsIarr[1]+"  ";
            //     }
            // }
            var industry_id_name = $('input:radio[name="checkbox1"]:checked').val()
            var industry_arr = industry_id_name.split("-");
            this.tagsIds=industry_arr[0];
            this.tagsNames=industry_arr[1];

            // this.tagsNames = tagsNames;
            // this.tagsIds = tagsIds;
            this.select_tags = false;
            this.shade=false
        },
        save_industry: function(){//确定选中的行业
            this.select_industry = false;
            var industry_id_name = $('input:radio[name="radio1"]:checked').val()
            var industry_arr = industry_id_name.split("-");
            this.industry_id=industry_arr[0];
            this.industry_name=industry_arr[1];
        },
        save_member: function(bool){
            var name = this.$refs.input_name.value;
            var phone = this.$refs.input_phone.value;
            if(name==null || name=="" || phone==null || phone==""){
                layer.open({
                    content: '姓名和手机号不能为空!'
                    ,skin: 'msg'
                    ,time: 1 //2秒后自动关闭
                    ,anim:false
                });
                return;
            }
            if(!checkPhone(phone)){
                warm("手机号码格式不正确！");
                return ;
            }

            this.$refs.input_name.value="";
            this.$refs.input_phone.value="";
            this.$data.members.push({memberName:name, phoneNumber:phone});
            if(bool){
                this.handwritten = false;
                this.add_type = false;
                this.shade = false;
            }
        },
        update_save_member:function () {
            var name = this.$refs.input_update_name.value;
            var phone = this.$refs.input_update_phone.value;
            if(name==null || name=="" || phone==null || phone==""){
                layer.open({
                    content: '姓名和手机号不能为空!'
                    ,skin: 'msg'
                    ,time: 1 //2秒后自动关闭
                    ,anim:false
                });
                return;
            }
            if(!checkPhone(phone)){
                warm("手机号码格式不正确！");
                return ;
            }

            this.$data.members[index_m].memberName = name;
            this.$data.members[index_m].phoneNumber = phone;
            this.$refs.input_update_name.value="";
            this.$refs.input_update_phone.value="";

            this.updateMember = false;
            this.shade = false;
        },
        remove_member:function (index) {
            this.members.splice(index,1);//删除members数组的单个数据
        },
        update_member:function (index) {
            index_m = index;
            var member = this.members[index];
            this.$refs.input_update_name.value=member.memberName;
            this.$refs.input_update_phone.value=member.phoneNumber;
            this.updateMember = true;
            this.shade = true;

            /*this.members[index].memberName = "桃子";//修改members数组的单个数据
            this.region_name = "oooX";*/
        },
        submit_data: function () {
        	var _self = this;
            //alert(team_name==null+"==="+team_name);
            console.log("====="+this.team_name);
            var team_name_value = document.getElementById("team_name_id").value;
	        if(this.teamType==undefined || this.teamType==0){
		        msg("请选择组织类型!");
		        return
	        }
	       if(!teamNameCheck(team_name_value,this.teamType)){
	            return;
           }
            if(this.teamType == 1) {
                if(this.creditCode == ""){
                    msg("请填写社会信用代码");
                    return;
                }
                /*if(this.orgCode == ""){
                 msg("请填写组织结构代码");
                 return;
                 }*/
                /*if(this.legalPersonName == ""){
                 msg("请填写法定代表人");
                 return;
                 }*/
            }
            if(this.teamType == 2) {
                if(this.creditCode == ""){
                    msg("请填写社会信用代码或组织机构代码");
                    return;
                }
            }
            // if(this.tagsIds==undefined || this.tagsIds == 0) {
		     //    msg("请选择组织标签!");
		     //    return;
	        // }

	        if(this.teamType == 2 && this.orgCode == "") {//注释，2017.11.25
                //msg("请填写组织结构代码");
                //return;
	        }
	        if(this.accreditImg =="") {
		        msg("请上传管理员授权认证函");
		        return;
	        }
	        var subCreate = function () {

	        }
	        if(team_name_value != "" && _self.orgCode != ""){
		        loading("正在认证中...");
	        }else{
		        loading("正在创建组织中...");
	        }
	        subCreate();
	        var members = [];
	        for(var i=0;i<this.members.length;i++){
		        var memberI = this.members[i];
		        members.push({memberName:memberI.memberName,phoneNumber:memberI.phoneNumber});
	        }
	        var param = {
		        teamName:_self.team_name,
		        tagsIds:_self.tagsIds,
		        teamType:_self.teamType,
		        creditCode:_self.creditCode,
		        orgCode:_self.orgCode,
		        legalPersonName:_self.legalPersonName,
		        accreditImg:_self.accreditImg/*,
		        region_name:_self.region_name,
		        projectTeamMemberTList:members*/
	        };
	        axios.post(getUrl()+"/concats_api/create_team_member", param).then(function (response) {
		        console.info(response);
		        if (response.data.code == 0) {
			        loading('创建成功！正在跳转！');
			        /*setTimeout(function () {
			        	appApi.closeNewWindow("../contacts/address_list.html");
			        },1500)*/
                    setTimeout(function () {
                        appApi.broadcast("reLoad()"); //刷新页面
                        appApi.closeNewWindow();
                    },1500)
		        } else {
			        layer.closeAll();
			        msg(response.data.message);
		        }
	        }).catch(function (error) {
		        alert("创建失败，请联系管理员!");
		        layer.closeAll();
		        console.log('创建失败--'+data.message);
	        });
        }

    }
});

//校验手机号
function checkPhone(phone){
    var pattern = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/;
    var flag = pattern.test(phone);
    return flag;
}

function selectCertImg (that) {
	try {
		lrz(that.files[0], {
			width: 800,
			height: 600
		}).then(function (rst) {
			uploadStatus = true;
			app.$data.accreditImg = rst.base64;
			document.getElementById("uploadImg").style.backgroundImage =  "url('" + rst.base64 + "')";
		})
	}catch (e){
		alert(e)
	}
}

function teamNameCheck(name,type) {
	if(name.length<3){
		msg("请输入最少三个字的组织名称!");
		return false;
	}
	if(type == 3 || type=="3"){
		var not = ["公司","有限公司","有限责任公司","股份有限公司","集团","集团有限公司","集团公司"];
		for(var i =0 ; i < not.length ; i++){
			if(name.indexOf(not[i])>-1){
				msg('非企业或者政府事业单位的组织名称不允许含有："' + not[i] + '"字样');
				return false;
			}
		}
	}
	var flag = false;
	//判断是否有重名
	$.ajax({
		url: getUrl()+"/concats_api/check_team_name",
		type: 'post',
		async:false,
		dataType: 'json',
		contentType:"application/json",
		data:JSON.stringify({teamName:name}),
		success: function(data){
			if(data.code == 0){
				flag = true;
			}else{
				setTimeout(function () {
                    layer.closeAll();
                },1500);
				msg(data.message);
			}
		}
	});
    return flag;
}
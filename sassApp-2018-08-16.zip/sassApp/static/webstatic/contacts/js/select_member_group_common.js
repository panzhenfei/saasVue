/*---------------选择成员-----------------*/
Array.prototype.contains = function (obj) {
	var i = this.length;
	while (i--) {
		if (this[i] === obj) {
			return true;
		}
	}
	return false;
}
Array.prototype.remove = function(val) {
	var index = this.indexOf(val);
	if(index > -1) {
		this.splice(index, 1);
	}
};
function selectInArr(bool,val) {
	val = val + "";
	if(bool){
		if(!selectArr.contains(val)){
			selectArr.push(val);
		}
	}else{
		// if(userId != val){ //自己不能删除
			selectArr.remove(val);
		// }
	}
	var count = selectArr.length;
	var text = count ? "完成(" + count + ")" : "完成";
	var btn = jQuery(".ok-btn");
	btn.text(text);
	if (count) {
		if (btn.hasClass("mui-disabled")) {
			btn.removeClass("mui-disabled");
		}
	} else {
		if (!btn.hasClass("mui-disabled")) {
			btn.addClass("mui-disabled");
		}
	}
	app.$data.selArr = selectArr;
	capp.$data.selArr = selectArr;
}

function selEvent(target) {
	var type = target.getAttribute("data-type");
	var value = target.value;
	if(type == "user"){
		selectInArr(target.checked,value);
	}else{
		var par = {deptId:value};
		axios.post(getUrl()+"/concats_api/query_team_members",par).then(function (response) {
			var memberList = response.data.result;
			for(var i= 0;i<memberList.length;i++){
				selectInArr(target.checked,memberList[i].userId);
			}
		}).catch(function (error) {
			console.info(error);
		});
		if(target.checked){
			if(!selectDept.contains(value)){
				selectDept.push(value);
			}
		}else{
			selectDept.remove(value);
		}
		capp.$data.selDept = selectDept;
		app.$data.selDept = selectDept;
	}
}
var app = new Vue({
	el:"#select_member",
	data:{
		items:[],
		friendsList:[],
		key:"",
		selArr:[],
		myId:userId,
		selDept:[],
		selectNumStr:"",
		groupName:"",
		projects:[]
	},
	created: function () {
		var _self = this;
		axios.post(getUrl()+"/chart/column/table_swprojectinfo?used=getPro",{}).then(function (response) {
//          console.log("数据",response.data.result)
            _self.$data.projects = response.data.result;
        }).catch(function (error) {
            console.info(error);
        });
        setTimeout(function(){
        	axios.post(getUrl()+"/concats_api/find_team_list",{}).then(function (response) {
				_self.$data.items = response.data.result;
			}).catch(function (error) {
				console.info(error);
			});
        },200);
		var param = new FormData();
		param.append("userId", "");
		setTimeout(function(){
			axios.post(getUrl()+"/concats_api/find_eg_list", param).then(function (response) {
				_self.$data.friendsList = convertData(response.data.result);
				_self.updated();
			}).catch(function (error) {
				console.info(error);
			});
		},400);
		//加载成员列表

		setTimeout(function () {
            console.log(sdkChatId,"kk")
            axios.post(getUrl()+"/concats_api/query_gm_list",{sdkChatId:sdkChatId}).then(function (response) {
                var mList = response.data.result;
                // console.log(response.data.result,"kksss")
                for(var i=0;i<mList.length;i++){
                    /**
                     * 全部群成员ID
                     */
                    groupMember.push(mList[i].userId)
                }
            }).catch(function (error) {
                console.info(error);
            });
        },600)

	},
	methods:{
		getImageUrl: function (val) {
			if(val==null || val=="") return getUrl()+"/static/images/60x60.gif";
			return val;
		},
		clickshow: function () {
			return true;
		},
		updated:function () {//DOM更新时，进行调用的方法
			document.getElementById("list").style.display = "block";
			mui.ready(function () {
				window.indexedList = new mui.IndexedList(list)
			});
		},
		//确定选中的userIds
		trueSelectUser: function () {
			/**
			 * 必须选人
			 */
			if(selectArr.length<1){
				return;
			}
			var l = loading("请稍等");
			var paramData = [];
			var param = {userIds:selectArr.toString()};//查询头像list返回
			var _self = this;
			axios.post(getUrl()+"/concats_api/query_gms_info_select",param).then(function (response) {
				var reps = response.data.result;
				_self.$data.none = reps;
				var mList = reps.groupMemberTempVOList;
				
				for(var i=0;i<mList.length;i++){
					paramData.push({
						"userId": mList[i].userId,
						"memberType": '0',
						"userAvatar":mList[i].imageHost,
						"memberName":mList[i].nickName,
						"phoneNumber":mList[i].phoneNumber,
						"imId":mList[i].imId
						
					})
					if(paramData.length==selectArr.length){
						console.log(paramData)
						window.appApi.setSelectData(paramData)
						layer.close(l)
						setTimeout(function(){
							window.appApi.closeNewWindow();
						},200);
					}
				}
			}).catch(function (error) {
				layer.close(l)
				console.info(error);
			});
			viewApi.back();//关闭选择子部门div
		}
	}
});

var capp = new Vue({
	el:"#select_children",
	data:{
		deptList:[],
		memberList:[],
		navList:[],
		selArr:[],
		myId:userId,
		selDept:[]
	},
	created: function () {

	},
	methods:{
		clickshow: function () {
			return true;
		},
		selectDept:function (deptId,deptName,event) {
			var obj = {teamId:undefined,deptId:deptId,deptName:deptName,type:2};//type2表示时团队，1表示时项目
			//i=0为联系人页面
			var flag = false;
			var nArr = new Array();
			for(var i=0;i<historyArr.length;i++){
				nArr.push(historyArr[i]);
				if(undefined != deptId && deptId == historyArr[i].deptId){
					flag = true;
					break;
				}

			}
			if(!flag){
				nArr.push(obj);
			}
			historyArr = nArr;
			var _self = this;
			_self.$data.navList = historyArr;
			initChildDept(undefined,deptId,deptName);
			event.preventDefault();
			event.stopPropagation();
		},
		selectTeam:function (teamId,teamName,event) {
			var obj = {teamId:undefined,teamName:teamName,deptId:undefined,deptName:undefined,type:2};//type2表示时团队，1表示时项目
			//i=0为联系人页面
			var flag = false;
			var nArr = new Array();
			for(var i=0;i<historyArr.length;i++){
				nArr.push(historyArr[i]);
				if(undefined != teamId && teamId == historyArr[i].teamId){
					flag = true;
					break;
				}
			}
			if(!flag){
				nArr.push(obj);
			}
			historyArr = nArr;
			var _self = this;
			_self.$data.navList = historyArr;
			initChildDept(teamId,undefined,undefined);
			event.preventDefault();
			event.stopPropagation();
		},
		updated:function () {//DOM更新时，进行调用的方法
			document.getElementById("list").style.display = "block";
			mui.ready(function () {
				window.indexedList = new mui.IndexedList(list)
			});
		}
	}
});


var project = new Vue({
	el:"#select_project",
	data:{
		deptList:[],
		memberList:[],
		navList:[],
		selArr:[],
		myId:userId,
		selDept:[],
		
	},
	created:function(){
		
	},
	methods:{
		getProjectMembers:function(projectSN,projectName){
			var _self = this;
//			_self.$data.deptList = [];
//			_self.$data.selDept = [];
			_self.$data.memberList = [];
//			console.log(projectName)
			var obj = {teamId:projectSN,teamName:projectName,type:1};
			var lengths = historyArr.length;
			if (lengths>0) {
				for(var i=0 ; i<lengths;i++){
					historyArr.pop();
				}
			}
			historyArr.push(obj)
			_self.$data.navList = historyArr;
			document.getElementById("sc").style.transform="translate3d(0px, 0px, 0px) translateZ(0px)";
			$.ajax({
	            type: "post",
	            url: getUrl()+"/pcontact_api/findallroomlist",
	            data: {
	                "projectSn":projectSN,
	                "flag":2,//1: 包涵会议室、招聘室 2 不包含会议室和招聘室
	                "isQueryMember":1//isQueryMember 是否返回成员信息  1：返回  2：不返回
	            },
	            datatype: "json",
	            success: function(data) {
	            	console.log(data)
	            	if(data.code==0){
	            		_self.$data.deptList = data.result.roomItems;
	            		_self.$data.selDept = data.result.roomItems;
//	            		console.log(_self.$data.deptList)
	            	}
//	            	if(c_scroll){
//						setTimeout(function () {
//							mui('#select_project_scroll').scroll().refresh();
//							var w = document.getElementById("project_scroll").scrollWidth;
//							var s = c_scroll.wrapperWidth - w;
//							if(s<0){
//								mui('#select_project_scroll').scroll().scrollTo(s,0,100);
//							}
//							var _self = capp;
//							mui('#project_scroll').on('tap', '.mui-control-item', function(e) {
//								viewApi.back('#select_member');
//							});
//						},500)
//					}
	            },
	            error:function(error){
	            	
	            }
	        });
		},
		/**
		 * 获取房间数据
		 * @param {Object} leave1 第一层
		 * @param {Object} leave2 第二层 当只有第一层时为-1
		 */
		getRoomMembers:function(leave1,leave2,className){
			var obj = {teamId:undefined,deptId:undefined,deptName:className,type:1};//type2表示时团队，1表示时项目
			//i=0为联系人页面
			
			var _self = this;
			var lengths = historyArr.length-1;
			if (lengths>0) {
				for(var i=0 ; i<lengths;i++){
					historyArr.pop();
				}
			}
			historyArr.push(obj)
			_self.$data.navList = historyArr;
			var deptList = _self.$data.deptList;
			_self.$data.selDept = [];
			if (leave2==-1) {
//				console.log(deptList[leave1].roomMembers.items)
				_self.memberList = deptList[leave1].roomMembers.items;
			}else{
//				console.log(deptList[leave1].items[leave2].roomMembers.items)
				_self.memberList = deptList[leave1].items[leave2].roomMembers.items;
			}
			//解决上拉太多点击后回不到顶部问题
			document.getElementById("sc").style.transform="translate3d(0px, 0px, 0px) translateZ(0px)";
			console.log(document.body.scrollTop || document.documentElement.scrollTop)
			console.log(111)
			if(c_scroll){
				setTimeout(function () {
//					mui('#select_project_scroll').scroll().refresh();
//					var w = document.getElementById("project_scroll").scrollWidth;
//					var s = c_scroll.wrapperWidth - w;
//					if(s<0){
//						mui('#select_project_scroll').scroll().scrollTo(s,0,100);
//					}
//					var _self = capp;
				},200)
			}
		}
	}
})
mui('#project_scroll').on('tap', '.mui-control-item', function(e) {
	var target = e.target;
	var teamId = target.getAttribute("data-team-id");
	if(undefined != teamId){
		var deptName = target.getAttribute("data-team-name");
		project.getProjectMembers(teamId,deptName);
	}else{
		viewApi.back('#select_member');
	}
});

//把自加进去
var init = function () {
//	selectInArr(true,userId);
	//绑定完成方法
	mui('#app__').on('tap', '.ok-btn', function(e) {
		var target = e.target;
		if(target.classList.contains("mui-disabled")){
			return;
		}else{
			//alert("共选择了：" + selectArr);
			document.getElementById("member_div1").style.display="none";
			document.getElementById("member_div2").style.display="block";

			document.getElementById("head_1").style.display="none";
			document.getElementById("head_2").style.display="block";

			viewApi.back();//关闭选择子部门div
		}
	});
}
init();
function initChildDept(teamId,deptId,deptName) {
	if(undefined == teamId){
		teamId = 0;
	}
	if(undefined == deptId){
		deptId = 0;
	}
	//清除原有选中
	//jQuery("#select_children").find('input[type="checkbox"]').removeAttr("checked").removeAttr("disabled");
	capp.$data.selDept = selectDept;
	app.$data.selDept = selectDept;
	var _self = capp;
	var par = {deptId:deptId,teamId:teamId};
	axios.post(getUrl()+"/concats_api/query_dept_list",par).then(function (response) {
		_self.$data.deptList = response.data.result;
		setTimeout(function () {
			$(".dept-select").each(function(){
				var id = $(this).val();
				if(selectDept.contains(id)){
					$(this).attr("checked","checked");
				}else{
					$(this).removeAttr("checked");
				}
			});
			mui('.dept-select').input();
		},200)
	}).catch(function (error) {
		console.info(error);
	});
	if(deptId!=0){
		par = {deptId:deptId};
	}else{
		par = {teamId:teamId};
	}
	axios.post(getUrl()+"/concats_api/query_team_members",par).then(function (response) {
		_self.$data.memberList = response.data.result;
	}).catch(function (error) {
		console.info(error);
	});
	if(c_scroll){
		setTimeout(function () {
			mui('#select_children_scroll').scroll().refresh();
			var w = document.getElementById("children_scroll").scrollWidth;
			var s = c_scroll.wrapperWidth - w;
			if(s<0){
				mui('#select_children_scroll').scroll().scrollTo(s,0,100);
			}
//			var _self = capp;
		},500)
	}


}

mui('#children_scroll').on('tap', '.mui-control-item', function(e) {
	var target = e.target;
	var teamId = target.getAttribute("data-team-id");
	var deptId = target.getAttribute("data-dept-id");
	if(undefined != teamId){
		var teamName = target.getAttribute("data-team-name");
		capp.selectTeam(teamId,teamName,e)
	}else if(undefined != deptId){
		var deptName = target.getAttribute("data-dept-name");
		capp.selectDept(deptId,deptName,e);
	}else{
		viewApi.back('#select_member');
	}
});

function convertData (friendArray) {
	if (friendArray && friendArray.length > 0) {

		var newArrs = new Array();
		for (var i = 0; i < 27; i++) {
			newArrs[i] = new Array();
		}
		for (var j = 0; j < friendArray.length; j++) {

			var f = friendArray[j].nameInitials.toUpperCase();
			var headerImage = !friendArray[j].avatar || friendArray[j].avatar == "" ? getUrl() + "/static/images/60x60.gif" : friendArray[j].avatar;
			var obj = {
				name: friendArray[j].remarksName,
				phone: friendArray[j].cellPhone,
				friendsUserId: friendArray[j].friendsUserId,
				headerImage: headerImage,
				imId: friendArray[j].imId
			};
			switch (f) {
				case 'A' :
					obj['first'] = 'A';
					if (newArrs[0].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[0][newArrs[0].length] = obj;
					break;
				case 'B' :
					obj['first'] = 'B';
					if (newArrs[1].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[1][newArrs[1].length] = obj;
					break;
				case 'C' :
					obj['first'] = 'C';
					if (newArrs[2].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[2][newArrs[2].length] = obj;
					break;
				case 'D' :
					obj['first'] = 'D';
					if (newArrs[3].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[3][newArrs[3].length] = obj;
					break;
				case 'E' :
					obj['first'] = 'E';
					if (newArrs[4].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[4][newArrs[4].length] = obj;
					break;
				case 'F' :
					obj['first'] = 'F';
					if (newArrs[5].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[5][newArrs[5].length] = obj;
					break;
				case 'G' :
					obj['first'] = 'G';
					if (newArrs[6].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[6][newArrs[6].length] = obj;
					break;
				case 'H' :
					obj['first'] = 'H';
					if (newArrs[7].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[7][newArrs[7].length] = obj;
					break;
				case 'I' :
					obj['first'] = 'I';
					if (newArrs[8].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[8][newArrs[8].length] = obj;
					break;
				case 'J' :
					obj['first'] = 'J';
					if (newArrs[9].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[9][newArrs[9].length] = obj;
					break;
				case 'K' :
					obj['first'] = 'K';
					if (newArrs[10].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[10][newArrs[10].length] = obj;
					break;
				case 'L' :
					obj['first'] = 'L';
					if (newArrs[11].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[11][newArrs[11].length] = obj;
					break;
				case 'M' :
					obj['first'] = 'M';
					if (newArrs[12].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[12][newArrs[12].length] = obj;
					break;
				case 'N' :
					obj['first'] = 'N';
					if (newArrs[13].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[13][newArrs[13].length] = obj;
					break;
				case 'O' :
					obj['first'] = 'O';
					if (newArrs[14].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[14][newArrs[14].length] = obj;
					break;
				case 'P' :
					obj['first'] = 'P';
					if (newArrs[15].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[15][newArrs[15].length] = obj;
					break;

				case 'Q' :
					obj['first'] = 'Q';
					if (newArrs[16].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[16][newArrs[16].length] = obj;
					break;
				case 'R' :
					obj['first'] = 'R';
					if (newArrs[17].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[17][newArrs[17].length] = obj;
					break;
				case 'S' :
					obj['first'] = 'S';
					if (newArrs[18].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[18][newArrs[18].length] = obj;
					break;
				case 'T' :
					obj['first'] = 'T';
					if (newArrs[19].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[19][newArrs[19].length] = obj;
					break;
				case 'U' :
					obj['first'] = 'U';
					if (newArrs[20].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[20][newArrs[20].length] = obj;
					break;
				case 'V' :
					obj['first'] = 'V';
					if (newArrs[21].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[21][newArrs[21].length] = obj;
					break;
				case 'W' :
					obj['first'] = 'W';
					if (newArrs[22].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[22][newArrs[22].length] = obj;
					break;
				case 'X' :
					obj['first'] = 'X';
					if (newArrs[23].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[23][newArrs[23].length] = obj;
					break;
				case 'Y' :
					obj['first'] = 'Y';
					if (newArrs[24].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[24][newArrs[24].length] = obj;
					break;
				case 'Z' :
					obj['first'] = 'Z';
					if (newArrs[25].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[25][newArrs[25].length] = obj;
					break;
				default:
					obj['first'] = '#';
					if (newArrs[26].length == 0) {
						obj['isp'] = 1;
					}
					newArrs[26][newArrs[26].length] = obj;

			}
		}
		return newArrs;
	} else {
		return []
	}
}
/**
 * Created by wyj on 2017/7/9.
 */
var uploadStatus = false
selDateEleId = "selectDate",
	opt = {"type": "date", "beginYear": 1975, "endYear": new Date().getFullYear()};
var add_issue = new Vue({
	el: "#add_issue",
	data: {
		oper:"",
		page_title:"",
		showBox:false,
		fm: {
			id:"",
			teamId:"",
			organizeName: "",
			gradeNames: "",
			certificateCode: "",
			issueTime: "",
			issueUnit: "",
			issueUrl: "",
			imgData:"",
			width:"",
			height:""
		},
		image_host: getUrl()
	},
	created: function () {
		var _self = this;
		var url_params = getParam(window.location.href);
		if(url_params.hasOwnProperty("id") ){
			//取id
			_self.getCert(url_params.id);
			_self.$data.oper = "保存";
			_self.$data.page_title = "修改资质";
		}else{
			_self.$data.page_title = "添加资质";
			_self.$data.oper = "添加";
			_self.$data.showBox = true;
		}
		_self.$data.fm.teamId = url_params.teamId;
	},
	methods: {
		/*初始化时间选择*/
		selectDate: function () {
			var o = this;
			var picker = new mui.DtPicker(opt);
			picker.show(function (rs) {
				/*
				 * rs.value 拼合后的 value
				 * rs.text 拼合后的 text
				 * rs.y 年，可以通过 rs.y.vaue 和 rs.y.text 获取值和文本
				 * rs.m 月，用法同年
				 * rs.d 日，用法同年
				 * rs.h 时，用法同年
				 * rs.i 分（minutes 的第二个字母），用法同年
				 */
				opt["value"] = rs.value; //控件同步
				o.fm.issueTime = rs.value;
				picker.dispose(); //释放资源
			})
		},
		getCert:function (id) {
			var _self = this;
			if(id){
				Base.load({url:getUrl() + "/app_team_rz/get_issue?issueId=" + id,dataType:"json"},function(response){
					if (response.code == 0) {
						_self.$data.fm = response.result.issue;
						_self.$data.fm.issueTime = formDate(_self.$data.fm.issueTime);
						_self.$data.image_host = response.result.image_host;
						_self.$data.showBox = true;
					}else{
						msg("获取资质信息失败！请稍后重试");
					}
				},function(error){
					console.info(error);
				})
			}
		}
		,deleteCert:function (id) {
			var _self = this;
			if(undefined == id){
				id = _self.$data.fm.id;
			}
			if(confirm("确认要删除此资质吗？")){
				axios.get(getUrl() + "/app_team_rz/remove_issue?issueId=" + id + "&teamId=" + _self.$data.fm.teamId).then(function (response) {
					if (response.data.code == 0) {
						msg("已成功删除此资质");
						setTimeout(function () {
							goToList();
						}, 1500)
					} else {
						msg(response.data.message);
					}
				}).catch(function (error) {
					console.info(error);
				});
			}
		}
	}
});
function formDate(value) {
	var date = new Date(value);
	Y = date.getFullYear(),
		m = date.getMonth() + 1,
		d = date.getDate(),
		H = date.getHours(),
		i = date.getMinutes(),
		s = date.getSeconds();
	if (m < 10) {
		m = '0' + m;
	}
	if (d < 10) {
		d = '0' + d;
	}
	if (H < 10) {
		H = '0' + H;
	}
	if (i < 10) {
		i = '0' + i;
	}
	if (s < 10) {
		s = '0' + s;
	}
	//<!-- 获取时间格式 2017-01-03 10:13:48 -->
	// var t = Y+'-'+m+'-'+d+' '+H+':'+i+':'+s;
	//<!-- 获取时间格式 2017-01-03 -->
	var t = Y + '-' + m + '-' + d;
	return t;
}
//获取照片
function getObjectURL(file) {
	var url = null;
	if (window.createObjectURL != undefined) { // basic
		url = window.createObjectURL(file);
	} else if (window.URL != undefined) { // mozilla(firefox)
		url = window.URL.createObjectURL(file);
	} else if (window.webkitURL != undefined) { // webkit or chrome
		url = window.webkitURL.createObjectURL(file);
	}
	return url;
}
/*上传资质照片时间*/
function selectCertImg (that) {
	try {
		var imgUrl = getObjectURL(document.getElementById("upfile").files[0]);
		lrz(that.files[0], {
			width: 800,
			height: 600
		}).then(function (rst) {
			uploadStatus = true;
			add_issue.$data.fm["imgData"] = rst.base64;
			add_issue.$data.fm["width"] = 800;
			add_issue.$data.fm["height"] = 600;
			var v = document.getElementById("img_view");
			v.src = rst.base64;
			v.style.display = "inline-block"
		})
	}catch (e){
		alert(e)
	}

}
function validator(data) {
	for (var o in data) {
		if (!checkParam(o, data)) {
			return false;
		}
	}
	if (!uploadStatus && add_issue.$data.fm.issueUrl == "") {
		msg("请上传证书照片");
		return false;
	}
	return true;
}
function checkParam(key, data) {
	var val = data[key]; //获取值
	if (undefined == val || val == "") {
		//没有值
		if(document.getElementsByName(key) && document.getElementsByName(key)[0]){
			var m = document.getElementsByName(key)[0].getAttribute("placeholder"); //获取提示信息
			if(m){
				msg(m);
				return false;
			}else{
				return true;
			}

		}else{
			return true;
		}
	} else {
		return true;
	}

}
/*资质提交上传*/
function submitCert() {
	if (validator(add_issue.$data.fm)) {
		//校验成功，异步提交数据
        loading("数据提交中，请稍等...");
		axios.post(getUrl() + "/app_team_rz/save_issue", add_issue.$data.fm).then(function (response) {
			if (response.data.code != 0) {
				msg(add_issue.$data.oper + "资质失败,请重试")
                layer.closeAll();
			} else {
				msg(add_issue.$data.oper + "成功！");
				setTimeout(function () {
					goToList();
                    layer.closeAll();
				}, 1000)
			}
		}).catch(function (error) {
			console.info(error);
            layer.closeAll();
		});

	}
}

function openAdd(){
	// location.href = getUrl() + "/static/webstatic/contacts/teamcert/add_team_issue.html?teamId=" + team_issues.$data.teamId;
	appApi.openNewWindow(getUrl() + "/static/webstatic/contacts/teamcert/add_team_issue.html?teamId=" + team_issues.$data.teamId,"资质管理")
}
function goToList(){
	appApi.broadcast("reLoad()"); //刷新页面
	appApi.closeNewWindow();
}
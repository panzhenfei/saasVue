/*---------------我的通讯录-----------------*/
//转换数据 wyj
function convertData (resultCon, resultPhone) {
    if (resultCon && resultCon != "") {

        //加载手机号码
        var phoneArray = resultCon.split(",");
        var newArrs = new Array();
        for (var i = 0; i < 27; i++) {
            newArrs[i] = new Array();
        }
        for (var j = 0; j < phoneArray.length; j++) {
            var personPhoneArray = phoneArray[j].split("=");
            var remarksName = personPhoneArray[0];
            var f = makePy(remarksName.charAt(0))[0].toUpperCase();
            var obj = {name: remarksName, phone: personPhoneArray[1]};
            if(resultPhone.indexOf(personPhoneArray[1])>-1){
                obj['is_add']=false;
            }else{
                obj['is_add']=true;
            }
            switch (f) {
                case 'A' :
                    obj['first'] = 'A';
                    if (newArrs[0].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[0][newArrs[0].length] = obj;

                    break;
                case 'B' :
                    obj['first'] = 'B';
                    if (newArrs[1].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[1][newArrs[1].length] = obj;
                    break;
                case 'C' :
                    obj['first'] = 'C';
                    if (newArrs[2].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[2][newArrs[2].length] = obj;
                    break;
                case 'D' :
                    obj['first'] = 'D';
                    if (newArrs[3].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[3][newArrs[3].length] = obj;
                    break;
                case 'E' :
                    obj['first'] = 'E';
                    if (newArrs[4].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[4][newArrs[4].length] = obj;
                    break;
                case 'F' :
                    obj['first'] = 'F';
                    if (newArrs[5].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[5][newArrs[5].length] = obj;
                    break;
                case 'G' :
                    obj['first'] = 'G';
                    if (newArrs[6].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[6][newArrs[6].length] = obj;
                    break;
                case 'H' :
                    obj['first'] = 'H';
                    if (newArrs[7].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[7][newArrs[7].length] = obj;
                    break;
                case 'I' :
                    obj['first'] = 'I';
                    if (newArrs[8].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[8][newArrs[8].length] = obj;
                    break;
                case 'J' :
                    obj['first'] = 'J';
                    if (newArrs[9].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[9][newArrs[9].length] = obj;
                    break;
                case 'K' :
                    obj['first'] = 'K';
                    if (newArrs[10].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[10][newArrs[10].length] = obj;
                    break;
                case 'L' :
                    obj['first'] = 'L';
                    if (newArrs[11].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[11][newArrs[11].length] = obj;
                    break;
                case 'M' :
                    obj['first'] = 'M';
                    if (newArrs[12].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[12][newArrs[12].length] = obj;
                    break;
                case 'N' :
                    obj['first'] = 'N';
                    if (newArrs[13].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[13][newArrs[13].length] = obj;
                    break;
                case 'O' :
                    obj['first'] = 'O';
                    if (newArrs[14].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[14][newArrs[14].length] = obj;
                    break;
                case 'P' :
                    obj['first'] = 'P';
                    if (newArrs[15].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[15][newArrs[15].length] = obj;
                    break;

                case 'Q' :
                    obj['first'] = 'Q';
                    if (newArrs[16].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[16][newArrs[16].length] = obj;
                    break;
                case 'R' :
                    obj['first'] = 'R';
                    if (newArrs[17].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[17][newArrs[17].length] = obj;
                    break;
                case 'S' :
                    obj['first'] = 'S';
                    if (newArrs[18].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[18][newArrs[18].length] = obj;
                    break;
                case 'T' :
                    obj['first'] = 'T';
                    if (newArrs[19].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[19][newArrs[19].length] = obj;
                    break;
                case 'U' :
                    obj['first'] = 'U';
                    if (newArrs[20].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[20][newArrs[20].length] = obj;
                    break;
                case 'V' :
                    obj['first'] = 'V';
                    if (newArrs[21].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[21][newArrs[21].length] = obj;
                    break;
                case 'W' :
                    obj['first'] = 'W';
                    if (newArrs[22].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[22][newArrs[22].length] = obj;
                    break;
                case 'X' :
                    obj['first'] = 'X';
                    if (newArrs[23].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[23][newArrs[23].length] = obj;
                    break;
                case 'Y' :
                    obj['first'] = 'Y';
                    if (newArrs[24].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[24][newArrs[24].length] = obj;
                    break;
                case 'Z' :
                    obj['first'] = 'Z';
                    if (newArrs[25].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[25][newArrs[25].length] = obj;
                    break;
                default:
                    obj['first'] = '#';
                    if (newArrs[26].length == 0) {
                        obj['isp'] = 1;
                    }
                    newArrs[26][newArrs[26].length] = obj;

            }
        }
        return newArrs;
    }else{
        return []
    }
}
var appPl = new Vue({
    el: "#phone_list",
    data: {
        phones: []
    },
    created: function () {
        window.appApi.getContacts();
    },
    methods: {
         addFriends: function (index1, index2) {
             var phoneMap = this.$data.phones[index1][index2];
             var addVo = {cellPhone: phoneMap.phone, receivedUserName: phoneMap.name};
             phoneMap.is_add= !(phoneMap.is_add);
             axios.post(getUrl() + "/concats_api/insert_add_info", addVo).then(function (response) {
                 var friendVO = response.data.result;
                 if(friendVO.isOwnOrFriend=="0"){
                     msg("不可添加自己为好友!");
                 }else if(friendVO.isOwnOrFriend=="1"){
                     msg("此用户已是你的好友!");
                 }else{
                     msg('好友请求发送成功！');
                     // window.location.href = "../contacts/address_list.html";
                 }

             }).catch(function (error) {
                 remin("好友请求发送失败，请联系管理员!", 2);
                 console.info(error);
             });
         },
        importPhones:function () {
            //loading("同步中...");
            window.appApi.getContacts()

        }
    },
    updated:function () {//DOM更新时，进行调用的方法
        document.getElementById("list").style.display = "block";
        mui.ready(function () {
            var header = document.querySelector('header.mui-bar');
            var list = document.getElementById('list');
            list.style.height = (document.body.offsetHeight - header.offsetHeight) + 'px';
            // alert(list.innerHTML);
            window.indexedList = new mui.IndexedList(list)
        });
    }
});


appApi.callBackFun = function (callFlag, CONTENT) {
    isLoginIm = true;
    if (callFlag == appApi.callBackFlag.CONTACTS) {
        //查询用户的好友
        var param = new FormData();
        param.append("userId", "");
        axios.post(getUrl()+"/concats_api/find_eg_list", param).then(function (response) {
            var resultArray = response.data.result;
            var resultStr = ",";
            for(var i in resultArray){
                resultStr = resultStr + resultArray[i].cellPhone + ",";
            }
            appPl.$data.phones = convertData(CONTENT.result, resultStr);
        }).catch(function (error) {
            console.info(error);
        });



    }
    /* if(callFlag == appApi.callBackFlag.HX_LOGIN){
     var result = CONTENT.result;
     if(result == true){
     if(window.appApi.saveUserInfo(JSON.stringify(resultJson),password)){
     // console.info('保存用户信息成功！');
     // warm('保存用户信息成功！');
     }else{
     // console.info('保存用户信息失败！');
     // warm('保存用户信息到本地失败！');
     }
     loading('登录成功！正在跳转到主页！');
     window.appApi.goHome();
     }else{
     layer.close(index);
     warm('登录失败，请重新登录!');
     }
     }*/
}
/*
function initMui() {
    document.getElementById("list").style.display = "block";
    mui.ready(function () {
        var header = document.querySelector('header.mui-bar');
        var list = document.getElementById('list');
        list.style.height = (document.body.offsetHeight - header.offsetHeight) + 'px';
        // alert(list.innerHTML);
        // window.indexedList = new mui.IndexedList(list)
        setTimeout(init_2, 4000);
    });
}
function init_2() {
    var list = document.getElementById('list');
    // alert(list.innerHTML);
    window.indexedList = new mui.IndexedList(list)

}*/

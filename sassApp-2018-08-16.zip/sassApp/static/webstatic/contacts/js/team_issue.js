/**
 * Created by wyj on 2017/7/9.
 */
var uploadStatus = false
selDateEleId = "selectDate",
	opt = {"type": "date", "beginYear": 1975, "endYear": new Date().getFullYear()};

var team_issues = new Vue({
	el: "#team_issues",
	data: {
		teamId:"",
		issue_list: [],
		image_host: getUrl()
	},
	created: function () {
		var _self = this;
		//获取参数
		var url_params = getParam(window.location.href);
		if(url_params.hasOwnProperty("teamId") ){
			_self.$data.teamId = url_params.teamId;
			axios.get(getUrl() + "/app_team_rz/get_issues?teamId=" + url_params.teamId).then(function (response) {
				if (response.data.code == 0) {
					var rs = response.data.result;
					_self.$data.issue_list = rs.issue_list;
					_self.$data.image_host = rs.image_host;
					setTimeout(function () {
						initImgPreview();
					},200)
				} else {
					msg(response.data.message);
				}

			}).catch(function (error) {
				console.info(error);
			});
		}
        appApi.imgPreview.init();
	},
	methods: {

	}
})
function openAdd(){
	appApi.openNewWindow(getUrl() + "/static/webstatic/contacts/teamcert/add_team_issue.html?teamId=" + team_issues.$data.teamId)
}

function reLoad() {
	window.history.go(0);
}

/*---------------团队成员(单个)---------------*/

var teamId;
var deptId;
var goUrl;
var webPath = getUrl()
var pagepath = getPagePath()
var paramMap = getParam(window.location.href);
var app = new Vue({
    el:"#member_create",
    data:{
        member_name:"",
        phone_number:"",
        position:"",
        bumen:''
    },
    created: function (){
    	this.bumenstar()
        var hrefPar = window.location.href.split('?')[1].split('=')[1];
        var type = hrefPar.split("&")[0];
        //var id = window.location.href.split('?')[1].split('=')[2];
        //alert(type+'--'+id);
        //type为0，团队主页进入  type 为1，部门进入
        if(type==0){
            teamId = window.location.href.split('?')[1].split('=')[2];
            goUrl = "../contacts/add_manually.html?type=0&teamId="+teamId;
        }
        if(type==1){
            teamId = window.location.href.split('?')[1].split('=')[2].split('&')[0];
            deptId = window.location.href.split('?')[1].split('=')[3];
            //goUrl = "../contacts/subdivision.html?teamId="+teamId+"&deptId="+deptId;
            goUrl = "../contacts/add_manually.html?type=1&teamId="+teamId+"&deptId="+deptId;
        }
    },
    methods:{
    	bumenstar:function(){
    		var _self=this
    		var par = {deptId:paramMap.deptId,teamId:paramMap.teamId};
   			axios.post(getUrl()+"/concats_api/query_team_dept",par).then(function (response) {
        		var newJson =response.data.result;
        		_self.bumen=newJson.deptName
        		console.log(_self.bumen)
       		})
    	},
        show_dept_select: function () {
            $("#select_dept").show();//显示部门选择
            appApi.hideBack();//隐藏返回键
            getSubDept(teamId,0);
        },
        save_dept: function(){
            var arrDept = $('input:radio[name="check1"]:checked').val();
            if(arrDept!=null && arrDept !=undefined){
                deptId = arrDept.split("=")[0];
                $("#dept_name_id").text(arrDept.split("=")[1]);
                $("#select_dept").hide();
            }
            //$("#select_dept").hide();
            appApi.showBack();
        },
        submit_data: function () {
            var memberName =  this.member_name;
            var phone =  this.phone_number;
            if(memberName=="" || phone==""){
                warm("姓名和手机号不能为空！");
                return ;
            }

            if(!checkphone(phone)){
                warm("手机号码格式不正确！");
                return ;
            }

            var param = {createType:"2",memberName:this.member_name,phoneNumber:this.phone_number,position:this.position,teamId:teamId,deptId:deptId};
            console.log(param);
            axios.post(getUrl()+"/concats_api/create_member", param).then(function (response) {
                console.log(response)
                var data=response.data;
                if(data.code==0){
                    msg("员工添加成功!");
                    setTimeout(function () {
                        appApi.broadcast("reLoad()"); //刷新页面
                        appApi.closeNewWindow();
                    },1000);
                }else if(data.code==201){//手机号未注册
                    msg("添加失败，该手机号未注册");
                    return
                }else if(data.code==203){
                    msg("添加失败，该员工已加入该团队");
                    return
                }
                else {
                    msg("添加失败，系统异常")
                    return
                }

             }).catch(function(error){
                console.log('创建成员失败-'+error);
             });

        }

    }
});

//校验手机号
function checkphone(phone){
    var pattern = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/;
    var flag = pattern.test(phone);
    return flag;
}
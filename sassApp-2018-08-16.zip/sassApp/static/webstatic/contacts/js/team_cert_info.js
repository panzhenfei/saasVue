
var paramMap = getParam(window.location.href);
var certification = new Vue({
    el:"#cert_content",
    data:{
        isShow:false,
        team:{},
        item:{
            teamId:paramMap.teamId,
            teamName:'',
            trustCode:'',
            artificialPerson:'',
            artificialCode:'',
            trustImageUrl:'',
            trustType:''
        }
    },
    created:function () {
        //获取参数
        //获取团队信息
	    var _self = this;
	    axios.post(getUrl()+"/concats_api/find_team_info?teamId="+paramMap.teamId).then(function (response) {
		    _self.$data.team = response.data.result;
	    }).catch(function (error) {
		    console.info(error);
	    });
        //查询认证信息
        axios.post(getUrl()+"/app_team_rz/getcertinfo?teamId="+paramMap.teamId).then(function (response) {
            var info =  response.data.result;
            if(info != null && info.id != null) {
                _self.$data.item = info;
            }
            _self.$data.isShow = true;
        }).catch(function (error) {
            console.info(error);
        });
    },
    methods:{
	    saveCheck :function() {
	        var _self = this;
		    if(!document.querySelector('[name="trustType"]:checked')){
			    msg("请选择证件类型")
			    return false;
		    }
		    if(_self.$data.item.trustImageUrl == ""){
			    msg("请上传相关证件照片");
			    return false;
            }
		    if(_self.$data.item.teamName == ""){
			    msg("请填写企业或者单位组织名称")
			    return false;
		    }
		    if(_self.$data.item.trustCode == ""){
			    msg("请填写统一信用代码");
			    return false;
		    }
		    if(_self.$data.team.teamType == "1"){
			    //企业认证需要法人
			    if(_self.$data.item.artificialPerson == ""){
				    msg("请填写法定代表人姓名");
				    return false;
			    }
			    if(_self.$data.item.artificialCode == ""){
				    msg("请填写法定代表人身份证号");
				    return false;
			    }
			    if(_self.$data.item.artificialCode.length != 18){
				    msg("法定代表人身份证号填写有误");
				    return false;
			    }
		    }
		    return true
	    }
    }
})
function savaCertInfo() {
    if(certification.saveCheck()){
	    axios.post(getUrl()+"/app_team_rz/savecertinfo", certification.$data.item).then(function (response) {
		    console.info(response);
		    if (response.data.code == 0) {
			    msg("保存成功");
			    setTimeout(function () {
				    goToIndex();
				    //location.href = getPagePath() + "/contacts/group_manage.html?teamId="+certification.$data.item.teamId;
			    }, 1500)
		    } else {
			    msg("上传证件失败,请重试")
		    }
	    }).catch(function (error) {
		    console.info(error);
	    });
    }
}
function selectCertImg (that) {
    try {
        lrz(that.files[0], {
            width: 800,
            height: 600
        }).then(function (rst) {
            uploadStatus = true;
            certification.$data.item["imgData"] = rst.base64;
            certification.$data.item["width"] = 800;
            certification.$data.item["height"] = 600;
            certification.$data.item.trustImageUrl = rst.base64;
        })
    }catch (e){
        alert(e)
    }

}

function goToIndex(){
	appApi.broadcast("reLoad()"); //刷新页面
	appApi.closeNewWindow();
}

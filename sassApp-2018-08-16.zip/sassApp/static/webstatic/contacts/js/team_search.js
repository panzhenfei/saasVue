//下拉刷新
window.appApi.setPullRefresh(true);
var sellerInfo = new Vue({
    el:"#team_search",
    data:{
        searchStr:"",//用来搜索的字符串
        teamId:"",//团队信息表id
        teamName:"",//团队名称
        applyState:"",//申请状态
        isNull:false,
        items:{},
    },
    created:function(){
    },
    methods:{
        //申请加入
        apply: function (teamId) {
            $.ajax({
                type: "post",
                url: getUrl() + "/project_team_info/send_add_team_News",
                data: {
                    "teamId":teamId,
                },
                datatype: "json",
                success: function(data) {
                    console.log(data)
                    if(data.code==200||data.code==0){
                        mui.toast("申请成功！")
                    }else if(data.code==201){
                        mui.toast(data.message)
                    }

                },
                error:function(){
                    mui.toast("申请失败！")
                }
            });
        },
    }
})

function onSearch(){
    $.ajax({
        type: "post",
        url: getUrl() + "/project_team_info/search_list",
        data: {
            "teamName": document.getElementById("searchStr").value,
        },
        datatype: "json",
        success: function(data) {
            console.log(data)
            if(data.code==200||data.code==0){
                var result = data.result;
                if(result==null||result.length<=0){
                    sellerInfo.isNull = false;
                }else{
                    sellerInfo.isNull = true;
                    sellerInfo.items = result;
                    console.log(sellerInfo.items)
                }
            }
            console.log(sellerInfo.isNull)
        },
        error:function(){
            mui.toast("获取数据失败")
        }
    });
}
/*---------------联系人首页-----------------*/
var app = new Vue({
	el: "#team_list",
	data: {
		items: [],
		projects: [],
		//userInfo:window.appApi.getUserInfo()
		userInfo: {}
	},
	created: function() {
		var _self = this;
		//      appApi.hideBack()
		//延迟0.5秒，兼容IOS
		setTimeout(function() {
			if(isApp && isIphoneOs) { //IOS
				window.appApi.getUserInfo();
			} else if(isApp && isAndroid) {
				var userInfoAndroid = window.appApi.getUserInfo();
				_self.$data.userInfo = JSON.parse(userInfoAndroid)
				//alert(_self.$data.userInfo.userId);
			} else {
				console.info("设备不支持");
			}
		}, 30)
		axios.post(getUrl() + "/concats_api/find_team_list", {}).then(function(response) {
			console.log("数据", response.data.result)
			_self.$data.items = response.data.result;
		}).catch(function(error) {
			console.info(error);
		});

		axios.post(getUrl() + "/chart/column/table_swprojectinfo?used=getPro", {}).then(function(response) {
			console.log("数据", response.data.result)
			_self.$data.projects = response.data.result;
		}).catch(function(error) {
			console.info(error);
		});

		//      //延迟0.5秒，兼容IOS
		//      setTimeout(function(){
		//          if (isApp && isIphoneOs) {//IOS
		//              window.appApi.getUserInfo();
		//          } else if (isApp && isAndroid) {
		//              var userInfoAndroid = window.appApi.getUserInfo();
		//              _self.$data.userInfo = JSON.parse(userInfoAndroid)
		//              //alert(_self.$data.userInfo.userId);
		//          } else {
		//          	alert("设备不支持")
		//              console.info("设备不支持");
		//          }
		//      },10)
	},
	methods: {

		openUrl: function(item, type) {
			appApi.openNewWindow(getUrl() + '/static/webstatic/contacts/group_manage.html?teamId=' + item.teamId + '&code=' + item.identifyNo, "团队管理")
		},

		clickshow: function() {
			// alert($(this).className);
			return true;
		},
		doShare: function() {
			var _self = this;
			//alert(_self.$data.userInfo.userId);
			//JSON.parse( _self.$data.userInfo)
			//var obj = eval('(' + _self.$data.userInfo + ')');
			//var userId=_self.$data.userInfo.userId;
			var userId = _self.$data.userInfo.userId;
			//alert("--1!-"+userId);

			var url = getUrl() + "/static/webstatic/register/share_reg.html?type=1&invUser=" + userId;
			var logo = getUrl() + "/static/images/app-logo.jpg";
			appApi.share(-1, "您有一条好友申请", "点击我进入注册吧", url, logo, null);
		}
	}

});

window.appApi.callBackFun = function(callFlag, CONTENT) {
	if(callFlag == appApi.callBackFlag.USER_INFO) {
		app.userInfo = JSON.parse(CONTENT); //转换成json对象
	}
}
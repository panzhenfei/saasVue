/*---------------成员编辑-----------------*/

var app = new Vue({

    el:"#memberVO",
    data:{
        none:{
            deptId:0
        }
    },
    created: function () {
        var _self = this;
        var memberId = window.location.href.split("?")[1].split("=")[1];
        //var param = {memberId:memberId};
        axios.get(getUrl()+"/concats_api/query_member?memberId="+memberId).then(function (response) {
            _self.$data.none = response.data.result;
            console.info(response.data.result);
            //this.date.memberName =
            // console.log(this);
            // console.log(this.memberName);
        }).catch(function (error) {
            console.info(error);
        });
    },
    methods:{
        delete_member: function () {
            //layer.confirm("确认删除吗?");
            var teamIdB = this.none.teamId;
            if(this.none.memberType=="1"){
                layer.open({
                    content: '管理员不能删除!'
                    ,skin: 'msg'
                    ,time: 1 //2秒后自动关闭
                    ,anim:false
                });
                return;
            }else {
                layer.open({
                    content: '确认删除吗?',
                    icon: 1
                    ,btn: ['确认', '取消']
                    ,yes: function(index, layero){
                        layer.closeAll();
                        var memberId = window.location.href.split("?")[1].split("=")[1];
                        axios.post(getUrl()+"/concats_api/delete_member_batch",{memberIds:memberId}).then(function (response) {
                            console.info(response);
                            msg("删除成功")
                            setTimeout(function () {
                                appApi.broadcast("reLoad()"); //刷新页面
                                appApi.closeNewWindow();
                            },2000)

                            //loading('创建成员成功！正在跳转！');
                            //console.info(getUrl()+"/contacts/group_address_m.html?teamId="+teamIdB);
                          //  window.location.href="../contacts/group_address_m.html?teamId="+teamIdB;
                        }).catch(function(error){
                            console.log('删除成员失败-'+error);
                        });
                    }
                });
            }
            /*
            var teamIdB = this.none.teamId
            var memberId = window.location.href.split("?")[1].split("=")[1];
            axios.post(getUrl()+"/concats_api/delete_member?memberIds="+memberId).then(function (response) {
                console.info(response);
                //loading('创建成员成功！正在跳转！');
                //console.info(getUrl()+"/contacts/group_address_m.html?teamId="+teamIdB);
                window.location.href="../contacts/group_address_m.html?teamId="+teamIdB;
            }).catch(function(error){
                console.log('删除成员失败-'+error);
            });*/
        },
        save_member: function () {
            var teamId = this.none.teamId;
            var deptId = this.none.deptId;
            var memberId = window.location.href.split("?")[1].split("=")[1];
            var param = {memberType:this.none.memberType,memberId:memberId,teamId:this.none.teamId,deptId:deptId,userId:this.none.userId,memberName:this.none.memberName,phoneNumber:this.none.phoneNumber,position:this.none.position,createDate:this.none.createDate};
            //param.projectTeamMemberVOList=members;
            console.log(param);
            axios.post(getUrl()+"/concats_api/update_member", param).then(function (response) {
                console.info(response);
                //loading('创建成员成功！正在跳转！');
                window.location.href="../contacts/group_address_m.html?teamId="+teamId;
            }).catch(function(error){
                console.log('修改成员失败-'+error);
            });
        },
        show_depts: function () {//选择部门
            $("#select_dept").show();
            appApi.hideBack();//隐藏返回键
            getSubDept(this.none.teamId,0);
        },
        save_dept: function () {//选择部门
            $("#select_dept").hide();
            appApi.showBack();//显示返回键
            var arrDept = $('input:radio[name="check1"]:checked').val();
            if(arrDept!=null && arrDept!=undefined){
                var dept_arr = arrDept.split("=");
                this.none.deptId=dept_arr[0];
                this.none.deptName=dept_arr[1];
                $("#deptName_id").text(this.none.deptName);
            }
        },
        getSubDept: function (parentDeptId) {//查询下级部门列表
            var hrefPar = window.location.href.split('?')[1].split('=')[1];
            var teamId = this.none.teamId;
            var deptInId = 0;
            var par = {deptId:parentDeptId,teamId:teamId,parentDeptId:deptInId};
            console.info(par);
            axios.post(getUrl()+"/concats_api/query_dept_list",par).then(function (response) {
                var newJson =response.data.result;
                console.info(newJson);
                var deptHtml = '<ul class="mui-table-view group-list">';
                for(var j=0;j<newJson.length;j++){
                    var arrJ = newJson[j];
                    var deptId = arrJ.deptId;
                    var deptName = arrJ.deptName;
                    deptHtml+='<li class="mui-table-view-cell mui-checkbox">'+
                        '<div class="oa-contact-cell mui-table" onclick="app.save_dept()">'+
                        '<div class="oa-contact-input mui-table-cell"><input type="checkbox" name="checkbox1" value="'+deptId+'='+deptName+'"/></div>'+
                        '<div class="oa-contact-content mui-table-cell">'+
                        '<h4 class="oa-contact-name">'+deptName+'</h4>'+
                        '</div>'+
                        '</div>'+
                        '<div class="sub-btn" onclick="app.getSubDept('+deptId+')"><span class="mui-icon iconfont icon-sub"></span>下级</div>'+
                        '</li>';
                }
                deptHtml=deptHtml+'</ul>';
                document.getElementById("deptHtml").innerHTML=deptHtml;
            }).catch(function (error) {
                alert("获取部门信息失败,请联系管理员!");
                console.info(error);
            });
        }
    }
});

/*---------------新的好友-----------------*/

var appNf = new Vue({
    el:"#new_friends",
    data:{
        items:[]
    },
    created: function () {
        var _self = this;
        axios.post(getUrl()+"/concats_api/find_new_friends").then(function (response) {
             _self.$data.items = response.data.result;
             console.info(response.data.result);
         }).catch(function (error) {
            console.info(error);
         });

    },
    methods:{
        agreeFriends: function (addId,addUserId,cellPhone,userName) {
            //alert(addId+'--'+'--'+addUserId+'----'+cellPhone+'-----'+userName);
            var addVo = {addId:addId,addUserId:addUserId,cellPhone:cellPhone,userName:userName};
            console.info(addVo);
            axios.post(getUrl()+"/concats_api/insert_friend_info",addVo).then(function (response) {
                loading('好友添加成功！');
                window.location.href="../contacts/address_list.html";
            }).catch(function (error) {
                console.info(error);
            });
        }
    },
    filters: {
        getImageUrl: function (val) {
            if(val==null || val=="") return getUrl()+"/static/images/60x60.gif";
            return val;
        }
    }
});
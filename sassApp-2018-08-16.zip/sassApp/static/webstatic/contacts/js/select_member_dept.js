/*---------------选择成员-----------------*/
Array.prototype.contains = function (obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
}
Array.prototype.remove = function(val) {
    var index = this.indexOf(val);
    if(index > -1) {
        this.splice(index, 1);
    }
};
function selectInArr(bool,val) {
    val = val + "";
    if(bool){
        if(!selectArr.contains(val)){
            selectArr.push(val);
        }
    }else{
        if(userId != val){ //自己不能删除
            //selectArr.remove(val);
        }
        selectArr.remove(val);//删除
    }
    var count = selectArr.length;
    var text = count ? "完成(" + count + ")" : "完成";
    var btn = jQuery(".ok-btn");
    btn.text(text);
    if (count) {
        if (btn.hasClass("mui-disabled")) {
            btn.removeClass("mui-disabled");
        }
    } else {
        if (!btn.hasClass("mui-disabled")) {
            btn.addClass("mui-disabled");
        }
    }
    app.$data.selArr = selectArr;
    capp.$data.selArr = selectArr;
}

function selEvent(target) {
    var type = target.getAttribute("data-type");
    var value = target.value;
    if(type == "user"){
        selectInArr(target.checked,value);

        //alert(selectArr.length+'----'+selectDept.length);
        capp.show_r = "已选择: "+selectArr.length+"个人，"+selectDept.length+"个部门";
        if(selectArr.length >0 || selectDept.length>0){
            //选择了人或者部门
            capp.button_class = "mui-btn mui-btn-nav mui-btn-primary mui-pull-right";
        }else{
            capp.button_class = "mui-btn mui-btn-nav mui-btn-primary mui-pull-right mui-disabled";
        }
    }else{
        //选中，灰色掉下级按钮 add at 2017.9.1
        var subDeptId="#sub_dept_"+value;
        if(target.checked){
            $(subDeptId).attr("class","sub-btn disabled");
        }else{
            $(subDeptId).attr("class","sub-btn");
        }


        var par = {deptId:value};
        axios.post(getUrl()+"/concats_api/query_team_members",par).then(function (response) {
            var memberList = response.data.result;
            for(var i= 0;i<memberList.length;i++){
                //selectInArr(target.checked,memberList[i].userId);//2017.9.1，注释，不需要选中人员，选中部门即可
            }
            //alert(selectArr.length+'----'+selectDept.length);
            capp.show_r = "已选择: "+selectArr.length+"个人，"+selectDept.length+"个部门";
            if(selectArr.length >0 || selectDept.length>0){
                //选择了人或者部门
                capp.button_class = "mui-btn mui-btn-nav mui-btn-primary mui-pull-right";
            }else{
                capp.button_class = "mui-btn mui-btn-nav mui-btn-primary mui-pull-right mui-disabled";
            }
        }).catch(function (error) {
            console.info(error);
        });
        if(target.checked){
            if(!selectDept.contains(value)){
                selectDept.push(value);
            }
        }else{
            selectDept.remove(value);
        }
        capp.$data.selDept = selectDept;
        app.$data.selDept = selectDept;
    }
}

var capp = new Vue({
    el:"#select_children",
    data:{
        deptList:[],
        memberList:[],
        navList:[],
        selArr:[],
        myId:userId,
        selDept:[],
        show_r:"已选择: 0个人，0个部门",
        button_class:"mui-btn mui-btn-nav mui-btn-primary mui-pull-right mui-disabled",
        setType:"" //设置类型:0替换负责人，1共享给同事
    },
    created: function () {

    },
    methods:{
        clickshow: function () {
            return true;
        },
        selectDept:function (deptId,deptName,event) {
            var isChecked = false;
            for(var j=0;j<selectDept.length;j++){
                if(deptId==selectDept[j]){
                    isChecked = true;
                }
            }
            if(isChecked){
                return;
            }

            var obj = {teamId:undefined,deptId:deptId,deptName:deptName};
            //i=0为联系人页面
            var flag = false;
            var nArr = new Array();
            for(var i=0;i<historyArr.length;i++){
                nArr.push(historyArr[i]);
                if(undefined != deptId && deptId == historyArr[i].deptId){
                    flag = true;
                    break;
                }

            }
            if(!flag){
                nArr.push(obj);
            }
            historyArr = nArr;
            var _self = this;
            _self.$data.navList = historyArr;
            initChildDept(undefined,deptId,deptName);
            event.preventDefault();
            event.stopPropagation();
        },
        selectTeam:function (teamId,teamName,event) {
            var obj = {teamId:undefined,teamName:teamName,deptId:undefined,deptName:undefined};
            //i=0为联系人页面
            var flag = false;
            var nArr = new Array();
            for(var i=0;i<historyArr.length;i++){
                nArr.push(historyArr[i]);
                if(undefined != teamId && teamId == historyArr[i].teamId){
                    flag = true;
                    break;
                }
            }
            if(!flag){
                nArr.push(obj);
            }
            historyArr = nArr;
            var _self = this;
            _self.$data.navList = historyArr;
            initChildDept(teamId,undefined,undefined);
            event.preventDefault();
            event.stopPropagation();
        },
        updated:function () {//DOM更新时，进行调用的方法
            document.getElementById("list").style.display = "block";
            mui.ready(function () {
                window.indexedList = new mui.IndexedList(list)
            });
        }
    }
});
//把自加进去
var init = function () {
    selectInArr(true,userId);
    //绑定完成方法
    mui('#app').on('tap', '.ok-btn', function(e) {
        var target = e.target;
        if(target.classList.contains("mui-disabled")){
            return;
        }else{
            alert("共选择了：" + selectArr);
            //viewApi.back();
            // myback();
        }
    });
}
//init();
function initChildDept(teamId,deptId,deptName,setType) {
    // 设置类型,控制是否有复选按钮 2017.9.1
    if(setType=='0'){
        capp.setType = '0';
    }else if(setType=='1'){
        capp.setType = '1';
    }
    //如果存在ID为backdrop的DIV，执行hideSetDiv（外部联系人查看权限页面用到）2017.9.1
    if(document.getElementById("backdrop")!=null && document.getElementById("backdrop")!=undefined){
        hideSetDiv();
    }

    if(undefined == teamId){
        teamId = 0;
    }
    if(undefined == deptId){
        deptId = 0;
    }
    //清除原有选中
    //jQuery("#select_children").find('input[type="checkbox"]').removeAttr("checked").removeAttr("disabled");
    capp.$data.selDept = selectDept;
    app.$data.selDept = selectDept;
    var _self = capp;
    var par = {deptId:deptId,teamId:teamId};
    axios.post(getUrl()+"/concats_api/query_dept_list",par).then(function (response) {
        _self.$data.deptList = response.data.result;
        setTimeout(function () {
            $(".dept-select").each(function(){
                var id = $(this).val();

                var subDeptId = "#sub_dept_"+id;
                if(selectDept.contains(id)){//alert(selectDept+'~~~~'+id+'===='+ $(this).attr("value"));
                    $(subDeptId).attr("class","sub-btn disabled");
                    //$(this).attr("checked","checked");
                    $(this).prop("checked",true);
                }else{
                    $(subDeptId).attr("class","sub-btn");
                    $(this).removeAttr("checked");
                }
            });
            mui('.dept-select').input();
        },200)
    }).catch(function (error) {
        console.info(error);
    });
    if(deptId!=0){
        par = {deptId:deptId};
    }else{
        par = {teamId:teamId};
    }
    axios.post(getUrl()+"/concats_api/query_team_members",par).then(function (response) {
        _self.$data.memberList = response.data.result;
    }).catch(function (error) {
        console.info(error);
    });
    if(c_scroll){
        setTimeout(function () {
            mui('#select_children_scroll').scroll().refresh();
            var w = document.getElementById("children_scroll").scrollWidth;
            var s = c_scroll.wrapperWidth - w;
            if(s<0){
                mui('#select_children_scroll').scroll().scrollTo(s,0,100);
            }
            var _self = capp;
            mui('#children_scroll').on('tap', '.mui-control-item', function(e) {
                var target = e.target;
                var teamId = target.getAttribute("data-team-id");
                var deptId = target.getAttribute("data-dept-id");
                if(undefined != teamId){
                    var teamName = target.getAttribute("data-team-name");
                    _self.selectTeam(teamId,teamName,e)
                }else if(undefined != deptId){
                    var deptName = target.getAttribute("data-dept-name");
                    _self.selectDept(deptId,deptName,e);
                }else{
                    viewApi.back('#select_member');
                }
            });
        },500)
    }
}

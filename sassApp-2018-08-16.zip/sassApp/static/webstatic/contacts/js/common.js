function openWindow(url) {
	window.appApi.openNewWindow(url);
}
function isNull(str){
	if (str==null||str==undefined||str.trim().length<=0) {
		return true;
	}
	return false;
}

function getUrl_ls(){
	return "http://192.168.0.218:8080";
}

function closeWindow(callBack) {
	if (callBack.length>0) {
		window.appApi.broadcast(callBack); //刷新页面
	}
	window.appApi.closeNewWindow();
}

function refreshPage(){
	window.location.reload() 
}

Array.prototype.indexOf = function(val) {
	for (var i = 0; i < this.length; i++) {
		if (this[i] == val) return i;
	}
	return -1;
}

Array.prototype.remove = function(val) {
	var index = this.indexOf(val);
	if (index > -1) {
		this.splice(index, 1);
	}
}
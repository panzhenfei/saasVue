var userId = 0;
var addClickNum =0;
var nowUserId = getCookie("userid");//当前登录人id
var app = new Vue({
    el:"#eg_details",
    data:{
        teamList:[],
        select_tag:false,
        tags:[],
        items:{},
        is_register:0,  //是否注册 0 未注册  1 已注册
        btnText:"",//,//按钮的内容
        //userInfo : window.appApi.getUserInfo()
        userInfo:{},
        isNotMe:true
    },
    created: function () {

        var paramMap = getParam(window.location.href);
        userId = paramMap.userId==undefined ? "" : paramMap.userId;
        var phone = paramMap.phone==undefined ? "" : paramMap.phone;
        var name = paramMap.name==undefined ? "" : paramMap.name;

        var param = new FormData();
        param.append("userId", userId);
        param.append("cellPhone", phone);
        var _self = this;
        _self.$data.isNotMe = (userId!=nowUserId);
        axios.post(getUrl()+"/concats_api/query_contacts_info", param).then(function (response){
            var resp = response.data;
            console.info("res",resp);
            if(resp.code == 0){
                _self.$data.tags = resp.result.tags;//用户标签list
                _self.$data.teamList = resp.result.teamList;//相关企业列表
                var array = resp.result.contactsInfoVO;//用户基础信息
                if(!array.userId){
                    array['nickName']=name;
                    array['cellPhone']=phone;
                    _self.$data.btnText="短信邀请";
                }else{
                    _self.$data.is_register=1;
                    _self.$data.btnText="加为好友";
                    if(array.userId==array.loginUserId){
                        array['isFriend']=2;
                    }
                }
                _self.$data.items = array;
                document.getElementById("eg_details").style.display = "block";

            }else{
                remin(resp.message, 2);
            }
            //_self.$data.userInfo=window.appApi.getUserInfo();

        }).catch(function (error) {
            console.info(error);
        });

        /*axios.post(getUrl()+"/work_api/queryTag").then(function (response){
            var resp = response.data.result;
            console.info(resp);
            _self.$data.tags = resp.data;

        }).catch(function (error) {
            console.info(error);
        });*/

        setTimeout(function(){
            //_self.$data.userInfo = window.appApi.getUserInfo();
            if (isApp && isIphoneOs) {//IOS
                window.appApi.getUserInfo();
            } else if (isApp && isAndroid) {
                var userInfoAndroid = window.appApi.getUserInfo();
                _self.$data.userInfo = JSON.parse(userInfoAndroid)
                //alert(_self.$data.userInfo.userId);
            } else {
                console.info("设备不支持");
            }
        },500)
        appApi.imgPreview.init();
    },
    methods:{
        deleteFriend: function () {
            mui('.mui-popover').popover('toggle',document.getElementById("popover-more"));//隐藏右上角菜单
            layer.open({
                content: '确定要删除好友关系麽？',
                icon: 1
                ,btn: ['确认', '取消']
                ,yes: function(index, layero){
                    var param = {deleteType:"1",friendsUserId:userId};
                    axios.post(getUrl()+"/concats_api/delete_friend",param).then(function (response){
                        remin("好友删除成功!",2);
                        window.appApi.closeNewWindow();
                        appApi.broadcast("reload();"); //刷新页面
                    }).catch(function (error) {
                        remin("好友删除失败,请联系管理员!",2);
                    });
                }
            });
        },
        addFriends: function () {
            if(addClickNum++ > 0) return;
            var _self = this;
            var addVo = {cellPhone: this.items.cellPhone, receivedUserName: this.items.nickName};
            axios.post(getUrl() + "/concats_api/insert_add_info", addVo).then(function (response) {
                if(response.data.code==0) {
                    var friendVO = response.data.result;
                    if (friendVO.isOwnOrFriend == "0") {
                        msg("不可添加自己为好友!");
                    } else if (friendVO.isOwnOrFriend == "1") {
                        msg("此用户已是你的好友!");
                    } else {
                        _self.$data.btnText = _self.$data.is_register == 0 ? "邀请短信已发送" : "好友请求已发送";
                    }
                }else{
                    msg(response.data.message);
                }

            }).catch(function (error) {
                remin("好友请求发送失败，请联系管理员!", 2);
                console.info(error);
            });
        },
        doShare:function () {
            var _self = this;
            var userId = _self.$data.userInfo.userId;
            var url = getUrl() + "/static/webstatic/register/share_reg.html?type=1&invUser=" + userId;
            var logo = getUrl() + "/static/images/app-logo.jpg";
            appApi.share(0,"您有一条好友申请","点击我进入注册吧",url,logo,null);
        },
        //打开个人主页跳转(一个标签直接跳转，多个标签时，)
        openIndexPersonal: function(){
            if(this.tags.length>1){
                this.select_tag=true;
                appApi.hideBack();
            }else{
                //只有一个或者没有职业标签
                var tag = this.tags[0];
                if(tag!=null || tag!=undefined){
                    var zhiyetagname = tag.zhiyetagname;
                    var zhiyetagid = tag.zhiyetagid;
                    window.location.href="../work/work_home.html?type=0&zhiyetagname="+zhiyetagname+"&zhiyetagid="+zhiyetagid;
                }else{
                    remin("该用户未注册或未配置职业标签，无法跳转到个人主页!", 2);
                }

            }
        },
        selectTagOpenIndex:function () {
            //this.select_tag=false;
            var tagNI = $('input:radio[name="radio1"]:checked').val();
            var tag = tagNI.split("!=");
            var zhiyetagname = tag[1];
            var zhiyetagid = tag[0];
            window.location.href="../work/work_home.html?type=0&zhiyetagname="+zhiyetagname+"&zhiyetagid="+zhiyetagid;
        }
    },
    filters: {
        getImageUrl: function (val) {
            if(val==null || val=="") return getUrl()+"/static/images/60x60.gif";
            return val;
        }
    }
});

function chat() {
    var imId = app.items.imId;
    /*if (isApp && isIphoneOs) {//IOS
    } else if (isApp && isAndroid) {
        window.webactivity.openChat(imId,app.items.userAvatar,app.items.nickName,1);
    }*/
    appApi.openChat(imId,app.items.userAvatar,app.items.nickName,1);
}



window.appApi.callBackFun = function(callFlag, CONTENT) {
    if(callFlag == appApi.callBackFlag.USER_INFO) {
        app.userInfo = JSON.parse(CONTENT);
    }
}
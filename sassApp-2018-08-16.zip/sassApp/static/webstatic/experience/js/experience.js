var experienceJson = {
	"企业高管": {
		username: "18000000001",
		pwd: "a"

	},
	"项目经理": {
		username: "18000000002",
		pwd: "a"

	},
	"工程部负责人": {
		username: "18000000003",
		pwd: "a"

	},
	"采购部负责人": {
		username: "18000000004",
		pwd: "a"

	},
	"财务部负责人": {
		username: "18000000005",
		pwd: "a"

	},
	"财务部人员": {
		username: "18000000006",
		pwd: "a"

	},
	"采购部人员": {
		username: "18000000007",
		pwd: "a"

	},
	"工程部人员": {
		username: "18000000008",
		pwd: "a"

	},
	"项目部人员": {
		username: "18000000009",
		pwd: "a"

	},
	"工长": {
		username: "18000000012",
		pwd: "a"

	},
	"工人": {
		username: "18000000013",
		pwd: "a"

	},
	"业主负责人": {
		username: "18000000011",
		pwd: "a"

	}
}

function init() {
	var aLi = document.getElementsByTagName("li");
	for(var i = 0; i < aLi.length; i++) {

		aLi[i].addEventListener("click", function() {
			var pNode = this.getElementsByTagName("p")[0];
			//alert(pNode.innerHTML);

			if(experienceJson[pNode.innerHTML] != undefined && experienceJson[pNode.innerHTML] != null) {
				var username = experienceJson[pNode.innerHTML].username;
				var pwd = experienceJson[pNode.innerHTML].pwd;

				var certCodeNode = document.getElementById("certCode");
				var pwdNode = document.getElementById("pwd");
				var loginBtu = document.getElementById("loginBtu");
				certCodeNode.value = username;
				pwdNode.value = pwd;
				loginBtu.click();
			} else {
				alert("暂未开放,尽请期待")
			}
			//alert(experienceJson[pNode.innerHTML].c)

		})
	}
}
init();